"""
egg_juicer_registration.py
---------------------------
Authority: Runtime extension layer.
Schema:    MB-ENGINE-REGISTRATION-1.1

Purpose:
    Canonical registration helper for the egg_juicer engine.
    Now uses engine_contract.register_engine() — enforces:

        1. Context-capture drift prevention:
           context_fingerprint seals repo_root at registration time.
           Re-registration with different repo_root raises
           EngineRegistrationConflict immediately.

        2. Executor contract enforcement:
           ContractEnforcingWrapper normalizes EngineResult → dict,
           surfaces exceptions as structured errors (no silent swallow),
           enforces NO_SILENT_FAIL and RETURN_DICT invariants at call time.

Usage:
    from egg_juicer_registration import build_egg_juicer_engine_map
    from kernel_context import build_kernel_context

    ctx = build_kernel_context(
        data_root=data_root,
        engine_map=build_egg_juicer_engine_map(repo_root="/path/to/repo"),
    )

Governance:
    Engine is artifact-producing. Output stored in artifact_store,
    committed via commit_system. Engine does not commit directly.

Failure semantics:
    If repo_root does not exist, engine raises ValueError → executor
    adds 'run_egg_juicer' to failed_engines → status='partial'.
    Reflector surfaces the failure. Nothing is swallowed.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

_HERE    = Path(__file__).resolve().parent
_EGG_PKG = _HERE / "engines" / "egg_juicer_package"

if str(_EGG_PKG) not in sys.path:
    sys.path.insert(0, str(_EGG_PKG))

from engine_logic import Engine as _EggJuicerEngine
from engine_contract import register_engine, AB_PRODUCES, EngineRegistrationConflict

SCHEMA      = "MB-ENGINE-REGISTRATION-1.1"
ENGINE_NAME = "run_egg_juicer"


def build_egg_juicer_engine_map(
    repo_root:        str | Path,
    allow_reregister: bool = False,
) -> dict[str, tuple]:
    """
    Build a governed engine_map entry for the egg_juicer engine.

    Returns:
        {"run_egg_juicer": (ContractEnforcingWrapper, governance_dict)}

    The governance_dict carries context_fingerprint, artifact_behavior,
    and contract_version — executor reads these for artifact storage policy.

    Raises EngineRegistrationConflict if the same engine_name was previously
    registered with a different repo_root (context-capture drift).
    """
    _repo_root = str(repo_root)
    _engine    = _EggJuicerEngine()

    def _raw_callable():
        if not Path(_repo_root).exists():
            raise ValueError(
                f"egg_juicer: repo_root does not exist: {_repo_root!r}"
            )
        return _engine.run({"repo_root": _repo_root})
        # Returns EngineResult — ContractEnforcingWrapper normalizes to dict

    manifest, wrapped = register_engine(
        engine_name       = ENGINE_NAME,
        raw_callable      = _raw_callable,
        context           = {"repo_root": _repo_root},
        artifact_behavior = AB_PRODUCES,
        registration_site = __file__,
        allow_reregister  = allow_reregister,
    )

    return {manifest.engine_name: (wrapped, manifest.to_governance_dict())}
