"""
Semantic Capability Graph Builder
----------------------------------
Builds a semantic planning graph from the capability graph.
Used by planners and analysis engines to reason about capabilities.

Write paths:
  export_graph(path)      — non-authoritative debug file write
  export_to_kernel(...)   — authoritative kernel-backed store + commit

Legacy impact: prior export_graph() wrote directly to disk via open(..., "w").
export_to_kernel() is the governed replacement.
"""

import json
from pathlib import Path
from collections import defaultdict

class SemanticCapabilityGraphBuilder:
    # Builds a semantic planning graph from the capability graph
    # Used by planners and analysis engines to reason about capabilities

    def __init__(self):
        self.semantic_graph = {
            "capabilities": defaultdict(list),
            "engine_routes": defaultdict(list),
            "phase_routes": defaultdict(list),
            "intent_routes": defaultdict(list)
        }

    def ingest_capability_graph(self, capability_graph):
        engines = capability_graph.get("engines", {})

        for engine_name, engine_info in engines.items():
            phases = engine_info.get("phases", [])
            intents = engine_info.get("intents", [])

            for phase in phases:
                self.semantic_graph["phase_routes"][phase].append(engine_name)

            for intent in intents:
                self.semantic_graph["intent_routes"][intent].append(engine_name)

            capability_id = f"capability:{engine_name}"

            self.semantic_graph["capabilities"][capability_id].append({
                "engine": engine_name,
                "phases": phases,
                "intents": intents
            })

            for intent in intents:
                self.semantic_graph["engine_routes"][intent].append({
                    "engine": engine_name,
                    "phases": phases
                })

    def capabilities_for_intent(self, intent):
        return self.semantic_graph["engine_routes"].get(intent, [])

    def engines_for_phase(self, phase):
        return self.semantic_graph["phase_routes"].get(phase, [])

    def graph_sha256(self) -> str:
        import hashlib
        data = json.dumps(
            {k: dict(v) for k, v in self.semantic_graph.items()},
            sort_keys=True, default=str
        ).encode()
        return hashlib.sha256(data).hexdigest()

    def export_graph(self, path):
        """
        Non-authoritative debug export to local filesystem.
        For governed state, use export_to_kernel() instead.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.semantic_graph, f, indent=2)
        return str(path)

    def export_to_kernel(self, artifact_store, commit_system,
                         intent: str = "semantic_capability_graph") -> dict:
        """
        Authoritative export: store semantic graph in ArtifactStore,
        commit via CommitSystem.
        Returns dict with artifact_id and commit_id.

        Legacy impact: replaces open(..., "w") + json.dump() that produced
        ghost state outside the kernel commit chain.
        """
        # defaultdict is not directly serializable — normalize first
        serializable = {k: dict(v) for k, v in self.semantic_graph.items()}
        store_receipt = artifact_store.store(
            serializable,
            engine_id="semantic_capability_graph_builder",
            phase="commit",
            intent=intent,
        )
        commit = commit_system.commit(
            artifact_ids=[store_receipt.artifact_id],
            engine_id="semantic_capability_graph_builder",
            phase="commit",
            intent=intent,
        )
        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "authoritative": store_receipt.authoritative,
            "graph_sha256": self.graph_sha256(),
        }
