"""
Artifact Graph Index Engine
---------------------------
CDR: duplicate indexing must be detected, not silently appended.
ECL: export uses canonical JSON (sorted keys) for deterministic hashing.

Behavior on duplicate artifact_id:
  - If all fields match: idempotent (no-op, no error)
  - If any field conflicts: raises ValueError — caller must resolve
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

# Kernel import (optional — only needed for export_to_kernel)
# Loaded lazily to avoid hard dependency when kernel is not present.
def _get_kernel_modules():
    """Lazily load kernel ArtifactStore + CommitSystem."""
    try:
        from artifact_store import ArtifactStore
        from commit_system import CommitSystem
        return ArtifactStore, CommitSystem
    except ImportError:
        return None, None


def _canonical_json(obj: object) -> str:
    return json.dumps(obj, sort_keys=True, default=str)


def _sha256(obj: object) -> str:
    return hashlib.sha256(_canonical_json(obj).encode()).hexdigest()


class ArtifactGraphIndex:
    def __init__(self):
        # Use plain dicts — no defaultdict; explicit is safer for serialization
        self.graph: dict = {
            "artifacts": {},
            "engines": {},
            "phases": {},
            "intents": {},
            "replay_packs": {},
        }

    def _append_unique(self, bucket: dict, key: str, value: str) -> None:
        existing = bucket.setdefault(key, [])
        if value not in existing:
            existing.append(value)

    def index_artifact(
        self,
        artifact_id: str,
        engine: str | None = None,
        phase: str | None = None,
        intent: str | None = None,
        replay_pack: str | None = None,
    ) -> None:
        entry = {
            "artifact_id": artifact_id,
            "engine": engine,
            "phase": phase,
            "intent": intent,
            "replay_pack": replay_pack,
        }

        existing = self.graph["artifacts"].get(artifact_id)
        if existing is not None:
            if existing != entry:
                raise ValueError(
                    f"Artifact '{artifact_id}' already indexed with different metadata.\n"
                    f"  Existing: {existing}\n"
                    f"  New:      {entry}"
                )
            # Idempotent: same entry, do nothing
            return

        self.graph["artifacts"][artifact_id] = entry

        if engine:
            self._append_unique(self.graph["engines"], engine, artifact_id)
        if phase:
            self._append_unique(self.graph["phases"], phase, artifact_id)
        if intent:
            self._append_unique(self.graph["intents"], intent, artifact_id)
        if replay_pack:
            self._append_unique(self.graph["replay_packs"], replay_pack, artifact_id)

    def query_by_engine(self, engine: str) -> list[str]:
        return self.graph["engines"].get(engine, [])

    def query_by_phase(self, phase: str) -> list[str]:
        return self.graph["phases"].get(phase, [])

    def query_by_intent(self, intent: str) -> list[str]:
        return self.graph["intents"].get(intent, [])

    def graph_sha256(self) -> str:
        return _sha256(self.graph)

    def export_graph(self, path: str | Path) -> str:
        """
        Non-authoritative debug export to local filesystem.
        For governed state, use export_to_kernel() instead.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Canonical JSON — sorted keys, deterministic output
        path.write_text(_canonical_json(self.graph), encoding="utf-8")
        return str(path)

    def export_to_kernel(self, artifact_store, commit_system,
                         intent: str = "artifact_graph_index") -> dict:
        """
        Authoritative export: store graph in ArtifactStore, commit via CommitSystem.
        Returns dict with artifact_id and commit_id.
        This is the governed write path — use instead of export_graph() for
        any state that must be part of the kernel audit trail.

        Legacy impact: replaces direct json.dump / write_text calls that
        produced ghost state outside the commit chain.
        """
        store_receipt = artifact_store.store(
            self.graph,
            engine_id="artifact_graph_index_engine",
            phase="commit",
            intent=intent,
        )
        commit = commit_system.commit(
            artifact_ids=[store_receipt.artifact_id],
            engine_id="artifact_graph_index_engine",
            phase="commit",
            intent=intent,
        )
        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "authoritative": store_receipt.authoritative,
            "graph_sha256": self.graph_sha256(),
        }
