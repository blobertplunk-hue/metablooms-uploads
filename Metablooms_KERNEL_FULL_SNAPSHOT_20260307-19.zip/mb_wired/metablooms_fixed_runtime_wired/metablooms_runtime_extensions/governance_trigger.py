"""
GovernanceTrigger — MetaBlooms Governance-When-Needed System
--------------------------------------------------------------
Authority: Runtime extension layer.
Schema:    MB-GOVERNANCE-TRIGGER-1.0

Purpose:
    Prevents infinite governance iteration by making governance additions
    evidence-triggered rather than anticipatory.

    The problem it solves:
        MetaBlooms (and any AI system analyzing itself) will always be able
        to identify potential future failure modes. This is valuable but
        dangerous — it can produce unbounded governance scaffolding around
        problems that don't yet exist, while real problems go unaddressed.

    The solution:
        Governance additions require a TRIGGER — observed evidence that a
        specific failure mode has actually occurred or is measurably approaching.
        No trigger = no governance addition, regardless of how plausible the
        failure mode sounds.

Trigger types:
    THRESHOLD_BREACH   — a measured metric crossed a defined threshold
    REPEATED_FINDING   — reflector surfaced the same finding N times
    FAILURE_OBSERVED   — a specific failure actually occurred in execution
    COLLISION_DETECTED — artifact or intent namespace collision occurred
    DRIFT_DETECTED     — context-capture drift conflict was raised
    MANUAL             — human explicitly decided governance is needed now

Governance areas (what can be gated):
    ARTIFACT_NAMESPACE    — artifact namespacing rules
    INTENT_RESOLUTION     — intent → engine routing rules
    CROSS_ENGINE_STATE    — engine isolation enforcement
    PARTIAL_EXECUTION     — partial run handling policy
    REFLECTION_NOISE      — reflection proposal thresholds
    REASONING_STRATEGY    — reasoning mode selection policy
    EXECUTION_GRAPH_SYNC  — execution graph / runtime graph consistency
    REPLAY_DETERMINISM    — replay normalization rules
    EVOLUTION_FEEDBACK    — evolution engine safeguards
    REGISTRY_MANAGEMENT   — engine registry scope enforcement

Usage — evaluating whether to add governance now:
    from governance_trigger import GovernanceTrigger, TriggerType, GovernanceArea

    trigger = GovernanceTrigger()

    # Record observed evidence
    trigger.record(TriggerType.REPEATED_FINDING, GovernanceArea.REFLECTION_NOISE,
                   detail="reflector produced 0 proposals on 12 consecutive clean runs",
                   count=12)

    # Ask whether governance is warranted NOW
    decision = trigger.evaluate(GovernanceArea.REFLECTION_NOISE)
    if decision.warranted:
        # build the governance
        pass
    else:
        print(decision.reason)   # "Not yet warranted: threshold not reached (12/20 runs)"

Invariant:
    GovernanceTrigger.evaluate() never returns warranted=True unless at
    least one trigger event has been recorded for that area with count >= threshold.
    "It might happen someday" is not a trigger. Observed evidence is.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

SCHEMA = "MB-GOVERNANCE-TRIGGER-1.0"


class TriggerType(str, Enum):
    THRESHOLD_BREACH   = "threshold_breach"
    REPEATED_FINDING   = "repeated_finding"
    FAILURE_OBSERVED   = "failure_observed"
    COLLISION_DETECTED = "collision_detected"
    DRIFT_DETECTED     = "drift_detected"
    MANUAL             = "manual"


class GovernanceArea(str, Enum):
    ARTIFACT_NAMESPACE   = "artifact_namespace"
    INTENT_RESOLUTION    = "intent_resolution"
    CROSS_ENGINE_STATE   = "cross_engine_state"
    PARTIAL_EXECUTION    = "partial_execution"
    REFLECTION_NOISE     = "reflection_noise"
    REASONING_STRATEGY   = "reasoning_strategy"
    EXECUTION_GRAPH_SYNC = "execution_graph_sync"
    REPLAY_DETERMINISM   = "replay_determinism"
    EVOLUTION_FEEDBACK   = "evolution_feedback"
    REGISTRY_MANAGEMENT  = "registry_management"


# Thresholds: how many trigger events of what type before governance is warranted.
# These are conservative — governance should lag observed problems, not anticipate them.
_THRESHOLDS: dict[tuple[GovernanceArea, TriggerType], int] = {
    # Collision and drift are immediate — one observed event is enough
    (GovernanceArea.ARTIFACT_NAMESPACE,   TriggerType.COLLISION_DETECTED): 1,
    (GovernanceArea.INTENT_RESOLUTION,    TriggerType.COLLISION_DETECTED): 1,
    (GovernanceArea.REGISTRY_MANAGEMENT,  TriggerType.DRIFT_DETECTED):     1,
    # Failures require one confirmed observation
    (GovernanceArea.PARTIAL_EXECUTION,    TriggerType.FAILURE_OBSERVED):   1,
    (GovernanceArea.CROSS_ENGINE_STATE,   TriggerType.FAILURE_OBSERVED):   1,
    (GovernanceArea.REPLAY_DETERMINISM,   TriggerType.FAILURE_OBSERVED):   1,
    (GovernanceArea.EVOLUTION_FEEDBACK,   TriggerType.FAILURE_OBSERVED):   1,
    # Repeated findings require pattern — not a single noisy reflection
    (GovernanceArea.REFLECTION_NOISE,     TriggerType.REPEATED_FINDING):  20,
    (GovernanceArea.REASONING_STRATEGY,   TriggerType.REPEATED_FINDING):  10,
    # Threshold breach uses measurement, any single breach is enough
    (GovernanceArea.EXECUTION_GRAPH_SYNC, TriggerType.THRESHOLD_BREACH):   1,
    # Manual override always warrants immediately
    **{(area, TriggerType.MANUAL): 1 for area in GovernanceArea},
}

# What governance to add when triggered (specification, not code — human decides implementation)
_GOVERNANCE_SPEC: dict[GovernanceArea, str] = {
    GovernanceArea.ARTIFACT_NAMESPACE:
        "Verify artifact_store envelope includes engine_id+intent. "
        "Add uniqueness assertion to integration test.",
    GovernanceArea.INTENT_RESOLUTION:
        "Add capability declarations to EngineRegistrationManifest. "
        "Replace direct intent→engine lookup with capability→engine resolution.",
    GovernanceArea.CROSS_ENGINE_STATE:
        "Audit all engine callables for global state access. "
        "Add engine isolation check to ContractEnforcingWrapper.",
    GovernanceArea.PARTIAL_EXECUTION:
        "Verify orchestrator status semantics: ok/partial/failed are distinct. "
        "Ensure reflector treats partial differently from failed.",
    GovernanceArea.REFLECTION_NOISE:
        "Add proposal deduplication to reflector. "
        "Add severity threshold filter (surface HIGH only by default). "
        "Add per-area proposal count cap.",
    GovernanceArea.REASONING_STRATEGY:
        "Add strategy_hint field to ReasonedPlan. "
        "Add strategy selection logic to reasoning_engine based on intent complexity.",
    GovernanceArea.EXECUTION_GRAPH_SYNC:
        "Generate execution graph dynamically from orchestrator config "
        "instead of maintaining static artifact.",
    GovernanceArea.REPLAY_DETERMINISM:
        "Add replay normalization: fixed sort order, timestamp stripping, "
        "determinism hash comparison between original and replay run.",
    GovernanceArea.EVOLUTION_FEEDBACK:
        "Add confirmation_count requirement to evolution engine: "
        "patch candidate requires N reflections before promotion to freeze candidate.",
    GovernanceArea.REGISTRY_MANAGEMENT:
        "Enforce single registration entry point via build_governed_engine_map. "
        "Add registry scope validation to integration test.",
}


@dataclass
class TriggerEvent:
    trigger_type:    TriggerType
    governance_area: GovernanceArea
    detail:          str
    count:           int
    timestamp_utc:   str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@dataclass
class GovernanceDecision:
    area:            GovernanceArea
    warranted:       bool
    reason:          str
    triggered_by:    Optional[TriggerEvent]
    spec:            Optional[str]        # what to build if warranted
    evidence_count:  int
    threshold:       int

    def to_dict(self) -> dict:
        return {
            "schema":         SCHEMA,
            "area":           self.area.value,
            "warranted":      self.warranted,
            "reason":         self.reason,
            "triggered_by":   {
                "type":   self.triggered_by.trigger_type.value,
                "detail": self.triggered_by.detail,
                "count":  self.triggered_by.count,
            } if self.triggered_by else None,
            "spec":           self.spec,
            "evidence_count": self.evidence_count,
            "threshold":      self.threshold,
        }


class GovernanceTrigger:
    """
    Evidence-gated governance decision system.

    Records observed trigger events and evaluates whether governance
    is warranted for a given area based on accumulated evidence vs threshold.

    Principle: governance additions must be earned by observed evidence,
    not granted by anticipatory analysis. The system can always imagine
    future failure modes — that is not sufficient justification to build
    governance for them now.
    """

    def __init__(self):
        # area → list of events
        self._events: dict[GovernanceArea, list[TriggerEvent]] = {
            area: [] for area in GovernanceArea
        }

    def record(
        self,
        trigger_type:    TriggerType,
        governance_area: GovernanceArea,
        detail:          str,
        count:           int = 1,
    ) -> TriggerEvent:
        """Record an observed trigger event."""
        event = TriggerEvent(
            trigger_type    = trigger_type,
            governance_area = governance_area,
            detail          = detail,
            count           = count,
        )
        self._events[governance_area].append(event)
        return event

    def evaluate(self, area: GovernanceArea) -> GovernanceDecision:
        """
        Evaluate whether governance is warranted for this area.
        Returns GovernanceDecision with warranted=True only if observed
        evidence meets the threshold for at least one trigger type.
        """
        events = self._events[area]
        if not events:
            return GovernanceDecision(
                area           = area,
                warranted      = False,
                reason         = f"No trigger events recorded for {area.value}. "
                                 f"Governance not warranted until evidence is observed.",
                triggered_by   = None,
                spec           = None,
                evidence_count = 0,
                threshold      = 0,
            )

        # Check each event against its threshold
        for event in events:
            key       = (area, event.trigger_type)
            threshold = _THRESHOLDS.get(key, 999)  # unknown combos require high bar
            total     = sum(e.count for e in events if e.trigger_type == event.trigger_type)

            if total >= threshold:
                return GovernanceDecision(
                    area           = area,
                    warranted      = True,
                    reason         = (
                        f"Warranted: {event.trigger_type.value} count={total} "
                        f">= threshold={threshold}. Evidence: {event.detail}"
                    ),
                    triggered_by   = event,
                    spec           = _GOVERNANCE_SPEC.get(area),
                    evidence_count = total,
                    threshold      = threshold,
                )

        # Events exist but threshold not reached
        best_event    = max(events, key=lambda e: e.count)
        key           = (area, best_event.trigger_type)
        threshold     = _THRESHOLDS.get(key, 999)
        total         = sum(e.count for e in events if e.trigger_type == best_event.trigger_type)
        return GovernanceDecision(
            area           = area,
            warranted      = False,
            reason         = (
                f"Not yet warranted: {best_event.trigger_type.value} count={total} "
                f"< threshold={threshold}. Continue monitoring."
            ),
            triggered_by   = None,
            spec           = None,
            evidence_count = total,
            threshold      = threshold,
        )

    def evaluate_all(self) -> list[GovernanceDecision]:
        """Evaluate all governance areas. Returns only warranted decisions."""
        return [
            d for area in GovernanceArea
            for d in [self.evaluate(area)]
            if d.warranted
        ]

    def status_report(self) -> dict:
        """
        Full status: which areas have events, which are approaching threshold,
        which are warranted. For use by reflector / evolution engine.
        """
        report = {
            "schema":    SCHEMA,
            "warranted": [],
            "monitoring": [],
            "inactive": [],
        }
        for area in GovernanceArea:
            events = self._events[area]
            if not events:
                report["inactive"].append(area.value)
                continue
            decision = self.evaluate(area)
            entry = {
                "area":            area.value,
                "event_count":     len(events),
                "evidence_total":  sum(e.count for e in events),
                "warranted":       decision.warranted,
                "reason":          decision.reason,
            }
            if decision.warranted:
                entry["spec"] = decision.spec
                report["warranted"].append(entry)
            else:
                report["monitoring"].append(entry)
        return report


# ── Singleton for process-level tracking ─────────────────────────────────────

_process_trigger: Optional[GovernanceTrigger] = None

def get_governance_trigger() -> GovernanceTrigger:
    """Process-level GovernanceTrigger. Use .record() to log observed events."""
    global _process_trigger
    if _process_trigger is None:
        _process_trigger = GovernanceTrigger()
    return _process_trigger

def reset_governance_trigger():
    """Reset process trigger. Use in tests only."""
    global _process_trigger
    _process_trigger = None
