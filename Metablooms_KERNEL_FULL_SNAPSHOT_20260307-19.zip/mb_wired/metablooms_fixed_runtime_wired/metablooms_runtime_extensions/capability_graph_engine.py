"""
Capability Graph Engine
-----------------------
Duplicate engine registration is idempotent if identical, error if conflicting.
Export uses canonical JSON (sorted keys).
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


def _canonical_json(obj: object) -> str:
    return json.dumps(obj, sort_keys=True, default=str)


def _sha256(obj: object) -> str:
    return hashlib.sha256(_canonical_json(obj).encode()).hexdigest()


def _append_unique(bucket: dict, key: str, value: str) -> None:
    existing = bucket.setdefault(key, [])
    if value not in existing:
        existing.append(value)


class CapabilityGraphEngine:
    def __init__(self):
        self.graph: dict = {
            "engines": {},
            "phases": {},
            "intents": {},
            "artifacts": {},
            "policies": {},
        }

    def register_engine(
        self,
        engine_name: str,
        phases: list[str] | None = None,
        intents: list[str] | None = None,
    ) -> None:
        phases = sorted(phases or [])
        intents = sorted(intents or [])
        entry = {"engine": engine_name, "phases": phases, "intents": intents}

        existing = self.graph["engines"].get(engine_name)
        if existing is not None:
            if existing != entry:
                raise ValueError(
                    f"Engine '{engine_name}' already registered with different config.\n"
                    f"  Existing: {existing}\n"
                    f"  New:      {entry}"
                )
            # Idempotent
            return

        self.graph["engines"][engine_name] = entry

        for p in phases:
            _append_unique(self.graph["phases"], p, engine_name)
        for i in intents:
            _append_unique(self.graph["intents"], i, engine_name)

    def link_artifact(self, artifact_id: str, engine: str) -> None:
        _append_unique(self.graph["artifacts"], artifact_id, engine)

    def link_policy(self, policy_id: str, engine: str) -> None:
        _append_unique(self.graph["policies"], policy_id, engine)

    def engines_for_phase(self, phase: str) -> list[str]:
        return self.graph["phases"].get(phase, [])

    def engines_for_intent(self, intent: str) -> list[str]:
        return self.graph["intents"].get(intent, [])

    def graph_sha256(self) -> str:
        return _sha256(self.graph)

    def export_graph(self, path: str | Path) -> str:
        """
        Non-authoritative debug export to local filesystem.
        For governed state, use export_to_kernel() instead.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(_canonical_json(self.graph), encoding="utf-8")
        return str(path)

    def export_to_kernel(self, artifact_store, commit_system,
                         intent: str = "capability_graph") -> dict:
        """
        Authoritative export: store graph in ArtifactStore, commit via CommitSystem.
        Returns dict with artifact_id and commit_id.

        Legacy impact: replaces direct write_text calls that produced ghost state
        outside the kernel commit chain.
        """
        store_receipt = artifact_store.store(
            self.graph,
            engine_id="capability_graph_engine",
            phase="commit",
            intent=intent,
        )
        commit = commit_system.commit(
            artifact_ids=[store_receipt.artifact_id],
            engine_id="capability_graph_engine",
            phase="commit",
            intent=intent,
        )
        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "authoritative": store_receipt.authoritative,
            "graph_sha256": self.graph_sha256(),
        }
