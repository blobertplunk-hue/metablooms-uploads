
"""
System Dashboard Engine
-----------------------
Builds a dashboard summary from capability, artifact, and semantic graph inputs.

Write paths:
  export_dashboard(path)    — non-authoritative debug file write
  export_to_kernel(...)     — authoritative kernel-backed store + commit

Legacy impact: prior export_dashboard() wrote directly to disk with no
commit trail. export_to_kernel() is the governed replacement.
"""

import json
from pathlib import Path


class SystemDashboardEngine:
    """
    Builds a dashboard summary from capability, artifact, and semantic graph inputs.
    """

    def __init__(self, capability_graph=None, artifact_graph=None, semantic_graph=None):
        self.capability_graph = capability_graph or {}
        self.artifact_graph = artifact_graph or {}
        self.semantic_graph = semantic_graph or {}

    def build_summary(self):
        engines = self.capability_graph.get("engines", {})
        phases = self.capability_graph.get("phases", {})
        intents = self.capability_graph.get("intents", {})

        artifacts = self.artifact_graph.get("artifacts", {})
        replay_packs = self.artifact_graph.get("replay_packs", {})

        semantic_caps = self.semantic_graph.get("capabilities", {})
        semantic_routes = self.semantic_graph.get("engine_routes", {})

        return {
            "engine_count": len(engines),
            "phase_count": len(phases),
            "intent_count": len(intents),
            "artifact_count": len(artifacts),
            "replay_pack_count": len(replay_packs),
            "semantic_capability_count": len(semantic_caps),
            "semantic_route_count": len(semantic_routes),
            "engines": sorted(list(engines.keys())),
            "phases": sorted(list(phases.keys())),
            "intents": sorted(list(intents.keys())),
        }

    def export_dashboard(self, path):
        """
        Non-authoritative debug export to local filesystem.
        For governed state, use export_to_kernel() instead.
        """
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        summary = self.build_summary()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
        return str(path)

    def export_to_kernel(self, artifact_store, commit_system,
                         intent: str = "system_dashboard") -> dict:
        """
        Authoritative export: store dashboard summary in ArtifactStore,
        commit via CommitSystem.
        Returns dict with artifact_id and commit_id.

        Legacy impact: replaces open(..., "w") + json.dump() calls that
        produced ghost state outside the kernel commit chain.
        """
        import hashlib
        summary = self.build_summary()
        store_receipt = artifact_store.store(
            summary,
            engine_id="system_dashboard_engine",
            phase="commit",
            intent=intent,
        )
        commit = commit_system.commit(
            artifact_ids=[store_receipt.artifact_id],
            engine_id="system_dashboard_engine",
            phase="commit",
            intent=intent,
        )
        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "authoritative": store_receipt.authoritative,
            "summary_sha256": store_receipt.content_hash,
        }
