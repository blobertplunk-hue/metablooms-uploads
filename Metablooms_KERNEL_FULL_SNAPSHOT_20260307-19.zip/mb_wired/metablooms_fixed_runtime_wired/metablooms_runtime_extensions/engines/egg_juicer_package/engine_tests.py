
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from engine_logic import Engine


def _hash_artifact(result):
    canonical = json.dumps(result.artifact, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def test_engine_runs_on_package_directory():
    engine = Engine()
    result = engine.run({"repo_root": str(Path(__file__).resolve().parent)})
    assert result.artifact["engine"] == "egg_juicer"
    assert result.artifact["file_count"] >= 1
    assert "structure_hash" in result.artifact


def test_engine_determinism_same_input_same_output_hash():
    engine = Engine()
    repo_root = str(Path(__file__).resolve().parent)
    r1 = engine.run({"repo_root": repo_root})
    r2 = engine.run({"repo_root": repo_root})
    assert _hash_artifact(r1) == _hash_artifact(r2)
