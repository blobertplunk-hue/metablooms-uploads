
from __future__ import annotations

from pathlib import Path
import hashlib
from engine_interface import EngineResult


class Engine:
    engine_id = "egg_juicer"

    def run(self, inputs):
        repo_root = inputs.get("repo_root")
        if not repo_root:
            raise ValueError("repo_root required")

        repo_root = Path(repo_root)
        files = []
        for p in sorted(repo_root.rglob("*")):
            if p.is_file():
                files.append(str(p.relative_to(repo_root)))

        payload = "\n".join(files).encode("utf-8")
        structure_hash = hashlib.sha256(payload).hexdigest()

        artifact = {
            "engine": self.engine_id,
            "repo": str(repo_root),
            "file_count": len(files),
            "structure_hash": structure_hash,
            "files_sample": files[:20],
        }

        metadata = {
            "deterministic": True,
            "input_hash_basis": {"repo_root": str(repo_root)},
        }

        return EngineResult(
            artifact=artifact,
            metadata=metadata,
            receipt_path=None,
        )
