
# Egg Juicer Governed Engine Package

Generated: 2026-03-07T01:12:37.995212+00:00

## Purpose
Deterministically scan a repository tree, enumerate files, and produce an artifact summary suitable for replay, graph indexing, and dashboarding.

## Inputs
- `repo_root` (path, required)

## Outputs
- artifact summary JSON
- execution receipt path (owned by executor)

## Failure Modes
- missing `repo_root` → fail closed
- unreadable target tree → exception propagated to executor
- receipt absent when governance requires it → invalid governed run

## Determinism Guarantee
For identical `repo_root` contents, Egg Juicer must produce identical canonical artifact hashes.

## Governance Restrictions
- allowed: read_files, produce_artifact
- forbidden: network_access, arbitrary_write
- receipt required and enforced by `mpp_executor`

## Phase Binding
- verification
