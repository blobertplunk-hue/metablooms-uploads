
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict


@dataclass(frozen=True)
class EngineResult:
    artifact: Dict[str, Any]
    metadata: Dict[str, Any]
    receipt_path: str | None = None
