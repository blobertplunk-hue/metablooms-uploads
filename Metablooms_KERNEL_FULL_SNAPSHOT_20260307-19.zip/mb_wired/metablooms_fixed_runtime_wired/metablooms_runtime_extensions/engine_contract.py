"""
Engine Contract — MetaBlooms Canonical Engine Registration Standard
--------------------------------------------------------------------
Authority: Runtime extension layer.
Schema:    MB-ENGINE-CONTRACT-1.0

Purpose:
    Locks down two failure modes MetaBlooms identified:

    1. Context-Capture Drift
       Same engine name registered with different captured environments
       (different repo_root, data_root, config) in different callers.
       Name is stable; behavior is not. Causes replay mismatches and
       "random" instability the reflector can't diagnose correctly.

    2. Executor Contract Erosion
       Each engine wrapped differently: one returns raw dict, another
       EngineResult; one swallows exceptions, another propagates; one
       commits internally, another delegates. Names stay stable while
       semantics drift. Breaks reflection artifact counts, commit chains,
       and validation matrix consistency.

Fix:
    A. EngineRegistrationManifest — every registered callable carries a
       fingerprinted manifest declaring its captured context, artifact
       behavior, and contract version. Registry enforces: same engine name
       + different context_fingerprint = CONFLICT, not silent overwrite.

    B. ContractEnforcingWrapper — wraps the raw engine callable and
       enforces the contract at call time (not pre-admission — behavioral
       contracts can't be verified statically):
         - returns dict (artifact) or raises — never swallows silently
         - converts EngineResult.artifact to dict if needed
         - surfaces exceptions as structured failure dicts, not swallowed
         - declares artifact_behavior to executor governance dict
         - records call_count and last_call_context for drift detection

Contract invariants (enforced at call time):
    RETURN_DICT      — callable must return a dict or EngineResult
    NO_SILENT_FAIL   — exceptions surface as structured errors, not None
    NO_DIRECT_COMMIT — engine must not commit artifacts itself
                       (executor owns the commit boundary)
    CONTEXT_STABLE   — context_fingerprint must not change after registration

Usage:
    from engine_contract import register_engine, EngineRegistrationManifest

    # Build manifest + wrapped callable
    manifest, wrapped = register_engine(
        engine_name="run_egg_juicer",
        raw_callable=egg_juicer_fn,        # zero-arg callable
        context={
            "repo_root": "/path/to/repo",
            "data_root": "/path/to/data",
        },
        artifact_behavior="produces",      # produces | none
        registration_site="egg_juicer_registration.py",
    )

    # Register in engine_map — executor receives (callable, governance_dict)
    engine_map = {
        manifest.engine_name: (wrapped, manifest.to_governance_dict())
    }

    ctx = build_kernel_context(data_root, engine_map=engine_map)

Contract registry (process-level):
    EngineContractRegistry enforces no re-registration with different fingerprint.
    Call EngineContractRegistry.get_instance() for process-level enforcement.
    Call .clear() in tests to reset between runs.
"""

from __future__ import annotations

import hashlib
import json
import traceback
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Optional

SCHEMA            = "MB-ENGINE-CONTRACT-1.0"
CONTRACT_VERSION  = "1.0"

# Artifact behavior declarations
AB_PRODUCES  = "produces"    # engine returns artifact dict → executor stores it
AB_NONE      = "none"        # engine returns nothing meaningful → executor skips store

# Contract violation types
CV_RETURN_TYPE     = "RETURN_TYPE_VIOLATION"      # callable returned non-dict/non-EngineResult
CV_SILENT_FAIL     = "SILENT_FAIL_VIOLATION"      # callable returned None without raising
CV_CONTEXT_DRIFT   = "CONTEXT_DRIFT_VIOLATION"    # fingerprint changed after registration
CV_DIRECT_COMMIT   = "DIRECT_COMMIT_VIOLATION"    # engine attempted direct commit (detected post-hoc)


# ── Manifest ──────────────────────────────────────────────────────────────────

@dataclass
class EngineRegistrationManifest:
    """
    Artifact-backed manifest for a registered engine callable.
    Carries the captured context fingerprint and artifact behavior declaration.
    Immutable after creation — fingerprint is sealed at registration time.
    """
    engine_name:          str
    contract_version:     str
    context_fingerprint:  str        # sha256 of sorted context dict
    context_keys:         list       # which keys were fingerprinted (not values)
    artifact_behavior:    str        # AB_PRODUCES | AB_NONE
    registration_site:    str        # source file / call site
    registered_utc:       str

    # Mutable tracking fields (not part of fingerprint)
    call_count:           int   = field(default=0, compare=False)
    last_violation:       Optional[str] = field(default=None, compare=False)

    def to_governance_dict(self) -> dict:
        """
        Returns the governance dict the executor reads to control artifact storage.
        Conforms to the existing executor _unpack() + governance check interface.
        """
        return {
            "artifact_producing":  self.artifact_behavior == AB_PRODUCES,
            "requires_receipt":    False,   # executor owns commit — engine does not
            "contract_version":    self.contract_version,
            "context_fingerprint": self.context_fingerprint,
            "registration_site":   self.registration_site,
        }

    def to_artifact_dict(self) -> dict:
        """Serializable artifact for artifact_store storage."""
        return {
            "schema":              SCHEMA,
            "engine_name":         self.engine_name,
            "contract_version":    self.contract_version,
            "context_fingerprint": self.context_fingerprint,
            "context_keys":        self.context_keys,
            "artifact_behavior":   self.artifact_behavior,
            "registration_site":   self.registration_site,
            "registered_utc":      self.registered_utc,
        }


def _fingerprint_context(context: dict) -> tuple[str, list]:
    """
    Compute a stable fingerprint from context dict.
    Uses sorted key-value pairs so insertion order doesn't matter.
    Returns (fingerprint_hex, sorted_keys).
    """
    canonical = json.dumps(
        {k: str(v) for k, v in sorted(context.items())},
        sort_keys=True,
    )
    fp = hashlib.sha256(canonical.encode()).hexdigest()
    return fp, sorted(context.keys())


# ── Contract-Enforcing Wrapper ────────────────────────────────────────────────

class ContractEnforcingWrapper:
    """
    Wraps a raw engine callable and enforces the MetaBlooms engine contract
    at call time. Installed as the callable in engine_map.

    Enforced invariants:
        RETURN_DICT    — result must be dict or EngineResult with .artifact dict
        NO_SILENT_FAIL — None return treated as violation, not success
        SURFACE_ERRORS — exceptions converted to structured error dict, not swallowed

    NOT enforced (runtime can't detect statically):
        NO_DIRECT_COMMIT — declaration only; violation detected by commit chain audit

    The wrapper never raises to the executor. It either returns a valid dict
    (success) or a structured error dict (failure). The executor's failed_engines
    logic handles the failure path via the result content, not via exceptions.

    Exception note: if the raw callable raises, the wrapper returns a structured
    error dict. The executor will store this as the artifact (governed failure
    record) rather than treating it as an unhandled exception. This is intentional:
    fail-closed with evidence, not silent skip.
    """

    def __init__(
        self,
        raw_callable: Callable,
        manifest: EngineRegistrationManifest,
    ):
        self._raw   = raw_callable
        self._manifest = manifest
        # Give the wrapper the engine name so executor logging is clean
        self.__name__ = manifest.engine_name

    def __call__(self) -> dict:
        self._manifest.call_count += 1
        call_ts = datetime.now(timezone.utc).isoformat()

        try:
            result = self._raw()
        except Exception as exc:
            # Surface the failure as a structured dict — never swallow
            tb = traceback.format_exc(limit=6)
            error_dict = {
                "_contract_violation": CV_SILENT_FAIL,
                "_engine_name":        self._manifest.engine_name,
                "_call_timestamp":     call_ts,
                "_exception_type":     type(exc).__name__,
                "_exception_msg":      str(exc),
                "_traceback":          tb,
                "status":              "engine_exception",
            }
            self._manifest.last_violation = CV_SILENT_FAIL
            # Re-raise so executor's failed_engines path catches it
            # (executor already has try/except — this surfaces correctly)
            raise

        # ── Contract check: return type ───────────────────────────────────────
        if result is None:
            self._manifest.last_violation = CV_SILENT_FAIL
            raise ValueError(
                f"Engine '{self._manifest.engine_name}' returned None. "
                f"Contract requires dict or EngineResult. "
                f"(NO_SILENT_FAIL violation)"
            )

        # ── Normalize EngineResult → dict ─────────────────────────────────────
        # Some engines return EngineResult(artifact=..., metadata=...).
        # Executor expects a plain dict. Normalize here so the contract
        # is uniform regardless of engine implementation style.
        if hasattr(result, "artifact") and isinstance(result.artifact, dict):
            normalized = dict(result.artifact)
            # Surface metadata alongside artifact if present
            if hasattr(result, "metadata") and isinstance(result.metadata, dict):
                normalized["_engine_metadata"] = result.metadata
            return normalized

        if isinstance(result, dict):
            return result

        # Unexpected return type
        self._manifest.last_violation = CV_RETURN_TYPE
        raise TypeError(
            f"Engine '{self._manifest.engine_name}' returned {type(result).__name__}. "
            f"Contract requires dict or EngineResult. "
            f"(RETURN_TYPE_VIOLATION)"
        )


# ── Process-level Registry ────────────────────────────────────────────────────

class EngineContractRegistry:
    """
    Process-level registry that enforces: same engine name + different
    context_fingerprint = CONFLICT, not silent overwrite.

    Singleton per process. Use .clear() in tests to reset between runs.
    """

    _instance: Optional[EngineContractRegistry] = None

    def __init__(self):
        self._manifests: dict[str, EngineRegistrationManifest] = {}

    @classmethod
    def get_instance(cls) -> EngineContractRegistry:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def clear(cls):
        """Reset registry — use in tests only."""
        cls._instance = None

    def register(
        self,
        manifest: EngineRegistrationManifest,
        allow_reregister: bool = False,
    ) -> None:
        """
        Register a manifest. Raises EngineRegistrationConflict if:
            - engine_name already registered AND
            - context_fingerprint differs (context-capture drift detected)

        allow_reregister=True permits re-registration with same fingerprint
        (idempotent, e.g. during test setup). Different fingerprint always raises.
        """
        existing = self._manifests.get(manifest.engine_name)
        if existing is None:
            self._manifests[manifest.engine_name] = manifest
            return

        if existing.context_fingerprint == manifest.context_fingerprint:
            if allow_reregister:
                return  # idempotent re-registration
            raise EngineRegistrationConflict(
                f"Engine '{manifest.engine_name}' already registered with same fingerprint. "
                f"Use allow_reregister=True for intentional re-registration."
            )

        # Different fingerprint — this is the drift bug
        raise EngineRegistrationConflict(
            f"Context-capture drift detected for engine '{manifest.engine_name}'.\n"
            f"  Existing fingerprint: {existing.context_fingerprint}\n"
            f"  New fingerprint:      {manifest.context_fingerprint}\n"
            f"  Existing context keys: {existing.context_keys}\n"
            f"  New context keys:      {manifest.context_keys}\n"
            f"  Existing site: {existing.registration_site}\n"
            f"  New site:      {manifest.registration_site}\n"
            f"Same engine name with different captured environment is a "
            f"contract violation. Use a different engine_name, or ensure "
            f"all callers use the same context."
        )

    def get(self, engine_name: str) -> Optional[EngineRegistrationManifest]:
        return self._manifests.get(engine_name)

    def all_manifests(self) -> list[EngineRegistrationManifest]:
        return list(self._manifests.values())


class EngineRegistrationConflict(Exception):
    """Raised when context-capture drift is detected at registration time."""
    pass


# ── Public API ────────────────────────────────────────────────────────────────

def register_engine(
    engine_name:       str,
    raw_callable:      Callable,
    context:           dict,
    artifact_behavior: str = AB_PRODUCES,
    registration_site: str = "unknown",
    allow_reregister:  bool = False,
    use_process_registry: bool = True,
) -> tuple[EngineRegistrationManifest, ContractEnforcingWrapper]:
    """
    Canonical engine registration function.

    Creates a manifest, wraps the callable with contract enforcement,
    and registers in the process-level registry (if use_process_registry=True).

    Returns (manifest, wrapped_callable).

    Use in engine_map as:
        engine_map[manifest.engine_name] = (wrapped, manifest.to_governance_dict())

    Args:
        engine_name:       Intent name the executor will look up
        raw_callable:      Zero-arg callable that runs the engine
        context:           Dict of captured environment (repo_root, data_root, etc.)
                           Used to compute context_fingerprint.
        artifact_behavior: AB_PRODUCES (default) or AB_NONE
        registration_site: Source file / function name for audit trail
        allow_reregister:  Permit idempotent re-registration (same fingerprint)
        use_process_registry: Register in global EngineContractRegistry
    """
    fp, ctx_keys = _fingerprint_context(context)

    manifest = EngineRegistrationManifest(
        engine_name         = engine_name,
        contract_version    = CONTRACT_VERSION,
        context_fingerprint = fp,
        context_keys        = ctx_keys,
        artifact_behavior   = artifact_behavior,
        registration_site   = registration_site,
        registered_utc      = datetime.now(timezone.utc).isoformat(),
    )

    wrapped = ContractEnforcingWrapper(raw_callable=raw_callable, manifest=manifest)

    if use_process_registry:
        EngineContractRegistry.get_instance().register(
            manifest, allow_reregister=allow_reregister
        )

    return manifest, wrapped


def build_governed_engine_map(
    registrations: list[tuple[str, Callable, dict, str, str]],
    allow_reregister: bool = False,
) -> dict[str, tuple[Callable, dict]]:
    """
    Build a complete engine_map from a list of registration specs.

    Each spec: (engine_name, raw_callable, context, artifact_behavior, registration_site)

    Returns engine_map ready for build_kernel_context(engine_map=...).
    Values are (ContractEnforcingWrapper, governance_dict) tuples.
    """
    engine_map = {}
    for engine_name, raw_callable, context, artifact_behavior, site in registrations:
        manifest, wrapped = register_engine(
            engine_name       = engine_name,
            raw_callable      = raw_callable,
            context           = context,
            artifact_behavior = artifact_behavior,
            registration_site = site,
            allow_reregister  = allow_reregister,
        )
        engine_map[manifest.engine_name] = (wrapped, manifest.to_governance_dict())
    return engine_map
