"""
Kernel Integration Validation
------------------------------
End-to-end test of the full kernel chain:

  FingerprintEngine → PhaseRegistry → ArtifactStore → CommitSystem
  → StateLoader → IRRegistry → KernelEngineRegistry → CapabilityResolver
  → PipelineDeterminismGuard → KernelPipelinePlanner
  → KernelGovernanceCompiler → KernelMPPExecutor

Every component must be reachable and functional.
Chain integrity is verified by commit log chain validation.

Run: python kernel_integration_validation.py
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

# Set up kernel path
KERNEL_ROOT = Path(__file__).parent.parent / "kernel"
for component_dir in KERNEL_ROOT.iterdir():
    if component_dir.is_dir():
        s = str(component_dir)
        if s not in sys.path:
            sys.path.insert(0, s)


from fingerprint_engine import FingerprintEngine, fingerprint
from phase_registry import PhaseRegistry, CANONICAL_PHASES
from artifact_store import ArtifactStore
from commit_system import CommitSystem
from state_loader import StateLoader, BootStatus
from ir_registry import IRRegistry
from engine_registry import KernelEngineRegistry
from capability_resolver import CapabilityResolver
from pipeline_determinism_guard import PipelineDeterminismGuard
from pipeline_planner import KernelPipelinePlanner
from governance_compiler import KernelGovernanceCompiler
from mpp_executor import KernelMPPExecutor


def run_tests(tmp: Path) -> dict:
    results = {}

    # ---- Test 1: FingerprintEngine ----
    try:
        fe = FingerprintEngine()
        fp1 = fe.fingerprint({"a": 1, "b": 2})
        fp2 = fe.fingerprint({"b": 2, "a": 1})
        assert fp1 == fp2, "fingerprint must be order-independent"
        assert fe.verify_pair({"a": 1, "b": 2}, fp1)
        results["fingerprint_engine"] = {"status": "PASS", "fingerprint": fp1[:16] + "..."}
    except Exception as e:
        results["fingerprint_engine"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 2: PhaseRegistry ----
    try:
        pr = PhaseRegistry()
        assert pr.is_valid("verification")
        assert not pr.is_valid("nonexistent_phase")
        sorted_phases = pr.sort_phases(["verification", "see", "mmd"])
        assert sorted_phases == ["see", "mmd", "verification"]
        assert pr.comes_before("see", "verification")
        results["phase_registry"] = {"status": "PASS", "canonical_phases": CANONICAL_PHASES}
    except Exception as e:
        results["phase_registry"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 3: ArtifactStore ----
    try:
        store = ArtifactStore(tmp / "artifact_store")
        receipt = store.store({"result": "test", "value": 42}, "test_engine", "verification", "test_intent")
        assert receipt.authoritative
        assert receipt.action == "stored"
        artifact_id = receipt.artifact_id

        # retrieve and verify
        loaded = store.retrieve(artifact_id)
        assert loaded["result"] == "test"

        # duplicate store is idempotent
        receipt2 = store.store({"result": "test", "value": 42}, "test_engine", "verification", "test_intent")
        assert receipt2.action == "duplicate_ok"
        assert receipt2.artifact_id == artifact_id

        results["artifact_store"] = {"status": "PASS", "artifact_id": artifact_id[:20] + "..."}
    except Exception as e:
        results["artifact_store"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 4: CommitSystem ----
    try:
        store4 = ArtifactStore(tmp / "commit_store")
        r = store4.store({"data": "commit_test"}, "eng", "verification", "intent")
        commits = CommitSystem(store4, tmp / "commit_log")

        commit1 = commits.commit([r.artifact_id], "eng", "verification", "intent")
        assert commit1.commit_index == 0
        assert commit1.parent_commit_hash == "0" * 64

        r2 = store4.store({"data": "second"}, "eng", "verification", "intent")
        commit2 = commits.commit([r2.artifact_id], "eng", "verification", "intent")
        assert commit2.commit_index == 1
        assert commit2.parent_commit_hash == commit1.commit_hash

        # chain integrity
        chain_violations = commits.verify_chain()
        assert chain_violations == [], f"chain violations: {chain_violations}"

        results["commit_system"] = {
            "status": "PASS",
            "commits": 2,
            "chain_ok": True,
        }
    except Exception as e:
        results["commit_system"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 5: StateLoader ----
    try:
        store5 = ArtifactStore(tmp / "sl_store")
        commits5 = CommitSystem(store5, tmp / "sl_commits")
        loader = StateLoader(store5, commits5, session_id="test-session-001")

        receipt = loader.boot()
        assert receipt.boot_status == BootStatus.BOOT_OK.value
        assert receipt.violations == []

        state = loader.require_booted()
        assert state.boot_status == BootStatus.BOOT_OK

        # second boot (new turn)
        receipt2 = loader.boot()
        assert receipt2.turn == 2

        results["state_loader"] = {
            "status": "PASS",
            "boot_status": receipt.boot_status,
            "state_fingerprint": receipt.state_fingerprint[:16] + "...",
        }
    except Exception as e:
        results["state_loader"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 6: KernelEngineRegistry + CapabilityResolver ----
    try:
        reg = KernelEngineRegistry()
        reg.register_from_dict(
            spec_dict={
                "engine_id": "test_engine",
                "version": "1.0",
                "purpose": "Test",
                "inputs": [],
                "outputs": [{"name": "result"}],
                "phases": ["verification"],
                "deterministic": True,
                "artifact_producing": True,
            },
            governance_dict={
                "requires_receipt": True,
                "receipt_enforcer": "mpp_executor",
                "fail_closed": True,
            },
        )
        assert "test_engine" in reg.list_engines()

        resolver = CapabilityResolver(reg)
        plan = resolver.resolve(
            "run_test",
            ["verification"],
            {"verification": ["test_engine"]},
        )
        assert plan.ok, f"resolve violations: {plan.violations}"
        assert plan.engine_attachments["verification"] == ["test_engine"]

        results["engine_registry_capability_resolver"] = {
            "status": "PASS",
            "resolved_phases": plan.phases,
        }
    except Exception as e:
        results["engine_registry_capability_resolver"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 7: PipelineDeterminismGuard ----
    try:
        reg7 = KernelEngineRegistry()
        reg7.register_from_dict(
            {"engine_id": "det_engine", "version": "1.0", "purpose": "Det",
             "inputs": [], "outputs": [{"name": "out"}], "phases": ["verification"],
             "deterministic": True, "artifact_producing": True},
            {"requires_receipt": False, "fail_closed": True},
        )
        guard = PipelineDeterminismGuard(reg7)

        class FakePlan:
            phases = [{"phase": "verification", "engines": ["det_engine"]}]

        report = guard.check(FakePlan())
        assert report.ok, f"guard violations: {report.violations}"

        # non-deterministic engine should fail
        reg7.register_from_dict(
            {"engine_id": "nondet", "version": "1.0", "purpose": "ND",
             "inputs": [], "outputs": [{"name": "x"}], "phases": ["verification"],
             "deterministic": False, "artifact_producing": False},
            {},
        )

        class FakePlan2:
            phases = [{"phase": "verification", "engines": ["nondet"]}]

        report2 = guard.check(FakePlan2())
        assert not report2.ok
        assert any("not_deterministic" in v for v in report2.violations)

        results["pipeline_determinism_guard"] = {"status": "PASS"}
    except Exception as e:
        results["pipeline_determinism_guard"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 8: KernelPipelinePlanner ----
    try:
        planner = KernelPipelinePlanner()
        plan = planner.create_plan(
            "run_test",
            ["verification", "see"],  # out of order intentionally
            {"see": ["collector"], "verification": ["checker"]},
        )
        assert plan.ok
        phase_names = [p["phase"] for p in plan.phases]
        assert phase_names == ["see", "verification"], f"Wrong order: {phase_names}"

        # unknown phase → violation
        bad_plan = planner.create_plan("bad", ["nonexistent_phase"], {})
        assert not bad_plan.ok

        results["kernel_pipeline_planner"] = {"status": "PASS", "ordered": phase_names}
    except Exception as e:
        results["kernel_pipeline_planner"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 9: KernelGovernanceCompiler ----
    try:
        compiler = KernelGovernanceCompiler(forbidden_engines=["bad_engine"])

        class GoodPlan:
            phases = [{"phase": "verification", "engines": ["good_engine"]}]

        class BadPlan:
            phases = [{"phase": "verification", "engines": ["bad_engine"]}]

        result_good = compiler.validate(GoodPlan())
        assert result_good.allowed

        result_bad = compiler.validate(BadPlan())
        assert not result_bad.allowed
        assert any("bad_engine" in v for v in result_bad.violations)

        results["governance_compiler"] = {"status": "PASS"}
    except Exception as e:
        results["governance_compiler"] = {"status": "FAIL", "error": str(e)}

    # ---- Test 10: Full Kernel Chain (KernelMPPExecutor) ----
    try:
        store10 = ArtifactStore(tmp / "exec_store")
        commits10 = CommitSystem(store10, tmp / "exec_commits")
        loader10 = StateLoader(store10, commits10, session_id="exec-session-001")
        loader10.boot()

        call_log = []

        def sample_engine():
            call_log.append("called")
            return {"engine": "sample", "value": 99, "deterministic": True}

        executor = KernelMPPExecutor(
            engine_map={
                "sample_engine": (sample_engine, {
                    "requires_receipt": True,
                    "receipt_enforcer": "mpp_executor",
                    "artifact_producing": True,
                }),
            },
            artifact_store=store10,
            commit_system=commits10,
            state_loader=loader10,
        )

        class ExecPlan:
            phases = [{"phase": "verification", "engines": ["sample_engine"]}]

        result = executor.execute(ExecPlan(), intent_type="run_sample")

        assert result.ok, f"exec failed: {result.failed_engines} {result.enforcer_violations}"
        assert len(result.artifact_ids) == 1
        assert result.commit_id is not None
        assert call_log == ["called"]

        # verify artifact is in store
        artifact = store10.retrieve(result.artifact_ids[0])
        assert artifact["value"] == 99

        # verify commit chain
        chain_ok = commits10.verify_chain() == []

        results["kernel_mpp_executor_full_chain"] = {
            "status": "PASS",
            "artifact_id": result.artifact_ids[0][:20] + "...",
            "commit_id": result.commit_id[:20] + "...",
            "chain_ok": chain_ok,
        }
    except Exception as e:
        results["kernel_mpp_executor_full_chain"] = {"status": "FAIL", "error": str(e)}

    return results


if __name__ == "__main__":
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        results = run_tests(tmp)

    passed = sum(1 for r in results.values() if r["status"] == "PASS")
    failed = sum(1 for r in results.values() if r["status"] == "FAIL")

    for name, result in results.items():
        status = result["status"]
        print(f"{status} {name}" + (f": {result.get('error')}" if status == "FAIL" else ""))

    print(f"\n{'='*50}")
    print(json.dumps({
        "all_pass": failed == 0,
        "passed": passed,
        "failed": failed,
        "total": len(results),
        "results": results,
    }, indent=2))
