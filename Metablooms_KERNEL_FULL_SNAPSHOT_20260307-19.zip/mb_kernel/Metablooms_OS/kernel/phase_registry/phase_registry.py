"""
Phase Registry
--------------
Single source of truth for canonical phase order in MetaBlooms OS.

Rule: Any component that needs to know what phases exist or what order
they run in MUST import from here. No component may hardcode phase names
or orderings independently.

This closes the gap identified in the external comparison:
  "Phase ordering is enforced in the pipeline_planner, but the canonical
   list itself lives as a local variable. The Phase Registry makes it
   a kernel-level authority."

CDR Pillar 2 (Explicit Constraint Mapping): phase constraints come from
one place, enforced by referential integrity.

Schema: MB-PHASE-REGISTRY-1.0
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

SCHEMA = "MB-PHASE-REGISTRY-1.0"

# The one canonical phase order. All pipeline components must use this.
CANONICAL_PHASES: list[str] = [
    "intent_intake",
    "see",
    "aca",
    "mmd",
    "verification",
    "commit",
]

# Phase index for O(1) order comparisons
_PHASE_INDEX: dict[str, int] = {phase: i for i, phase in enumerate(CANONICAL_PHASES)}


@dataclass(frozen=True)
class PhaseInfo:
    name: str
    index: int
    required: bool = False
    description: str = ""


# Phase metadata registry
_PHASE_METADATA: dict[str, PhaseInfo] = {
    "intent_intake": PhaseInfo("intent_intake", 0, required=True,
        description="Parse and classify user intent into a governed dispatch"),
    "see": PhaseInfo("see", 1, required=False,
        description="Evidence collection — gather facts before analysis"),
    "aca": PhaseInfo("aca", 2, required=False,
        description="Assumption and context analysis"),
    "mmd": PhaseInfo("mmd", 3, required=False,
        description="Multi-modal decomposition — break problem into governed subtasks"),
    "verification": PhaseInfo("verification", 4, required=False,
        description="Deterministic verification and artifact production"),
    "commit": PhaseInfo("commit", 5, required=False,
        description="Append-only commit of verified artifacts to the artifact store"),
}


class PhaseRegistryError(Exception):
    pass


class PhaseRegistry:
    """
    Canonical authority for phase names, ordering, and metadata.
    Stateless — all data is module-level constants.
    """

    schema = SCHEMA

    def is_valid(self, phase: str) -> bool:
        return phase in _PHASE_INDEX

    def index_of(self, phase: str) -> int:
        if phase not in _PHASE_INDEX:
            raise PhaseRegistryError(f"Unknown phase: '{phase}'")
        return _PHASE_INDEX[phase]

    def sort_phases(self, phases: list[str]) -> list[str]:
        """Sort a list of phase names into canonical order. Raises on unknown phases."""
        unknown = [p for p in phases if p not in _PHASE_INDEX]
        if unknown:
            raise PhaseRegistryError(f"Unknown phases: {unknown}")
        return sorted(phases, key=lambda p: _PHASE_INDEX[p])

    def validate_phases(self, phases: list[str]) -> list[str]:
        """Return list of violation strings. Empty = valid."""
        violations = []
        unknown = [p for p in phases if p not in _PHASE_INDEX]
        if unknown:
            violations.append(f"unknown_phases:{sorted(unknown)}")
        return violations

    def all_phases(self) -> list[str]:
        return list(CANONICAL_PHASES)

    def info(self, phase: str) -> PhaseInfo:
        if phase not in _PHASE_METADATA:
            raise PhaseRegistryError(f"Unknown phase: '{phase}'")
        return _PHASE_METADATA[phase]

    def comes_before(self, phase_a: str, phase_b: str) -> bool:
        """True if phase_a must run before phase_b in canonical order."""
        return self.index_of(phase_a) < self.index_of(phase_b)
