from phase_registry.phase_registry import PhaseRegistry, PhaseRegistryError, PhaseInfo, CANONICAL_PHASES
