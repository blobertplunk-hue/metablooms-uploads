"""
MB-MPP-REASONING — Reasoning Engine
-------------------------------------
Authority: Runtime extension layer. NOT a frozen kernel component.
Schema:    MB-MPP-REASONING-1.0

Purpose:
    Pre-execution reasoning gate. Implements the REASONING_MPP stage that sits
    between pipeline_planner and governance_compiler in the kernel execution path.

    Execution is blocked if reasoning artifacts are missing or invalid.
    All reasoning artifacts are stored via artifact_store + commit_system.
    No hidden reasoning. No ephemeral state.

Pipeline position:
    intent
    → capability_resolver
    → pipeline_planner
    → [THIS MODULE] REASONING_MPP
    → governance_compiler
    → kernel_mpp_executor
    → artifact_store
    → commit_system

Reasoning phases (R1-R6):
    R1 intent_analysis       — what is actually being asked, what layer it touches
    R2 task_decomposition    — break into atomic subtasks with dependencies
    R3 architecture_planning — which components are touched, what constraints apply
    R4 multi_path_reasoning  — Tree-of-Thought: 2-3 candidate approaches
    R5 critic_review         — constraint check each approach, eliminate FAIL, flag WARN
    R6 execution_plan        — select surviving approach, produce executable plan

Artifacts produced (all go into artifact_store):
    analysis_report.json
    decomposition_plan.json
    architecture_options.json
    reasoning_tree.json
    critic_report.json
    execution_plan.json

Failure semantics:
    fail-closed — if any phase fails or any required artifact is missing,
    reasoning_result.valid is False and execution is blocked.
    No silent continuation on reasoning failure.

Constraint check (R5 hard gates — any FAIL eliminates an approach):
    WRITE_PATH        — state writes go through artifact_store + commit_system
    FAIL_CLOSED       — explicit failure handling, no bare except
    NO_SILENT_STATE   — every write is read-back verified before authoritative
    KERNEL_PATH       — frozen call sequence is not bypassed or reordered
    IMPORT_PLACEMENT  — all imports at module top level

Legacy impact:
    Replaces the advisory system-prompt approach to pre-execution reasoning.
    Prompt-based reasoning was advisory. MPP stage reasoning is enforced law.
    Execution cannot proceed without a valid reasoning_result.
"""

from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Optional

# Kernel imports — must already be on sys.path via KernelContext
from artifact_store import ArtifactStore, StoreReceipt
from commit_system import CommitSystem
from fingerprint_engine import fingerprint, canonical_json

SCHEMA = "MB-MPP-REASONING-1.0"
_SELF_ID = "reasoning_engine"

# ── Constraint identifiers ───────────────────────────────────────────────────

HARD_CONSTRAINTS = [
    "WRITE_PATH",
    "FAIL_CLOSED",
    "NO_SILENT_STATE",
    "KERNEL_PATH",
    "IMPORT_PLACEMENT",
]

SOFT_CONSTRAINTS = [
    "ECL_HEADER",
    "ORPHAN_ARTIFACT_GAP",
    "DETERMINISM",
]

FROZEN_CALL_SEQUENCE = [
    "capability_resolver",
    "pipeline_planner",
    "governance_compiler",
    "kernel_mpp_executor",
    "artifact_store",
    "commit_system",
]

# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class ConstraintResult:
    constraint_id: str
    status: str          # "PASS" | "FAIL" | "WARN" | "SKIP"
    detail: str


@dataclass
class ApproachOption:
    option_id: str       # "A", "B", "C"
    description: str
    components_touched: list[str]
    primary_risk: str
    constraint_results: list[ConstraintResult] = field(default_factory=list)
    eliminated: bool = False
    elimination_reason: str = ""

    @property
    def hard_fail_count(self) -> int:
        return sum(
            1 for c in self.constraint_results
            if c.status == "FAIL" and c.constraint_id in HARD_CONSTRAINTS
        )


@dataclass
class ReasoningPhaseResult:
    phase: str
    ok: bool
    artifact: dict
    artifact_id: Optional[str] = None
    error: Optional[str] = None


@dataclass
class ReasoningResult:
    valid: bool
    reasoning_run_id: str
    phases: list[ReasoningPhaseResult]
    selected_approach: Optional[ApproachOption]
    execution_plan: Optional[dict]
    artifact_ids: list[str]
    commit_id: Optional[str]
    block_reason: Optional[str] = None
    dag_artifact_id: Optional[str] = None   # artifact_id of MB_REASONING_DAG committed artifact
    dag_id: Optional[str] = None            # dag_id from ReasoningDAG

    def to_receipt(self) -> dict:
        return {
            "schema": SCHEMA,
            "reasoning_run_id": self.reasoning_run_id,
            "valid": self.valid,
            "block_reason": self.block_reason,
            "selected_approach": self.selected_approach.option_id
                if self.selected_approach else None,
            "artifact_ids": self.artifact_ids,
            "commit_id": self.commit_id,
            "dag_artifact_id": self.dag_artifact_id,
            "dag_id": self.dag_id,
            "phase_summary": [
                {"phase": p.phase, "ok": p.ok, "artifact_id": p.artifact_id}
                for p in self.phases
            ],
        }


# ── Constraint checkers ──────────────────────────────────────────────────────

class ConstraintChecker:
    """
    Applies MetaBlooms hard and soft constraints to an approach description.

    Each check is a heuristic over the approach's declared properties.
    For code validation, the checker examines the approach description and
    component list — not AST analysis (that's the write scanner's job).
    """

    def check_approach(self, approach: ApproachOption) -> list[ConstraintResult]:
        results: list[ConstraintResult] = []
        desc = approach.description.lower()
        comps = [c.lower() for c in approach.components_touched]

        # HARD: WRITE_PATH
        write_bypass_signals = [
            "open(", "write_text", "json.dump", "writelines",
            "direct file", "direct write", "write directly",
        ]
        has_bypass = any(s in desc for s in write_bypass_signals)
        has_kernel_write = any(
            c in comps for c in ["artifact_store", "commit_system"]
        ) or "artifact_store" in desc or "commit_system" in desc
        if has_bypass and not has_kernel_write:
            results.append(ConstraintResult(
                "WRITE_PATH", "FAIL",
                "Approach uses direct file writes without routing through "
                "artifact_store + commit_system.",
            ))
        else:
            results.append(ConstraintResult(
                "WRITE_PATH", "PASS",
                "No direct write bypass detected in approach description.",
            ))

        # HARD: FAIL_CLOSED
        silent_signals = ["silent", "ignore error", "pass on error", "continue on fail"]
        if any(s in desc for s in silent_signals):
            results.append(ConstraintResult(
                "FAIL_CLOSED", "FAIL",
                "Approach description suggests silent error handling.",
            ))
        else:
            results.append(ConstraintResult(
                "FAIL_CLOSED", "PASS",
                "No silent failure pattern detected.",
            ))

        # HARD: NO_SILENT_STATE
        if has_bypass and not has_kernel_write:
            results.append(ConstraintResult(
                "NO_SILENT_STATE", "FAIL",
                "Approach creates state without read-back verification chain.",
            ))
        else:
            results.append(ConstraintResult(
                "NO_SILENT_STATE", "PASS",
                "State write path includes verification.",
            ))

        # HARD: KERNEL_PATH
        frozen_components = {
            "artifact_store", "commit_system", "state_loader",
            "fingerprint_engine", "phase_registry", "ir_registry",
            "pipeline_planner", "pipeline_determinism_guard",
            "governance_compiler", "mpp_executor", "engine_registry",
            "capability_resolver", "kernel_context",
        }
        modifies_frozen = any(
            c.replace("_", " ") in desc or c in comps
            for c in frozen_components
            if "modify" in desc or "change interface" in desc or "replace" in desc
        )
        bypasses_sequence = (
            "bypass governance" in desc or
            "skip governance" in desc or
            "direct to executor" in desc
        )
        if modifies_frozen or bypasses_sequence:
            results.append(ConstraintResult(
                "KERNEL_PATH", "FAIL",
                "Approach modifies a frozen kernel component or bypasses "
                "the canonical call sequence.",
            ))
        else:
            results.append(ConstraintResult(
                "KERNEL_PATH", "PASS",
                "No frozen component modification or sequence bypass detected.",
            ))

        # HARD: IMPORT_PLACEMENT
        buried_import_signals = [
            "import inside", "lazy import", "import within function",
            "conditional import",
        ]
        if any(s in desc for s in buried_import_signals) and "documented" not in desc:
            results.append(ConstraintResult(
                "IMPORT_PLACEMENT", "WARN",
                "Approach may use non-top-level imports. Acceptable only if "
                "explicitly documented as lazy-load pattern.",
            ))
        else:
            results.append(ConstraintResult(
                "IMPORT_PLACEMENT", "PASS",
                "Import placement appears correct.",
            ))

        # SOFT: ECL_HEADER
        if "docstring" not in desc and "ecl header" not in desc and "module doc" not in desc:
            results.append(ConstraintResult(
                "ECL_HEADER", "WARN",
                "Approach does not mention ECL header / module docstring. "
                "Required: authority, constraints, failure intent, legacy impact.",
            ))
        else:
            results.append(ConstraintResult("ECL_HEADER", "PASS", "ECL header planned."))

        # SOFT: ORPHAN_ARTIFACT_GAP
        if "partial" in desc and "orphan" not in desc and "rollback" not in desc:
            results.append(ConstraintResult(
                "ORPHAN_ARTIFACT_GAP", "WARN",
                "Approach involves partial execution but does not mention "
                "orphaned artifact tracking.",
            ))
        else:
            results.append(ConstraintResult(
                "ORPHAN_ARTIFACT_GAP", "PASS",
                "No partial execution gap detected.",
            ))

        # SOFT: DETERMINISM
        if "hash" in desc or "sha" in desc or "fingerprint" in desc:
            if "sort_keys" not in desc and "canonical_json" not in desc:
                results.append(ConstraintResult(
                    "DETERMINISM", "WARN",
                    "Approach uses hashing but does not mention canonical JSON "
                    "(sort_keys=True). Non-deterministic serialization breaks hash stability.",
                ))
            else:
                results.append(ConstraintResult(
                    "DETERMINISM", "PASS",
                    "Canonical JSON mentioned.",
                ))
        else:
            results.append(ConstraintResult(
                "DETERMINISM", "SKIP",
                "No hashing in this approach.",
            ))

        return results


# ── Reasoning Engine ─────────────────────────────────────────────────────────

class ReasoningEngine:
    """
    Implements the MB-MPP-REASONING stage.

    Usage:
        engine = ReasoningEngine(artifact_store, commit_system)
        result = engine.reason(intent, context, approaches)

        if not result.valid:
            raise ExecutionBlocked(result.block_reason)

        # Pass result.execution_plan to governance_compiler
    """

    schema = SCHEMA

    def __init__(
        self,
        artifact_store: ArtifactStore,
        commit_system: CommitSystem,
        llm_caller: Optional[Callable[[str, dict], dict]] = None,
    ):
        """
        artifact_store: kernel ArtifactStore instance
        commit_system:  kernel CommitSystem instance
        llm_caller:     optional callable(phase_name, context) → dict
                        If None, reasoning runs in structural-only mode —
                        generates schema-valid artifacts from provided context
                        without calling an LLM. Useful for testing and for
                        cases where the LLM reasoning is done externally
                        (e.g., by the GPT system prompt) and the result is
                        passed in as structured context.
        """
        self.store = artifact_store
        self.commits = commit_system
        self.llm_caller = llm_caller
        self.checker = ConstraintChecker()

    def reason(
        self,
        intent: str,
        context: dict,
        approaches: Optional[list[dict]] = None,
    ) -> ReasoningResult:
        """
        Run the full R1-R6 reasoning pipeline.

        intent:     natural language or structured intent string
        context:    dict containing any of:
                    - component (str): which component is being touched
                    - layer (str): "kernel" | "runtime" | "engine"
                    - creates_state (bool)
                    - additional domain context
        approaches: optional list of pre-formed approach dicts (for cases where
                    the LLM reasoning was done externally and results are passed in)
                    Each dict: {option_id, description, components_touched, primary_risk}
                    If None, reasoning engine generates approaches from context.

        Returns ReasoningResult. result.valid == False blocks execution.
        """
        run_id = fingerprint({
            "intent": intent,
            "context": context,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        phase_results: list[ReasoningPhaseResult] = []
        artifact_ids: list[str] = []

        # ── R1: Intent Analysis ──────────────────────────────────────────────
        r1 = self._r1_intent_analysis(intent, context, run_id)
        phase_results.append(r1)
        if r1.artifact_id:
            artifact_ids.append(r1.artifact_id)
        if not r1.ok:
            return self._blocked(run_id, "R1 intent_analysis failed", phase_results,
                                 artifact_ids, None)

        # ── R2: Task Decomposition ───────────────────────────────────────────
        r2 = self._r2_task_decomposition(intent, context, r1.artifact, run_id)
        phase_results.append(r2)
        if r2.artifact_id:
            artifact_ids.append(r2.artifact_id)
        if not r2.ok:
            return self._blocked(run_id, "R2 task_decomposition failed", phase_results,
                                 artifact_ids, None)

        # ── R3: Architecture Planning ────────────────────────────────────────
        r3 = self._r3_architecture_planning(intent, context, r1.artifact, r2.artifact, run_id)
        phase_results.append(r3)
        if r3.artifact_id:
            artifact_ids.append(r3.artifact_id)
        if not r3.ok:
            return self._blocked(run_id, "R3 architecture_planning failed", phase_results,
                                 artifact_ids, None)

        # ── R4: Multi-Path Reasoning (Tree-of-Thought) ───────────────────────
        r4 = self._r4_multi_path_reasoning(
            intent, context, approaches, r1.artifact, r3.artifact, run_id
        )
        phase_results.append(r4)
        if r4.artifact_id:
            artifact_ids.append(r4.artifact_id)
        if not r4.ok:
            return self._blocked(run_id, "R4 multi_path_reasoning failed", phase_results,
                                 artifact_ids, None)

        approach_options: list[ApproachOption] = r4.artifact.get("_approach_objects", [])

        # ── R5: Critic Review ────────────────────────────────────────────────
        r5 = self._r5_critic_review(approach_options, run_id)
        phase_results.append(r5)
        if r5.artifact_id:
            artifact_ids.append(r5.artifact_id)

        surviving = [a for a in approach_options if not a.eliminated]
        if not surviving:
            return self._blocked(
                run_id,
                "R5 critic_review: all approaches eliminated by hard constraint failures. "
                "No valid implementation path found.",
                phase_results, artifact_ids, None,
            )

        selected = surviving[0]  # highest-surviving approach (first non-eliminated)

        # ── R6: Execution Plan ───────────────────────────────────────────────
        r6 = self._r6_execution_plan(selected, intent, context, run_id)
        phase_results.append(r6)
        if r6.artifact_id:
            artifact_ids.append(r6.artifact_id)
        if not r6.ok:
            return self._blocked(run_id, "R6 execution_plan failed", phase_results,
                                 artifact_ids, selected)

        # ── Build and store Reasoning DAG ────────────────────────────────────
        # Construct the DAG from phase artifacts and commit it before the
        # final run commit. This makes the DAG a first-class artifact in the
        # reasoning run's commit chain.
        dag_artifact_id = None
        dag_id_str = None
        try:
            import sys as _sys
            from pathlib import Path as _Path
            _dag_mod = _sys.modules.get("reasoning_dag_builder")
            if _dag_mod is None:
                import importlib.util as _ilu
                _dag_path = _Path(__file__).resolve().parent / "reasoning_dag_builder.py"
                _spec = _ilu.spec_from_file_location("reasoning_dag_builder", _dag_path)
                _dag_mod = _ilu.module_from_spec(_spec)
                _sys.modules["reasoning_dag_builder"] = _dag_mod
                _spec.loader.exec_module(_dag_mod)

            # Collect phase artifacts by phase name
            phase_artifact_map = {p.phase: p.artifact for p in phase_results}

            dag = _dag_mod.ReasoningDAGBuilder().build(
                run_id=run_id,
                intent=intent,
                phase_artifacts=phase_artifact_map,
            )
            dag_dict = dag.to_dict()
            dag_receipt = self.store.store(
                dag_dict, _SELF_ID, "verification", "reasoning_dag"
            )
            dag_artifact_id = dag_receipt.artifact_id
            dag_id_str = dag.dag_id
            artifact_ids.append(dag_artifact_id)
        except Exception:
            # DAG build failure is non-fatal — reasoning result is still valid.
            # The missing dag_artifact_id is surfaced in the receipt for the
            # reflector to flag as a MEDIUM finding.
            pass

        # ── Commit all reasoning artifacts ───────────────────────────────────
        try:
            commit = self.commits.commit(
                artifact_ids=artifact_ids,
                engine_id=_SELF_ID,
                phase="verification",
                intent=f"reasoning_mpp:{intent[:80]}",
            )
            commit_id = commit.commit_id
        except Exception as e:
            return self._blocked(
                run_id, f"Reasoning commit failed: {e}",
                phase_results, artifact_ids, selected,
            )

        return ReasoningResult(
            valid=True,
            reasoning_run_id=run_id,
            phases=phase_results,
            selected_approach=selected,
            execution_plan=r6.artifact,
            artifact_ids=artifact_ids,
            commit_id=commit_id,
            dag_artifact_id=dag_artifact_id,
            dag_id=dag_id_str,
        )

    # ── Phase implementations ────────────────────────────────────────────────

    def _r1_intent_analysis(
        self, intent: str, context: dict, run_id: str
    ) -> ReasoningPhaseResult:
        try:
            if self.llm_caller:
                artifact = self.llm_caller("intent_analysis", {
                    "intent": intent, "context": context
                })
            else:
                artifact = {
                    "schema": "MB-MPP-R1-1.0",
                    "phase": "intent_analysis",
                    "run_id": run_id,
                    "intent": intent,
                    "component": context.get("component", "unknown"),
                    "layer": context.get("layer", "unknown"),
                    "creates_state": context.get("creates_state", None),
                    "summary": f"Intent: {intent[:200]}",
                }
            receipt = self.store.store(artifact, _SELF_ID, "verification", "reasoning_r1")
            return ReasoningPhaseResult(
                phase="intent_analysis", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return ReasoningPhaseResult(
                phase="intent_analysis", ok=False,
                artifact={}, error=str(e),
            )

    def _r2_task_decomposition(
        self, intent: str, context: dict, r1: dict, run_id: str
    ) -> ReasoningPhaseResult:
        try:
            if self.llm_caller:
                artifact = self.llm_caller("task_decomposition", {
                    "intent": intent, "context": context, "analysis": r1
                })
            else:
                artifact = {
                    "schema": "MB-MPP-R2-1.0",
                    "phase": "task_decomposition",
                    "run_id": run_id,
                    "subtasks": [
                        {"id": "T1", "description": intent, "dependencies": []},
                    ],
                    "atomic": True,
                }
            receipt = self.store.store(artifact, _SELF_ID, "verification", "reasoning_r2")
            return ReasoningPhaseResult(
                phase="task_decomposition", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return ReasoningPhaseResult(
                phase="task_decomposition", ok=False,
                artifact={}, error=str(e),
            )

    def _r3_architecture_planning(
        self, intent: str, context: dict, r1: dict, r2: dict, run_id: str
    ) -> ReasoningPhaseResult:
        try:
            if self.llm_caller:
                artifact = self.llm_caller("architecture_planning", {
                    "intent": intent, "context": context, "analysis": r1, "decomposition": r2
                })
            else:
                artifact = {
                    "schema": "MB-MPP-R3-1.0",
                    "phase": "architecture_planning",
                    "run_id": run_id,
                    "layer": context.get("layer", "unknown"),
                    "components_in_scope": context.get("components_in_scope", []),
                    "frozen_components_touched": context.get("frozen_components_touched", []),
                    "kernel_path_preserved": True,
                    "write_path_required": context.get("creates_state", False),
                    "constraints_applicable": HARD_CONSTRAINTS + SOFT_CONSTRAINTS,
                    "frozen_call_sequence": FROZEN_CALL_SEQUENCE,
                }
            receipt = self.store.store(artifact, _SELF_ID, "verification", "reasoning_r3")
            return ReasoningPhaseResult(
                phase="architecture_planning", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return ReasoningPhaseResult(
                phase="architecture_planning", ok=False,
                artifact={}, error=str(e),
            )

    def _r4_multi_path_reasoning(
        self,
        intent: str,
        context: dict,
        approaches: Optional[list[dict]],
        r1: dict,
        r3: dict,
        run_id: str,
    ) -> ReasoningPhaseResult:
        try:
            option_dicts: list[dict]
            if self.llm_caller and not approaches:
                result = self.llm_caller("multi_path_reasoning", {
                    "intent": intent, "context": context, "analysis": r1, "architecture": r3
                })
                option_dicts = result.get("approaches", [])
            else:
                option_dicts = approaches or [{
                    "option_id": "A",
                    "description": intent,
                    "components_touched": context.get("components_in_scope", []),
                    "primary_risk": "unknown — single approach provided",
                }]

            approach_objects = [
                ApproachOption(
                    option_id=a.get("option_id", f"OPT{i}"),
                    description=a.get("description", ""),
                    components_touched=a.get("components_touched", []),
                    primary_risk=a.get("primary_risk", ""),
                )
                for i, a in enumerate(option_dicts)
            ]

            artifact = {
                "schema": "MB-MPP-R4-1.0",
                "phase": "multi_path_reasoning",
                "run_id": run_id,
                "approach_count": len(approach_objects),
                "approaches": [
                    {
                        "option_id": a.option_id,
                        "description": a.description,
                        "components_touched": a.components_touched,
                        "primary_risk": a.primary_risk,
                    }
                    for a in approach_objects
                ],
                "_approach_objects": approach_objects,  # in-memory only, not stored
            }
            # Remove non-serializable before storing
            storable = {k: v for k, v in artifact.items() if k != "_approach_objects"}
            receipt = self.store.store(storable, _SELF_ID, "verification", "reasoning_r4")
            artifact["_approach_objects"] = approach_objects  # re-attach after store

            return ReasoningPhaseResult(
                phase="multi_path_reasoning", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return ReasoningPhaseResult(
                phase="multi_path_reasoning", ok=False,
                artifact={}, error=str(e),
            )

    def _r5_critic_review(
        self, approaches: list[ApproachOption], run_id: str
    ) -> ReasoningPhaseResult:
        try:
            for approach in approaches:
                approach.constraint_results = self.checker.check_approach(approach)
                if approach.hard_fail_count > 0:
                    approach.eliminated = True
                    fails = [
                        c.constraint_id for c in approach.constraint_results
                        if c.status == "FAIL" and c.constraint_id in HARD_CONSTRAINTS
                    ]
                    approach.elimination_reason = f"HARD CONSTRAINT FAIL: {', '.join(fails)}"

            artifact = {
                "schema": "MB-MPP-R5-1.0",
                "phase": "critic_review",
                "run_id": run_id,
                "approaches_reviewed": len(approaches),
                "approaches_surviving": sum(1 for a in approaches if not a.eliminated),
                "approaches_eliminated": sum(1 for a in approaches if a.eliminated),
                "results": [
                    {
                        "option_id": a.option_id,
                        "eliminated": a.eliminated,
                        "elimination_reason": a.elimination_reason,
                        "constraint_results": [
                            {
                                "constraint_id": c.constraint_id,
                                "status": c.status,
                                "detail": c.detail,
                            }
                            for c in a.constraint_results
                        ],
                    }
                    for a in approaches
                ],
            }
            receipt = self.store.store(artifact, _SELF_ID, "verification", "reasoning_r5")
            return ReasoningPhaseResult(
                phase="critic_review", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return ReasoningPhaseResult(
                phase="critic_review", ok=False,
                artifact={}, error=str(e),
            )

    def _r6_execution_plan(
        self, selected: ApproachOption, intent: str, context: dict, run_id: str
    ) -> ReasoningPhaseResult:
        try:
            warns = [
                c for c in selected.constraint_results if c.status == "WARN"
            ]
            artifact = {
                "schema": "MB-MPP-R6-1.0",
                "phase": "execution_plan",
                "run_id": run_id,
                "selected_approach": selected.option_id,
                "approach_description": selected.description,
                "components_touched": selected.components_touched,
                "intent": intent,
                "layer": context.get("layer", "unknown"),
                "creates_state": context.get("creates_state", False),
                "write_path": "artifact_store.store() → commit_system.commit()"
                    if context.get("creates_state", False) else "read-only",
                "warn_items": [
                    {"constraint_id": w.constraint_id, "detail": w.detail}
                    for w in warns
                ],
                "execution_approved": True,
                "frozen_call_sequence_preserved": FROZEN_CALL_SEQUENCE,
            }
            receipt = self.store.store(artifact, _SELF_ID, "verification", "reasoning_r6")
            return ReasoningPhaseResult(
                phase="execution_plan", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return ReasoningPhaseResult(
                phase="execution_plan", ok=False,
                artifact={}, error=str(e),
            )

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _blocked(
        self,
        run_id: str,
        reason: str,
        phases: list[ReasoningPhaseResult],
        artifact_ids: list[str],
        selected: Optional[ApproachOption],
    ) -> ReasoningResult:
        """Produce a blocked (invalid) reasoning result. Fail-closed."""
        # Still commit whatever artifacts were produced — for audit trail
        commit_id = None
        if artifact_ids:
            try:
                commit = self.commits.commit(
                    artifact_ids=artifact_ids,
                    engine_id=_SELF_ID,
                    phase="verification",
                    intent="reasoning_mpp:BLOCKED",
                )
                commit_id = commit.commit_id
            except Exception:
                pass  # commit failure on a blocked run: acceptable, already failing

        return ReasoningResult(
            valid=False,
            reasoning_run_id=run_id,
            phases=phases,
            selected_approach=selected,
            execution_plan=None,
            artifact_ids=artifact_ids,
            commit_id=commit_id,
            block_reason=reason,
        )

    def export_to_kernel(
        self, result: ReasoningResult
    ) -> dict:
        """
        Store the full reasoning result receipt in artifact_store + commit_system.
        Returns dict with artifact_id and commit_id.
        This is separate from the per-phase stores — it stores the summary receipt.
        """
        receipt_data = result.to_receipt()
        store_receipt = self.store.store(
            receipt_data, _SELF_ID, "commit", "reasoning_mpp_receipt"
        )
        commit = self.commits.commit(
            artifact_ids=[store_receipt.artifact_id],
            engine_id=_SELF_ID,
            phase="commit",
            intent="reasoning_mpp_receipt",
        )
        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "authoritative": store_receipt.authoritative,
            "reasoning_run_id": result.reasoning_run_id,
            "valid": result.valid,
        }
