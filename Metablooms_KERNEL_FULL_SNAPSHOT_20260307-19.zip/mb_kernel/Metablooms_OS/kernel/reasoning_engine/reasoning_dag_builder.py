"""
ReasoningDAGBuilder — Reasoning Engine sub-module
---------------------------------------------------
Authority: Runtime extension layer. Sub-module of reasoning_engine.
Schema:    MB-REASONING-DAG-1.0

Purpose:
    Constructs a directed acyclic graph from the six reasoning phase artifacts
    (R1-R6) produced by ReasoningEngine. The DAG makes the internal structure
    of each reasoning run explicit, inspectable, and replayable.

    Previously the execution graph showed reasoning_engine as a single opaque
    node. The Reasoning DAG exposes the internal phase topology:

        intent → R1 → R2 → R3(branches) → R4(evaluations) → R5(critic) → R6(plan)

    The DAG is committed to artifact_store as MB_REASONING_DAG_v1.json.
    Governance compiler can validate DAG presence and structural integrity.
    Reflector engine consumes the DAG to detect reasoning quality issues.

Node types:
    intent          — the source intent string
    constraint      — a hard or soft constraint from R3
    decomposition   — a subtask from R2
    option          — a candidate approach from R4 (Tree-of-Thought branch)
    evaluation      — constraint check results for an option (from R5)
    critic_finding  — individual R5 constraint result (PASS/FAIL/WARN)
    risk            — a risk identified in an option's primary_risk field
    execution_plan  — the R6 final plan node (single, selected approach)
    phase_summary   — summary node for each R1-R6 phase

Edge types:
    derived_from    — node was produced from another node
    depends_on      — phase depends on prior phase output
    evaluates       — evaluation node evaluates an option
    eliminates      — critic finding eliminates an approach
    supports        — finding supports an approach surviving
    selects         — execution plan selects a surviving approach
    contains        — phase_summary contains its sub-nodes

Determinism invariant:
    Given identical phase artifacts, DAG construction is deterministic.
    Node IDs are derived from content hashes — same content = same ID.
    Edge set is fully determined by phase artifact content.

Failure semantics:
    If any required phase artifact is missing or malformed, the builder
    returns a partial DAG with integrity_ok=False and a list of missing_phases.
    A partial DAG is stored and committed — it is not silently discarded.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

SCHEMA = "MB-REASONING-DAG-1.0"

PHASE_ORDER = [
    "R1_intent_analysis",
    "R2_task_decomposition",
    "R3_architecture_planning",
    "R4_multi_path_reasoning",
    "R5_critic_review",
    "R6_execution_plan",
]

# Node type constants
NT_INTENT        = "intent"
NT_CONSTRAINT    = "constraint"
NT_DECOMPOSITION = "decomposition"
NT_OPTION        = "option"
NT_EVALUATION    = "evaluation"
NT_CRITIC        = "critic_finding"
NT_RISK          = "risk"
NT_PLAN          = "execution_plan"
NT_PHASE         = "phase_summary"

# Edge type constants
ET_DERIVED_FROM  = "derived_from"
ET_DEPENDS_ON    = "depends_on"
ET_EVALUATES     = "evaluates"
ET_ELIMINATES    = "eliminates"
ET_SUPPORTS      = "supports"
ET_SELECTS       = "selects"
ET_CONTAINS      = "contains"


def _node_id(prefix: str, content: Any) -> str:
    """Deterministic node ID from prefix + content hash."""
    content_str = json.dumps(content, sort_keys=True) if not isinstance(content, str) else content
    h = hashlib.sha256(content_str.encode()).hexdigest()[:12]
    return f"{prefix}.{h}"


@dataclass
class DAGNode:
    node_id: str
    node_type: str
    phase: str
    content: dict
    label: str = ""

    def to_dict(self) -> dict:
        return {
            "node_id": self.node_id,
            "node_type": self.node_type,
            "phase": self.node_type,  # kept for backward compat
            "phase_label": self.phase,
            "label": self.label,
            "content": self.content,
        }


@dataclass
class DAGEdge:
    from_node: str
    to_node: str
    relation: str
    label: str = ""

    def to_dict(self) -> dict:
        return {
            "from": self.from_node,
            "to": self.to_node,
            "relation": self.relation,
            "label": self.label,
        }


@dataclass
class ReasoningDAG:
    dag_id: str
    source_intent: str
    generated_utc: str
    nodes: list[DAGNode]
    edges: list[DAGEdge]
    selected_plan_node: Optional[str]
    integrity_ok: bool
    missing_phases: list[str]
    metrics: dict  # computed graph metrics

    def to_dict(self) -> dict:
        return {
            "schema": SCHEMA,
            "dag_id": self.dag_id,
            "generated_utc": self.generated_utc,
            "source_intent": self.source_intent,
            "phase_order": PHASE_ORDER,
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "selected_plan_node": self.selected_plan_node,
            "integrity_ok": self.integrity_ok,
            "missing_phases": self.missing_phases,
            "metrics": self.metrics,
            "nodes": [n.to_dict() for n in self.nodes],
            "edges": [e.to_dict() for e in self.edges],
        }


class ReasoningDAGBuilder:
    """
    Constructs a ReasoningDAG from the six phase artifacts produced by
    ReasoningEngine.reason().

    Usage:
        builder = ReasoningDAGBuilder()
        dag = builder.build(
            run_id=reasoning_result.reasoning_run_id,
            intent=intent_string,
            phase_artifacts={
                "intent_analysis": r1_artifact,
                "task_decomposition": r2_artifact,
                "architecture_planning": r3_artifact,
                "multi_path_reasoning": r4_artifact,
                "critic_review": r5_artifact,
                "execution_plan": r6_artifact,
            }
        )
        dag_dict = dag.to_dict()
    """

    def build(
        self,
        run_id: str,
        intent: str,
        phase_artifacts: dict[str, dict],
    ) -> ReasoningDAG:
        nodes: list[DAGNode] = []
        edges: list[DAGEdge] = []
        missing_phases: list[str] = []

        # ── Spine: phase_summary nodes + depends_on chain ────────────────────
        phase_map = {
            "intent_analysis":      "R1_intent_analysis",
            "task_decomposition":   "R2_task_decomposition",
            "architecture_planning":"R3_architecture_planning",
            "multi_path_reasoning": "R4_multi_path_reasoning",
            "critic_review":        "R5_critic_review",
            "execution_plan":       "R6_execution_plan",
        }
        phase_nodes = {}
        prev_phase_node_id = None
        for artifact_key, phase_label in phase_map.items():
            artifact = phase_artifacts.get(artifact_key, {})
            if not artifact:
                missing_phases.append(phase_label)
            node_id = _node_id(f"phase.{artifact_key}", run_id + artifact_key)
            pnode = DAGNode(
                node_id=node_id,
                node_type=NT_PHASE,
                phase=phase_label,
                content={"phase": phase_label, "artifact_present": bool(artifact)},
                label=phase_label,
            )
            nodes.append(pnode)
            phase_nodes[artifact_key] = node_id
            if prev_phase_node_id:
                edges.append(DAGEdge(prev_phase_node_id, node_id, ET_DEPENDS_ON))
            prev_phase_node_id = node_id

        # ── R1: Intent node ──────────────────────────────────────────────────
        r1 = phase_artifacts.get("intent_analysis", {})
        intent_node_id = _node_id("r1.intent", intent)
        nodes.append(DAGNode(
            node_id=intent_node_id,
            node_type=NT_INTENT,
            phase="R1_intent_analysis",
            content={
                "intent": r1.get("intent", intent),
                "component": r1.get("component", "unknown"),
                "layer": r1.get("layer", "unknown"),
                "creates_state": r1.get("creates_state"),
            },
            label=f"intent:{intent[:40]}",
        ))
        edges.append(DAGEdge(phase_nodes["intent_analysis"], intent_node_id, ET_CONTAINS))

        # ── R2: Decomposition nodes ──────────────────────────────────────────
        r2 = phase_artifacts.get("task_decomposition", {})
        subtasks = r2.get("subtasks", [])
        prev_subtask_id = intent_node_id
        for subtask in subtasks:
            st_id = _node_id("r2.subtask", subtask)
            nodes.append(DAGNode(
                node_id=st_id,
                node_type=NT_DECOMPOSITION,
                phase="R2_task_decomposition",
                content=subtask,
                label=subtask.get("description", str(subtask))[:50],
            ))
            edges.append(DAGEdge(intent_node_id, st_id, ET_DERIVED_FROM))
            edges.append(DAGEdge(phase_nodes["task_decomposition"], st_id, ET_CONTAINS))

        # ── R3: Constraint nodes ─────────────────────────────────────────────
        r3 = phase_artifacts.get("architecture_planning", {})
        constraints = r3.get("constraints_applicable", [])
        for constraint_name in constraints[:5]:  # cap at 5 to keep graph readable
            c_id = _node_id("r3.constraint", constraint_name)
            nodes.append(DAGNode(
                node_id=c_id,
                node_type=NT_CONSTRAINT,
                phase="R3_architecture_planning",
                content={
                    "constraint": constraint_name,
                    "layer": r3.get("layer", "unknown"),
                    "kernel_path_preserved": r3.get("kernel_path_preserved", True),
                },
                label=f"constraint:{constraint_name}",
            ))
            edges.append(DAGEdge(phase_nodes["architecture_planning"], c_id, ET_CONTAINS))

        # ── R4: Option nodes ─────────────────────────────────────────────────
        r4 = phase_artifacts.get("multi_path_reasoning", {})
        approaches = r4.get("approaches", [])
        option_node_ids = {}
        for approach in approaches:
            opt_id = _node_id("r4.option", approach.get("option_id", "?"))
            option_node_ids[approach.get("option_id", "?")] = opt_id
            nodes.append(DAGNode(
                node_id=opt_id,
                node_type=NT_OPTION,
                phase="R4_multi_path_reasoning",
                content={
                    "option_id": approach.get("option_id"),
                    "description": approach.get("description", "")[:120],
                    "components_touched": approach.get("components_touched", []),
                    "primary_risk": approach.get("primary_risk", ""),
                },
                label=f"option:{approach.get('option_id','?')}",
            ))
            edges.append(DAGEdge(intent_node_id, opt_id, ET_DERIVED_FROM))
            edges.append(DAGEdge(phase_nodes["multi_path_reasoning"], opt_id, ET_CONTAINS))

            # Risk node if non-trivial risk declared
            risk = approach.get("primary_risk", "")
            if risk and risk.lower() not in ("none", "minor", "none significant", ""):
                risk_id = _node_id("r4.risk", opt_id + risk)
                nodes.append(DAGNode(
                    node_id=risk_id,
                    node_type=NT_RISK,
                    phase="R4_multi_path_reasoning",
                    content={"risk": risk, "option_id": approach.get("option_id")},
                    label=f"risk:{risk[:40]}",
                ))
                edges.append(DAGEdge(opt_id, risk_id, ET_DERIVED_FROM))

        # ── R5: Critic nodes ─────────────────────────────────────────────────
        r5 = phase_artifacts.get("critic_review", {})
        critic_results = r5.get("results", [])
        for result in critic_results:
            option_id = result.get("option_id", "?")
            opt_node_id = option_node_ids.get(option_id)
            eliminated = result.get("eliminated", False)
            elimination_reason = result.get("elimination_reason", "")

            # Evaluation summary node for this option
            eval_id = _node_id("r5.eval", option_id + str(eliminated))
            nodes.append(DAGNode(
                node_id=eval_id,
                node_type=NT_EVALUATION,
                phase="R5_critic_review",
                content={
                    "option_id": option_id,
                    "eliminated": eliminated,
                    "elimination_reason": elimination_reason,
                    "constraint_count": len(result.get("constraint_results", [])),
                },
                label=f"eval:{option_id}:{'ELIMINATED' if eliminated else 'SURVIVED'}",
            ))
            if opt_node_id:
                edges.append(DAGEdge(eval_id, opt_node_id, ET_EVALUATES))
            edges.append(DAGEdge(phase_nodes["critic_review"], eval_id, ET_CONTAINS))

            # Individual constraint finding nodes (FAIL only — to keep graph lean)
            for cr in result.get("constraint_results", []):
                if cr.get("status") in ("FAIL", "WARN"):
                    cf_id = _node_id(
                        "r5.critic",
                        option_id + cr.get("constraint_id","") + cr.get("status","")
                    )
                    nodes.append(DAGNode(
                        node_id=cf_id,
                        node_type=NT_CRITIC,
                        phase="R5_critic_review",
                        content={
                            "constraint_id": cr.get("constraint_id"),
                            "status": cr.get("status"),
                            "detail": cr.get("detail", "")[:80],
                            "option_id": option_id,
                        },
                        label=f"{cr.get('status')}:{cr.get('constraint_id')}",
                    ))
                    edges.append(DAGEdge(eval_id, cf_id, ET_CONTAINS))
                    if opt_node_id:
                        if eliminated:
                            edges.append(DAGEdge(cf_id, opt_node_id, ET_ELIMINATES))
                        else:
                            edges.append(DAGEdge(cf_id, opt_node_id, ET_SUPPORTS))

        # ── R6: Execution plan node ──────────────────────────────────────────
        r6 = phase_artifacts.get("execution_plan", {})
        selected_option_id = r6.get("selected_approach")
        plan_node_id = _node_id("r6.plan", run_id)
        nodes.append(DAGNode(
            node_id=plan_node_id,
            node_type=NT_PLAN,
            phase="R6_execution_plan",
            content={
                "selected_approach": selected_option_id,
                "approach_description": r6.get("approach_description", "")[:120],
                "components_touched": r6.get("components_touched", []),
                "write_path": r6.get("write_path", "unknown"),
                "creates_state": r6.get("creates_state", False),
                "execution_approved": r6.get("execution_approved", False),
                "warn_items": r6.get("warn_items", []),
                "frozen_call_sequence_preserved": r6.get("frozen_call_sequence_preserved", []),
            },
            label=f"plan:option_{selected_option_id}",
        ))
        edges.append(DAGEdge(phase_nodes["execution_plan"], plan_node_id, ET_CONTAINS))

        # Connect surviving options to plan via SELECTS edge
        if selected_option_id:
            selected_opt_node = option_node_ids.get(selected_option_id)
            if selected_opt_node:
                edges.append(DAGEdge(selected_opt_node, plan_node_id, ET_SELECTS))

        # ── Compute metrics ──────────────────────────────────────────────────
        option_count     = len(approaches)
        eliminated_count = sum(1 for r in critic_results if r.get("eliminated"))
        surviving_count  = option_count - eliminated_count
        fail_findings    = sum(
            1 for r in critic_results
            for cr in r.get("constraint_results", [])
            if cr.get("status") == "FAIL"
        )
        warn_findings    = sum(
            1 for r in critic_results
            for cr in r.get("constraint_results", [])
            if cr.get("status") == "WARN"
        )
        metrics = {
            "node_count": len(nodes),
            "edge_count": len(edges),
            "option_count": option_count,
            "eliminated_count": eliminated_count,
            "surviving_count": surviving_count,
            "critic_fail_findings": fail_findings,
            "critic_warn_findings": warn_findings,
            "decomposition_depth": len(subtasks),
            "constraint_count": len(constraints),
            "missing_phase_count": len(missing_phases),
            "branch_waste_ratio": (
                round(eliminated_count / option_count, 2)
                if option_count > 0 else 0.0
            ),
        }

        dag_id = _node_id("dag", run_id + intent)

        return ReasoningDAG(
            dag_id=dag_id,
            source_intent=intent,
            generated_utc=datetime.now(timezone.utc).isoformat(),
            nodes=nodes,
            edges=edges,
            selected_plan_node=plan_node_id,
            integrity_ok=len(missing_phases) == 0,
            missing_phases=missing_phases,
            metrics=metrics,
        )
