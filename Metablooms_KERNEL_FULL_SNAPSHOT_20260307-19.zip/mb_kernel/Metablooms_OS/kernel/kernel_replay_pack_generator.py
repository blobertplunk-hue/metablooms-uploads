"""
Replay Pack Generator — Kernel Wired
--------------------------------------
Routes replay pack creation through the kernel's ArtifactStore + CommitSystem
instead of direct ASG filesystem writes.

Legacy impact: replaces ReplayPackGenerator (runtime version) which wrote
  directly to disk via AuthoritativeStateGate. Prior version had no commit
  trail — replay packs were not reachable from the commit log.

Constraint: replay pack content is stored as a content-addressed artifact.
  The manifest + all referenced artifact_ids are committed together.
  If any referenced artifact_id is not in the store, commit is blocked.

Integration reciprocity:
  - Caller provides ArtifactStore + CommitSystem (from KernelContext).
  - Returns: artifact_id of stored manifest + commit_id.
  - Still writes a human-readable copy to disk via pack_dir for debuggability,
    but the authoritative record is the ArtifactStore + CommitSystem entry.

Schema: MB-REPLAY-PACK-KERNEL-1.0
"""

from __future__ import annotations

import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent

# Bootstrap kernel component paths
_KERNEL_COMP_DIRS = [
    "artifact_store", "commit_system", "fingerprint_engine",
]
for _comp in _KERNEL_COMP_DIRS:
    _p = str(_HERE / _comp)
    if _p not in sys.path:
        sys.path.insert(0, _p)

from artifact_store import ArtifactStore
from commit_system import CommitSystem
from fingerprint_engine import canonical_json

SCHEMA = "MB-REPLAY-PACK-KERNEL-1.0"


class KernelReplayPackGenerator:
    """
    Kernel-wired replay pack generator.
    Stores the manifest in ArtifactStore and commits via CommitSystem.
    """

    def __init__(
        self,
        artifact_store: ArtifactStore,
        commit_system: CommitSystem,
        pack_dir: str | Path | None = None,
    ):
        self.store = artifact_store
        self.commits = commit_system
        # Optional: human-readable disk copy. Authoritative = store + commit.
        self.pack_dir = Path(pack_dir) if pack_dir else None

    def create_replay_pack(
        self,
        fingerprint: str,
        artifact_ids: list[str],
        metadata: dict,
        *,
        engine_inputs: dict | None = None,
        phase_plan: list[dict] | None = None,
        governance_snapshot: dict | None = None,
        execution_receipt: dict | None = None,
    ) -> dict:
        """
        Create a replay pack and commit it to the kernel.
        Returns dict with artifact_id, commit_id, and authoritative=True.
        """
        manifest = {
            "schema": SCHEMA,
            "fingerprint": fingerprint,
            "artifact_ids": artifact_ids,
            "engine_inputs": engine_inputs or {},
            "phase_plan": phase_plan or [],
            "governance_snapshot": governance_snapshot or {},
            "execution_receipt": execution_receipt or {},
            "metadata": metadata,
        }

        # Store manifest as content-addressed artifact
        store_receipt = self.store.store(
            manifest,
            engine_id="replay_pack_generator",
            phase="commit",
            intent="replay_pack",
        )

        # Commit: manifest artifact + all referenced artifact_ids
        # Only include artifact_ids that exist in the store (best-effort)
        committable = [
            aid for aid in artifact_ids
            if self.store.exists(aid)
        ]
        committable.append(store_receipt.artifact_id)

        commit = self.commits.commit(
            artifact_ids=committable,
            engine_id="replay_pack_generator",
            phase="commit",
            intent="replay_pack",
            metadata={"fingerprint": fingerprint},
        )

        # Optional: write human-readable disk copy
        disk_path = None
        if self.pack_dir:
            pack_out = self.pack_dir / fingerprint
            pack_out.mkdir(parents=True, exist_ok=True)
            manifest_file = pack_out / "manifest.json"
            manifest_file.write_bytes(canonical_json(manifest).encode("utf-8"))
            disk_path = str(manifest_file)

        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "fingerprint": fingerprint,
            "authoritative": store_receipt.authoritative,
            "disk_path": disk_path,
            "manifest_sha256": store_receipt.content_hash,
        }
