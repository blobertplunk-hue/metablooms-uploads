"""
Fingerprint Engine
------------------
Canonical identity for any piece of state in MetaBlooms OS.

Rule: Two objects that are semantically identical must produce the same
fingerprint regardless of key insertion order, whitespace, or repr.

This is the foundation every other kernel component depends on.
It MUST NOT import from any other kernel component (no circular deps).

Operations:
  fingerprint(obj)  -> str   canonical SHA-256 hex of JSON-serialized obj
  fingerprint_file(path) -> str   SHA-256 of raw file bytes
  canonical_json(obj) -> str   deterministic JSON string

Schema: MB-FINGERPRINT-1.0
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


SCHEMA = "MB-FINGERPRINT-1.0"


def canonical_json(obj: Any) -> str:
    """Deterministic JSON: sorted keys, no extra whitespace, UTF-8 safe."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def fingerprint(obj: Any) -> str:
    """SHA-256 of the canonical JSON encoding of obj."""
    return hashlib.sha256(canonical_json(obj).encode("utf-8")).hexdigest()


def fingerprint_bytes(data: bytes) -> str:
    """SHA-256 of raw bytes (for files, binary blobs)."""
    return hashlib.sha256(data).hexdigest()


def fingerprint_file(path: str | Path) -> str:
    """SHA-256 of raw file bytes. Raises FileNotFoundError if missing."""
    return fingerprint_bytes(Path(path).read_bytes())


def fingerprint_text(text: str) -> str:
    """SHA-256 of UTF-8 encoded text."""
    return fingerprint_bytes(text.encode("utf-8"))


class FingerprintEngine:
    """
    Stateless engine wrapper — useful for dependency injection
    and for producing receipted fingerprint operations.
    """

    schema = SCHEMA

    def fingerprint(self, obj: Any) -> str:
        return fingerprint(obj)

    def fingerprint_file(self, path: str | Path) -> str:
        return fingerprint_file(path)

    def fingerprint_text(self, text: str) -> str:
        return fingerprint_text(text)

    def canonical_json(self, obj: Any) -> str:
        return canonical_json(obj)

    def verify_pair(self, obj: Any, claimed_fp: str) -> bool:
        """Return True if fingerprint(obj) matches claimed_fp."""
        return fingerprint(obj) == claimed_fp
