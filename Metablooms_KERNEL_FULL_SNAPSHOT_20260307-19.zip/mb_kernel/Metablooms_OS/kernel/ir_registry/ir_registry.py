"""
IR Registry (Intent-Result Registry)
-------------------------------------
Maps intent_types to their expected result schemas and past execution records.
Provides the "what should this intent produce?" authority.

Schema: MB-IR-REGISTRY-1.0
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
import json

from fingerprint_engine import fingerprint, canonical_json

SCHEMA = "MB-IR-REGISTRY-1.0"


@dataclass
class IntentSpec:
    intent_type: str
    description: str
    required_phases: list[str]
    expected_output_fields: list[str]
    artifact_producing: bool = True


@dataclass
class IntentRecord:
    intent_type: str
    run_id: str
    artifact_ids: list[str]
    commit_id: str
    timestamp_utc: str
    result_fingerprint: str


class IRRegistry:
    """
    Append-only registry of intent specs and execution records.
    """
    schema = SCHEMA

    _BUILTIN_SPECS: dict[str, IntentSpec] = {
        "run_egg_juicer": IntentSpec(
            intent_type="run_egg_juicer",
            description="Analyze repository structure deterministically",
            required_phases=["verification"],
            expected_output_fields=["engine", "repo", "file_count", "structure_hash"],
            artifact_producing=True,
        ),
    }

    def __init__(self, registry_root: Optional[str | Path] = None):
        self.registry_root = Path(registry_root) if registry_root else None
        self._specs: dict[str, IntentSpec] = dict(self._BUILTIN_SPECS)
        self._records: list[IntentRecord] = []
        if self.registry_root:
            self.registry_root.mkdir(parents=True, exist_ok=True)
            self._load()

    def register_spec(self, spec: IntentSpec) -> None:
        self._specs[spec.intent_type] = spec

    def record_execution(
        self,
        intent_type: str,
        run_id: str,
        artifact_ids: list[str],
        commit_id: str,
        result: Any,
    ) -> IntentRecord:
        record = IntentRecord(
            intent_type=intent_type,
            run_id=run_id,
            artifact_ids=artifact_ids,
            commit_id=commit_id,
            timestamp_utc=_now_utc(),
            result_fingerprint=fingerprint(result),
        )
        self._records.append(record)
        if self.registry_root:
            self._persist()
        return record

    def get_spec(self, intent_type: str) -> Optional[IntentSpec]:
        return self._specs.get(intent_type)

    def history(self, intent_type: Optional[str] = None) -> list[IntentRecord]:
        if intent_type:
            return [r for r in self._records if r.intent_type == intent_type]
        return list(self._records)

    def _load(self) -> None:
        path = self.registry_root / "_ir_registry.json"
        if path.exists():
            try:
                raw = json.loads(path.read_text(encoding="utf-8"))
                for rd in raw.get("records", []):
                    self._records.append(IntentRecord(**rd))
            except Exception:
                pass

    def _persist(self) -> None:
        path = self.registry_root / "_ir_registry.json"
        serialized = {
            "schema": SCHEMA,
            "records": [asdict(r) for r in self._records],
        }
        encoded = canonical_json(serialized).encode("utf-8")
        path.write_bytes(encoded)


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()
