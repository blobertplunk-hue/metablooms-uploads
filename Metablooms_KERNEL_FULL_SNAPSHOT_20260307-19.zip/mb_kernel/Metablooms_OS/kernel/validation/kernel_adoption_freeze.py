"""
Kernel Adoption Freeze
-----------------------
Generates and verifies the MB-KERNEL-ADOPTION-FREEZE artifact.

Purpose: lock the proven kernel wiring so that future work (new engines,
dashboards, refactors) cannot silently break the kernel execution path
that was validated in KERNEL_WIRING_VALIDATION_MATRIX_v2.

What the freeze protects (Interpretation A — architectural invariants):
  - Component file hashes (byte-level identity of each frozen file)
  - Import graph (component-boundary imports, not internal calls)
  - Reference call sequence (ordered component-type transitions)
  - Top-level freeze hash (hash of the above three)

What the freeze deliberately does NOT protect:
  - Method names inside a component
  - Argument shapes
  - Helper function extraction
  - Comments, docstrings
  - Internal implementation changes that don't alter component role

Freeze violation semantics:
  MUST re-freeze:  component added/removed, call sequence changes,
                   import graph changes across kernel boundaries,
                   frozen file hash changes
  MUST NOT re-freeze: rename, helper extraction, arg reshape,
                      comment-only changes

Schema: MB-KERNEL-ADOPTION-FREEZE-1.0

Legacy impact: first freeze artifact for MetaBlooms OS kernel.
  No prior freeze existed. This is the inaugural adoption lock.
"""

from __future__ import annotations

import ast
import hashlib
import json
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

# Bootstrap kernel paths
_HERE = Path(__file__).resolve().parent
_KERNEL_ROOT = _HERE.parent
for _comp in [
    "artifact_store", "commit_system", "fingerprint_engine",
    "phase_registry", "governance_compiler", "mpp_executor",
    "engine_registry", "capability_resolver", "pipeline_planner",
    "state_loader", "ir_registry",
]:
    _p = str(_KERNEL_ROOT / _comp)
    if _p not in sys.path:
        sys.path.insert(0, _p)
if str(_KERNEL_ROOT) not in sys.path:
    sys.path.insert(0, str(_KERNEL_ROOT))

from fingerprint_engine import fingerprint, canonical_json

SCHEMA = "MB-KERNEL-ADOPTION-FREEZE-1.0"
KERNEL_VERSION = "1.0.0"

# ── Canonical frozen component set ──────────────────────────────────────────
# These are the files whose hashes are locked at freeze time.
# Adding or removing a component here requires a new freeze.

FROZEN_COMPONENT_PATHS: dict[str, str] = {
    "artifact_store":                "artifact_store/artifact_store.py",
    "commit_system":                 "commit_system/commit_system.py",
    "state_loader":                  "state_loader/state_loader.py",
    "fingerprint_engine":            "fingerprint_engine/fingerprint_engine.py",
    "phase_registry":                "phase_registry/phase_registry.py",
    "ir_registry":                   "ir_registry/ir_registry.py",
    "pipeline_planner":              "pipeline_planner/pipeline_planner.py",
    "pipeline_determinism_guard":    "pipeline_planner/pipeline_determinism_guard.py",
    "governance_compiler":           "governance_compiler/governance_compiler.py",
    "mpp_executor":                  "mpp_executor/mpp_executor.py",
    "engine_registry":               "engine_registry/engine_registry.py",
    "capability_resolver":           "capability_resolver/capability_resolver.py",
    "kernel_context":                "kernel_context.py",
    "kernel_wiring_validation_runner": "validation/kernel_wiring_validation_runner.py",
}

# ── Reference call sequence ──────────────────────────────────────────────────
# Interpretation A: ordered component-boundary transitions only.
# Not a stack trace — each entry is a component type, not a method name.
# This sequence is the architectural route proven by MATRIX_v2.

REFERENCE_CALL_SEQUENCE: list[str] = [
    "capability_resolver",
    "pipeline_planner",
    "governance_compiler",
    "kernel_mpp_executor",
    "artifact_store",
    "commit_system",
]

# ── Import graph (component-boundary imports) ────────────────────────────────
# Maps each component to the other frozen components it imports.
# Derived from AST analysis of import statements — not runtime introspection.
# Internal helpers are excluded; only cross-component kernel imports are tracked.

KERNEL_COMPONENT_NAMES = set(FROZEN_COMPONENT_PATHS.keys()) | {
    "kernel_mpp_executor",  # alias used in call sequence
}


# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class FreezeViolation:
    component: str
    violation_type: str   # "hash_changed" | "missing" | "sequence_changed" | "import_graph_changed"
    detail: str


@dataclass
class FreezeVerifyResult:
    passed: bool
    freeze_id: str
    violations: list[FreezeViolation] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


# ── Core functions ───────────────────────────────────────────────────────────

def _sha256_file(path: Path) -> str:
    """SHA-256 of file bytes. Stable — does not depend on parse."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _extract_kernel_imports(py_path: Path, kernel_component_names: set[str]) -> list[str]:
    """
    AST-walk a Python file and return the sorted list of frozen kernel
    component names it imports directly.

    Only tracks top-level `import X` and `from X import Y` where X is a
    known kernel component. Internal helper imports are excluded.
    """
    try:
        tree = ast.parse(py_path.read_text(encoding="utf-8"))
    except SyntaxError:
        return []

    imported: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root in kernel_component_names:
                    imported.add(root)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                root = node.module.split(".")[0]
                if root in kernel_component_names:
                    imported.add(root)

    return sorted(imported)


def _build_import_graph(kernel_root: Path) -> dict[str, list[str]]:
    """
    Build the normalized import graph across all frozen components.
    Returns dict: component_name → sorted list of kernel components it imports.
    """
    graph: dict[str, list[str]] = {}
    for comp_name, rel_path in FROZEN_COMPONENT_PATHS.items():
        py_path = kernel_root / rel_path
        if py_path.exists():
            imports = _extract_kernel_imports(py_path, KERNEL_COMPONENT_NAMES)
            # Only include if it imports at least one kernel component
            if imports:
                graph[comp_name] = imports
    return dict(sorted(graph.items()))


def generate_freeze(
    kernel_root: str | Path,
    freeze_id: str | None = None,
    reference_call_sequence: list[str] | None = None,
    reference_run: dict | None = None,
) -> dict:
    """
    Generate a freeze artifact from the current state of the kernel.

    kernel_root: path to the kernel/ directory.
    freeze_id: stable ID for this freeze. Defaults to new UUID.
    reference_call_sequence: defaults to REFERENCE_CALL_SEQUENCE.
    reference_run: dict with keys:
        validation_run_id       — determinism_hash from wiring matrix
        reference_artifact_hash — artifact_id from ArtifactStore evidence
        reference_commit_id     — commit_id from CommitSystem evidence
        matrix_timestamp_utc    — timestamp_utc from the matrix
        matrix_session_id       — session_id from the matrix
      If provided, these are embedded in the freeze and included in the
      top-level hash. This ties the freeze to the exact validated run.

    Returns the freeze dict. Does NOT write to disk — caller decides where.
    """
    kernel_root = Path(kernel_root)
    freeze_id = freeze_id or str(uuid.uuid4())
    call_seq = reference_call_sequence or REFERENCE_CALL_SEQUENCE

    # 1. Component file hashes
    frozen_components: dict[str, dict] = {}
    missing_components: list[str] = []
    for comp_name, rel_path in FROZEN_COMPONENT_PATHS.items():
        full_path = kernel_root / rel_path
        if full_path.exists():
            frozen_components[comp_name] = {
                "path": str(full_path),
                "relative_path": rel_path,
                "sha256": _sha256_file(full_path),
            }
        else:
            missing_components.append(comp_name)
            frozen_components[comp_name] = {
                "path": str(full_path),
                "relative_path": rel_path,
                "sha256": "MISSING",
            }

    # 2. Import graph
    import_graph = _build_import_graph(kernel_root)

    # 3. Top-level freeze hash
    # Covers: component hashes + import graph + call sequence + reference run
    # Excludes: freeze_id, created_at timestamps (volatile metadata)
    # Including reference_run ties this freeze to the exact validated execution.
    normalized_reference_run = reference_run or {}
    freeze_payload = {
        "component_hashes": {
            name: data["sha256"]
            for name, data in frozen_components.items()
        },
        "import_graph": import_graph,
        "reference_call_sequence": call_seq,
        "reference_run": normalized_reference_run,
    }
    top_level_hash = "sha256:" + fingerprint(freeze_payload)

    freeze = {
        "schema": SCHEMA,
        "freeze_id": freeze_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "kernel_version": KERNEL_VERSION,
        "frozen_component_count": len(FROZEN_COMPONENT_PATHS),
        "missing_components": missing_components,
        "frozen_components": frozen_components,
        "import_graph": import_graph,
        "reference_call_sequence": call_seq,
        "reference_run": normalized_reference_run,
        "top_level_freeze_hash": top_level_hash,
        "re_freeze_triggers": [
            "component added or removed from frozen kernel path",
            "component-type call sequence changes",
            "import graph changes across kernel boundaries",
            "frozen file hash changes in a kernel component",
            "runtime path stops routing through kernel",
        ],
        "re_freeze_not_triggered_by": [
            "method rename inside a frozen component",
            "helper function extraction",
            "argument shape refactor",
            "comment or docstring changes",
            "internal implementation change with identical component role",
        ],
    }

    return freeze


def verify_freeze(
    freeze_artifact: dict,
    kernel_root: str | Path,
) -> FreezeVerifyResult:
    """
    Verify the current kernel state against a stored freeze artifact.

    Returns FreezeVerifyResult with passed=True if no violations.
    Any violation means the kernel wiring has changed in a way that
    requires explicit re-freeze review.
    """
    kernel_root = Path(kernel_root)
    freeze_id = freeze_artifact.get("freeze_id", "unknown")
    violations: list[FreezeViolation] = []
    warnings: list[str] = []

    # 1. Component hash check
    frozen_components = freeze_artifact.get("frozen_components", {})
    for comp_name, frozen_data in frozen_components.items():
        rel_path = frozen_data.get("relative_path", "")
        full_path = kernel_root / rel_path

        if not full_path.exists():
            violations.append(FreezeViolation(
                component=comp_name,
                violation_type="missing",
                detail=f"Frozen component file no longer exists: {rel_path}",
            ))
            continue

        current_hash = _sha256_file(full_path)
        frozen_hash = frozen_data.get("sha256", "")

        if frozen_hash == "MISSING":
            warnings.append(f"{comp_name}: was missing at freeze time, now present")
        elif current_hash != frozen_hash:
            violations.append(FreezeViolation(
                component=comp_name,
                violation_type="hash_changed",
                detail=(
                    f"File content changed since freeze. "
                    f"Frozen: {frozen_hash[:12]}... Current: {current_hash[:12]}..."
                ),
            ))

    # 2. Import graph check
    frozen_graph = freeze_artifact.get("import_graph", {})
    current_graph = _build_import_graph(kernel_root)

    frozen_set = set(json.dumps(frozen_graph, sort_keys=True))
    current_set = set(json.dumps(current_graph, sort_keys=True))

    if frozen_graph != current_graph:
        # Find specific differences
        all_comps = set(frozen_graph) | set(current_graph)
        for comp in sorted(all_comps):
            frozen_imports = frozen_graph.get(comp, [])
            current_imports = current_graph.get(comp, [])
            if frozen_imports != current_imports:
                violations.append(FreezeViolation(
                    component=comp,
                    violation_type="import_graph_changed",
                    detail=(
                        f"Import graph changed. "
                        f"Frozen: {frozen_imports} → Current: {current_imports}"
                    ),
                ))

    # 3. Call sequence check
    frozen_seq = freeze_artifact.get("reference_call_sequence", [])
    current_seq = REFERENCE_CALL_SEQUENCE
    if frozen_seq != current_seq:
        violations.append(FreezeViolation(
            component="call_sequence",
            violation_type="sequence_changed",
            detail=(
                f"Reference call sequence changed. "
                f"Frozen: {frozen_seq} → Current: {current_seq}"
            ),
        ))

    # 4. Top-level hash re-verification
    frozen_top_hash = freeze_artifact.get("top_level_freeze_hash", "")
    # Recompute from current frozen components (not from current state —
    # we verify the stored freeze is internally consistent)
    stored_payload = {
        "component_hashes": {
            name: data["sha256"]
            for name, data in frozen_components.items()
        },
        "import_graph": frozen_graph,
        "reference_call_sequence": frozen_seq,
        "reference_run": freeze_artifact.get("reference_run", {}),
    }
    expected_top_hash = "sha256:" + fingerprint(stored_payload)
    if frozen_top_hash != expected_top_hash:
        violations.append(FreezeViolation(
            component="freeze_artifact",
            violation_type="hash_changed",
            detail=(
                "Top-level freeze hash does not match stored components. "
                "Freeze artifact may have been tampered with."
            ),
        ))

    return FreezeVerifyResult(
        passed=len(violations) == 0,
        freeze_id=freeze_id,
        violations=violations,
        warnings=warnings,
    )


def verify_freeze_dict(freeze_artifact: dict, kernel_root: str | Path) -> dict:
    """Convenience wrapper — returns dict instead of dataclass."""
    result = verify_freeze(freeze_artifact, kernel_root)
    return {
        "schema": SCHEMA,
        "passed": result.passed,
        "freeze_id": result.freeze_id,
        "violation_count": len(result.violations),
        "violations": [
            {
                "component": v.component,
                "violation_type": v.violation_type,
                "detail": v.detail,
            }
            for v in result.violations
        ],
        "warnings": result.warnings,
    }


# ── CLI ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Kernel Adoption Freeze tool")
    sub = parser.add_subparsers(dest="command")

    gen = sub.add_parser("generate", help="Generate a new freeze artifact")
    gen.add_argument("--kernel-root", required=True)
    gen.add_argument("--output", required=True, help="Path to write freeze JSON")
    gen.add_argument("--freeze-id", default=None)
    gen.add_argument("--validation-run-id", default=None, help="determinism_hash from wiring matrix")
    gen.add_argument("--reference-artifact-hash", default=None)
    gen.add_argument("--reference-commit-id", default=None)
    gen.add_argument("--matrix-timestamp", default=None)
    gen.add_argument("--matrix-session-id", default=None)
    gen.add_argument("--matrix-sha256", default=None, help="SHA-256 of the validation matrix file itself")

    ver = sub.add_parser("verify", help="Verify kernel against an existing freeze")
    ver.add_argument("--freeze", required=True, help="Path to freeze JSON")
    ver.add_argument("--kernel-root", required=True)

    args = parser.parse_args()

    if args.command == "generate":
        ref_run = {}
        if args.validation_run_id:
            ref_run["validation_run_id"] = args.validation_run_id
        if args.reference_artifact_hash:
            ref_run["reference_artifact_hash"] = args.reference_artifact_hash
        if args.reference_commit_id:
            ref_run["reference_commit_id"] = args.reference_commit_id
        if args.matrix_timestamp:
            ref_run["matrix_timestamp_utc"] = args.matrix_timestamp
        if args.matrix_session_id:
            ref_run["matrix_session_id"] = args.matrix_session_id
        if args.matrix_sha256:
            ref_run["matrix_sha256"] = args.matrix_sha256
        freeze = generate_freeze(
            args.kernel_root,
            freeze_id=args.freeze_id,
            reference_run=ref_run or None,
        )
        Path(args.output).write_text(
            json.dumps(freeze, indent=2), encoding="utf-8"
        )
        print(json.dumps({
            "status": "generated",
            "freeze_id": freeze["freeze_id"],
            "top_level_freeze_hash": freeze["top_level_freeze_hash"],
            "frozen_components": freeze["frozen_component_count"],
            "missing": freeze["missing_components"],
            "output": args.output,
        }, indent=2))

    elif args.command == "verify":
        freeze_artifact = json.loads(Path(args.freeze).read_text(encoding="utf-8"))
        result = verify_freeze_dict(freeze_artifact, args.kernel_root)
        print(json.dumps(result, indent=2))
        sys.exit(0 if result["passed"] else 1)

    else:
        parser.print_help()
