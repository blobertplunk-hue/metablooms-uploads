"""
Runtime Write Scanner
----------------------
Static analysis tool (AST-based) that detects direct filesystem writes
in runtime modules that should be routing through the kernel.

What it detects:
  open(..., 'w'), open(..., 'wb')
  Path.write_text(), Path.write_bytes()
  json.dump() to a file handle

What it allows (via ALLOWED_MODULES whitelist):
  Kernel components themselves (they ARE the write layer)
  AuthoritativeStateGate (approved write primitive)
  deterministic_write_repair (approved write primitive)

Constraint: static analysis at validation time — not runtime monkey-patching.
  Runtime patching produces false positives from library internals and
  is fragile across Python versions.

Integration reciprocity:
  Called by Kernel Wiring Validation Runner.
  Returns a ScanReport with violations list.
  Empty violations = all writes routed through kernel.

Legacy impact: replaces ad-hoc manual review of write paths.
  Prior approach: read code and hope. This approach: AST + evidence.

Schema: MB-WRITE-SCAN-1.0
"""

from __future__ import annotations

import ast
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

SCHEMA = "MB-WRITE-SCAN-1.0"

# Modules allowed to write directly — they ARE the kernel write layer
ALLOWED_MODULES = {
    "artifact_store",
    "commit_system",
    "authoritative_state_gate",
    "deterministic_write_repair",
    "fingerprint_engine",  # reads only but whitelisted for clarity
    "kernel_replay_pack_generator",  # writes via ArtifactStore internally
}

# AST patterns that indicate a direct write
_WRITE_CALL_NAMES = {"write_text", "write_bytes"}
_OPEN_WRITE_MODES = {"w", "wb", "w+", "wb+"}


@dataclass
class WriteViolation:
    file: str
    line: int
    col: int
    pattern: str
    detail: str


@dataclass
class ScanReport:
    schema: str
    scanned_files: int
    violations: list[WriteViolation] = field(default_factory=list)
    allowed_files: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return len(self.violations) == 0

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "passed": self.passed,
            "scanned_files": self.scanned_files,
            "violation_count": len(self.violations),
            "violations": [
                {
                    "file": v.file,
                    "line": v.line,
                    "col": v.col,
                    "pattern": v.pattern,
                    "detail": v.detail,
                }
                for v in self.violations
            ],
            "allowed_files": self.allowed_files,
            "errors": self.errors,
        }


class RuntimeWriteScanner:
    """
    AST-based scanner for direct filesystem writes in runtime modules.
    """

    def __init__(self, allowed_modules: set[str] | None = None):
        self.allowed_modules = allowed_modules or ALLOWED_MODULES

    def scan_directory(self, directory: str | Path) -> ScanReport:
        """
        Scan all .py files in directory (recursive).
        Returns ScanReport.
        """
        directory = Path(directory)
        py_files = sorted(directory.rglob("*.py"))

        report = ScanReport(schema=SCHEMA, scanned_files=0)

        for py_file in py_files:
            module_stem = py_file.stem
            if module_stem in self.allowed_modules:
                report.allowed_files.append(str(py_file))
                continue

            report.scanned_files += 1
            violations = self._scan_file(py_file)
            report.violations.extend(violations)

        return report

    def scan_file(self, filepath: str | Path) -> ScanReport:
        """Scan a single file."""
        filepath = Path(filepath)
        module_stem = filepath.stem
        report = ScanReport(schema=SCHEMA, scanned_files=0)

        if module_stem in self.allowed_modules:
            report.allowed_files.append(str(filepath))
            return report

        report.scanned_files = 1
        report.violations = self._scan_file(filepath)
        return report

    def _scan_file(self, filepath: Path) -> list[WriteViolation]:
        violations = []
        try:
            source = filepath.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(filepath))
        except (SyntaxError, UnicodeDecodeError) as e:
            # Can't parse — report as error, not violation
            return []

        for node in ast.walk(tree):
            # Pattern 1: open(path, 'w') or open(path, 'wb')
            if isinstance(node, ast.Call):
                if self._is_open_write(node):
                    violations.append(WriteViolation(
                        file=str(filepath),
                        line=node.lineno,
                        col=node.col_offset,
                        pattern="open_write",
                        detail=f"open() with write mode at line {node.lineno}",
                    ))

                # Pattern 2: something.write_text(...) or something.write_bytes(...)
                if isinstance(node.func, ast.Attribute):
                    if node.func.attr in _WRITE_CALL_NAMES:
                        violations.append(WriteViolation(
                            file=str(filepath),
                            line=node.lineno,
                            col=node.col_offset,
                            pattern=f"path_{node.func.attr}",
                            detail=f".{node.func.attr}() call at line {node.lineno}",
                        ))

                # Pattern 3: json.dump(obj, file_handle)
                if self._is_json_dump(node):
                    violations.append(WriteViolation(
                        file=str(filepath),
                        line=node.lineno,
                        col=node.col_offset,
                        pattern="json_dump",
                        detail=f"json.dump() to file handle at line {node.lineno}",
                    ))

        return violations

    def _is_open_write(self, node: ast.Call) -> bool:
        """Detect open(path, mode) where mode is a write mode."""
        func = node.func
        # open() builtin
        is_open = (isinstance(func, ast.Name) and func.id == "open")
        if not is_open:
            return False
        # Check second positional arg or 'mode' keyword
        mode_val = None
        if len(node.args) >= 2:
            arg = node.args[1]
            if isinstance(arg, ast.Constant):
                mode_val = arg.value
        for kw in node.keywords:
            if kw.arg == "mode" and isinstance(kw.value, ast.Constant):
                mode_val = kw.value.value
        if mode_val is None:
            return False  # default is 'r' — not a write
        return any(wm in str(mode_val) for wm in ("w", "wb"))

    def _is_json_dump(self, node: ast.Call) -> bool:
        """Detect json.dump(obj, fp) — the 2-arg form that writes to a file."""
        func = node.func
        if not isinstance(func, ast.Attribute):
            return False
        if func.attr != "dump":
            return False
        # json.dump
        if isinstance(func.value, ast.Name) and func.value.id == "json":
            # Must have at least 2 args (obj + file handle)
            return len(node.args) >= 2
        return False


def scan_runtime(runtime_dir: str | Path) -> dict:
    """
    Convenience function. Scans a runtime directory and returns report dict.
    """
    scanner = RuntimeWriteScanner()
    report = scanner.scan_directory(runtime_dir)
    return report.to_dict()
