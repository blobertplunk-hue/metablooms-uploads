"""
Kernel Wiring Validation Runner
---------------------------------
Runs a full end-to-end turn through the wired system and produces the
KERNEL_WIRING_VALIDATION_MATRIX — the Phase 2 completion proof.

What it proves:
  Each of the 7 kernel components was actually exercised during a real
  execution turn, not just that the files exist.

Evidence per component:
  ArtifactStore  → artifact_id of stored result (hash)
  CommitSystem   → commit_id (chain entry)
  PhaseRegistry  → resolved phase list from plan
  GovernanceCompiler → policy decision receipt (allowed=True/False)
  KernelMPPExecutor  → execution receipt with executor_id
  EngineRegistry     → engine load log (if engines registered)
  CapabilityResolver → resolved plan (intent → phases → engines)

Completion condition: verified_components == 7/7
Determinism check: run twice, hash(matrix_run_1) == hash(matrix_run_2)
  (timestamps excluded from determinism hash)

Schema: MB-KERNEL-WIRING-MATRIX-1.0
"""

from __future__ import annotations

import json
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_KERNEL_ROOT = _HERE.parent  # .../kernel/

# Bootstrap
_COMP_DIRS = [
    "artifact_store", "commit_system", "state_loader",
    "fingerprint_engine", "phase_registry", "governance_compiler",
    "mpp_executor", "engine_registry", "capability_resolver",
    "ir_registry", "pipeline_planner",
]
for _comp in _COMP_DIRS:
    _p = str(_KERNEL_ROOT / _comp)
    if _p not in sys.path:
        sys.path.insert(0, _p)
if str(_KERNEL_ROOT) not in sys.path:
    sys.path.insert(0, str(_KERNEL_ROOT))

from kernel_context import build_kernel_context
from fingerprint_engine import fingerprint

SCHEMA = "MB-KERNEL-WIRING-MATRIX-1.0"

# ─── Canonical engine package loader ────────────────────────────────────────
# Loads the real egg_juicer engine from its canonical package directory.
# This is the load path being validated — not a synthetic stub.

# Default: sibling mb_wired directory relative to mb_kernel root
_KERNEL_REPO_ROOT = Path(__file__).resolve().parents[4]  # home/claude
EGG_JUICER_PKG = _KERNEL_REPO_ROOT / (
    "mb_wired/metablooms_fixed_runtime_wired"
    "/metablooms_runtime_extensions/engines/egg_juicer_package"
)

# Fallback: allow override via env var for portability
import os as _os
_env_pkg = _os.environ.get("EGG_JUICER_PKG_PATH")
if _env_pkg:
    EGG_JUICER_PKG = Path(_env_pkg)


def _load_canonical_engine_package(pkg_dir: Path) -> tuple:
    """
    Load engine spec, governance, and callable from a canonical package directory.
    Returns (spec_dict, governance_dict, engine_callable, package_root_str).
    Raises if any required file is missing — fail-closed.
    """
    spec_path = pkg_dir / "engine_spec.json"
    gov_path = pkg_dir / "engine_governance.json"
    logic_path = pkg_dir / "engine_logic.py"

    missing = [str(p) for p in [spec_path, gov_path, logic_path] if not p.exists()]
    if missing:
        raise FileNotFoundError(f"Canonical engine package missing files: {missing}")

    spec_dict = json.loads(spec_path.read_text(encoding="utf-8"))
    gov_dict = json.loads(gov_path.read_text(encoding="utf-8"))

    # Load engine_logic module from package dir
    import importlib.util
    if str(pkg_dir) not in sys.path:
        sys.path.insert(0, str(pkg_dir))
    spec_mod = importlib.util.spec_from_file_location("egg_juicer_engine_logic", logic_path)
    mod = importlib.util.module_from_spec(spec_mod)
    spec_mod.loader.exec_module(mod)

    engine_instance = mod.Engine()

    def engine_callable():
        # Run against the package directory itself as a stable repo_root
        result = engine_instance.run({"repo_root": str(pkg_dir)})
        # Normalize EngineResult dataclass to plain dict for ArtifactStore
        if hasattr(result, "artifact"):
            return result.artifact
        return result

    return spec_dict, gov_dict, engine_callable, str(pkg_dir)

# ─── Runner ─────────────────────────────────────────────────────────────────

def run_wiring_validation(data_root: str | Path | None = None) -> dict:
    """
    Execute one full turn through the wired kernel and collect evidence
    for each of the 7 components.

    Returns the wiring matrix dict.
    """
    _tmpdir = None
    if data_root is None:
        import tempfile as _tf
        _tmpdir = _tf.TemporaryDirectory()
        data_root = _tmpdir.name

    data_root = Path(data_root)

    evidence: dict[str, dict] = {}
    violations: list[str] = []

    # ── Load canonical engine package ────────────────────────────────────────
    spec_dict, gov_dict, egg_juicer_callable, pkg_root = _load_canonical_engine_package(EGG_JUICER_PKG)
    engine_map = {
        spec_dict["engine_id"]: (egg_juicer_callable, gov_dict),
    }
    engine_id = spec_dict["engine_id"]  # "egg_juicer"

    ctx = build_kernel_context(
        data_root=data_root,
        engine_map=engine_map,
        session_id="wiring-validation-session",
    )

    # ── Boot ─────────────────────────────────────────────────────────────────
    boot_receipt = ctx.state_loader.boot()
    if boot_receipt.boot_status != "BOOT_OK":
        violations.append(f"boot_failed:{boot_receipt.violations}")

    # ── PhaseRegistry evidence ────────────────────────────────────────────────
    all_phases = ctx.phase_registry.all_phases()
    evidence["PhaseRegistry"] = {
        "verified": len(all_phases) > 0,
        "resolved_phases": all_phases,
    }

    # ── CapabilityResolver evidence ───────────────────────────────────────────
    # Register our test engine so resolver can see it
    # Register the canonical spec into the registry (with package_root)
    ctx.engine_registry.register_from_dict(
        spec_dict=spec_dict,
        governance_dict=gov_dict,
        package_root=pkg_root,
    )

    resolved = ctx.capability_resolver.resolve(
        intent_type="run_egg_juicer",
        requested_phases=["verification"],
        engine_attachments_hint={"verification": [engine_id]},
    )
    evidence["CapabilityResolver"] = {
        "verified": resolved is not None,
        "resolved_intent": "run_egg_juicer",
        "resolved_phases": getattr(resolved, "phases", []),
    }

    # ── GovernanceCompiler evidence ───────────────────────────────────────────
    # Build a minimal plan to validate against
    plan = ctx.pipeline_planner.create_plan(
        intent_type="run_egg_juicer",
        requested_phases=["verification"],
        engine_attachments={"verification": [engine_id]},
    )
    gov_result = ctx.governance_compiler.validate(plan)
    evidence["GovernanceCompiler"] = {
        "verified": True,  # governance ran regardless of outcome
        "allowed": gov_result.allowed,
        "violations": gov_result.violations,
    }
    if not gov_result.allowed:
        violations.append(f"governance_blocked:{gov_result.violations}")

    # ── KernelMPPExecutor evidence ────────────────────────────────────────────
    exec_result = ctx.executor.execute(plan, intent_type="run_validation")
    evidence["KernelMPPExecutor"] = {
        "verified": True,
        "ok": exec_result.ok,
        "executor_id": exec_result.receipt.get("executor_id"),
        "phases_executed": exec_result.phases_executed,
        "failed_engines": exec_result.failed_engines,
        "enforcer_violations": exec_result.enforcer_violations,
    }
    if not exec_result.ok:
        violations.append(f"execution_failed:{exec_result.failed_engines}")

    # ── ArtifactStore evidence ────────────────────────────────────────────────
    artifact_ids = exec_result.artifact_ids
    evidence["ArtifactStore"] = {
        "verified": len(artifact_ids) > 0,
        "artifact_ids": artifact_ids,
        "store_index_fingerprint": ctx.artifact_store.index_fingerprint(),
    }
    if not artifact_ids:
        violations.append("artifact_store:no_artifacts_produced")

    # ── CommitSystem evidence ─────────────────────────────────────────────────
    commit_id = exec_result.commit_id
    chain_violations = ctx.commit_system.verify_chain()
    evidence["CommitSystem"] = {
        "verified": commit_id is not None and len(chain_violations) == 0,
        "commit_id": commit_id,
        "chain_violations": chain_violations,
        "log_fingerprint": ctx.commit_system.log_fingerprint(),
    }
    if commit_id is None:
        violations.append("commit_system:no_commit_produced")
    if chain_violations:
        violations.append(f"commit_system:chain_violations:{chain_violations}")

    # ── EngineRegistry evidence ───────────────────────────────────────────────
    # Proves canonical package was loaded into the registry with package_root set.
    reg_spec = ctx.engine_registry.get_spec(engine_id)
    engine_obj = ctx.engine_registry.get(engine_id)
    evidence["EngineRegistry"] = {
        "verified": reg_spec is not None and engine_obj is not None and engine_obj.package_root is not None,
        "registered_engine": engine_id,
        "spec_found": reg_spec is not None,
        "package_root_set": engine_obj.package_root if engine_obj else None,
        "load_path": "canonical_package",
    }
    if reg_spec is None:
        violations.append(f"engine_registry:{engine_id}_not_found")
    elif engine_obj and engine_obj.package_root is None:
        violations.append(f"engine_registry:{engine_id}_package_root_missing")

    # ── Assemble matrix ───────────────────────────────────────────────────────
    component_order = [
        "ArtifactStore", "CommitSystem", "PhaseRegistry",
        "GovernanceCompiler", "KernelMPPExecutor",
        "EngineRegistry", "CapabilityResolver",
    ]
    verified_count = sum(
        1 for c in component_order
        if evidence.get(c, {}).get("verified", False)
    )

    matrix = {
        "schema": SCHEMA,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "session_id": ctx.session_id,
        "kernel_wiring_status": "COMPLETE" if verified_count == 7 and not violations else "INCOMPLETE",
        "verified_components": f"{verified_count}/7",
        "violations": violations,
        "components": {
            c: {
                "executed_through_runtime": evidence.get(c, {}).get("verified", False),
                "evidence": evidence.get(c, {}),
            }
            for c in component_order
        },
    }

    # Determinism hash — excludes volatile fields (timestamps, commit_ids,
    # store fingerprints which embed timestamps via commit chain).
    # What IS deterministic: which components verified, what phases resolved,
    # what the engine produced, whether governance passed.
    determinism_payload = {
        "schema": matrix["schema"],
        "session_id": matrix["session_id"],
        "kernel_wiring_status": matrix["kernel_wiring_status"],
        "verified_components": matrix["verified_components"],
        "violations": matrix["violations"],
        "components_verified": {
            c: data["executed_through_runtime"]
            for c, data in matrix["components"].items()
        },
        "phases_resolved": matrix["components"]["PhaseRegistry"]["evidence"].get("resolved_phases"),
        "governance_allowed": matrix["components"]["GovernanceCompiler"]["evidence"].get("allowed"),
        "executor_id": matrix["components"]["KernelMPPExecutor"]["evidence"].get("executor_id"),
        "phases_executed": matrix["components"]["KernelMPPExecutor"]["evidence"].get("phases_executed"),
        "artifact_ids": matrix["components"]["ArtifactStore"]["evidence"].get("artifact_ids"),
    }
    matrix["determinism_hash"] = fingerprint(determinism_payload)

    if _tmpdir:
        _tmpdir.cleanup()

    return matrix


def run_determinism_check(data_root: str | Path | None = None) -> dict:
    """
    Run the validation twice and confirm determinism_hash matches.
    Returns dict with passed=True/False and both hashes.
    """
    import tempfile

    with tempfile.TemporaryDirectory() as d:
        r1 = run_wiring_validation(d)
    with tempfile.TemporaryDirectory() as d:
        r2 = run_wiring_validation(d)

    h1 = r1.get("determinism_hash")
    h2 = r2.get("determinism_hash")

    return {
        "passed": h1 == h2,
        "run_1_hash": h1,
        "run_2_hash": h2,
        "run_1_status": r1.get("kernel_wiring_status"),
        "run_2_status": r2.get("kernel_wiring_status"),
    }


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Kernel Wiring Validation Runner")
    parser.add_argument("--data-root", default=None, help="Persistent data root (optional)")
    parser.add_argument("--determinism-check", action="store_true", help="Run twice and check determinism")
    parser.add_argument("--output", default=None, help="Write matrix JSON to this path")
    args = parser.parse_args()

    if args.determinism_check:
        result = run_determinism_check(args.data_root)
        print(json.dumps(result, indent=2))
    else:
        matrix = run_wiring_validation(args.data_root)
        print(json.dumps(matrix, indent=2))
        if args.output:
            Path(args.output).write_text(json.dumps(matrix, indent=2), encoding="utf-8")
            print(f"\nMatrix written to: {args.output}", file=sys.stderr)
