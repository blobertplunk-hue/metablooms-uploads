"""
Governance Compiler (Kernel)
-----------------------------
Kernel version. Identical semantics to the runtime extension version
(which is now fixed and tested) but imports phase authority from
PhaseRegistry rather than using a local constant list.

Schema: MB-GOVERNANCE-COMPILER-1.0
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from phase_registry import PhaseRegistry

SCHEMA = "MB-GOVERNANCE-COMPILER-1.0"


@dataclass
class GovResult:
    allowed: bool
    violations: list[str] = field(default_factory=list)


class KernelGovernanceCompiler:
    """
    Validates a plan against governance policy before execution.
    Fail-closed: if allowed=False, MPPExecutor must not run.
    """
    schema = SCHEMA

    def __init__(
        self,
        forbidden_engines: list[str] | None = None,
        allowed_phases: list[str] | None = None,
        phase_registry: PhaseRegistry | None = None,
    ):
        self.forbidden_engines: set[str] = set(forbidden_engines or [])
        self.phase_registry = phase_registry or PhaseRegistry()
        # if allowed_phases not specified, all canonical phases are allowed
        self.allowed_phases: set[str] = (
            set(allowed_phases) if allowed_phases is not None
            else set(self.phase_registry.all_phases())
        )

    def validate(self, plan: Any) -> GovResult:
        """
        Validates plan. Returns GovResult with allowed=False if any violation.
        Collects ALL violations before returning (not fail-fast).
        """
        violations: list[str] = []

        if hasattr(plan, "phases"):
            phase_entries = plan.phases
        elif hasattr(plan, "engine_attachments"):
            phase_entries = [
                {"phase": p, "engines": e}
                for p, e in plan.engine_attachments.items()
            ]
        else:
            phase_entries = []

        for entry in phase_entries:
            if isinstance(entry, dict):
                phase = entry.get("phase", "")
                engines = entry.get("engines", [])
            else:
                phase = getattr(entry, "phase", "")
                engines = getattr(entry, "engines", [])

            # phase must be in allowed set
            if phase and phase not in self.allowed_phases:
                violations.append(f"Phase '{phase}' is not in allowed_phases")

            # no forbidden engines
            for engine in engines:
                if engine in self.forbidden_engines:
                    violations.append(
                        f"Engine '{engine}' is forbidden by governance policy"
                    )

        return GovResult(allowed=len(violations) == 0, violations=violations)
