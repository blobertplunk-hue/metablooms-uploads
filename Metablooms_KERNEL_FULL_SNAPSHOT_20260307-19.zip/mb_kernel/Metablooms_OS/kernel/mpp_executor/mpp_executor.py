"""
MPP Executor (Kernel)
---------------------
Kernel version. Wraps the runtime extension MPPExecutor and adds:
  - ArtifactStore integration: results are stored and receipted
  - CommitSystem integration: each execution produces a commit
  - StateLoader gate: execution blocked if boot_status != BOOT_OK

Schema: MB-MPP-EXECUTOR-KERNEL-1.0
"""

from __future__ import annotations

import datetime
import hashlib
import json
from dataclasses import dataclass, field
from typing import Any, Callable, Optional

from artifact_store import ArtifactStore
from commit_system import CommitSystem
from state_loader import StateLoader, BootStatus

SCHEMA = "MB-MPP-EXECUTOR-KERNEL-1.0"
_SELF_ID = "mpp_executor"


class KernelMPPExecutorError(Exception):
    pass


@dataclass
class KernelExecResult:
    phases_executed: list[str]
    results: dict[str, Any]
    artifact_ids: list[str]
    commit_id: Optional[str]
    failed_engines: list[str] = field(default_factory=list)
    enforcer_violations: list[str] = field(default_factory=list)
    receipt: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return not self.failed_engines and not self.enforcer_violations


def _unpack(entry: Any) -> tuple[Callable, dict]:
    if isinstance(entry, tuple) and len(entry) == 2:
        fn, gov = entry
        return fn, gov if isinstance(gov, dict) else {}
    return entry, {}


class KernelMPPExecutor:

    schema = SCHEMA

    def __init__(
        self,
        engine_map: dict[str, Any],
        artifact_store: ArtifactStore,
        commit_system: CommitSystem,
        state_loader: StateLoader,
    ):
        self.engine_map = engine_map
        self.store = artifact_store
        self.commits = commit_system
        self.state_loader = state_loader

    def execute(self, plan: Any, intent_type: str = "unknown") -> KernelExecResult:
        # Gate: require successful boot
        try:
            session_state = self.state_loader.require_booted()
        except Exception as e:
            raise KernelMPPExecutorError(f"Execution blocked: {e}")

        phases_executed: list[str] = []
        results: dict[str, Any] = {}
        failed_engines: list[str] = []
        enforcer_violations: list[str] = []
        artifact_ids: list[str] = []

        for phase_entry in getattr(plan, "phases", []):
            phase = phase_entry["phase"] if isinstance(phase_entry, dict) else phase_entry.phase
            engines = phase_entry.get("engines", []) if isinstance(phase_entry, dict) else getattr(phase_entry, "engines", [])

            for engine_name in engines:
                raw = self.engine_map.get(engine_name)
                if raw is None:
                    failed_engines.append(engine_name)
                    continue

                fn, governance = _unpack(raw)

                # CDR Pillar 8 enforcer check
                declared_enforcer = governance.get("receipt_enforcer")
                if governance.get("requires_receipt", False) and declared_enforcer:
                    if declared_enforcer != _SELF_ID:
                        enforcer_violations.append(
                            f"{engine_name}: receipt_enforcer='{declared_enforcer}' != '{_SELF_ID}'"
                        )
                        failed_engines.append(engine_name)
                        continue

                try:
                    result = fn()
                    results[engine_name] = result

                    # store artifact if engine is artifact-producing
                    if governance.get("artifact_producing", True):
                        store_receipt = self.store.store(
                            result, engine_name, phase, intent_type
                        )
                        artifact_ids.append(store_receipt.artifact_id)

                except Exception as e:
                    failed_engines.append(engine_name)
                    results[engine_name] = {"error": str(e)}

            phases_executed.append(phase)

        # commit if we have artifacts and no failures.
        # INVARIANT: every stored artifact must have a commit record.
        # On partial failure, artifacts are stored but uncommittable.
        # Record orphaned_artifact_ids explicitly — no silent state (ECL P5).
        commit_id = None
        orphaned_artifact_ids: list[str] = []
        if artifact_ids and not failed_engines and not enforcer_violations:
            try:
                commit = self.commits.commit(
                    artifact_ids=artifact_ids,
                    engine_id=",".join(results.keys()),
                    phase=phases_executed[-1] if phases_executed else "unknown",
                    intent=intent_type,
                )
                commit_id = commit.commit_id
            except Exception as e:
                enforcer_violations.append(f"commit_failed:{e}")
                orphaned_artifact_ids = list(artifact_ids)
        elif artifact_ids and (failed_engines or enforcer_violations):
            orphaned_artifact_ids = list(artifact_ids)

        receipt = {
            "schema": SCHEMA,
            "executor_id": _SELF_ID,
            "timestamp_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "session_id": session_state.session_id,
            "turn": session_state.turn,
            "phases_executed": phases_executed,
            "artifact_ids": artifact_ids,
            "commit_id": commit_id,
            "failed_engines": failed_engines,
            "enforcer_violations": enforcer_violations,
            "ok": not failed_engines and not enforcer_violations,
            "orphaned_artifact_ids": orphaned_artifact_ids,
        }

        return KernelExecResult(
            phases_executed=phases_executed,
            results=results,
            artifact_ids=artifact_ids,
            commit_id=commit_id,
            failed_engines=failed_engines,
            enforcer_violations=enforcer_violations,
            receipt=receipt,
        )
