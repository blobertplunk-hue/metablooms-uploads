"""
KernelContext
-------------
Factory that builds and wires all kernel components together.

Constraint: stateless-first. Every turn calls build_kernel_context()
which reconstructs in-memory state from persisted ArtifactStore +
CommitSystem. No global singletons.

Constructor dependency order (must be respected):
  ArtifactStore (root)
  CommitSystem  (ArtifactStore, commit_root)
  StateLoader   (ArtifactStore, CommitSystem, session_id)
  PhaseRegistry (no deps)
  KernelGovernanceCompiler (PhaseRegistry)
  KernelPipelinePlanner    (PhaseRegistry)
  KernelEngineRegistry     (no deps)
  CapabilityResolver       (KernelEngineRegistry, PhaseRegistry)
  KernelMPPExecutor        (engine_map, ArtifactStore, CommitSystem, StateLoader)

Legacy impact: replaces direct filesystem writes in runtime_orchestrator.
Prior runtime used inline dicts + ASG writes with no commit trail.
This context provides a commit-chained, boot-gated replacement.

Schema: MB-KERNEL-CONTEXT-1.0
"""

from __future__ import annotations

import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# ------------------------------------------------------------------
# Path bootstrap — kernel components use flat local imports
# ------------------------------------------------------------------
_KERNEL_ROOT = Path(__file__).resolve().parent

_COMPONENT_DIRS = [
    "artifact_store", "commit_system", "state_loader",
    "fingerprint_engine", "phase_registry", "governance_compiler",
    "mpp_executor", "engine_registry", "capability_resolver",
    "ir_registry", "pipeline_planner",
]

for _comp in _COMPONENT_DIRS:
    _p = str(_KERNEL_ROOT / _comp)
    if _p not in sys.path:
        sys.path.insert(0, _p)

from artifact_store import ArtifactStore
from commit_system import CommitSystem
from state_loader import StateLoader
from phase_registry import PhaseRegistry
from governance_compiler import KernelGovernanceCompiler
from pipeline_planner import KernelPipelinePlanner
from engine_registry import KernelEngineRegistry
from capability_resolver import CapabilityResolver
from mpp_executor import KernelMPPExecutor

SCHEMA = "MB-KERNEL-CONTEXT-1.0"


@dataclass
class KernelContext:
    """
    Fully wired kernel. All components share the same ArtifactStore +
    CommitSystem instance — single source of truth per session.
    """
    artifact_store: ArtifactStore
    commit_system: CommitSystem
    state_loader: StateLoader
    phase_registry: PhaseRegistry
    governance_compiler: KernelGovernanceCompiler
    pipeline_planner: KernelPipelinePlanner
    engine_registry: KernelEngineRegistry
    capability_resolver: CapabilityResolver
    executor: KernelMPPExecutor
    session_id: str
    data_root: Path


def build_kernel_context(
    data_root: str | Path,
    engine_map: dict[str, Any] | None = None,
    session_id: str | None = None,
    forbidden_engines: list[str] | None = None,
) -> KernelContext:
    """
    Build a fully wired KernelContext for one session turn.

    data_root: persistent root directory for artifacts + commits.
    engine_map: dict of engine_name → callable (or (callable, governance_dict)).
                If None, executor is built with empty map (no engines run).
    session_id: stable identifier for this session. Defaults to new UUID.
    forbidden_engines: engines blocked by governance policy.
    """
    data_root = Path(data_root)
    session_id = session_id or str(uuid.uuid4())

    # Dependency order is load-bearing — do not reorder.
    store = ArtifactStore(data_root / "artifacts")
    commits = CommitSystem(store, data_root / "commits")
    loader = StateLoader(store, commits, session_id=session_id)

    phases = PhaseRegistry()
    governance = KernelGovernanceCompiler(
        forbidden_engines=forbidden_engines or [],
        phase_registry=phases,
    )
    planner = KernelPipelinePlanner(phase_registry=phases)

    registry = KernelEngineRegistry()
    resolver = CapabilityResolver(engine_registry=registry, phase_registry=phases)

    executor = KernelMPPExecutor(
        engine_map=engine_map or {},
        artifact_store=store,
        commit_system=commits,
        state_loader=loader,
    )

    return KernelContext(
        artifact_store=store,
        commit_system=commits,
        state_loader=loader,
        phase_registry=phases,
        governance_compiler=governance,
        pipeline_planner=planner,
        engine_registry=registry,
        capability_resolver=resolver,
        executor=executor,
        session_id=session_id,
        data_root=data_root,
    )
