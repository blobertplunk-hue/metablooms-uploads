"""
Capability Resolver
--------------------
Given an intent_type and a set of requested phases, resolves which engines
are authorized to run in which phases.

Pulls from the Engine Registry (what engines exist and what they declare)
and validates against Phase Registry (are those phases canonical).

Schema: MB-CAPABILITY-RESOLVER-1.0
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from phase_registry import PhaseRegistry, PhaseRegistryError

SCHEMA = "MB-CAPABILITY-RESOLVER-1.0"


@dataclass
class ResolvedPlan:
    intent_type: str
    phases: list[str]                       # canonical-ordered
    engine_attachments: dict[str, list[str]] # phase → [engine_ids]
    unresolved_phases: list[str]            # phases with no engine
    violations: list[str]

    @property
    def ok(self) -> bool:
        return len(self.violations) == 0


class CapabilityResolver:
    """
    Resolves intent + requested_phases → canonical engine attachment plan.
    """
    schema = SCHEMA

    def __init__(self, engine_registry: Any, phase_registry: Optional[PhaseRegistry] = None):
        self.engine_registry = engine_registry
        self.phase_registry = phase_registry or PhaseRegistry()

    def resolve(
        self,
        intent_type: str,
        requested_phases: list[str],
        engine_attachments_hint: Optional[dict[str, list[str]]] = None,
    ) -> ResolvedPlan:
        """
        Resolve which engines run in which phases.
        engine_attachments_hint: from CommandBus dispatch — used as starting point.
        The resolver validates and fills gaps.
        """
        violations: list[str] = []

        # validate phases
        phase_violations = self.phase_registry.validate_phases(requested_phases)
        violations.extend(phase_violations)

        # sort into canonical order
        try:
            ordered_phases = self.phase_registry.sort_phases(requested_phases)
        except PhaseRegistryError as e:
            violations.append(str(e))
            ordered_phases = []

        # start from hint or empty
        attachments: dict[str, list[str]] = {}
        for phase in ordered_phases:
            hint_engines = (engine_attachments_hint or {}).get(phase, [])
            # validate each engine exists and declares this phase
            valid_engines = []
            for engine_id in hint_engines:
                spec = self.engine_registry.get_spec(engine_id)
                if spec is None:
                    violations.append(f"unknown_engine:{engine_id}")
                elif phase not in spec.get("phases", []):
                    violations.append(
                        f"engine_{engine_id}_not_declared_for_phase:{phase}"
                    )
                else:
                    valid_engines.append(engine_id)
            attachments[phase] = valid_engines

        unresolved = [p for p, engines in attachments.items() if not engines]

        return ResolvedPlan(
            intent_type=intent_type,
            phases=ordered_phases,
            engine_attachments=attachments,
            unresolved_phases=unresolved,
            violations=violations,
        )
