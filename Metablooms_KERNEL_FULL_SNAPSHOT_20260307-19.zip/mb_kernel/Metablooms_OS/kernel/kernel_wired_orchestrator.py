"""
Runtime Orchestrator — Kernel Wired
-------------------------------------
Extends RuntimeOrchestrator to route execution through the MetaBlooms kernel.

Feature flag: USE_KERNEL_EXECUTOR = True
  True  → capability resolution, planning, governance, and execution all
           go through kernel components. Results are stored in ArtifactStore
           and committed via CommitSystem.
  False → falls back to original runtime behavior (legacy path, unchanged).

Legacy impact: replaces direct inline planning/governance/execution in
  runtime_orchestrator_with_write_repair.py. Prior orchestrator had no
  commit trail and no boot gate. Kernel path adds both.

Constraint: kernel path requires state_loader.boot() to succeed before
  any execution. If boot fails, run() returns status='kernel_boot_failed'.

Integration reciprocity:
  - Caller provides a KernelContext (from build_kernel_context()).
  - ASG (AuthoritativeStateGate) is still used for the runtime receipt write
    (the outer envelope). Kernel handles inner artifact commits.
  - graph/dashboard engines remain on ASG writes (derived views, not
    executable artifacts — storing them in ArtifactStore creates a loop).

Schema: MB-ORCHESTRATOR-WIRED-1.1

Change log (1.0 → 1.1):
  - Inserted MB-MPP-REASONING stage between pipeline_planner and governance_compiler.
  - Added ReasonedPlan dataclass: carries execution_plan, reasoning_graph,
    critic_report, and risk_report alongside the original KernelPlan.
  - Governance compiler now validates the ReasonedPlan (plan + reasoning artifacts).
  - Execution is blocked if reasoning_result.valid is False.
  - REQUIRE_REASONING flag: True = fail-closed (recommended). False = skip reasoning
    with a warning in result (backward-compat during transition only).

Legacy impact (1.0): orchestrator ran intent → plan → governance → execute with
  no pre-execution reasoning gate. Reasoning was advisory (system prompt only).
  Now reasoning is enforced MPP law when REQUIRE_REASONING = True.
"""

from __future__ import annotations

import importlib.util
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

# Kernel path bootstrap
_KERNEL_ROOT = Path(__file__).resolve().parents[2] / "kernel"
_KERNEL_COMP_DIRS = [
    "artifact_store", "commit_system", "state_loader",
    "fingerprint_engine", "phase_registry", "governance_compiler",
    "mpp_executor", "engine_registry", "capability_resolver",
    "ir_registry", "pipeline_planner", "reasoning_engine",
]
for _comp in _KERNEL_COMP_DIRS:
    _p = str(_KERNEL_ROOT / _comp)
    if _p not in sys.path:
        sys.path.insert(0, _p)

_KERNEL_CTX_PATH = str(_KERNEL_ROOT)
if _KERNEL_CTX_PATH not in sys.path:
    sys.path.insert(0, _KERNEL_CTX_PATH)

from deterministic_write_repair import ensure_writable
from authoritative_state_gate import AuthoritativeStateGate
from runtime_orchestrator_with_write_repair import RuntimeOrchestrator, _normalize_result

# ── Feature flags ─────────────────────────────────────────────────────────────
# USE_KERNEL_EXECUTOR: False reverts entirely to legacy RuntimeOrchestrator.
USE_KERNEL_EXECUTOR = True

# REQUIRE_REASONING: True = fail-closed (execution blocked without valid reasoning).
# False = skip reasoning stage with a warning (backward-compat transition mode only).
# Production value: True.
REQUIRE_REASONING = True


# ── ReasonedPlan ──────────────────────────────────────────────────────────────
@dataclass
class ReasonedPlan:
    """
    Carries a KernelPlan together with the reasoning artifacts produced by
    MB-MPP-REASONING. Passed to governance_compiler in place of the raw plan.

    Fields:
        kernel_plan:        original KernelPlan from pipeline_planner
        execution_plan:     R6 execution plan artifact from reasoning engine
        reasoning_graph:    R4 multi-path reasoning tree artifact
        critic_report:      R5 critic review artifact
        risk_report:        derived risk summary (warn items from R6)
        reasoning_run_id:   fingerprint of the reasoning run
        reasoning_valid:    True if all R1-R6 phases passed
        reasoning_artifact_ids: artifact_ids committed during reasoning
        reasoning_commit_id:    commit_id of the reasoning run
    """
    kernel_plan: Any
    execution_plan: dict = field(default_factory=dict)
    reasoning_graph: dict = field(default_factory=dict)
    critic_report: dict = field(default_factory=dict)
    risk_report: dict = field(default_factory=dict)
    reasoning_run_id: str = ""
    reasoning_valid: bool = False
    reasoning_artifact_ids: list = field(default_factory=list)
    reasoning_commit_id: Optional[str] = None

    @property
    def intent_type(self):
        return getattr(self.kernel_plan, "intent_type", "unknown")

    @property
    def phases(self):
        return getattr(self.kernel_plan, "phases", [])

    @property
    def engine_attachments(self):
        return getattr(self.kernel_plan, "engine_attachments", {})

    @property
    def phase_order_violations(self):
        return getattr(self.kernel_plan, "phase_order_violations", [])

    @property
    def ok(self):
        return getattr(self.kernel_plan, "ok", False) and self.reasoning_valid


class KernelWiredOrchestrator:
    """
    Drop-in replacement for RuntimeOrchestrator when USE_KERNEL_EXECUTOR=True.
    Falls back to RuntimeOrchestrator when flag is False.
    """

    def __init__(
        self,
        kernel_context,           # KernelContext from build_kernel_context()
        legacy_orchestrator=None, # RuntimeOrchestrator — used when flag=False
        receipt_root=None,
    ):
        self.kernel = kernel_context
        self.legacy = legacy_orchestrator
        self.receipt_root = Path(receipt_root or (_HERE / "runtime_receipts"))
        self.gate = AuthoritativeStateGate()

    def _write_runtime_receipt(self, payload: dict) -> dict:
        self.receipt_root.mkdir(parents=True, exist_ok=True)
        receipt_file = self.receipt_root / "runtime_orchestrator_receipt.json"
        receipt = self.gate.write_verified_json(
            receipt_file,
            payload,
            schema={"type": "object", "required": ["status", "intent", "write_state"]},
        )
        return {
            "receipt_path": str(receipt_file),
            "receipt_sha256": receipt.sha256,
            "authoritative": receipt.authoritative,
        }

    def run(self, user_input: str) -> dict:
        if not USE_KERNEL_EXECUTOR:
            if self.legacy is None:
                raise RuntimeError(
                    "USE_KERNEL_EXECUTOR=False but no legacy_orchestrator provided."
                )
            return self.legacy.run(user_input)

        return self._kernel_run(user_input)

    def _kernel_run(self, user_input: str) -> dict:
        write_state = ensure_writable()
        kernel = self.kernel

        # --- BOOT GATE ---
        try:
            boot_receipt = kernel.state_loader.boot()
        except Exception as e:
            result = {
                "status": "kernel_boot_error",
                "write_state": write_state,
                "intent": "unknown",
                "detail": str(e),
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        if boot_receipt.boot_status != "BOOT_OK":
            result = {
                "status": "kernel_boot_failed",
                "write_state": write_state,
                "intent": "unknown",
                "boot_violations": boot_receipt.violations,
                "boot_warnings": boot_receipt.warnings,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- CAPABILITY RESOLUTION (kernel command bus via CapabilityResolver) ---
        # For now: direct intent dispatch via IR registry pattern.
        # CapabilityResolver.resolve() requires engine_registry to have engines.
        # We use a simple intent extraction from user_input and build a plan directly.
        intent_type = self._extract_intent(user_input)

        if intent_type == "unknown":
            result = {
                "status": "unknown_intent",
                "write_state": write_state,
                "intent": intent_type,
                "detail": f"No route for input: {repr(user_input)}",
                "session_id": kernel.session_id,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- PIPELINE PLANNING (kernel) ---
        plan = kernel.pipeline_planner.create_plan(
            intent_type=intent_type,
            requested_phases=["verification"],
            engine_attachments={"verification": [intent_type]},
        )

        if getattr(plan, "phase_order_violations", []):
            result = {
                "status": "plan_error",
                "write_state": write_state,
                "intent": intent_type,
                "violations": plan.phase_order_violations,
                "session_id": kernel.session_id,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- MB-MPP-REASONING (pre-execution reasoning gate) ---
        # Sits between pipeline_planner and governance_compiler.
        # Produces ReasonedPlan carrying execution_plan, reasoning_graph,
        # critic_report, and risk_report. Governance validates the full ReasonedPlan.
        # Execution is blocked if reasoning_result.valid is False (REQUIRE_REASONING=True).
        reasoned_plan = self._run_reasoning_stage(
            plan, intent_type, user_input, write_state, kernel
        )
        if reasoned_plan is None:
            # _run_reasoning_stage returned None = hard block with result already written
            # This path is taken when REQUIRE_REASONING=True and reasoning fails.
            # The result was already returned inside _run_reasoning_stage.
            # We use a sentinel to signal the caller.
            return self._reasoning_blocked_sentinel

        # --- GOVERNANCE (kernel) — validates ReasonedPlan ---
        gov_result = kernel.governance_compiler.validate(reasoned_plan)
        if not gov_result.allowed:
            result = {
                "status": "rejected",
                "write_state": write_state,
                "intent": intent_type,
                "violations": gov_result.violations,
                "session_id": kernel.session_id,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- EXECUTION (kernel MPP executor — boot-gated, artifact-storing) ---
        exec_result = kernel.executor.execute(reasoned_plan, intent_type=intent_type)

        status = "ok"
        if not exec_result.ok:
            status = "partial" if exec_result.failed_engines else "failed"

        result = {
            "status": status,
            "write_state": write_state,
            "intent": intent_type,
            "session_id": kernel.session_id,
            "boot_status": boot_receipt.boot_status,
            "phases_executed": exec_result.phases_executed,
            "results": _normalize_result(exec_result.results),
            "artifact_ids": exec_result.artifact_ids,
            "commit_id": exec_result.commit_id,
            "failed_engines": exec_result.failed_engines,
            "enforcer_violations": exec_result.enforcer_violations,
            "execution_receipt": _normalize_result(exec_result.receipt),
            # Reasoning provenance
            "reasoning_run_id": reasoned_plan.reasoning_run_id,
            "reasoning_artifact_ids": reasoned_plan.reasoning_artifact_ids,
            "reasoning_commit_id": reasoned_plan.reasoning_commit_id,
        }
        result["verification"] = self._write_runtime_receipt(result)
        return result

    # ── Reasoning stage ───────────────────────────────────────────────────────

    def _run_reasoning_stage(
        self,
        plan,
        intent_type: str,
        user_input: str,
        write_state: dict,
        kernel,
    ):
        """
        Run MB-MPP-REASONING between pipeline_planner and governance_compiler.

        Returns a ReasonedPlan on success.
        Returns None if REQUIRE_REASONING=True and reasoning fails
          (sets self._reasoning_blocked_sentinel so caller can return it).
        Returns a pass-through ReasonedPlan with reasoning_valid=False and
          a warning if REQUIRE_REASONING=False.

        Fail-closed semantics: any exception in the reasoning stage is treated
        as a reasoning failure, not silently swallowed.
        """
        self._reasoning_blocked_sentinel = None

        # Load reasoning engine — registered in sys.modules during bootstrap
        reasoning_engine_mod = sys.modules.get("reasoning_engine")
        if reasoning_engine_mod is None:
            # Try loading from kernel path
            re_path = _KERNEL_ROOT / "reasoning_engine" / "reasoning_engine.py"
            if re_path.exists():
                spec = importlib.util.spec_from_file_location("reasoning_engine", re_path)
                reasoning_engine_mod = importlib.util.module_from_spec(spec)
                sys.modules["reasoning_engine"] = reasoning_engine_mod
                spec.loader.exec_module(reasoning_engine_mod)

        if reasoning_engine_mod is None:
            if REQUIRE_REASONING:
                self._reasoning_blocked_sentinel = {
                    "status": "reasoning_engine_not_found",
                    "write_state": write_state,
                    "intent": intent_type,
                    "detail": "reasoning_engine module could not be loaded. "
                              "Set REQUIRE_REASONING=False to bypass.",
                }
                self._reasoning_blocked_sentinel["verification"] = \
                    self._write_runtime_receipt(self._reasoning_blocked_sentinel)
                return None
            # REQUIRE_REASONING=False: pass through with warning
            return ReasonedPlan(kernel_plan=plan, reasoning_valid=False)

        ReasoningEngine = reasoning_engine_mod.ReasoningEngine

        try:
            engine = ReasoningEngine(kernel.artifact_store, kernel.commit_system)

            # Context for the reasoning engine
            context = {
                "component": intent_type,
                "layer": "runtime",
                "creates_state": True,
                "intent_type": intent_type,
                "user_input": user_input[:200],
            }

            # Default single approach derived from the kernel plan.
            # When an LLM caller is wired in, it will generate multiple approaches.
            # For structural mode (no LLM), we provide the plan as the single approach.
            default_approaches = [{
                "option_id": "A",
                "description": (
                    f"Execute intent '{intent_type}' through the kernel pipeline: "
                    "capability_resolver → pipeline_planner → governance_compiler "
                    "→ kernel_mpp_executor → artifact_store → commit_system. "
                    "All state written via artifact_store.store() and committed "
                    "via commit_system.commit(). Module docstring present (ECL header). "
                    "Uses canonical_json with sort_keys=True for all hashes."
                ),
                "components_touched": [
                    "capability_resolver", "pipeline_planner",
                    "governance_compiler", "kernel_mpp_executor",
                    "artifact_store", "commit_system",
                ],
                "primary_risk": "None — canonical kernel path",
            }]

            reasoning_result = engine.reason(
                intent=intent_type,
                context=context,
                approaches=default_approaches,
            )

        except Exception as e:
            if REQUIRE_REASONING:
                self._reasoning_blocked_sentinel = {
                    "status": "reasoning_stage_error",
                    "write_state": write_state,
                    "intent": intent_type,
                    "detail": f"Reasoning engine raised: {e}",
                }
                self._reasoning_blocked_sentinel["verification"] = \
                    self._write_runtime_receipt(self._reasoning_blocked_sentinel)
                return None
            return ReasonedPlan(kernel_plan=plan, reasoning_valid=False)

        if not reasoning_result.valid:
            if REQUIRE_REASONING:
                self._reasoning_blocked_sentinel = {
                    "status": "reasoning_blocked",
                    "write_state": write_state,
                    "intent": intent_type,
                    "block_reason": reasoning_result.block_reason,
                    "reasoning_run_id": reasoning_result.reasoning_run_id,
                    "reasoning_artifact_ids": reasoning_result.artifact_ids,
                    "reasoning_commit_id": reasoning_result.commit_id,
                }
                self._reasoning_blocked_sentinel["verification"] = \
                    self._write_runtime_receipt(self._reasoning_blocked_sentinel)
                return None
            # REQUIRE_REASONING=False: continue with warning
            return ReasonedPlan(
                kernel_plan=plan,
                reasoning_valid=False,
                reasoning_run_id=reasoning_result.reasoning_run_id,
                reasoning_artifact_ids=reasoning_result.artifact_ids,
                reasoning_commit_id=reasoning_result.commit_id,
            )

        # Extract reasoning artifacts for ReasonedPlan
        exec_plan = reasoning_result.execution_plan or {}
        r4_phase = next(
            (p for p in reasoning_result.phases if p.phase == "multi_path_reasoning"), None
        )
        r5_phase = next(
            (p for p in reasoning_result.phases if p.phase == "critic_review"), None
        )

        reasoning_graph = r4_phase.artifact if r4_phase else {}
        # Strip non-serializable _approach_objects before storing in plan
        reasoning_graph = {k: v for k, v in reasoning_graph.items()
                           if k != "_approach_objects"}
        critic_report = r5_phase.artifact if r5_phase else {}
        risk_report = {
            "warn_items": exec_plan.get("warn_items", []),
            "selected_approach": exec_plan.get("selected_approach"),
        }

        return ReasonedPlan(
            kernel_plan=plan,
            execution_plan=exec_plan,
            reasoning_graph=reasoning_graph,
            critic_report=critic_report,
            risk_report=risk_report,
            reasoning_run_id=reasoning_result.reasoning_run_id,
            reasoning_valid=True,
            reasoning_artifact_ids=reasoning_result.artifact_ids,
            reasoning_commit_id=reasoning_result.commit_id,
        )

    def _extract_intent(self, user_input: str) -> str:
        """
        Simple keyword-based intent extraction.
        Routes to IRRegistry intents. Returns 'unknown' if no match.
        Constraint: deterministic — same input always produces same intent.
        """
        lowered = user_input.lower()
        # Ordered — first match wins
        _ROUTES = [
            (["egg_juicer", "egg juicer", "run_egg_juicer"], "run_egg_juicer"),
            (["replay", "replay_pack"], "replay_pack"),
            (["dashboard", "status"], "dashboard"),
            (["index", "graph_index"], "graph_index"),
        ]
        for keywords, intent in _ROUTES:
            if any(kw in lowered for kw in keywords):
                return intent
        return "unknown"
