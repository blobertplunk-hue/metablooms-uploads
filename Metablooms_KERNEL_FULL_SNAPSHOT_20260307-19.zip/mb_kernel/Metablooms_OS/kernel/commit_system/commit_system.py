"""
Commit System
-------------
Append-only commit log for MetaBlooms OS. Every state transition that
produces verified artifacts is recorded here permanently.

Rules:
  1. Commits are append-only. No commit may be modified or deleted.
  2. Every commit references one or more artifact_ids from the ArtifactStore.
  3. Every commit is fingerprinted and chained: commit_N includes the
     fingerprint of commit_(N-1). This creates a tamper-evident log.
  4. A commit without valid artifact_ids from the store is rejected.

This is the "Commit System" kernel component.
It wraps ArtifactStore — artifacts are stored first, then committed.

Schema: MB-COMMIT-SYSTEM-1.0
"""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from fingerprint_engine import fingerprint, canonical_json
from artifact_store import ArtifactStore, ArtifactStoreError

SCHEMA = "MB-COMMIT-SYSTEM-1.0"
COMMIT_LOG_FILENAME = "_commit_log.json"
GENESIS_HASH = "0" * 64  # sentinel for first commit


class CommitSystemError(Exception):
    pass


@dataclass
class CommitRecord:
    commit_id: str          # "commit:<fingerprint of commit payload>"
    commit_index: int       # monotonic, 0-based
    artifact_ids: list[str]
    engine_id: str
    phase: str
    intent: str
    parent_commit_hash: str # fingerprint of previous commit record (GENESIS_HASH if first)
    commit_hash: str        # fingerprint of this commit record (excluding commit_hash itself)
    timestamp_utc: str
    metadata: dict


class CommitSystem:
    """
    Append-only commit log chained to the ArtifactStore.
    commit_root: directory for the commit log file.
    """

    schema = SCHEMA

    def __init__(self, artifact_store: ArtifactStore, commit_root: str | Path):
        self.store = artifact_store
        self.commit_root = Path(commit_root)
        self.commit_root.mkdir(parents=True, exist_ok=True)
        self._log: list[CommitRecord] = []
        self._load_log()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def commit(
        self,
        artifact_ids: list[str],
        engine_id: str,
        phase: str,
        intent: str,
        metadata: Optional[dict] = None,
    ) -> CommitRecord:
        """
        Commit a set of artifact_ids to the append-only log.
        All artifact_ids must exist in the ArtifactStore.
        Returns the CommitRecord.
        """
        # Validate all artifact_ids exist
        missing = [aid for aid in artifact_ids if not self.store.exists(aid)]
        if missing:
            raise CommitSystemError(
                f"Cannot commit artifact_ids not in store: {missing}"
            )

        parent_hash = self._last_commit_hash()
        commit_index = len(self._log)

        # Build payload (without commit_hash) to fingerprint
        payload = {
            "commit_index": commit_index,
            "artifact_ids": sorted(artifact_ids),
            "engine_id": engine_id,
            "phase": phase,
            "intent": intent,
            "parent_commit_hash": parent_hash,
            "timestamp_utc": _now_utc(),
            "metadata": metadata or {},
        }
        commit_hash = fingerprint(payload)
        commit_id = f"commit:{commit_hash}"

        record = CommitRecord(
            commit_id=commit_id,
            commit_index=commit_index,
            artifact_ids=sorted(artifact_ids),
            engine_id=engine_id,
            phase=phase,
            intent=intent,
            parent_commit_hash=parent_hash,
            commit_hash=commit_hash,
            timestamp_utc=payload["timestamp_utc"],
            metadata=metadata or {},
        )

        self._log.append(record)
        self._persist_log()
        return record

    def head(self) -> Optional[CommitRecord]:
        """Most recent commit, or None if log is empty."""
        return self._log[-1] if self._log else None

    def get(self, commit_id: str) -> Optional[CommitRecord]:
        for record in self._log:
            if record.commit_id == commit_id:
                return record
        return None

    def log(self) -> list[CommitRecord]:
        """Full ordered commit log, oldest first."""
        return list(self._log)

    def verify_chain(self) -> list[str]:
        """
        Verify the chain integrity. Returns list of violations.
        Empty = chain is intact.
        """
        violations = []
        expected_parent = GENESIS_HASH

        for record in self._log:
            if record.parent_commit_hash != expected_parent:
                violations.append(
                    f"commit_{record.commit_index}: parent_hash mismatch "
                    f"(expected {expected_parent[:8]}..., "
                    f"got {record.parent_commit_hash[:8]}...)"
                )
            # verify commit_hash matches payload
            payload = {
                "commit_index": record.commit_index,
                "artifact_ids": record.artifact_ids,
                "engine_id": record.engine_id,
                "phase": record.phase,
                "intent": record.intent,
                "parent_commit_hash": record.parent_commit_hash,
                "timestamp_utc": record.timestamp_utc,
                "metadata": record.metadata,
            }
            expected_hash = fingerprint(payload)
            if record.commit_hash != expected_hash:
                violations.append(
                    f"commit_{record.commit_index}: commit_hash corrupted"
                )
            expected_parent = record.commit_hash

        return violations

    def log_fingerprint(self) -> str:
        """SHA-256 of the entire commit log. For cross-session integrity."""
        return fingerprint([asdict(r) for r in self._log])

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _last_commit_hash(self) -> str:
        if not self._log:
            return GENESIS_HASH
        return self._log[-1].commit_hash

    def _load_log(self) -> None:
        log_path = self.commit_root / COMMIT_LOG_FILENAME
        if log_path.exists():
            try:
                raw = json.loads(log_path.read_text(encoding="utf-8"))
                for rec_dict in raw.get("commits", []):
                    self._log.append(CommitRecord(**rec_dict))
            except Exception:
                self._log = []

    def _persist_log(self) -> None:
        log_path = self.commit_root / COMMIT_LOG_FILENAME
        serialized = {
            "schema": SCHEMA,
            "commit_count": len(self._log),
            "head": self._log[-1].commit_hash if self._log else None,
            "commits": [asdict(r) for r in self._log],
        }
        encoded = canonical_json(serialized).encode("utf-8")
        log_path.write_bytes(encoded)
        if log_path.read_bytes() != encoded:
            raise CommitSystemError("Commit log write verification failed")


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()
