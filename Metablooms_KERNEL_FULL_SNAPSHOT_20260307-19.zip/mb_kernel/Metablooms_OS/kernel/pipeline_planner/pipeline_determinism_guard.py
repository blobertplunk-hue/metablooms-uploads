"""
Pipeline Determinism Guard
--------------------------
Verifies that a pipeline plan is deterministic before execution is permitted.

A plan is deterministic if:
  1. Phase order is canonical (enforced by PhaseRegistry).
  2. Every engine in the plan declares deterministic=True in its spec.
  3. No two engines in the same phase produce the same output field
     (output field collision would make result order-dependent).

If any check fails → execution is blocked (fail-closed).

Schema: MB-PIPELINE-DETERMINISM-GUARD-1.0
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from phase_registry import PhaseRegistry, CANONICAL_PHASES

SCHEMA = "MB-PIPELINE-DETERMINISM-GUARD-1.0"


@dataclass
class DeterminismReport:
    ok: bool
    violations: list[str]
    warnings: list[str]
    checked_engines: list[str]


class PipelineDeterminismGuard:
    """
    Pre-execution determinism gate. Must pass before MPPExecutor runs.
    """
    schema = SCHEMA

    def __init__(self, engine_registry: Any, phase_registry: Optional[PhaseRegistry] = None):
        self.engine_registry = engine_registry
        self.phase_registry = phase_registry or PhaseRegistry()

    def check(self, plan: Any) -> DeterminismReport:
        """
        plan: object with .phases (list of {phase, engines}) attribute
              or dict with same structure.
        """
        violations: list[str] = []
        warnings: list[str] = []
        checked_engines: list[str] = []

        if hasattr(plan, "phases"):
            phase_entries = plan.phases
        else:
            phase_entries = plan.get("phases", [])

        # Check 1: phase ordering
        phase_names = [
            e["phase"] if isinstance(e, dict) else e.phase
            for e in phase_entries
        ]
        phase_violations = self.phase_registry.validate_phases(phase_names)
        violations.extend(phase_violations)

        if not phase_violations:
            try:
                sorted_names = self.phase_registry.sort_phases(phase_names)
                if sorted_names != phase_names:
                    violations.append(
                        f"phase_order_violation: got {phase_names}, "
                        f"expected {sorted_names}"
                    )
            except Exception as e:
                violations.append(f"phase_sort_error:{e}")

        # Check 2: engine determinism declarations + output field collisions
        for entry in phase_entries:
            if isinstance(entry, dict):
                phase = entry["phase"]
                engines = entry.get("engines", [])
            else:
                phase = entry.phase
                engines = getattr(entry, "engines", [])

            output_fields_seen: set[str] = set()
            for engine_id in engines:
                checked_engines.append(engine_id)
                spec = self.engine_registry.get_spec(engine_id)

                if spec is None:
                    violations.append(f"unknown_engine_in_plan:{engine_id}")
                    continue

                if not spec.get("deterministic", False):
                    violations.append(
                        f"engine_{engine_id}_not_deterministic: "
                        f"non-deterministic engine in governed pipeline"
                    )

                for output in spec.get("outputs", []):
                    field_name = output.get("name") if isinstance(output, dict) else str(output)
                    if field_name in output_fields_seen:
                        violations.append(
                            f"output_field_collision_in_{phase}:{field_name}"
                        )
                    output_fields_seen.add(field_name)

        return DeterminismReport(
            ok=len(violations) == 0,
            violations=violations,
            warnings=warnings,
            checked_engines=list(set(checked_engines)),
        )
