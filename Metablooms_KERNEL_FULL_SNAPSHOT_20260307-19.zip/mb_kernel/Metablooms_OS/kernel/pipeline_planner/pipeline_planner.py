"""
Pipeline Planner (Kernel)
--------------------------
Kernel version of the pipeline planner. Differs from the runtime extension
version in that it delegates phase authority to PhaseRegistry rather than
maintaining its own CANONICAL_PHASE_ORDER list.

Schema: MB-PIPELINE-PLANNER-1.0
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from phase_registry import PhaseRegistry, PhaseRegistryError

SCHEMA = "MB-PIPELINE-PLANNER-1.0"


@dataclass
class KernelPlan:
    intent_type: str
    phases: list[dict]                  # [{"phase": str, "engines": [str]}]
    engine_attachments: dict[str, list[str]]
    phase_order_violations: list[str]
    repo_root: Optional[str] = None

    @property
    def ok(self) -> bool:
        return len(self.phase_order_violations) == 0


class KernelPipelinePlanner:
    """
    Creates execution plans. Delegates all phase authority to PhaseRegistry.
    """
    schema = SCHEMA

    def __init__(self, phase_registry: Optional[PhaseRegistry] = None):
        self.phase_registry = phase_registry or PhaseRegistry()

    def create_plan(
        self,
        intent_type: str,
        requested_phases: list[str],
        engine_attachments: dict[str, list[str]],
        repo_root: Optional[str] = None,
    ) -> KernelPlan:
        violations: list[str] = []

        # validate phases against registry
        phase_violations = self.phase_registry.validate_phases(requested_phases)
        violations.extend(phase_violations)

        # sort into canonical order
        try:
            ordered_phases = self.phase_registry.sort_phases(requested_phases)
        except PhaseRegistryError as e:
            violations.append(str(e))
            ordered_phases = []

        # build structured phase list
        phase_list = [
            {"phase": p, "engines": engine_attachments.get(p, [])}
            for p in ordered_phases
        ]

        return KernelPlan(
            intent_type=intent_type,
            phases=phase_list,
            engine_attachments={p: engine_attachments.get(p, []) for p in ordered_phases},
            phase_order_violations=violations,
            repo_root=repo_root,
        )
