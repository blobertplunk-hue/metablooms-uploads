"""
Engine Registry (Kernel)
------------------------
Single authority for engine specs at the kernel level.
The runtime extension CanonicalEngineRegistry loads from disk packages.
This kernel version holds the in-memory authority consulted by the
Capability Resolver and Pipeline Determinism Guard.

Populated from CanonicalEngineRegistry at session boot.

Schema: MB-ENGINE-REGISTRY-1.0
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from fingerprint_engine import fingerprint

SCHEMA = "MB-ENGINE-REGISTRY-1.0"


class EngineRegistryError(Exception):
    pass


@dataclass
class EngineSpec:
    engine_id: str
    version: str
    purpose: str
    inputs: list[dict]
    outputs: list[dict]
    phases: list[str]
    deterministic: bool
    artifact_producing: bool
    governance: dict            # from engine_governance.json
    package_root: Optional[str] = None


class KernelEngineRegistry:
    """
    In-memory engine spec registry.
    Populated at session BOOT from CanonicalEngineRegistry.
    """
    schema = SCHEMA

    def __init__(self):
        self._specs: dict[str, EngineSpec] = {}

    def register(self, spec: EngineSpec) -> None:
        if spec.engine_id in self._specs:
            existing = self._specs[spec.engine_id]
            if existing.version != spec.version:
                # version bump — update
                self._specs[spec.engine_id] = spec
            # same version, same engine — idempotent
        else:
            self._specs[spec.engine_id] = spec

    def register_from_dict(self, spec_dict: dict, governance_dict: dict,
                           package_root: Optional[str] = None) -> EngineSpec:
        spec = EngineSpec(
            engine_id=spec_dict["engine_id"],
            version=spec_dict.get("version", "unknown"),
            purpose=spec_dict.get("purpose", ""),
            inputs=spec_dict.get("inputs", []),
            outputs=spec_dict.get("outputs", []),
            phases=spec_dict.get("phases", []),
            deterministic=spec_dict.get("deterministic", False),
            artifact_producing=spec_dict.get("artifact_producing", False),
            governance=governance_dict,
            package_root=package_root,
        )
        self.register(spec)
        return spec

    def get_spec(self, engine_id: str) -> Optional[dict]:
        """Returns spec as dict for compatibility with Capability Resolver / Guard."""
        spec = self._specs.get(engine_id)
        if spec is None:
            return None
        return {
            "engine_id": spec.engine_id,
            "version": spec.version,
            "purpose": spec.purpose,
            "inputs": spec.inputs,
            "outputs": spec.outputs,
            "phases": spec.phases,
            "deterministic": spec.deterministic,
            "artifact_producing": spec.artifact_producing,
            "governance": spec.governance,
        }

    def get(self, engine_id: str) -> Optional[EngineSpec]:
        return self._specs.get(engine_id)

    def list_engines(self) -> list[str]:
        return sorted(self._specs.keys())

    def engines_for_phase(self, phase: str) -> list[str]:
        return [eid for eid, spec in self._specs.items() if phase in spec.phases]

    def registry_fingerprint(self) -> str:
        return fingerprint({eid: self.get_spec(eid) for eid in self.list_engines()})
