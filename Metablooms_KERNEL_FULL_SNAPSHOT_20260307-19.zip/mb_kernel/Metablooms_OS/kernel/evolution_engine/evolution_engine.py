"""
MB-EVOLUTION — Evolution Engine
---------------------------------
Authority: Runtime extension layer. NOT a frozen kernel component.
Schema:    MB-EVOLUTION-1.0

Purpose:
    Post-reflection governed improvement pipeline. Reads committed reflection
    artifacts, builds patch candidates, validates them, and emits
    kernel_patch_candidate artifacts. Humans apply approved patches.

    The Evolution Engine closes the MetaBlooms self-improvement loop:

        run → commit → reflect → commit_reflection → evolve → commit_candidates
                                                            ↓
                                                    human reviews
                                                            ↓
                                                    human applies
                                                            ↓
                                                    re-freeze (if required)

    The engine NEVER applies patches itself. It NEVER modifies frozen components.
    It NEVER mutates the kernel. It produces data artifacts that describe
    what should change. Application is a human-gated process.

Pipeline position:
    → reflector_engine → [THIS MODULE] → (human review queue)

Execution phases (EV1-EV3):
    EV1 proposal_ingestion   — read reflection artifacts, extract proposals
    EV2 patch_generation     — PatchBuilder converts proposals to PatchCandidates
    EV3 patch_validation     — PatchValidator runs each candidate through
                               structural, compatibility, simulation, freeze_impact checks

Artifacts produced (all committed to artifact_store):
    patch_candidates.json        — all candidates with validation results
    evolution_receipt.json       — summary: counts, freeze_required, human_approval_required

Governance invariants:
    - Candidates targeting frozen components always have requires_human_approval=True
    - FAIL-validated candidates are included in output (for human review) but
      flagged status=REJECTED
    - freeze_required=True candidates are surfaced prominently in receipt
    - Evolution Engine commits its own artifacts — no ghost state

Constraint: Evolution Engine reads from artifact_store (committed artifacts only).
    It does NOT read transient runtime state. If reflection_artifact_ids is not
    provided, it queries by engine_id=reflector_engine (most recent run).

Legacy impact:
    Previously there was no governed path from reflection findings to structured
    improvement proposals. Improvements were implicit and undocumented.
    Evolution Engine makes the improvement pipeline explicit, validated, and auditable.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# Kernel imports
from artifact_store import ArtifactStore
from commit_system import CommitSystem
from fingerprint_engine import fingerprint

SCHEMA = "MB-EVOLUTION-1.0"
_SELF_ID = "evolution_engine"

# Bootstrap sub-module imports (same directory)
_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from patch_builder import PatchBuilder, PatchCandidate
from patch_validator import PatchValidator, RESULT_PASS, RESULT_FAIL, RESULT_SKIP, RESULT_ERROR


# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class EvolutionPhaseResult:
    phase: str
    ok: bool
    artifact: dict
    artifact_id: Optional[str] = None
    error: Optional[str] = None


@dataclass
class EvolutionReport:
    evolution_run_id: str
    valid: bool
    phases: list
    candidates: list[PatchCandidate]
    artifact_ids: list
    commit_id: Optional[str]
    summary: dict
    block_reason: Optional[str] = None

    def to_receipt(self) -> dict:
        validated = [c for c in self.candidates if c.validation_result == RESULT_PASS]
        failed    = [c for c in self.candidates if c.validation_result == RESULT_FAIL]
        skipped   = [c for c in self.candidates if c.validation_result == RESULT_SKIP]
        human_required = [c for c in validated if c.requires_human_approval]
        freeze_required = [c for c in validated if c.freeze_required]
        return {
            "schema": SCHEMA,
            "evolution_run_id": self.evolution_run_id,
            "valid": self.valid,
            "block_reason": self.block_reason,
            "total_candidates": len(self.candidates),
            "validated_pass": len(validated),
            "validated_fail": len(failed),
            "validated_skip": len(skipped),
            "requires_human_approval": len(human_required),
            "requires_freeze_regeneration": len(freeze_required),
            "artifact_ids": self.artifact_ids,
            "commit_id": self.commit_id,
            "summary": self.summary,
        }


# ── Evolution Engine ─────────────────────────────────────────────────────────

class EvolutionEngine:
    """
    Governed improvement pipeline.

    Usage:
        engine = EvolutionEngine(artifact_store, commit_system, kernel_root=KERNEL_PATH)

        # From a live reflection report (preferred)
        report = engine.evolve_from_reflection(
            reflection_report=reflector_report,
        )

        # From artifact IDs (for replay / deferred processing)
        report = engine.evolve_from_artifact_ids(
            reflection_artifact_ids=[...],
        )

        # report.candidates contains PatchCandidates with validation results
        # report.commit_id is the authoritative proof of this evolution run
    """

    schema = SCHEMA

    def __init__(
        self,
        artifact_store: ArtifactStore,
        commit_system: CommitSystem,
        kernel_root: Optional[str] = None,
    ):
        self.store = artifact_store
        self.commits = commit_system
        self.builder = PatchBuilder()
        self.validator = PatchValidator(
            kernel_root=kernel_root or str(Path(__file__).resolve().parents[2])
        )

    def evolve_from_reflection(
        self,
        reflection_report: Any,                # ReflectionReport from reflector_engine
    ) -> EvolutionReport:
        """
        Primary entry point. Takes a live ReflectionReport object.
        Extracts proposals, builds candidates, validates them, commits results.
        """
        run_id = fingerprint({
            "reflection_run_id": reflection_report.reflection_run_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        # Extract proposals as dicts
        proposals = [
            p.to_dict() if hasattr(p, 'to_dict') else p
            for p in reflection_report.proposals
        ]

        return self._run_pipeline(proposals, reflection_report.reflection_run_id, run_id)

    def evolve_from_artifact_ids(
        self,
        reflection_artifact_ids: list[str],
    ) -> EvolutionReport:
        """
        Replay entry point. Reads reflection artifacts from artifact_store by ID.
        Useful for deferred processing or re-running evolution against old reflections.
        """
        run_id = fingerprint({
            "reflection_artifact_ids": reflection_artifact_ids,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        # Extract proposals from RF4 artifact (improvement_proposals phase)
        proposals = []
        reflection_run_id = "unknown"
        for aid in reflection_artifact_ids:
            artifact = self.store.retrieve(aid)
            if artifact and artifact.get("phase") == "improvement_proposals":
                proposals = artifact.get("proposals", [])
                reflection_run_id = artifact.get("run_id", "unknown")
                break

        if not proposals:
            return self._blocked(
                run_id, "No improvement_proposals artifact found in provided IDs",
                [], [], None
            )

        return self._run_pipeline(proposals, reflection_run_id, run_id)

    def _run_pipeline(
        self,
        proposals: list[dict],
        reflection_run_id: str,
        run_id: str,
    ) -> EvolutionReport:
        phases: list[EvolutionPhaseResult] = []
        artifact_ids: list[str] = []
        all_candidates: list[PatchCandidate] = []

        # ── EV1: Proposal Ingestion ──────────────────────────────────────────
        ev1 = self._ev1_proposal_ingestion(proposals, reflection_run_id, run_id)
        phases.append(ev1)
        if ev1.artifact_id:
            artifact_ids.append(ev1.artifact_id)
        if not ev1.ok:
            return self._blocked(run_id, f"EV1 failed: {ev1.error}", phases, artifact_ids, None)

        # ── EV2: Patch Generation ────────────────────────────────────────────
        ev2 = self._ev2_patch_generation(proposals, reflection_run_id, run_id)
        phases.append(ev2)
        if ev2.artifact_id:
            artifact_ids.append(ev2.artifact_id)
        if not ev2.ok:
            return self._blocked(run_id, f"EV2 failed: {ev2.error}", phases, artifact_ids, None)

        all_candidates = ev2.artifact.get("_candidate_objects", [])

        # ── EV3: Patch Validation ────────────────────────────────────────────
        ev3 = self._ev3_patch_validation(all_candidates, run_id)
        phases.append(ev3)
        if ev3.artifact_id:
            artifact_ids.append(ev3.artifact_id)
        # EV3 never hard-blocks — even if all patches fail validation,
        # we emit the failure artifacts for human review

        # Apply validation results back to candidates
        validation_map = ev3.artifact.get("_validation_map", {})
        for candidate in all_candidates:
            vr = validation_map.get(candidate.patch_id)
            if vr:
                candidate.validation_result = vr.result
                candidate.validation_detail = vr.detail
                candidate.status = (
                    "VALIDATED" if vr.result == RESULT_PASS
                    else "SKIPPED" if vr.result == RESULT_SKIP
                    else "REJECTED"
                )
                # Surface simulation result as replay_proof for engine_registration patches
                if (candidate.patch_type == "engine_registration"
                        and vr.result == RESULT_PASS
                        and "simulation" in vr.levels_run):
                    candidate.replay_proof = {
                        "simulation_ran": True,
                        "simulation_result": vr.level_results.get("simulation"),
                        "simulation_detail": vr.detail,
                        "note": "Stub engine registered in isolated temp kernel. "
                                "Real implementation required before production use.",
                    }
                # Extract implementation_template from proposed_change if present
                if not candidate.implementation_template:
                    candidate.implementation_template = candidate.proposed_change.get(
                        "implementation_template"
                    )

        # ── Summary ──────────────────────────────────────────────────────────
        validated = [c for c in all_candidates if c.validation_result == RESULT_PASS]
        failed    = [c for c in all_candidates if c.validation_result == RESULT_FAIL]
        skipped   = [c for c in all_candidates if c.validation_result == RESULT_SKIP]
        freeze_req = [c for c in validated if c.freeze_required]
        human_req  = [c for c in validated if c.requires_human_approval]

        summary = {
            "total_proposals_ingested": len(proposals),
            "total_candidates": len(all_candidates),
            "validated_pass": len(validated),
            "validated_fail": len(failed),
            "validated_skip": len(skipped),
            "freeze_regeneration_required": len(freeze_req) > 0,
            "human_approval_required": len(human_req) > 0,
            "freeze_candidates": [c.patch_id for c in freeze_req],
            "human_candidates": [c.patch_id for c in human_req],
            "reflection_run_id": reflection_run_id,
        }

        # ── Commit ───────────────────────────────────────────────────────────
        try:
            commit = self.commits.commit(
                artifact_ids=artifact_ids,
                engine_id=_SELF_ID,
                phase="commit",
                intent=f"evolution:{reflection_run_id[:40]}",
            )
            commit_id = commit.commit_id
        except Exception as e:
            commit_id = None
            summary["commit_error"] = str(e)

        return EvolutionReport(
            evolution_run_id=run_id,
            valid=True,
            phases=phases,
            candidates=all_candidates,
            artifact_ids=artifact_ids,
            commit_id=commit_id,
            summary=summary,
        )

    # ── Phase implementations ────────────────────────────────────────────────

    def _ev1_proposal_ingestion(
        self, proposals: list[dict], reflection_run_id: str, run_id: str
    ) -> EvolutionPhaseResult:
        try:
            artifact = {
                "schema": "MB-EV1-1.0",
                "phase": "proposal_ingestion",
                "run_id": run_id,
                "reflection_run_id": reflection_run_id,
                "proposal_count": len(proposals),
                "proposals_ingested": [
                    {
                        "proposal_id": p.get("proposal_id"),
                        "target_component": p.get("target_component"),
                        "severity": p.get("severity"),
                        "category": p.get("category"),
                    }
                    for p in proposals
                ],
            }
            receipt = self.store.store(artifact, _SELF_ID, "commit", "evolution_ev1")
            return EvolutionPhaseResult(
                phase="proposal_ingestion", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return EvolutionPhaseResult(
                phase="proposal_ingestion", ok=False,
                artifact={}, error=str(e),
            )

    def _ev2_patch_generation(
        self, proposals: list[dict], reflection_run_id: str, run_id: str
    ) -> EvolutionPhaseResult:
        try:
            candidates = self.builder.build(proposals, reflection_run_id)
            storable = [c.to_dict() for c in candidates]
            artifact = {
                "schema": "MB-EV2-1.0",
                "phase": "patch_generation",
                "run_id": run_id,
                "candidate_count": len(candidates),
                "candidates": storable,
                "_candidate_objects": candidates,  # in-memory only
            }
            storable_artifact = {k: v for k, v in artifact.items() if k != "_candidate_objects"}
            receipt = self.store.store(storable_artifact, _SELF_ID, "commit", "evolution_ev2")
            artifact["_candidate_objects"] = candidates  # re-attach after store
            return EvolutionPhaseResult(
                phase="patch_generation", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return EvolutionPhaseResult(
                phase="patch_generation", ok=False,
                artifact={}, error=str(e),
            )

    def _ev3_patch_validation(
        self, candidates: list[PatchCandidate], run_id: str
    ) -> EvolutionPhaseResult:
        try:
            validation_results = []
            validation_map = {}
            for candidate in candidates:
                vr = self.validator.validate(candidate)
                validation_results.append(vr.to_dict())
                validation_map[candidate.patch_id] = vr

            by_result = {}
            for vr in validation_results:
                by_result[vr["result"]] = by_result.get(vr["result"], 0) + 1

            artifact = {
                "schema": "MB-EV3-1.0",
                "phase": "patch_validation",
                "run_id": run_id,
                "candidates_validated": len(candidates),
                "by_result": by_result,
                "validation_results": validation_results,
                "_validation_map": validation_map,  # in-memory only
            }
            storable = {k: v for k, v in artifact.items() if k != "_validation_map"}
            receipt = self.store.store(storable, _SELF_ID, "commit", "evolution_ev3")
            artifact["_validation_map"] = validation_map
            return EvolutionPhaseResult(
                phase="patch_validation", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
            )
        except Exception as e:
            return EvolutionPhaseResult(
                phase="patch_validation", ok=False,
                artifact={}, error=str(e),
            )

    def export_to_kernel(self, report: EvolutionReport) -> dict:
        """
        Store evolution receipt as authoritative artifact + commit.
        """
        receipt_data = report.to_receipt()
        store_receipt = self.store.store(
            receipt_data, _SELF_ID, "commit", "evolution_receipt"
        )
        commit = self.commits.commit(
            artifact_ids=[store_receipt.artifact_id],
            engine_id=_SELF_ID,
            phase="commit",
            intent="evolution_receipt",
        )
        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "authoritative": store_receipt.authoritative,
            "evolution_run_id": report.evolution_run_id,
            "total_candidates": len(report.candidates),
        }

    def _blocked(
        self,
        run_id: str,
        reason: str,
        phases: list,
        artifact_ids: list,
        candidates,
    ) -> EvolutionReport:
        commit_id = None
        if artifact_ids:
            try:
                commit = self.commits.commit(
                    artifact_ids=artifact_ids,
                    engine_id=_SELF_ID,
                    phase="commit",
                    intent="evolution:BLOCKED",
                )
                commit_id = commit.commit_id
            except Exception:
                pass
        return EvolutionReport(
            evolution_run_id=run_id,
            valid=False,
            phases=phases,
            candidates=candidates or [],
            artifact_ids=artifact_ids,
            commit_id=commit_id,
            summary={},
            block_reason=reason,
        )
