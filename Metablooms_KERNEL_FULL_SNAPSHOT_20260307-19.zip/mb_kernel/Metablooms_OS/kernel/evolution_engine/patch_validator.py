"""
PatchValidator — Evolution Engine sub-module
----------------------------------------------
Authority: Runtime extension layer. Sub-module of evolution_engine.
Schema:    MB-PATCH-VALIDATOR-1.0

Purpose:
    Validates PatchCandidate objects against the MetaBlooms validation suite
    before they are presented to a human for approval.

    Validation runs in an isolated temporary environment — it never touches
    the live kernel. Results are PASS, FAIL, or SKIP (with reason).

    The validator does NOT apply patches. It tests whether a proposed patch
    is safe to apply (passes the wiring matrix) and whether it would require
    a freeze regeneration.

Validation levels:
    STRUCTURAL   — patch is well-formed, has required fields, type is known
    COMPATIBILITY — patch type is compatible with target component and kernel state
    SIMULATION   — for engine_registration patches: boot + execute in temp env
                   to verify the registration would resolve the observed issue
    FREEZE_IMPACT — does this patch change anything the freeze tracks?

Result values:
    PASS   — patch passed all applicable validation levels
    FAIL   — patch failed one or more validation levels (not safe to apply)
    SKIP   — validation not applicable to this patch type (e.g. no_action)
    ERROR  — validator itself encountered an exception (treated as FAIL)

Constraint:
    Validation never modifies the live kernel, artifact_store, or commit_system.
    It uses a separate temporary build_kernel_context() per validation run.
    Failures in validation are recorded — they do not propagate as exceptions.

Legacy impact:
    Previously patches were applied manually without pre-validation.
    PatchValidator adds a governed validation gate between proposal and application.
"""

from __future__ import annotations

import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

SCHEMA = "MB-PATCH-VALIDATOR-1.0"

RESULT_PASS  = "PASS"
RESULT_FAIL  = "FAIL"
RESULT_SKIP  = "SKIP"
RESULT_ERROR = "ERROR"

LEVEL_STRUCTURAL    = "structural"
LEVEL_COMPATIBILITY = "compatibility"
LEVEL_SIMULATION    = "simulation"
LEVEL_FREEZE_IMPACT = "freeze_impact"


@dataclass
class ValidationResult:
    patch_id: str
    result: str         # PASS | FAIL | SKIP | ERROR
    levels_run: list
    level_results: dict  # level → PASS | FAIL | SKIP
    detail: str
    freeze_impact: bool  # True if this patch would change something the freeze tracks

    def to_dict(self) -> dict:
        return {
            "patch_id": self.patch_id,
            "result": self.result,
            "levels_run": self.levels_run,
            "level_results": self.level_results,
            "detail": self.detail,
            "freeze_impact": self.freeze_impact,
        }


class PatchValidator:
    """
    Validates patch candidates. Runs in isolation — never touches live kernel.

    Usage:
        validator = PatchValidator(kernel_root=KERNEL_PATH)
        result = validator.validate(patch_candidate)
    """

    def __init__(self, kernel_root: Optional[str] = None):
        self.kernel_root = kernel_root or str(
            Path(__file__).resolve().parents[2]
        )

    def validate(self, patch: Any) -> ValidationResult:
        """
        Run all applicable validation levels for this patch candidate.
        Returns a ValidationResult — never raises.
        """
        try:
            return self._validate_internal(patch)
        except Exception as e:
            return ValidationResult(
                patch_id=patch.patch_id,
                result=RESULT_ERROR,
                levels_run=[],
                level_results={},
                detail=f"Validator exception: {e}",
                freeze_impact=patch.freeze_required,
            )

    def _validate_internal(self, patch: Any) -> ValidationResult:
        from patch_builder import (
            PATCH_TYPE_ENGINE_REGISTRATION,
            PATCH_TYPE_GOVERNANCE_RULE_UPDATE,
            PATCH_TYPE_FREEZE_REGENERATION,
            PATCH_TYPE_TOPOLOGY_CORRECTION,
            PATCH_TYPE_CONFIG_UPDATE,
            PATCH_TYPE_NO_ACTION,
        )

        levels_run = []
        level_results = {}

        # ── SKIP: no_action patches ──────────────────────────────────────────
        if patch.patch_type == PATCH_TYPE_NO_ACTION:
            return ValidationResult(
                patch_id=patch.patch_id,
                result=RESULT_SKIP,
                levels_run=[],
                level_results={},
                detail="No-action patch — validation not applicable.",
                freeze_impact=False,
            )

        # ── Level 1: STRUCTURAL ──────────────────────────────────────────────
        levels_run.append(LEVEL_STRUCTURAL)
        structural_result, structural_detail = self._validate_structural(patch)
        level_results[LEVEL_STRUCTURAL] = structural_result
        if structural_result == RESULT_FAIL:
            return ValidationResult(
                patch_id=patch.patch_id,
                result=RESULT_FAIL,
                levels_run=levels_run,
                level_results=level_results,
                detail=f"Structural validation failed: {structural_detail}",
                freeze_impact=patch.freeze_required,
            )

        # ── Level 2: COMPATIBILITY ───────────────────────────────────────────
        levels_run.append(LEVEL_COMPATIBILITY)
        compat_result, compat_detail = self._validate_compatibility(patch)
        level_results[LEVEL_COMPATIBILITY] = compat_result
        if compat_result == RESULT_FAIL:
            return ValidationResult(
                patch_id=patch.patch_id,
                result=RESULT_FAIL,
                levels_run=levels_run,
                level_results=level_results,
                detail=f"Compatibility validation failed: {compat_detail}",
                freeze_impact=patch.freeze_required,
            )

        # ── Level 3: SIMULATION (engine_registration only) ──────────────────
        if patch.patch_type == PATCH_TYPE_ENGINE_REGISTRATION:
            levels_run.append(LEVEL_SIMULATION)
            sim_result, sim_detail = self._validate_simulation(patch)
            level_results[LEVEL_SIMULATION] = sim_result
            if sim_result == RESULT_FAIL:
                return ValidationResult(
                    patch_id=patch.patch_id,
                    result=RESULT_FAIL,
                    levels_run=levels_run,
                    level_results=level_results,
                    detail=f"Simulation failed: {sim_detail}",
                    freeze_impact=False,
                )
        else:
            level_results[LEVEL_SIMULATION] = RESULT_SKIP

        # ── Level 4: FREEZE IMPACT ───────────────────────────────────────────
        levels_run.append(LEVEL_FREEZE_IMPACT)
        freeze_impact = patch.freeze_required
        level_results[LEVEL_FREEZE_IMPACT] = RESULT_PASS
        freeze_detail = (
            "Freeze regeneration required after applying this patch."
            if freeze_impact else "No freeze impact."
        )

        summary = (
            f"All levels passed. "
            f"{freeze_detail} "
            f"Human approval required: {patch.requires_human_approval}."
        )

        return ValidationResult(
            patch_id=patch.patch_id,
            result=RESULT_PASS,
            levels_run=levels_run,
            level_results=level_results,
            detail=summary,
            freeze_impact=freeze_impact,
        )

    def _validate_structural(self, patch: Any) -> tuple[str, str]:
        """Check patch has required fields and known type."""
        from patch_builder import (
            PATCH_TYPE_ENGINE_REGISTRATION, PATCH_TYPE_GOVERNANCE_RULE_UPDATE,
            PATCH_TYPE_FREEZE_REGENERATION, PATCH_TYPE_TOPOLOGY_CORRECTION,
            PATCH_TYPE_CONFIG_UPDATE, PATCH_TYPE_NO_ACTION,
        )
        known_types = {
            PATCH_TYPE_ENGINE_REGISTRATION, PATCH_TYPE_GOVERNANCE_RULE_UPDATE,
            PATCH_TYPE_FREEZE_REGENERATION, PATCH_TYPE_TOPOLOGY_CORRECTION,
            PATCH_TYPE_CONFIG_UPDATE, PATCH_TYPE_NO_ACTION,
        }
        if not patch.patch_id:
            return RESULT_FAIL, "patch_id is empty"
        if patch.patch_type not in known_types:
            return RESULT_FAIL, f"Unknown patch_type: {patch.patch_type}"
        if not patch.target_component:
            return RESULT_FAIL, "target_component is empty"
        if not isinstance(patch.proposed_change, dict):
            return RESULT_FAIL, "proposed_change must be a dict"
        return RESULT_PASS, "All required fields present and well-formed"

    def _validate_compatibility(self, patch: Any) -> tuple[str, str]:
        """Check patch type is compatible with target component."""
        from patch_builder import FROZEN_COMPONENTS, PATCH_TYPE_ENGINE_REGISTRATION

        # Engine registration patches must not target frozen components
        if (patch.patch_type == PATCH_TYPE_ENGINE_REGISTRATION
                and patch.target_component in FROZEN_COMPONENTS):
            return (
                RESULT_FAIL,
                f"engine_registration patches cannot target frozen component "
                f"'{patch.target_component}'. Frozen components have fixed interfaces.",
            )

        # Patches flagged as requires_human_approval still pass compatibility —
        # that flag is for the approval gate, not for validation
        return RESULT_PASS, "Patch type compatible with target component"

    def _validate_simulation(self, patch: Any) -> tuple[str, str]:
        """
        For engine_registration: boot a temp kernel, simulate registration,
        run a minimal execution, check status improves.

        Runs in a completely isolated temporary directory — never touches live kernel.
        """
        try:
            # We can't actually instantiate the missing engine (it doesn't exist yet),
            # but we can verify that a stub registration resolves the "not registered" issue.
            with tempfile.TemporaryDirectory() as tmp:
                # Build minimal sys.path for kernel
                kernel_root = Path(self.kernel_root)
                for comp in ["artifact_store", "commit_system", "fingerprint_engine",
                             "phase_registry", "governance_compiler", "mpp_executor",
                             "engine_registry", "capability_resolver", "ir_registry",
                             "pipeline_planner", "state_loader"]:
                    p = str(kernel_root / comp)
                    if p not in sys.path:
                        sys.path.insert(0, p)
                if str(kernel_root) not in sys.path:
                    sys.path.insert(0, str(kernel_root))

                from kernel_context import build_kernel_context

                engine_name = patch.proposed_change.get("engine", "unknown")
                intent      = patch.proposed_change.get("intent", engine_name)

                # Stub engine: returns a minimal result artifact
                def stub_engine(context):
                    return {"stub": True, "engine": engine_name, "status": "stub_ok"}

                stub_map = {engine_name: stub_engine}
                ctx = build_kernel_context(tmp, engine_map=stub_map)
                ctx.state_loader.boot()

                # Check: engine is accessible in executor's map
                if engine_name in ctx.executor.engine_map:
                    return (
                        RESULT_PASS,
                        f"Stub registration of '{engine_name}' resolves the missing engine issue. "
                        f"Real implementation required before production use.",
                    )
                else:
                    return (
                        RESULT_FAIL,
                        f"Stub registration did not appear in executor.engine_map. "
                        f"build_kernel_context may not be passing engine_map to executor.",
                    )
        except Exception as e:
            return RESULT_FAIL, f"Simulation exception: {e}"
