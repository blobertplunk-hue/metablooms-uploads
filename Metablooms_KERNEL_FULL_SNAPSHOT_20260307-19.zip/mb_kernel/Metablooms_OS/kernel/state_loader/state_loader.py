"""
State Loader
------------
Handles turn-based session state for MetaBlooms OS running in stateless
sandbox environments (ChatGPT Code Interpreter, Claude artifacts).

The fundamental problem: Python state resets between turns. The Artifact Store
persists to disk, but the in-memory session (loaded engines, active plan,
governance snapshot) must be reconstructed each turn.

The State Loader enforces the BOOT → LOAD → VERIFY sequence before any
execution is allowed. This is the "no silent state" principle applied to
cross-turn continuity.

BOOT:   Check that required kernel components are available and healthy.
LOAD:   Load last commit from CommitSystem + artifacts from ArtifactStore.
VERIFY: Fingerprint the loaded state and confirm it matches the stored head.

If any step fails → BOOT_FAILED, execution is blocked.

Schema: MB-STATE-LOADER-1.0
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from fingerprint_engine import fingerprint
from artifact_store import ArtifactStore
from commit_system import CommitSystem

SCHEMA = "MB-STATE-LOADER-1.0"


class BootStatus(str, Enum):
    BOOT_OK = "BOOT_OK"
    BOOT_FAILED = "BOOT_FAILED"
    NOT_BOOTED = "NOT_BOOTED"


class StateLoaderError(Exception):
    pass


@dataclass
class SessionState:
    """The verified state of a MetaBlooms session after BOOT → LOAD → VERIFY."""
    boot_status: BootStatus
    session_id: str
    turn: int
    last_commit_id: Optional[str]
    last_commit_hash: Optional[str]
    loaded_artifacts: dict[str, Any]    # artifact_id → artifact content
    state_fingerprint: str              # fingerprint of this state object (excl. itself)
    boot_timestamp_utc: str
    violations: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)


@dataclass
class BootReceipt:
    schema: str
    boot_status: str
    session_id: str
    turn: int
    state_fingerprint: str
    violations: list[str]
    warnings: list[str]
    timestamp_utc: str
    kernel_health: dict


class StateLoader:
    """
    Turn-based state loader. Call boot() at the start of every turn.
    Execution must not proceed if boot_status != BOOT_OK.
    """

    schema = SCHEMA

    def __init__(
        self,
        artifact_store: ArtifactStore,
        commit_system: CommitSystem,
        session_id: str,
    ):
        self.store = artifact_store
        self.commits = commit_system
        self.session_id = session_id
        self._turn = 0
        self._current_state: Optional[SessionState] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def boot(self) -> BootReceipt:
        """
        Execute BOOT → LOAD → VERIFY sequence.
        Must be called at the start of every turn before any execution.
        """
        self._turn += 1
        violations: list[str] = []
        warnings: list[str] = []

        # --- BOOT: kernel health checks ---
        kernel_health = self._check_kernel_health()
        for component, healthy in kernel_health.items():
            if not healthy:
                violations.append(f"kernel_component_unhealthy:{component}")

        # --- LOAD: last commit and its artifacts ---
        loaded_artifacts: dict[str, Any] = {}
        last_commit = self.commits.head()
        last_commit_id = None
        last_commit_hash = None

        if last_commit:
            last_commit_id = last_commit.commit_id
            last_commit_hash = last_commit.commit_hash
            for artifact_id in last_commit.artifact_ids:
                try:
                    loaded_artifacts[artifact_id] = self.store.retrieve(artifact_id)
                except Exception as e:
                    violations.append(f"artifact_load_failed:{artifact_id}:{e}")

        # --- VERIFY: chain integrity ---
        chain_violations = self.commits.verify_chain()
        violations.extend(chain_violations)

        if chain_violations:
            warnings.append("commit_chain_integrity_check_failed")

        # --- determine boot status ---
        boot_status = BootStatus.BOOT_FAILED if violations else BootStatus.BOOT_OK

        # --- fingerprint the state ---
        state_payload = {
            "session_id": self.session_id,
            "turn": self._turn,
            "last_commit_id": last_commit_id,
            "last_commit_hash": last_commit_hash,
            "loaded_artifact_ids": sorted(loaded_artifacts.keys()),
            "boot_status": boot_status.value,
        }
        state_fp = fingerprint(state_payload)

        self._current_state = SessionState(
            boot_status=boot_status,
            session_id=self.session_id,
            turn=self._turn,
            last_commit_id=last_commit_id,
            last_commit_hash=last_commit_hash,
            loaded_artifacts=loaded_artifacts,
            state_fingerprint=state_fp,
            boot_timestamp_utc=_now_utc(),
            violations=violations,
            warnings=warnings,
        )

        return BootReceipt(
            schema=SCHEMA,
            boot_status=boot_status.value,
            session_id=self.session_id,
            turn=self._turn,
            state_fingerprint=state_fp,
            violations=violations,
            warnings=warnings,
            timestamp_utc=_now_utc(),
            kernel_health=kernel_health,
        )

    def require_booted(self) -> SessionState:
        """
        Returns current state if booted successfully.
        Raises StateLoaderError if not booted or boot failed.
        Call this at the start of any execution path.
        """
        if self._current_state is None:
            raise StateLoaderError("boot() has not been called this turn")
        if self._current_state.boot_status != BootStatus.BOOT_OK:
            raise StateLoaderError(
                f"Boot failed with violations: {self._current_state.violations}. "
                f"Execution is blocked."
            )
        return self._current_state

    @property
    def current_state(self) -> Optional[SessionState]:
        return self._current_state

    @property
    def turn(self) -> int:
        return self._turn

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _check_kernel_health(self) -> dict[str, bool]:
        """
        Verify kernel components are reachable.
        Returns dict of component_name → healthy (bool).
        """
        health = {}

        # ArtifactStore: can we read the index?
        try:
            _ = self.store.index_fingerprint()
            health["artifact_store"] = True
        except Exception:
            health["artifact_store"] = False

        # CommitSystem: can we read the log?
        try:
            _ = self.commits.log_fingerprint()
            health["commit_system"] = True
        except Exception:
            health["commit_system"] = False

        return health


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()
