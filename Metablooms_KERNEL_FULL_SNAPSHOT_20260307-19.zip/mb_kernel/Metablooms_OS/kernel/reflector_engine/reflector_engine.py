"""
MB-REFLECTOR — Reflector Engine
---------------------------------
Authority: Runtime extension layer. NOT a frozen kernel component.
Schema:    MB-REFLECTOR-1.0

Purpose:
    Post-execution reflection stage. Sits after commit_system in the pipeline.
    Consumes committed artifacts (execution graph, reasoning artifacts, governance
    results) and produces structured improvement proposals stored in artifact_store.

    The reflector does NOT modify the kernel. It emits governed patch proposals.
    All reflection output is committed via commit_system — reports are authoritative
    or they do not exist.

Pipeline position:
    ... → artifact_store → commit_system → [THIS MODULE] → (next intent)

    Reflector is optional in the execution path (REQUIRE_REFLECTION flag in
    orchestrator). It is fail-closed when active: if reflection itself fails,
    the failure is committed as an error artifact, not silently discarded.

Reflection phases (RF1-RF4):
    RF1 execution_analysis    — topology check against freeze, missing stages,
                                illegal edges, partial status causes
    RF2 reasoning_analysis    — artifact depth, critic elimination rate,
                                unused approaches, R1-R6 completeness
    RF3 governance_analysis   — violations, false positive detection,
                                threshold drift
    RF4 improvement_proposals — structured proposals derived from RF1-RF3,
                                each with a severity and target component

Artifacts produced (all committed to artifact_store):
    execution_analysis.json
    reasoning_analysis.json
    governance_analysis.json
    improvement_proposals.json
    reflection_receipt.json

Failure semantics:
    fail-closed — any reflection phase error is committed as an error artifact.
    The reflector never silently swallows its own failures.
    A failed reflection is still a committed reflection.

Constraint: The reflector reads from artifact_store but writes only via
    export_to_kernel(). It does not modify frozen components. It does not
    alter the execution graph. It does not apply its own proposals.
    Proposals are data — applying them is a separate governed process.

Legacy impact:
    Replaces ad-hoc post-run inspection. Previously there was no post-execution
    analysis layer. Reflection was implicit (human review of outputs).
    Now reflection is a committed, replayable, artifact-backed stage.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

from artifact_store import ArtifactStore
from commit_system import CommitSystem
from fingerprint_engine import fingerprint, canonical_json

SCHEMA = "MB-REFLECTOR-1.0"
_SELF_ID = "reflector_engine"

# Severity levels for improvement proposals
SEVERITY_CRITICAL = "CRITICAL"   # Execution was blocked or corrupted
SEVERITY_HIGH     = "HIGH"        # Architecture invariant violated
SEVERITY_MEDIUM   = "MEDIUM"      # Inefficiency or gap detected
SEVERITY_LOW      = "LOW"         # Minor optimization opportunity
SEVERITY_INFO     = "INFO"        # Observation, no action required


# ── Data structures ──────────────────────────────────────────────────────────

@dataclass
class ImprovementProposal:
    proposal_id: str
    target_component: str
    severity: str
    category: str        # "execution" | "reasoning" | "governance" | "topology"
    observation: str
    proposed_action: str
    evidence: list       # artifact_ids or field references that support this proposal

    def to_dict(self) -> dict:
        return {
            "proposal_id": self.proposal_id,
            "target_component": self.target_component,
            "severity": self.severity,
            "category": self.category,
            "observation": self.observation,
            "proposed_action": self.proposed_action,
            "evidence": self.evidence,
        }


@dataclass
class ReflectionPhaseResult:
    phase: str
    ok: bool
    artifact: dict
    artifact_id: Optional[str] = None
    proposals: list = field(default_factory=list)
    error: Optional[str] = None


@dataclass
class ReflectionReport:
    reflection_run_id: str
    valid: bool
    phases: list
    proposals: list
    artifact_ids: list
    commit_id: Optional[str]
    summary: dict
    block_reason: Optional[str] = None

    def to_receipt(self) -> dict:
        return {
            "schema": SCHEMA,
            "reflection_run_id": self.reflection_run_id,
            "valid": self.valid,
            "block_reason": self.block_reason,
            "proposal_count": len(self.proposals),
            "proposals_by_severity": self.summary.get("by_severity", {}),
            "artifact_ids": self.artifact_ids,
            "commit_id": self.commit_id,
        }


# ── Reflector Engine ─────────────────────────────────────────────────────────

class ReflectorEngine:
    """
    Post-execution reflection engine.

    Usage:
        reflector = ReflectorEngine(artifact_store, commit_system)
        report = reflector.reflect(
            execution_result=orchestrator_result,
            reasoning_artifact_ids=result['reasoning_artifact_ids'],
            execution_graph=graph_dict,        # optional — from MB_EXECUTION_GRAPH_v2
            freeze=freeze_dict,                # optional — from KERNEL_ADOPTION_FREEZE_v4
        )
        # report.proposals contains improvement proposals
        # All proposals are committed — report.commit_id is the proof
    """

    schema = SCHEMA

    # Canonical call sequence — reflector detects deviations from this
    CANONICAL_SEQUENCE = [
        "capability_resolver",
        "pipeline_planner",
        "reasoning_engine",
        "governance_compiler",
        "kernel_mpp_executor",
        "artifact_store",
        "commit_system",
    ]

    # Minimum reasoning artifacts expected per run (R1-R6 = 6)
    MIN_REASONING_ARTIFACTS = 6

    def __init__(
        self,
        artifact_store: ArtifactStore,
        commit_system: CommitSystem,
    ):
        self.store = artifact_store
        self.commits = commit_system

    def reflect(
        self,
        execution_result: dict,
        reasoning_artifact_ids: Optional[list] = None,
        execution_graph: Optional[dict] = None,
        freeze: Optional[dict] = None,
    ) -> ReflectionReport:
        """
        Run RF1-RF4 reflection phases against execution_result.

        execution_result:       the dict returned by KernelWiredOrchestrator.run()
        reasoning_artifact_ids: list of artifact IDs from the reasoning stage
        execution_graph:        MB_EXECUTION_GRAPH_v2 dict (optional but improves RF1)
        freeze:                 KERNEL_ADOPTION_FREEZE_v4 dict (optional but improves RF1)

        Returns a ReflectionReport. Always committed — even failed reflections
        produce a committed error artifact.
        """
        run_id = fingerprint({
            "execution_result_status": execution_result.get("status"),
            "intent": execution_result.get("intent"),
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        phase_results: list[ReflectionPhaseResult] = []
        artifact_ids: list[str] = []
        all_proposals: list[ImprovementProposal] = []

        # ── RF1: Execution Analysis ──────────────────────────────────────────
        rf1 = self._rf1_execution_analysis(
            execution_result, execution_graph, freeze, run_id
        )
        phase_results.append(rf1)
        if rf1.artifact_id:
            artifact_ids.append(rf1.artifact_id)
        all_proposals.extend(rf1.proposals)

        # ── RF2: Reasoning Analysis ──────────────────────────────────────────
        rf2 = self._rf2_reasoning_analysis(
            execution_result, reasoning_artifact_ids or [], run_id
        )
        phase_results.append(rf2)
        if rf2.artifact_id:
            artifact_ids.append(rf2.artifact_id)
        all_proposals.extend(rf2.proposals)

        # ── RF3: Governance Analysis ─────────────────────────────────────────
        rf3 = self._rf3_governance_analysis(execution_result, run_id)
        phase_results.append(rf3)
        if rf3.artifact_id:
            artifact_ids.append(rf3.artifact_id)
        all_proposals.extend(rf3.proposals)

        # ── RF4: Improvement Proposals ───────────────────────────────────────
        rf4 = self._rf4_improvement_proposals(all_proposals, execution_result, run_id)
        phase_results.append(rf4)
        if rf4.artifact_id:
            artifact_ids.append(rf4.artifact_id)

        # ── Summary ──────────────────────────────────────────────────────────
        by_severity = {}
        for p in all_proposals:
            by_severity[p.severity] = by_severity.get(p.severity, 0) + 1

        summary = {
            "total_proposals": len(all_proposals),
            "by_severity": by_severity,
            "has_critical": SEVERITY_CRITICAL in by_severity,
            "has_high": SEVERITY_HIGH in by_severity,
            "execution_status": execution_result.get("status"),
            "reasoning_stage_present": bool(
                execution_result.get("reasoning_run_id")
            ),
        }

        # ── Commit all reflection artifacts ──────────────────────────────────
        try:
            commit = self.commits.commit(
                artifact_ids=artifact_ids,
                engine_id=_SELF_ID,
                phase="commit",
                intent=f"reflection:{execution_result.get('intent','unknown')}",
            )
            commit_id = commit.commit_id
        except Exception as e:
            # Commit failure is a CRITICAL issue — record it but don't silently drop
            commit_id = None
            all_proposals.append(ImprovementProposal(
                proposal_id=f"COMMIT-FAIL-{run_id[:8]}",
                target_component="commit_system",
                severity=SEVERITY_CRITICAL,
                category="execution",
                observation=f"Reflection commit failed: {e}",
                proposed_action="Inspect commit_system health. Check for chain corruption.",
                evidence=[],
            ))

        return ReflectionReport(
            reflection_run_id=run_id,
            valid=True,
            phases=phase_results,
            proposals=all_proposals,
            artifact_ids=artifact_ids,
            commit_id=commit_id,
            summary=summary,
        )

    # ── Phase implementations ────────────────────────────────────────────────

    def _rf1_execution_analysis(
        self,
        result: dict,
        graph: Optional[dict],
        freeze: Optional[dict],
        run_id: str,
    ) -> ReflectionPhaseResult:
        proposals = []
        findings = []

        try:
            status = result.get("status", "unknown")
            intent = result.get("intent", "unknown")
            failed_engines = result.get("failed_engines", [])
            enforcer_violations = result.get("enforcer_violations", [])
            artifact_ids = result.get("artifact_ids", [])

            # Check: execution produced artifacts
            if not artifact_ids:
                findings.append("No execution artifacts produced")
                proposals.append(ImprovementProposal(
                    proposal_id=f"EX-NO-ARTIFACTS-{run_id[:8]}",
                    target_component="kernel_mpp_executor",
                    severity=SEVERITY_HIGH,
                    category="execution",
                    observation="Execution completed but produced no artifacts in artifact_store.",
                    proposed_action=(
                        "Verify engine_map is populated for this intent type. "
                        "Register engines via build_kernel_context(engine_map={...})."
                    ),
                    evidence=[f"intent={intent}", f"status={status}"],
                ))

            # Check: partial status — identify cause
            if status == "partial":
                for eng in failed_engines:
                    findings.append(f"Engine failed: {eng}")
                    proposals.append(ImprovementProposal(
                        proposal_id=f"EX-ENGINE-FAIL-{eng[:12]}-{run_id[:8]}",
                        target_component=eng,
                        severity=SEVERITY_MEDIUM,
                        category="execution",
                        observation=f"Engine '{eng}' failed during execution (status=partial).",
                        proposed_action=(
                            f"Register '{eng}' in engine_map before calling orchestrator, "
                            f"or remove it from engine_attachments for this intent."
                        ),
                        evidence=[f"failed_engines={failed_engines}"],
                    ))

            # Check: enforcer violations
            for v in enforcer_violations:
                findings.append(f"Enforcer violation: {v}")
                proposals.append(ImprovementProposal(
                    proposal_id=f"EX-ENFORCER-{run_id[:8]}",
                    target_component="governance_compiler",
                    severity=SEVERITY_HIGH,
                    category="governance",
                    observation=f"Enforcer violation: {v}",
                    proposed_action="Review governance rules for this intent type.",
                    evidence=[f"violation={v}"],
                ))

            # Check: topology against freeze call sequence
            if freeze:
                frozen_seq = freeze.get("reference_call_sequence", [])
                if "reasoning_engine" not in frozen_seq:
                    findings.append("reasoning_engine missing from frozen call sequence")
                    proposals.append(ImprovementProposal(
                        proposal_id=f"EX-FREEZE-SEQ-{run_id[:8]}",
                        target_component="kernel_wired_orchestrator",
                        severity=SEVERITY_HIGH,
                        category="topology",
                        observation="Freeze v4 call sequence does not include reasoning_engine.",
                        proposed_action="Regenerate freeze after confirming reasoning stage is wired.",
                        evidence=["freeze.reference_call_sequence"],
                    ))
                if frozen_seq and frozen_seq != self.CANONICAL_SEQUENCE:
                    diff = [s for s in self.CANONICAL_SEQUENCE if s not in frozen_seq]
                    if diff:
                        findings.append(f"Frozen sequence missing stages: {diff}")
                        proposals.append(ImprovementProposal(
                            proposal_id=f"EX-SEQ-DRIFT-{run_id[:8]}",
                            target_component="kernel_adoption_freeze",
                            severity=SEVERITY_MEDIUM,
                            category="topology",
                            observation=f"Frozen call sequence differs from canonical. Missing: {diff}",
                            proposed_action="Re-freeze after confirming canonical sequence matches design.",
                            evidence=[f"canonical={self.CANONICAL_SEQUENCE}", f"frozen={frozen_seq}"],
                        ))

            # Check: execution graph integrity
            if graph:
                if not graph.get("integrity_ok", False):
                    findings.append("Execution graph integrity_ok=False")
                    mismatches = graph.get("freeze_hash_mismatches", [])
                    missing = graph.get("missing_nodes", [])
                    proposals.append(ImprovementProposal(
                        proposal_id=f"EX-GRAPH-INTEGRITY-{run_id[:8]}",
                        target_component="execution_graph",
                        severity=SEVERITY_CRITICAL,
                        category="topology",
                        observation=(
                            f"Execution graph integrity check failed. "
                            f"Mismatches: {mismatches}. Missing: {missing}."
                        ),
                        proposed_action=(
                            "Regenerate execution graph from current freeze. "
                            "Verify no frozen files were modified outside governance."
                        ),
                        evidence=["execution_graph.integrity_ok=False"],
                    ))

            artifact = {
                "schema": "MB-RF1-1.0",
                "phase": "execution_analysis",
                "run_id": run_id,
                "status_observed": status,
                "intent": intent,
                "failed_engines": failed_engines,
                "enforcer_violations": enforcer_violations,
                "artifact_count": len(artifact_ids),
                "findings": findings,
                "proposal_count": len(proposals),
            }
            receipt = self.store.store(artifact, _SELF_ID, "commit", "reflection_rf1")
            return ReflectionPhaseResult(
                phase="execution_analysis", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
                proposals=proposals,
            )
        except Exception as e:
            return ReflectionPhaseResult(
                phase="execution_analysis", ok=False,
                artifact={"error": str(e)}, proposals=proposals, error=str(e),
            )

    def _rf2_reasoning_analysis(
        self,
        result: dict,
        reasoning_artifact_ids: list,
        run_id: str,
    ) -> ReflectionPhaseResult:
        proposals = []
        findings = []

        try:
            reasoning_run_id = result.get("reasoning_run_id")
            artifact_count = len(reasoning_artifact_ids)

            # Check: reasoning stage ran
            if not reasoning_run_id:
                findings.append("reasoning_run_id absent — reasoning stage may not have run")
                proposals.append(ImprovementProposal(
                    proposal_id=f"RS-NO-REASONING-{run_id[:8]}",
                    target_component="kernel_wired_orchestrator",
                    severity=SEVERITY_CRITICAL,
                    category="reasoning",
                    observation="No reasoning_run_id in execution result. Reasoning stage absent.",
                    proposed_action=(
                        "Confirm REQUIRE_REASONING=True in orchestrator. "
                        "Verify reasoning_engine is on sys.path and loaded."
                    ),
                    evidence=["execution_result.reasoning_run_id=None"],
                ))

            # Check: artifact completeness (R1-R6 = 6 artifacts expected)
            if reasoning_run_id and artifact_count < self.MIN_REASONING_ARTIFACTS:
                findings.append(
                    f"Reasoning produced {artifact_count} artifacts, expected {self.MIN_REASONING_ARTIFACTS}"
                )
                proposals.append(ImprovementProposal(
                    proposal_id=f"RS-INCOMPLETE-{run_id[:8]}",
                    target_component="reasoning_engine",
                    severity=SEVERITY_HIGH,
                    category="reasoning",
                    observation=(
                        f"Reasoning stage produced {artifact_count} artifacts. "
                        f"R1-R6 pipeline requires {self.MIN_REASONING_ARTIFACTS}. "
                        "Incomplete reasoning may indicate a phase failure."
                    ),
                    proposed_action=(
                        "Inspect reasoning_engine phase results. "
                        "Check for exceptions in R1-R6 phases. "
                        "Verify artifact_store has capacity."
                    ),
                    evidence=[f"reasoning_artifact_ids.count={artifact_count}"],
                ))

            # Check: reasoning committed
            reasoning_commit_id = result.get("reasoning_commit_id")
            if reasoning_run_id and not reasoning_commit_id:
                findings.append("reasoning_commit_id absent — reasoning artifacts not committed")
                proposals.append(ImprovementProposal(
                    proposal_id=f"RS-NO-COMMIT-{run_id[:8]}",
                    target_component="reasoning_engine",
                    severity=SEVERITY_HIGH,
                    category="reasoning",
                    observation="Reasoning ran but commit_id is absent. Artifacts are uncommitted.",
                    proposed_action="Inspect reasoning_engine._blocked() — commit may have failed silently.",
                    evidence=["execution_result.reasoning_commit_id=None"],
                ))

            if reasoning_run_id and artifact_count >= self.MIN_REASONING_ARTIFACTS:
                findings.append(
                    f"Reasoning complete: {artifact_count} artifacts, run_id present, committed"
                )

            artifact = {
                "schema": "MB-RF2-1.0",
                "phase": "reasoning_analysis",
                "run_id": run_id,
                "reasoning_run_id_present": bool(reasoning_run_id),
                "reasoning_artifact_count": artifact_count,
                "reasoning_committed": bool(result.get("reasoning_commit_id")),
                "min_expected": self.MIN_REASONING_ARTIFACTS,
                "findings": findings,
                "proposal_count": len(proposals),
            }
            receipt = self.store.store(artifact, _SELF_ID, "commit", "reflection_rf2")
            return ReflectionPhaseResult(
                phase="reasoning_analysis", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
                proposals=proposals,
            )
        except Exception as e:
            return ReflectionPhaseResult(
                phase="reasoning_analysis", ok=False,
                artifact={"error": str(e)}, proposals=proposals, error=str(e),
            )

    def _rf3_governance_analysis(
        self,
        result: dict,
        run_id: str,
    ) -> ReflectionPhaseResult:
        proposals = []
        findings = []

        try:
            enforcer_violations = result.get("enforcer_violations", [])
            status = result.get("status")

            # Check: governance pass rate
            if enforcer_violations:
                for v in enforcer_violations:
                    findings.append(f"Governance violation: {v}")
                # Already added to RF1 proposals — here we add a governance-layer proposal
                proposals.append(ImprovementProposal(
                    proposal_id=f"GOV-VIOLATIONS-{run_id[:8]}",
                    target_component="governance_compiler",
                    severity=SEVERITY_HIGH,
                    category="governance",
                    observation=(
                        f"{len(enforcer_violations)} governance violation(s) during execution. "
                        "Indicates rules triggered that the execution plan did not account for."
                    ),
                    proposed_action=(
                        "Review governance_compiler rules against the execution plan. "
                        "Update reasoning engine approach descriptions to reflect governance constraints."
                    ),
                    evidence=[f"violations={enforcer_violations}"],
                ))

            # Check: governance false positive indicator
            # If status=partial AND enforcer_violations=[] AND failed_engines not empty,
            # governance passed but execution failed — governance was not the bottleneck.
            if (status == "partial"
                    and not enforcer_violations
                    and result.get("failed_engines")):
                findings.append(
                    "Governance passed but execution partial — governance not the bottleneck"
                )
                proposals.append(ImprovementProposal(
                    proposal_id=f"GOV-NOT-BOTTLENECK-{run_id[:8]}",
                    target_component="kernel_mpp_executor",
                    severity=SEVERITY_INFO,
                    category="governance",
                    observation=(
                        "Governance passed cleanly. Execution partial due to missing engines, "
                        "not governance rules. Consider adding engine coverage for this intent."
                    ),
                    proposed_action=(
                        "Register missing engines in engine_map for this intent type. "
                        "Governance rules are correctly calibrated."
                    ),
                    evidence=[
                        f"enforcer_violations=[]",
                        f"failed_engines={result.get('failed_engines')}",
                    ],
                ))

            if not enforcer_violations:
                findings.append("Governance clean — no violations")

            artifact = {
                "schema": "MB-RF3-1.0",
                "phase": "governance_analysis",
                "run_id": run_id,
                "enforcer_violations": enforcer_violations,
                "violation_count": len(enforcer_violations),
                "governance_clean": len(enforcer_violations) == 0,
                "findings": findings,
                "proposal_count": len(proposals),
            }
            receipt = self.store.store(artifact, _SELF_ID, "commit", "reflection_rf3")
            return ReflectionPhaseResult(
                phase="governance_analysis", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
                proposals=proposals,
            )
        except Exception as e:
            return ReflectionPhaseResult(
                phase="governance_analysis", ok=False,
                artifact={"error": str(e)}, proposals=proposals, error=str(e),
            )

    def _rf4_improvement_proposals(
        self,
        all_proposals: list,
        result: dict,
        run_id: str,
    ) -> ReflectionPhaseResult:
        try:
            # Sort proposals by severity
            severity_order = {
                SEVERITY_CRITICAL: 0, SEVERITY_HIGH: 1,
                SEVERITY_MEDIUM: 2, SEVERITY_LOW: 3, SEVERITY_INFO: 4
            }
            sorted_proposals = sorted(
                all_proposals,
                key=lambda p: severity_order.get(p.severity, 99)
            )

            by_severity = {}
            by_component = {}
            for p in sorted_proposals:
                by_severity[p.severity] = by_severity.get(p.severity, 0) + 1
                by_component[p.target_component] = by_component.get(p.target_component, 0) + 1

            artifact = {
                "schema": "MB-RF4-1.0",
                "phase": "improvement_proposals",
                "run_id": run_id,
                "total_proposals": len(sorted_proposals),
                "by_severity": by_severity,
                "by_component": by_component,
                "proposals": [p.to_dict() for p in sorted_proposals],
                "execution_intent": result.get("intent"),
                "execution_status": result.get("status"),
            }
            receipt = self.store.store(artifact, _SELF_ID, "commit", "reflection_rf4")
            return ReflectionPhaseResult(
                phase="improvement_proposals", ok=True,
                artifact=artifact, artifact_id=receipt.artifact_id,
                proposals=[],
            )
        except Exception as e:
            return ReflectionPhaseResult(
                phase="improvement_proposals", ok=False,
                artifact={"error": str(e)}, error=str(e),
            )

    def export_to_kernel(
        self,
        report: ReflectionReport,
    ) -> dict:
        """
        Store the full reflection receipt in artifact_store + commit_system.
        Returns dict with artifact_id, commit_id, authoritative flag.
        Separate from per-phase stores — stores the summary receipt.
        """
        receipt_data = report.to_receipt()
        store_receipt = self.store.store(
            receipt_data, _SELF_ID, "commit", "reflection_receipt"
        )
        commit = self.commits.commit(
            artifact_ids=[store_receipt.artifact_id],
            engine_id=_SELF_ID,
            phase="commit",
            intent="reflection_receipt",
        )
        return {
            "artifact_id": store_receipt.artifact_id,
            "commit_id": commit.commit_id,
            "authoritative": store_receipt.authoritative,
            "reflection_run_id": report.reflection_run_id,
            "total_proposals": len(report.proposals),
        }
