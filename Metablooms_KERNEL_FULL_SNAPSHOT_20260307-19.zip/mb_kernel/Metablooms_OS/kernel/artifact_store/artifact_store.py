"""
Artifact Store
--------------
Content-addressed, append-only storage for all MetaBlooms OS artifacts.

Rules:
  1. Every artifact is keyed by its SHA-256 fingerprint. Same content = same key.
  2. Append-only: existing artifacts are never overwritten or deleted.
  3. Write-then-verify: no artifact is authoritative until read-back matches.
  4. Index is maintained as a separate JSON file, also fingerprinted.
  5. Conflict on same key with different content = hard error (not silent overwrite).

This is the "Artifact Store" kernel component that the validation matrix
marks as MISSING. It is what makes state persist across turns.

Schema: MB-ARTIFACT-STORE-1.0
"""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from fingerprint_engine import fingerprint, fingerprint_file, canonical_json

SCHEMA = "MB-ARTIFACT-STORE-1.0"
INDEX_FILENAME = "_artifact_index.json"


class ArtifactStoreError(Exception):
    pass


class ArtifactConflictError(ArtifactStoreError):
    """Raised when an artifact key already exists with different content."""
    pass


@dataclass
class ArtifactRecord:
    artifact_id: str        # "sha256:<hex>"
    content_hash: str       # hex only (no prefix)
    engine_id: str
    phase: str
    intent: str
    fingerprint_id: str     # same as content_hash for content-addressed store
    timestamp_utc: str
    bytes_size: int
    artifact_path: str      # relative to store_root


@dataclass
class StoreReceipt:
    artifact_id: str
    content_hash: str
    authoritative: bool
    read_back_match: bool
    action: str             # "stored" | "duplicate_ok" | "conflict_error"
    timestamp_utc: str


class ArtifactStore:
    """
    Content-addressed, append-only artifact store.
    store_root: directory where artifacts and the index live.
    """

    schema = SCHEMA

    def __init__(self, store_root: str | Path):
        self.store_root = Path(store_root)
        self.store_root.mkdir(parents=True, exist_ok=True)
        self._index: dict[str, ArtifactRecord] = {}
        self._load_index()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def store(self, obj: Any, engine_id: str, phase: str, intent: str) -> StoreReceipt:
        """
        Store a JSON-serializable object.
        Returns a StoreReceipt. If the artifact already exists with the same
        content, returns a receipt with action='duplicate_ok'.
        Raises ArtifactConflictError if same key, different content (impossible
        in a correct content-addressed store, but guarded against).

        Namespace guarantee: the stored envelope always includes engine_id,
        phase, and intent so that two engines producing structurally identical
        artifacts are stored as distinct records with distinct content hashes.
        This prevents artifact namespace collisions across engines.
        """
        # Wrap payload in a namespace envelope before hashing.
        # This guarantees: same payload from different engine_id/phase/intent
        # produces a different artifact_id. No cross-engine collision possible.
        envelope = {
            "_engine_id": engine_id,
            "_phase":     phase,
            "_intent":    intent,
            "_payload":   obj,
        }
        canonical = canonical_json(envelope)
        content_hash = fingerprint(envelope)
        artifact_id = f"sha256:{content_hash}"

        # duplicate check
        if artifact_id in self._index:
            existing_path = self.store_root / self._index[artifact_id].artifact_path
            existing_hash = fingerprint_file(existing_path)
            if existing_hash != content_hash:
                raise ArtifactConflictError(
                    f"Artifact {artifact_id} already exists with different content. "
                    f"Append-only store cannot overwrite."
                )
            return StoreReceipt(
                artifact_id=artifact_id,
                content_hash=content_hash,
                authoritative=True,
                read_back_match=True,
                action="duplicate_ok",
                timestamp_utc=_now_utc(),
            )

        # write — serialize the envelope (namespace-wrapped payload)
        artifact_path = self.store_root / f"{content_hash}.json"
        encoded = canonical.encode("utf-8")
        artifact_path.write_bytes(encoded)

        # verify read-back
        read_back = artifact_path.read_bytes()
        read_back_match = (encoded == read_back)
        if not read_back_match:
            artifact_path.unlink(missing_ok=True)
            raise ArtifactStoreError(
                f"Write verification failed for {artifact_id}: read-back mismatch."
            )

        # index
        record = ArtifactRecord(
            artifact_id=artifact_id,
            content_hash=content_hash,
            engine_id=engine_id,
            phase=phase,
            intent=intent,
            fingerprint_id=content_hash,
            timestamp_utc=_now_utc(),
            bytes_size=len(encoded),
            artifact_path=f"{content_hash}.json",
        )
        self._index[artifact_id] = record
        self._persist_index()

        return StoreReceipt(
            artifact_id=artifact_id,
            content_hash=content_hash,
            authoritative=True,
            read_back_match=True,
            action="stored",
            timestamp_utc=_now_utc(),
        )

    def retrieve(self, artifact_id: str) -> Any:
        """
        Load and return a stored artifact.
        Transparently unwraps the namespace envelope — callers receive
        the original payload, not the engine_id/_phase/_intent wrapper.
        Raises if not found or hash mismatch.
        """
        if artifact_id not in self._index:
            raise ArtifactStoreError(f"Artifact not found: {artifact_id}")
        record = self._index[artifact_id]
        artifact_path = self.store_root / record.artifact_path
        if not artifact_path.exists():
            raise ArtifactStoreError(f"Artifact file missing on disk: {artifact_path}")
        raw = artifact_path.read_bytes()
        actual_hash = fingerprint_file(artifact_path)
        if actual_hash != record.content_hash:
            raise ArtifactStoreError(
                f"Artifact {artifact_id} hash mismatch: "
                f"expected {record.content_hash}, got {actual_hash}"
            )
        parsed = json.loads(raw.decode("utf-8"))
        # Unwrap namespace envelope if present (added in store() for collision prevention)
        if isinstance(parsed, dict) and "_payload" in parsed and "_engine_id" in parsed:
            return parsed["_payload"]
        return parsed  # legacy artifacts stored without envelope pass through unchanged

    def exists(self, artifact_id: str) -> bool:
        return artifact_id in self._index

    def list_artifacts(self, engine_id: Optional[str] = None,
                       phase: Optional[str] = None) -> list[ArtifactRecord]:
        records = list(self._index.values())
        if engine_id:
            records = [r for r in records if r.engine_id == engine_id]
        if phase:
            records = [r for r in records if r.phase == phase]
        return sorted(records, key=lambda r: r.timestamp_utc)

    def index_fingerprint(self) -> str:
        """SHA-256 of the current index state. For cross-session integrity checks."""
        return fingerprint(self._serialized_index())

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _load_index(self) -> None:
        index_path = self.store_root / INDEX_FILENAME
        if index_path.exists():
            try:
                raw = json.loads(index_path.read_text(encoding="utf-8"))
                for artifact_id, rec_dict in raw.get("artifacts", {}).items():
                    self._index[artifact_id] = ArtifactRecord(**rec_dict)
            except Exception:
                # corrupt index — start fresh but don't delete existing artifacts
                self._index = {}

    def _persist_index(self) -> None:
        index_path = self.store_root / INDEX_FILENAME
        serialized = self._serialized_index()
        encoded = canonical_json(serialized).encode("utf-8")
        index_path.write_bytes(encoded)
        # verify
        if index_path.read_bytes() != encoded:
            raise ArtifactStoreError("Index write verification failed")

    def _serialized_index(self) -> dict:
        return {
            "schema": SCHEMA,
            "artifact_count": len(self._index),
            "artifacts": {
                aid: asdict(rec) for aid, rec in self._index.items()
            },
        }


def _now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()
