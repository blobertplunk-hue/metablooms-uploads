"""
STAGE_RUNNER.py — Sequential stage orchestrator with DEBUGGING conditional
===========================================================================

CDR V1 (Rationale):
    StageRunner is the execution engine for the MPP pipeline. It iterates
    through all stages sequentially, enforces that each returns COMPLETE status,
    and handles the DEBUGGING conditional — DEBUGGING is skipped when
    VERIFICATION passes, injecting a skipped receipt into state so ECL's
    stage count check is satisfied.

CDR V2 (Trust):
    task is deep-copied before PipelineState construction — pipeline runs are
    idempotent. The same task dict can be passed to run_mpp() multiple times
    without state accumulation. No stage result is trusted without COMPLETE status.

CDR V3 (Boundary):
    Inputs:  stages (list of StageBase instances), task (dict, will be deep-copied)
    Outputs: PipelineState with all stage artifacts populated
    Side effects: none — StageRunner is stateless between runs
    Assumptions: stages list includes DEBUGGING instance; runner handles conditional

CDR V4 (Failure):
    stage.run() raises RuntimeError → propagates up unchanged (not swallowed).
    result['status'] != 'COMPLETE' → STAGE_FAIL: {stage.name} raised.
    safe_state: pipeline halts at first failure, no partial completion.

CDR V5 (S-tier):
    DEBUGGING is conditionally skipped based on VERIFICATION artifact.verified.
    Comparable to: GitLab CI allow_failure, GitHub Actions if: conditions.
    Industry pattern: conditional stage execution with audit receipt even on skip.
"""

from __future__ import annotations

import copy
import hashlib
from typing import Any

from PIPELINE_STATE import PipelineState

MAX_DEBUG_LOOPS: int = 2


class StageRunner:
    def __init__(self, stages: list) -> None:
        self.stages = stages

    def run(self, task: dict[str, Any]) -> PipelineState:
        state = PipelineState(copy.deepcopy(task))
        for stage in self.stages:
            if stage.name == "DEBUGGING":
                verification = state.data.get("VERIFICATION", {})
                verified = verification.get("artifact", {}).get("verified", False)
                if verified:
                    state.update(
                        {
                            "stage": "DEBUGGING",
                            "status": "COMPLETE",
                            "artifact": {"skipped": True, "reason": "VERIFICATION_PASSED"},
                            "trace_span": {"stage": "DEBUGGING", "artifacts": {"skipped": True}},
                        }
                    )
                    continue
            result = stage.run(state)
            if result["status"] != "COMPLETE":
                raise RuntimeError(f"STAGE_FAIL: {stage.name}")
            state.update(result)
        return state

    def run_hash(self, state: PipelineState) -> str:
        """SHA-256 of all stage names that completed — pipeline integrity anchor."""
        result_hash = hashlib.sha256("|".join(state.data.keys()).encode()).hexdigest()
        return result_hash
