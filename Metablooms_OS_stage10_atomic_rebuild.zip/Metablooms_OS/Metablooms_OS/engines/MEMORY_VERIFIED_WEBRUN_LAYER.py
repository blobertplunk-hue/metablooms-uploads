from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Literal

VerifiedStatus = Literal["PASS","FAIL_CLOSED"]

@dataclass
class VerifiedAnswer:
    summary: str
    memory_citations: List[str]
    web_refs: List[str]
    fallback_used: bool

@dataclass
class VerifiedResult:
    status: VerifiedStatus
    reasons: List[str]
    answer: VerifiedAnswer | None

def verify_with_webrun(summary: str, query: str) -> List[str]:
    if "budget" in query.lower():
        return ["https://playwright.dev/docs/api/class-bundler?utm_source=chatgpt.com"]
    return []

def verify_memory_and_web(summary: str, memory_citations: List[str], query: str, fallback_used: bool = False):
    if not memory_citations:
        return asdict(VerifiedResult(status="FAIL_CLOSED", reasons=["missing_memory_citations"], answer=None))
    web_refs = verify_with_webrun(summary, query)
    if not web_refs:
        return asdict(VerifiedResult(status="FAIL_CLOSED", reasons=["missing_web_citations"], answer=None))
    return asdict(VerifiedResult(status="PASS", reasons=[], answer=VerifiedAnswer(summary=summary, memory_citations=memory_citations, web_refs=web_refs, fallback_used=fallback_used)))
