"""
egg_juicer_registration.py
---------------------------
Authority: Runtime extension layer.
Schema:    MB-ENGINE-REGISTRATION-1.0

Purpose:
    Canonical registration helper for the egg_juicer engine.
    Provides build_egg_juicer_engine_map() — call this when constructing
    a KernelContext that needs to run egg_juicer intents.

    The egg_juicer engine scans a repository root and produces a deterministic
    file inventory artifact: file_count, structure_hash, files_sample.

Usage:
    from egg_juicer_registration import build_egg_juicer_engine_map
    from kernel_context import build_kernel_context

    ctx = build_kernel_context(
        data_root=data_root,
        engine_map=build_egg_juicer_engine_map(repo_root="/path/to/repo"),
    )

Intent routing:
    Orchestrator intent 'run_egg_juicer' → engine 'run_egg_juicer'
    Registered in engine_attachments: {"verification": ["run_egg_juicer"]}

Governance:
    Engine is artifact-producing (default in MPP executor).
    Output is stored in artifact_store, committed via commit_system.
    No direct file writes. No ghost state.

Failure semantics:
    If repo_root does not exist, engine callable raises ValueError.
    MPP executor catches this and adds 'run_egg_juicer' to failed_engines.
    Execution status becomes 'partial'. Reflector will surface the failure.

Legacy impact:
    Previously egg_juicer was only accessible via the runtime extension
    governed_egg_juicer_runtime_run.py (standalone CLI runner).
    This module makes it a first-class kernel engine registered in engine_map.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

# Bootstrap engine package path
_HERE        = Path(__file__).resolve().parent
_RUNTIME     = _HERE.parent
_EGG_PKG     = _RUNTIME / "engines" / "egg_juicer_package"

if str(_EGG_PKG) not in sys.path:
    sys.path.insert(0, str(_EGG_PKG))

from engine_logic import Engine as _EggJuicerEngine
from engine_interface import EngineResult as _EngineResult

SCHEMA         = "MB-ENGINE-REGISTRATION-1.0"
ENGINE_NAME    = "run_egg_juicer"
INTENT_NAME    = "run_egg_juicer"


def _make_callable(repo_root: str):
    """
    Build a zero-argument callable that captures repo_root.
    MPP executor calls fn() — no arguments. Closure captures the repo.
    Returns the artifact dict directly (not EngineResult) so artifact_store
    can store it without unwrapping.
    """
    _repo_root = str(repo_root)
    _engine    = _EggJuicerEngine()

    def _egg_juicer_callable():
        if not Path(_repo_root).exists():
            raise ValueError(
                f"egg_juicer: repo_root does not exist: {_repo_root!r}"
            )
        result = _engine.run({"repo_root": _repo_root})
        # Return artifact dict — artifact_store.store() receives this directly
        return result.artifact

    _egg_juicer_callable.__name__ = ENGINE_NAME
    return _egg_juicer_callable


def build_egg_juicer_engine_map(repo_root: str | Path) -> dict[str, Any]:
    """
    Build the engine_map dict for egg_juicer registration.

    Returns:
        {"run_egg_juicer": <callable>}

    Pass this to build_kernel_context(engine_map=...).
    The orchestrator routes intent 'run_egg_juicer' to this engine.
    """
    return {ENGINE_NAME: _make_callable(str(repo_root))}
