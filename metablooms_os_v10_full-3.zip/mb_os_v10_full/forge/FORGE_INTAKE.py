"""
FORGE_INTAKE.py — Artifact classifier and rubric loader

CDR V1 (Intent): Given any artifact path, determine its type, load the
    correct rubric, and return an initial score with gap analysis.
    FORGE_INTAKE is the entry point for everything FORGE processes.

CDR V2 (Trust): Classification is based on file extension and content
    inspection, not filename alone. A .json file with HTML content is
    classified as HTML. Content always wins over extension.

CDR V3 (Boundary): FORGE_INTAKE classifies and scores. It does not improve.
    It does not write files except the intake receipt via FORGE_RECEIPT.

CDR V4 (Failure): Unknown artifact type raises INTAKE_UNKNOWN_TYPE with
    the detected MIME-like classification and a list of supported types.
    Unreadable files raise INTAKE_READ_FAIL.

CDR V5 (Integration):
    Inputs:  artifact_path (Path or str), rubric_name (str optional),
             session_id (str optional)
    Outputs: IntakeResult with rubric_result, rubric_name, artifact_type
    Side effects: writes intake receipt to ./forge_output/
    Assumptions: artifact is readable UTF-8 text
"""

from __future__ import annotations

import sys
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any

# Add forge root to path
_FORGE_ROOT = Path(__file__).parent
if str(_FORGE_ROOT) not in sys.path:
    sys.path.insert(0, str(_FORGE_ROOT))

from rubrics.RUBRIC_PYTHON import RubricResult  # noqa: E402
import FORGE_RECEIPT as receipt_module  # noqa: E402

SUPPORTED_RUBRICS = {
    "RUBRIC_PYTHON": "rubrics.RUBRIC_PYTHON",
    "RUBRIC_JSON": "rubrics.RUBRIC_JSON",
    "RUBRIC_LESSON": "rubrics.RUBRIC_LESSON",
    "RUBRIC_HTML": "rubrics.RUBRIC_HTML",
}

# Extension → rubric mapping (content inspection overrides this)
EXTENSION_MAP = {
    ".py": "RUBRIC_PYTHON",
    ".json": "RUBRIC_JSON",
    ".html": "RUBRIC_HTML",
    ".htm": "RUBRIC_HTML",
    ".md": "RUBRIC_LESSON",  # markdown lesson plans
}


@dataclass
class IntakeResult:
    artifact_path: str
    artifact_type: str
    rubric_name: str
    rubric_result: RubricResult
    session_id: str
    receipt_path: str


def _detect_type(path: Path, source: str) -> str:
    """Detect artifact type from content + extension."""
    src_lower = source[:2000].lower().strip()

    # Content wins over extension
    if src_lower.startswith("<!doctype html") or "<html" in src_lower:
        return "RUBRIC_HTML"
    if src_lower.startswith("{") or src_lower.startswith("["):
        # Could be JSON lesson plan — check for TEKS codes
        import re

        if re.search(r"\b\d+\.\d+[A-Z]\b", source):
            return "RUBRIC_LESSON"
        return "RUBRIC_JSON"
    if (
        src_lower.startswith("def ")
        or src_lower.startswith("class ")
        or src_lower.startswith('"""')
        or "import " in src_lower[:200]
    ):
        return "RUBRIC_PYTHON"
    if "teks" in src_lower or "bloom" in src_lower or "lesson" in src_lower:
        return "RUBRIC_LESSON"

    # Fall back to extension
    ext = path.suffix.lower()
    return EXTENSION_MAP.get(ext, "RUBRIC_PYTHON")  # default to Python rubric


def _load_rubric(rubric_name: str) -> Any:
    import importlib

    module_path = SUPPORTED_RUBRICS.get(rubric_name)
    if not module_path:
        raise RuntimeError(
            f"INTAKE_UNKNOWN_RUBRIC: '{rubric_name}' not in supported rubrics: "
            f"{list(SUPPORTED_RUBRICS.keys())}"
        )
    return importlib.import_module(module_path)


def run(
    artifact_path: str | Path,
    rubric_name: str | None = None,
    session_id: str | None = None,
    output_dir: Path | None = None,
) -> IntakeResult:
    """
    Classify an artifact, load the rubric, score it, write intake receipt.

    Args:
        artifact_path: path to the artifact to score
        rubric_name:   force a specific rubric (skips auto-detection)
        session_id:    session identifier for receipt chain continuity
        output_dir:    where to write receipts (default: ./forge_output)
    """
    path = Path(artifact_path)
    session_id = session_id or f"FORGE-SESSION-{uuid.uuid4().hex[:8].upper()}"
    output_dir = output_dir or Path("./forge_output")

    # Read source
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        raise RuntimeError(f"INTAKE_READ_FAIL: {path} — {e}") from e

    # Detect or use provided rubric
    artifact_type = rubric_name or _detect_type(path, source)
    rubric_name_resolved = rubric_name or artifact_type

    # Load and run rubric
    rubric = _load_rubric(rubric_name_resolved)
    rubric_result = rubric.score(path, source)

    # Write intake receipt
    r = receipt_module.make_receipt(
        artifact_path=str(path),
        rubric_name=rubric_name_resolved,
        action="INTAKE",
        baseline_score=rubric_result.overall_score,
        final_score=rubric_result.overall_score,
        gaps_found=rubric_result.gaps,
        improvements_applied=[],
        remaining_gaps=rubric_result.gaps,
        session_id=session_id,
        s_tier_achieved=rubric_result.s_tier,
    )
    rpath = receipt_module.write_receipt(r, output_dir)

    return IntakeResult(
        artifact_path=str(path),
        artifact_type=artifact_type,
        rubric_name=rubric_name_resolved,
        rubric_result=rubric_result,
        session_id=session_id,
        receipt_path=str(rpath),
    )
