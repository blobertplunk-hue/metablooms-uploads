"""
RUBRIC_HTML.py — S-tier rubric for HTML educational artifacts

CDR V1 (Intent): Score HTML artifacts built for Robert's classroom:
    interactive elements present, TEKS tagging, accessibility basics,
    bilingual content, mobile-friendly structure, and load safety.

CDR V2 (Trust): Checks parse actual HTML source with regex.
    No criterion inferred from filename. Script injection and external
    dependency risks are flagged.

CDR V3 (Boundary): Scores and reports. Does not modify HTML.

CDR V4 (Failure): Empty file or binary -> score 0.0, gap EMPTY_OR_BINARY.

CDR V5 (Integration):
    Inputs:  artifact_path (Path), source (str optional)
    Outputs: RubricResult
    Side effects: none
    Assumptions: UTF-8 HTML source
"""

from __future__ import annotations

import hashlib
import re
from pathlib import Path

from rubrics.RUBRIC_PYTHON import CriterionResult, RubricResult

RUBRIC_NAME = "RUBRIC_HTML"
S_TIER_THRESHOLD = 0.90

TEKS_PATTERN = re.compile(r"\b\d+\.\d+[A-Z]\b")


def score(artifact_path: Path, source: str | None = None) -> RubricResult:
    path_str = str(artifact_path)

    if source is None:
        if not artifact_path.exists():
            return RubricResult(
                RUBRIC_NAME, path_str, 0.0, False, gaps=["FILE_NOT_FOUND"]
            )
        source = artifact_path.read_text(encoding="utf-8", errors="replace")

    content_hash = hashlib.sha256(source.encode()).hexdigest()
    src = source.lower()

    if len(source.strip()) < 50:
        return RubricResult(
            RUBRIC_NAME,
            path_str,
            0.0,
            False,
            gaps=["EMPTY_OR_TOO_SHORT"],
            content_hash=content_hash,
        )

    criteria: list[CriterionResult] = []

    # SH-001: DOCTYPE and basic HTML structure
    has_doctype = "<!doctype html>" in src
    has_html_tag = "<html" in src
    has_body = "<body" in src
    sh001_score = sum([has_doctype, has_html_tag, has_body]) / 3
    sh001_pass = sh001_score == 1.0
    criteria.append(
        CriterionResult(
            "SH-001",
            "html_structure",
            sh001_pass,
            sh001_score,
            (
                "Valid HTML structure"
                if sh001_pass
                else f"doctype={has_doctype} html={has_html_tag} body={has_body}"
            ),
            "" if sh001_pass else "Add <!DOCTYPE html>, <html>, and <body> tags.",
        )
    )

    # SH-002: Interactive elements (drag-drop, buttons, inputs, checkboxes)
    interactive = [
        ("button", bool(re.search(r"<button", source, re.I))),
        ("input", bool(re.search(r"<input", source, re.I))),
        ("draggable", "draggable" in src),
        ("onclick", "onclick" in src or "addeventlistener" in src),
        ("select", bool(re.search(r"<select", source, re.I))),
    ]
    interactive_count = sum(1 for _, v in interactive if v)
    sh002_score = min(interactive_count / 2, 1.0)
    sh002_pass = interactive_count >= 2
    criteria.append(
        CriterionResult(
            "SH-002",
            "interactive_elements",
            sh002_pass,
            sh002_score,
            f"Interactive elements: {[n for n, v in interactive if v]}",
            (
                ""
                if sh002_pass
                else "Add at least 2 interactive elements: buttons, drag-drop, inputs, "
                "or click handlers for student engagement."
            ),
        )
    )

    # SH-003: TEKS reference
    teks_codes = TEKS_PATTERN.findall(source)
    sh003_pass = len(teks_codes) >= 1
    criteria.append(
        CriterionResult(
            "SH-003",
            "teks_reference",
            sh003_pass,
            1.0 if sh003_pass else 0.0,
            (
                f"TEKS codes: {list(set(teks_codes))}"
                if sh003_pass
                else "No TEKS codes in HTML"
            ),
            (
                ""
                if sh003_pass
                else "Add TEKS standard in a comment, data attribute, or visible footer: "
                "e.g. <!-- TEKS 3.6C --> or data-teks='3.6C'"
            ),
        )
    )

    # SH-004: Bilingual content
    bilingual_signals = [
        "español",
        "spanish",
        "lenguaje",
        "en español",
        "bilingual",
        "dual",
        "traducción",
        bool(re.search(r"lang=['\"]es", source, re.I)),
    ]
    bil_count = sum(1 for s in bilingual_signals if s and s is not False)
    sh004_pass = bil_count >= 1
    criteria.append(
        CriterionResult(
            "SH-004",
            "bilingual_content",
            sh004_pass,
            1.0 if sh004_pass else 0.0,
            (
                f"Bilingual signals: {bil_count}"
                if sh004_pass
                else "No bilingual content detected"
            ),
            (
                ""
                if sh004_pass
                else "Add Spanish labels, lang='es' sections, or bilingual vocabulary. "
                "Critical for emergent bilingual students."
            ),
        )
    )

    # SH-005: Viewport meta (mobile-friendly)
    has_viewport = bool(re.search(r"<meta[^>]+viewport", source, re.I))
    criteria.append(
        CriterionResult(
            "SH-005",
            "viewport_meta",
            has_viewport,
            1.0 if has_viewport else 0.0,
            "Viewport meta present" if has_viewport else "No viewport meta tag",
            (
                ""
                if has_viewport
                else "Add: <meta name='viewport' content='width=device-width, initial-scale=1'>"
            ),
        )
    )

    # SH-006: No unsafe external scripts (only known CDNs or no external scripts)
    ext_scripts = re.findall(r'<script[^>]+src=["\']([^"\']+)["\']', source, re.I)
    safe_cdns = [
        "cdnjs.cloudflare.com",
        "cdn.jsdelivr.net",
        "unpkg.com",
        "code.jquery.com",
        "cdn.tailwindcss.com",
    ]
    unsafe = [s for s in ext_scripts if not any(cdn in s for cdn in safe_cdns)]
    sh006_pass = len(unsafe) == 0
    criteria.append(
        CriterionResult(
            "SH-006",
            "safe_external_scripts",
            sh006_pass,
            1.0 if sh006_pass else 0.0,
            (
                "External scripts safe"
                if sh006_pass
                else f"Potentially unsafe external scripts: {unsafe}"
            ),
            (
                ""
                if sh006_pass
                else "Use only trusted CDNs or inline scripts. Remove or replace unsafe sources."
            ),
        )
    )

    overall = sum(c.score for c in criteria) / len(criteria)
    s_tier = overall >= S_TIER_THRESHOLD
    gaps = [c.finding for c in criteria if not c.passed]
    improvements = [c.improvement for c in criteria if c.improvement]

    return RubricResult(
        RUBRIC_NAME,
        path_str,
        overall,
        s_tier,
        criteria,
        gaps,
        improvements,
        content_hash,
    )
