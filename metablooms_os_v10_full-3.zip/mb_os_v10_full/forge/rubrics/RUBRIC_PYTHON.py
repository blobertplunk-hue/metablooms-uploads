"""
RUBRIC_PYTHON.py — S-tier rubric for Python engine files

CDR V1 (Intent): Evaluate any .py file against the 6 S-tier criteria
    derived from the LFIS session. These criteria are the same regardless
    of what the engine does — they govern HOW it's built, not WHAT it does.

CDR V2 (Trust): Every check reads actual source code via AST and regex.
    No criterion is scored without inspecting the real file content.
    Partial credit is given where measurable progress exists.

CDR V3 (Boundary): RUBRIC_PYTHON scores and reports gaps. It does not
    modify source files. Improvement suggestions are returned as strings
    for FORGE_RUNNER to apply.

CDR V4 (Failure): Missing file returns score 0.0 with gap FILE_NOT_FOUND.
    SyntaxError returns score 0.0 with gap SYNTAX_ERROR — cannot score
    a file that does not parse.

CDR V5 (Integration):
    Inputs:  artifact_path (Path), source (str, optional override)
    Outputs: RubricResult with score, criteria, gaps, improvements
    Side effects: none
    Assumptions: file is UTF-8 encoded Python source
"""

from __future__ import annotations

import ast
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

RUBRIC_NAME = "RUBRIC_PYTHON"
S_TIER_THRESHOLD = 0.95


@dataclass
class CriterionResult:
    criterion_id: str
    name: str
    passed: bool
    score: float  # 0.0–1.0, partial credit allowed
    finding: str
    improvement: str  # concrete fix to apply


@dataclass
class RubricResult:
    rubric_name: str
    artifact_path: str
    overall_score: float
    s_tier: bool
    criteria: list[CriterionResult] = field(default_factory=list)
    gaps: list[str] = field(default_factory=list)
    improvements: list[str] = field(default_factory=list)
    content_hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "rubric": self.rubric_name,
            "artifact": self.artifact_path,
            "overall_score": round(self.overall_score, 4),
            "s_tier": self.s_tier,
            "criteria": [
                {
                    "id": c.criterion_id,
                    "name": c.name,
                    "passed": c.passed,
                    "score": round(c.score, 4),
                    "finding": c.finding,
                    "improvement": c.improvement,
                }
                for c in self.criteria
            ],
            "gaps": self.gaps,
            "improvements": self.improvements,
            "content_hash": self.content_hash,
        }


def score(artifact_path: Path, source: str | None = None) -> RubricResult:
    """Score a Python file against all 6 S-tier criteria."""
    path_str = str(artifact_path)

    if source is None:
        if not artifact_path.exists():
            return RubricResult(
                RUBRIC_NAME,
                path_str,
                0.0,
                False,
                gaps=["FILE_NOT_FOUND"],
                improvements=["Create the file before scoring"],
            )
        source = artifact_path.read_text(encoding="utf-8")

    # Compute content hash
    content_hash = hashlib.sha256(source.encode()).hexdigest()

    # Parse AST
    tree: ast.Module | None = None
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return RubricResult(
            RUBRIC_NAME,
            path_str,
            0.0,
            False,
            gaps=[f"SYNTAX_ERROR: {e}"],
            improvements=["Fix syntax errors before scoring"],
            content_hash=content_hash,
        )

    criteria: list[CriterionResult] = []

    # ── ST-001: No auto-pass sentinels ────────────────────────────────────────
    sentinel_patterns = [
        (r"governance_compliant\s*=\s*True", "governance_compliant=True"),
        (r"tests_passed\s*=\s*True", "tests_passed=True"),
        (r"['\"]complete['\"]\s*:\s*True", "'complete': True"),
        (r"['\"]all_passed['\"]\s*:\s*True", "'all_passed': True"),
        (r"['\"]ok['\"]\s*:\s*True\b", "'ok': True"),
    ]
    real_sentinels = []
    for pattern, label in sentinel_patterns:
        for m in re.finditer(pattern, source):
            ctx = source[max(0, m.start() - 60) : m.end() + 60]
            if not any(kw in ctx for kw in ("raise", "if ", "assert", "#")):
                real_sentinels.append(label)
    st001_pass = len(real_sentinels) == 0
    criteria.append(
        CriterionResult(
            "ST-001",
            "no_auto_pass_sentinels",
            st001_pass,
            1.0 if st001_pass else 0.0,
            "Clean" if st001_pass else f"Sentinels: {real_sentinels}",
            (
                ""
                if st001_pass
                else "Remove auto-pass sentinels. Replace with real evidence checks "
                "that raise RuntimeError on failure."
            ),
        )
    )

    # ── ST-002: SHA-256 byte-backed artifacts ─────────────────────────────────
    has_sha256 = bool(re.search(r"hashlib\.sha256|sha256\(", source))
    has_hash_field = bool(
        re.search(r"result_hash|artifact_hash|content_hash|entry_hash", source)
    )
    has_hexdigest = "hexdigest()" in source
    st002_score = (
        1.0
        if (has_sha256 and has_hash_field and has_hexdigest)
        else 0.5 if (has_sha256 or has_hash_field) else 0.0
    )
    st002_pass = st002_score == 1.0
    criteria.append(
        CriterionResult(
            "ST-002",
            "sha256_backed_artifacts",
            st002_pass,
            st002_score,
            (
                "SHA-256 hash verification present"
                if st002_pass
                else f"sha256={has_sha256} hash_field={has_hash_field} hexdigest={has_hexdigest}"
            ),
            (
                ""
                if st002_pass
                else "Add: import hashlib; compute hashlib.sha256(content.encode()).hexdigest(); "
                "store as result_hash or content_hash in every output dict."
            ),
        )
    )

    # ── ST-003: Failure modes declared ────────────────────────────────────────
    has_raise = "raise RuntimeError" in source
    has_cdr_v4 = bool(re.search(r"CDR V4|Failure[:\s]|failure_mode", source, re.I))
    has_named_error = bool(re.search(r'raise RuntimeError\(\s*f?"[A-Z_]+:', source))
    st003_score = (
        1.0
        if (has_raise and has_cdr_v4 and has_named_error)
        else 0.7 if (has_raise and has_cdr_v4) else 0.3 if has_raise else 0.0
    )
    st003_pass = st003_score >= 0.95
    criteria.append(
        CriterionResult(
            "ST-003",
            "failure_modes_declared",
            st003_pass,
            st003_score,
            (
                "Named failure modes with RuntimeError present"
                if st003_pass
                else f"raise={has_raise} cdr_v4={has_cdr_v4} named_code={has_named_error}"
            ),
            (
                ""
                if st003_pass
                else "Add CDR V4 (Failure) docblock. Use named error codes: "
                "raise RuntimeError('ENGINE_NAME_FAIL_CODE: reason'). "
                "Document each failure mode and its safe state."
            ),
        )
    )

    # ── ST-004: Integration contract ─────────────────────────────────────────
    has_inputs = bool(re.search(r"Inputs?\s*:", source))
    has_outputs = bool(re.search(r"Outputs?\s*:", source))
    has_side_effects = bool(re.search(r"Side effects?\s*:", source, re.I))
    has_assumptions = bool(re.search(r"Assumptions?\s*:", source))
    contract_count = sum([has_inputs, has_outputs, has_side_effects, has_assumptions])
    st004_score = contract_count / 4
    st004_pass = contract_count == 4
    missing_contract = [
        n
        for n, v in zip(
            ["Inputs:", "Outputs:", "Side effects:", "Assumptions:"],
            [has_inputs, has_outputs, has_side_effects, has_assumptions],
        )
        if not v
    ]
    criteria.append(
        CriterionResult(
            "ST-004",
            "integration_contract",
            st004_pass,
            st004_score,
            "Full contract present" if st004_pass else f"Missing: {missing_contract}",
            (
                ""
                if st004_pass
                else f"Add to module docstring: {', '.join(missing_contract)}. "
                "Format: 'Inputs: ...\\nOutputs: ...\\nSide effects: ...\\nAssumptions: ...'"
            ),
        )
    )

    # ── ST-005: CDR V1–V5 docstring blocks ───────────────────────────────────
    cdr_blocks = [f"CDR V{i}" for i in range(1, 6)]
    present = [b for b in cdr_blocks if b in source]
    missing_cdr = [b for b in cdr_blocks if b not in source]
    st005_score = len(present) / 5
    st005_pass = len(present) >= 4
    criteria.append(
        CriterionResult(
            "ST-005",
            "cdr_docstring_complete",
            st005_pass,
            st005_score,
            f"CDR blocks present: {present}" if present else "No CDR blocks",
            (
                ""
                if st005_pass
                else f"Add missing CDR blocks: {missing_cdr}. "
                "CDR V1=Intent, V2=Trust, V3=Boundary, V4=Failure, V5=Integration."
            ),
        )
    )

    # ── ST-006: Type annotations ≥ 80% on public methods ────────────────────
    if tree:
        funcs = [
            n
            for n in ast.walk(tree)
            if isinstance(n, ast.FunctionDef) and not n.name.startswith("_")
        ]
        annotated = [f for f in funcs if f.returns is not None]
        type_cov = len(annotated) / len(funcs) if funcs else 1.0
        unannotated = [f.name for f in funcs if f.returns is None][:5]
    else:
        type_cov = 0.0
        unannotated = []
    st006_pass = type_cov >= 0.80
    criteria.append(
        CriterionResult(
            "ST-006",
            "type_annotations_80pct",
            st006_pass,
            type_cov,
            f"Type coverage {type_cov:.0%}"
            + (f" — unannotated: {unannotated}" if unannotated else ""),
            (
                ""
                if st006_pass
                else f"Add return type annotations to: {unannotated}. "
                "Use '-> dict[str, Any]' or '-> None' as appropriate."
            ),
        )
    )

    # ── Aggregate ─────────────────────────────────────────────────────────────
    overall = sum(c.score for c in criteria) / len(criteria)
    s_tier = overall >= S_TIER_THRESHOLD
    gaps = [c.finding for c in criteria if not c.passed]
    improvements = [c.improvement for c in criteria if c.improvement]

    return RubricResult(
        RUBRIC_NAME,
        path_str,
        overall,
        s_tier,
        criteria,
        gaps,
        improvements,
        content_hash,
    )
