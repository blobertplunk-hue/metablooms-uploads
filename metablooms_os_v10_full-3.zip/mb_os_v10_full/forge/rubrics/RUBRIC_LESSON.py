"""
RUBRIC_LESSON.py — S-tier rubric for lesson plans (TEKS-aligned, bilingual)

CDR V1 (Intent): Score any lesson plan artifact — JSON, dict, or markdown —
    against quality criteria specific to Robert's 3rd grade bilingual
    classroom: TEKS alignment, Bloom's scaffold levels, bilingual support,
    assessment presence, and instructional completeness.

CDR V2 (Trust): Checks run against actual content. No criterion is scored
    without reading the lesson structure. TEKS codes are validated against
    known pattern (e.g. 3.6C, 3.1A). Grade level is verified if present.

CDR V3 (Boundary): Scores and reports gaps with concrete fixes.
    Does not rewrite lesson content.

CDR V4 (Failure): Unrecognized format returns score 0.0, gap FORMAT_UNKNOWN.
    Missing TEKS entirely returns ST-001 score 0.0, hard cap on overall.

CDR V5 (Integration):
    Inputs:  artifact_path (Path), source (str optional), data (dict optional)
    Outputs: RubricResult
    Side effects: none
    Assumptions: lesson plan is JSON or markdown with identifiable structure
"""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from rubrics.RUBRIC_PYTHON import CriterionResult, RubricResult

RUBRIC_NAME = "RUBRIC_LESSON"
S_TIER_THRESHOLD = (
    0.90  # Slightly lower — lesson quality is harder to mechanically verify
)

BLOOMS_LEVELS = {
    "remember": 1,
    "recall": 1,
    "identify": 1,
    "list": 1,
    "name": 1,
    "understand": 2,
    "explain": 2,
    "describe": 2,
    "summarize": 2,
    "apply": 3,
    "use": 3,
    "demonstrate": 3,
    "solve": 3,
    "analyze": 4,
    "compare": 4,
    "differentiate": 4,
    "examine": 4,
    "evaluate": 5,
    "justify": 5,
    "assess": 5,
    "critique": 5,
    "create": 6,
    "design": 6,
    "compose": 6,
    "produce": 6,
}

TEKS_PATTERN = re.compile(r"\b\d+\.\d+[A-Z]\b")
BILINGUAL_TERMS = [
    "spanish",
    "bilingual",
    "esl",
    "ell",
    "emergent bilingual",
    "lenguaje",
    "idioma",
    "español",
    "en español",
    "dual language",
]


def _extract_text(data: Any) -> str:
    """Recursively extract all string values from a nested structure."""
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return " ".join(_extract_text(v) for v in data.values())
    if isinstance(data, list):
        return " ".join(_extract_text(i) for i in data)
    return str(data)


def score(
    artifact_path: Path,
    source: str | None = None,
    data: dict | None = None,
) -> RubricResult:
    path_str = str(artifact_path)

    if data is None:
        if source is None:
            if not artifact_path.exists():
                return RubricResult(
                    RUBRIC_NAME, path_str, 0.0, False, gaps=["FILE_NOT_FOUND"]
                )
            source = artifact_path.read_text(encoding="utf-8")

        content_hash = hashlib.sha256(source.encode()).hexdigest()

        if artifact_path.suffix == ".json" or source.strip().startswith("{"):
            try:
                data = json.loads(source)
            except json.JSONDecodeError:
                data = {}
        else:
            # markdown / plain text — wrap in dict
            data = {"content": source}
    else:
        raw = json.dumps(data, sort_keys=True)
        content_hash = hashlib.sha256(raw.encode()).hexdigest()

    full_text = _extract_text(data).lower()
    criteria: list[CriterionResult] = []

    # SL-001: TEKS alignment — at least one valid TEKS code
    teks_codes = TEKS_PATTERN.findall(_extract_text(data))
    sl001_pass = len(teks_codes) >= 1
    criteria.append(
        CriterionResult(
            "SL-001",
            "teks_alignment",
            sl001_pass,
            1.0 if sl001_pass else 0.0,
            (
                f"TEKS codes found: {list(set(teks_codes))}"
                if sl001_pass
                else "No TEKS codes found"
            ),
            (
                ""
                if sl001_pass
                else "Add TEKS standard codes (e.g. 3.6C, 3.1A) in teks_standard, "
                "teks_alignment, or objective fields."
            ),
        )
    )

    # SL-002: Bloom's taxonomy — at least 2 distinct levels represented
    found_levels = set()
    for word, level in BLOOMS_LEVELS.items():
        if word in full_text:
            found_levels.add(level)
    sl002_score = min(len(found_levels) / 3, 1.0)  # 3+ levels = full score
    sl002_pass = len(found_levels) >= 2
    criteria.append(
        CriterionResult(
            "SL-002",
            "blooms_scaffold",
            sl002_pass,
            sl002_score,
            (
                f"Bloom's levels present: {sorted(found_levels)}"
                if found_levels
                else "No Bloom's level verbs detected"
            ),
            (
                ""
                if sl002_pass
                else "Add activities at multiple cognitive levels. Include lower-order "
                "(identify/explain) AND higher-order (analyze/create) tasks."
            ),
        )
    )

    # SL-003: Bilingual/ELL support
    bil_found = [t for t in BILINGUAL_TERMS if t in full_text]
    sl003_pass = len(bil_found) >= 1
    criteria.append(
        CriterionResult(
            "SL-003",
            "bilingual_support",
            sl003_pass,
            1.0 if sl003_pass else 0.0,
            (
                f"Bilingual markers: {bil_found}"
                if sl003_pass
                else "No bilingual/ELL support indicated"
            ),
            (
                ""
                if sl003_pass
                else "Add bilingual_support, ell_accommodations, or spanish_vocabulary "
                "section. Include Spanish translations of key terms."
            ),
        )
    )

    # SL-004: Assessment present
    assess_terms = [
        "assessment",
        "assess",
        "quiz",
        "check",
        "exit ticket",
        "formative",
        "summative",
        "evaluate student",
        "rubric",
    ]
    has_assessment = any(t in full_text for t in assess_terms)
    criteria.append(
        CriterionResult(
            "SL-004",
            "assessment_present",
            has_assessment,
            1.0 if has_assessment else 0.0,
            (
                "Assessment component found"
                if has_assessment
                else "No assessment component"
            ),
            (
                ""
                if has_assessment
                else "Add assessment field: exit ticket, formative check, or evaluation "
                "criteria aligned to the TEKS objective."
            ),
        )
    )

    # SL-005: Instructional sequence (at least 3 distinct phases)
    phase_terms = [
        "introduce",
        "introduction",
        "hook",
        "engage",
        "activate",
        "teach",
        "model",
        "explain",
        "direct instruction",
        "input",
        "practice",
        "guided",
        "independent",
        "apply",
        "close",
        "closure",
        "wrap up",
        "exit",
        "review",
    ]
    phases_found = sum(1 for t in phase_terms if t in full_text)
    sl005_score = min(phases_found / 5, 1.0)
    sl005_pass = phases_found >= 3
    criteria.append(
        CriterionResult(
            "SL-005",
            "instructional_sequence",
            sl005_pass,
            sl005_score,
            f"Instructional phase terms found: {phases_found}",
            (
                ""
                if sl005_pass
                else "Add explicit lesson phases: introduction/hook, direct instruction, "
                "guided practice, independent practice, closure."
            ),
        )
    )

    # SL-006: Time/duration specified
    time_pattern = re.compile(r"\b\d+\s*(min|minute|hour|hr|period)\b", re.I)
    has_time = bool(time_pattern.search(_extract_text(data)))
    criteria.append(
        CriterionResult(
            "SL-006",
            "duration_specified",
            has_time,
            1.0 if has_time else 0.0,
            "Duration specified" if has_time else "No time/duration found",
            (
                ""
                if has_time
                else "Add duration field or time estimates per activity (e.g. '20 minutes')."
            ),
        )
    )

    overall = sum(c.score for c in criteria) / len(criteria)
    s_tier = overall >= S_TIER_THRESHOLD
    gaps = [c.finding for c in criteria if not c.passed]
    improvements = [c.improvement for c in criteria if c.improvement]

    return RubricResult(
        RUBRIC_NAME,
        path_str,
        overall,
        s_tier,
        criteria,
        gaps,
        improvements,
        content_hash,
    )
