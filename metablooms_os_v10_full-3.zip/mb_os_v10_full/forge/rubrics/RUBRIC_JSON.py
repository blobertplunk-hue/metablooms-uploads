"""
RUBRIC_JSON.py — S-tier rubric for JSON config/schema files

CDR V1 (Intent): Any JSON artifact can be scored for structural quality:
    required fields present, no nulls in critical positions, hash anchoring,
    schema self-declaration, and semantic completeness.

CDR V2 (Trust): Every check parses the actual JSON. If JSON is malformed,
    score is 0.0. No criterion is inferred from filename alone.

CDR V3 (Boundary): Scores and reports. Does not modify JSON files.

CDR V4 (Failure): Malformed JSON -> score 0.0, gap JSON_PARSE_ERROR.
    Empty file -> score 0.0, gap EMPTY_FILE.

CDR V5 (Integration):
    Inputs:  artifact_path (Path), source (str optional)
    Outputs: RubricResult
    Side effects: none
    Assumptions: file is UTF-8 encoded JSON
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

from rubrics.RUBRIC_PYTHON import CriterionResult, RubricResult

RUBRIC_NAME = "RUBRIC_JSON"
S_TIER_THRESHOLD = 0.95


def score(artifact_path: Path, source: str | None = None) -> RubricResult:
    path_str = str(artifact_path)

    if source is None:
        if not artifact_path.exists():
            return RubricResult(
                RUBRIC_NAME, path_str, 0.0, False, gaps=["FILE_NOT_FOUND"]
            )
        source = artifact_path.read_text(encoding="utf-8")

    content_hash = hashlib.sha256(source.encode()).hexdigest()

    if not source.strip():
        return RubricResult(
            RUBRIC_NAME,
            path_str,
            0.0,
            False,
            gaps=["EMPTY_FILE"],
            content_hash=content_hash,
        )

    try:
        data = json.loads(source)
    except json.JSONDecodeError as e:
        return RubricResult(
            RUBRIC_NAME,
            path_str,
            0.0,
            False,
            gaps=[f"JSON_PARSE_ERROR: {e}"],
            content_hash=content_hash,
        )

    criteria: list[CriterionResult] = []

    # SJ-001: Schema self-declaration (schema or artifact_type field)
    has_schema = isinstance(data, dict) and bool(
        data.get("schema") or data.get("artifact_type") or data.get("$schema")
    )
    criteria.append(
        CriterionResult(
            "SJ-001",
            "schema_declared",
            has_schema,
            1.0 if has_schema else 0.0,
            "Schema declared" if has_schema else "No schema/artifact_type field",
            (
                ""
                if has_schema
                else "Add top-level 'schema' field: e.g. 'schema': 'forge.config.v1'"
            ),
        )
    )

    # SJ-002: No null values in top-level required fields
    if isinstance(data, dict):
        nulls = [k for k, v in data.items() if v is None]
        sj002_pass = len(nulls) == 0
    else:
        nulls = []
        sj002_pass = True
    criteria.append(
        CriterionResult(
            "SJ-002",
            "no_null_values",
            sj002_pass,
            1.0 if sj002_pass else max(0.0, 1.0 - len(nulls) * 0.2),
            "No nulls" if sj002_pass else f"Null fields: {nulls}",
            (
                ""
                if sj002_pass
                else f"Replace null values in {nulls} with defaults or remove."
            ),
        )
    )

    # SJ-003: Hash anchor present (content_hash or hash field)
    if isinstance(data, dict):
        has_hash = bool(
            data.get("hash")
            or data.get("content_hash")
            or data.get("sha256")
            or data.get("artifact_hash")
        )
    else:
        has_hash = False
    criteria.append(
        CriterionResult(
            "SJ-003",
            "hash_anchor",
            has_hash,
            1.0 if has_hash else 0.0,
            "Hash anchor present" if has_hash else "No hash field",
            (
                ""
                if has_hash
                else "Add 'hash': sha256(json.dumps(content, sort_keys=True).encode()).hexdigest()"
            ),
        )
    )

    # SJ-004: Timestamp present
    if isinstance(data, dict):
        has_ts = bool(
            data.get("timestamp")
            or data.get("timestamp_utc")
            or data.get("generated_utc")
            or data.get("created_at")
        )
    else:
        has_ts = False
    criteria.append(
        CriterionResult(
            "SJ-004",
            "timestamp_present",
            has_ts,
            1.0 if has_ts else 0.0,
            "Timestamp present" if has_ts else "No timestamp field",
            (
                ""
                if has_ts
                else "Add 'timestamp_utc': datetime.now(timezone.utc).isoformat()"
            ),
        )
    )

    # SJ-005: Non-trivial content (more than 3 fields if dict, more than 1 item if list)
    if isinstance(data, dict):
        sz = len(data)
        sj005_pass = sz >= 3
        finding = f"{sz} top-level fields"
    elif isinstance(data, list):
        sz = len(data)
        sj005_pass = sz >= 1
        finding = f"{sz} items"
    else:
        sj005_pass = False
        finding = "Scalar JSON — not a config artifact"
    criteria.append(
        CriterionResult(
            "SJ-005",
            "non_trivial_content",
            sj005_pass,
            1.0 if sj005_pass else 0.0,
            finding,
            "" if sj005_pass else "Artifact appears empty or trivially small.",
        )
    )

    # SJ-006: Version or status field
    if isinstance(data, dict):
        has_version = bool(
            data.get("version")
            or data.get("status")
            or data.get("os_version")
            or data.get("schema_version")
        )
    else:
        has_version = False
    criteria.append(
        CriterionResult(
            "SJ-006",
            "version_or_status",
            has_version,
            1.0 if has_version else 0.0,
            "Version/status present" if has_version else "No version or status field",
            "" if has_version else "Add 'version': '1.0.0' or 'status': 'ACTIVE'",
        )
    )

    overall = sum(c.score for c in criteria) / len(criteria)
    s_tier = overall >= S_TIER_THRESHOLD
    gaps = [c.finding for c in criteria if not c.passed]
    improvements = [c.improvement for c in criteria if c.improvement]

    return RubricResult(
        RUBRIC_NAME,
        path_str,
        overall,
        s_tier,
        criteria,
        gaps,
        improvements,
        content_hash,
    )
