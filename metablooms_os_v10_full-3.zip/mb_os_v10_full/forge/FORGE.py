"""
FORGE.py — Forced Output Refinement and Governance Engine

CDR V1 (Intent): FORGE is a universal S-tier system builder. Feed it any
    artifact — Python engine, JSON config, lesson plan, HTML activity —
    and it scores it against a rubric, applies every auto-fixable improvement,
    and reports what remains for human implementation. The system has no
    choice but to get better on each run.

CDR V2 (Trust): Every FORGE run produces SHA-256 anchored receipts. The
    final report contains the baseline score, final score, delta, and
    content hash of the improved artifact. No score is claimed without
    a receipt chain proving the measurement.

CDR V3 (Boundary): FORGE orchestrates FORGE_INTAKE → FORGE_RUNNER.
    It does not implement business logic improvements — those belong to the
    artifact owner. FORGE handles structural quality: contracts, hashes,
    CDR blocks, type annotations, schema declarations.

CDR V4 (Failure): If artifact cannot be read: FORGE_FAIL_READ.
    If rubric unknown: FORGE_FAIL_RUBRIC. If output_dir unwritable:
    FORGE_FAIL_OUTPUT. FORGE never silently succeeds on a real failure.

CDR V5 (Integration):
    Inputs:  artifact (str/Path), rubric (str optional), output_dir (Path optional)
    Outputs: ForgeReport written to output_dir/FORGE_REPORT_{artifact}.json
    Side effects: may modify artifact in-place, writes receipts + report
    Assumptions: artifact is UTF-8 readable text

USAGE:
    python FORGE.py path/to/artifact.py
    python FORGE.py path/to/config.json --rubric RUBRIC_JSON
    python FORGE.py path/to/lesson.json --rubric RUBRIC_LESSON
    python FORGE.py path/to/activity.html --rubric RUBRIC_HTML

    # Python API:
    from FORGE import forge
    report = forge("my_engine.py")
    report = forge("lesson.json", rubric="RUBRIC_LESSON")
"""

from __future__ import annotations

import hashlib
import json
import sys
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_FORGE_ROOT = Path(__file__).parent
if str(_FORGE_ROOT) not in sys.path:
    sys.path.insert(0, str(_FORGE_ROOT))

import FORGE_INTAKE as intake_module  # noqa: E402
import FORGE_RUNNER as runner_module  # noqa: E402
import FORGE_RECEIPT as receipt_module  # noqa: E402


@dataclass
class ForgeReport:
    session_id: str
    artifact_path: str
    rubric_name: str
    artifact_type: str
    baseline_score: float
    final_score: float
    delta: float
    s_tier_achieved: bool
    loops_run: int
    improvements_applied: list[str]
    backlog: list[dict]
    receipt_count: int
    artifact_hash_before: str
    artifact_hash_after: str
    timestamp: str
    report_hash: str = ""

    def compute_hash(self) -> str:
        payload = {
            "session_id": self.session_id,
            "artifact_path": self.artifact_path,
            "baseline_score": self.baseline_score,
            "final_score": self.final_score,
            "s_tier_achieved": self.s_tier_achieved,
            "improvements_applied": self.improvements_applied,
            "timestamp": self.timestamp,
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "forge.report.v1",
            "session_id": self.session_id,
            "artifact_path": self.artifact_path,
            "rubric_name": self.rubric_name,
            "artifact_type": self.artifact_type,
            "baseline_score": round(self.baseline_score, 4),
            "final_score": round(self.final_score, 4),
            "delta": round(self.delta, 4),
            "s_tier_achieved": self.s_tier_achieved,
            "loops_run": self.loops_run,
            "improvements_applied": self.improvements_applied,
            "backlog_count": len(self.backlog),
            "backlog": self.backlog,
            "receipt_count": self.receipt_count,
            "artifact_hash_before": self.artifact_hash_before,
            "artifact_hash_after": self.artifact_hash_after,
            "timestamp": self.timestamp,
            "report_hash": self.report_hash,
        }

    def print_summary(self) -> None:
        bar = "█" * int(self.final_score * 20) + "░" * (20 - int(self.final_score * 20))
        tier = "✅ S-TIER" if self.s_tier_achieved else "⚠ BELOW S-TIER"
        print(f"\n{'='*60}")
        print(f"FORGE REPORT — {Path(self.artifact_path).name}")
        print(f"{'='*60}")
        print(f"Rubric:   {self.rubric_name}")
        print(f"Score:    [{bar}] {self.final_score:.3f}  {tier}")
        print(
            f"Baseline: {self.baseline_score:.3f} → Final: {self.final_score:.3f}  (Δ{self.delta:+.3f})"
        )
        print(f"Loops:    {self.loops_run}")
        if self.improvements_applied:
            print(f"\nImprovements applied ({len(self.improvements_applied)}):")
            for imp in self.improvements_applied:
                print(f"  • {imp[:75]}")
        if self.backlog:
            print(
                f"\nHardening backlog ({len(self.backlog)} items — require human work):"
            )
            for item in self.backlog:
                print(f"  ⚠ [{item['criterion']}] {item['gap'][:60]}")
                print(f"    Fix: {item['fix'][:60]}")
        print(f"\nReceipts: {self.receipt_count} written")
        print(
            f"Report:   {self.artifact_path.replace(str(Path(self.artifact_path).name), '')}forge_output/"
        )
        print(f"Hash:     {self.report_hash[:16]}...")
        print(f"{'='*60}\n")


def forge(
    artifact: str | Path,
    rubric: str | None = None,
    output_dir: Path | None = None,
    max_loops: int = 3,
    dry_run: bool = False,
) -> ForgeReport:
    """
    Run FORGE on any artifact. Returns ForgeReport.

    Args:
        artifact:   path to the artifact to process
        rubric:     rubric name override (auto-detected if None)
        output_dir: where to write receipts/reports (default: ./forge_output)
        max_loops:  max improvement iterations per artifact (default: 3)
        dry_run:    score only, do not apply improvements
    """
    if dry_run:
        max_loops = 0

    path = Path(artifact)
    output_dir = output_dir or Path("./forge_output")
    output_dir.mkdir(parents=True, exist_ok=True)
    session_id = f"FORGE-{uuid.uuid4().hex[:8].upper()}"

    # Hash before
    try:
        source_before = path.read_text(encoding="utf-8", errors="replace")
        hash_before = hashlib.sha256(source_before.encode()).hexdigest()
    except OSError as e:
        raise RuntimeError(f"FORGE_FAIL_READ: {path} — {e}") from e

    # INTAKE
    print(f"\n[FORGE] Intake: {path.name} ...", end=" ", flush=True)
    intake = intake_module.run(
        artifact_path=path,
        rubric_name=rubric,
        session_id=session_id,
        output_dir=output_dir,
    )
    print(
        f"score={intake.rubric_result.overall_score:.3f} "
        f"rubric={intake.rubric_name} "
        f"{'✅' if intake.rubric_result.s_tier else '⚠'}"
    )

    all_receipts = [intake.receipt_path]

    # RUNNER
    if max_loops > 0 and not intake.rubric_result.s_tier:
        print(f"[FORGE] Running improvement loops (max={max_loops}) ...")
        runner_result = runner_module.run(
            intake, output_dir=output_dir, max_loops=max_loops
        )
        all_receipts.extend(runner_result.receipt_paths)
        final_score = runner_result.final_score
        s_tier = runner_result.s_tier_achieved
        improvements = runner_result.improvements_applied
        backlog = runner_result.backlog
        loops_run = runner_result.loops_run
    else:
        final_score = intake.rubric_result.overall_score
        s_tier = intake.rubric_result.s_tier
        improvements = []
        backlog = []
        loops_run = 0
        if s_tier:
            print("[FORGE] Already S-tier — no improvements needed.")

    # Hash after
    try:
        source_after = path.read_text(encoding="utf-8", errors="replace")
        hash_after = hashlib.sha256(source_after.encode()).hexdigest()
    except OSError:
        hash_after = hash_before

    # Write final PROMOTE receipt
    final_action = "PROMOTE" if s_tier else "BACKLOG"
    r = receipt_module.make_receipt(
        artifact_path=str(path),
        rubric_name=intake.rubric_name,
        action=final_action,
        baseline_score=intake.rubric_result.overall_score,
        final_score=final_score,
        gaps_found=[],
        improvements_applied=improvements,
        remaining_gaps=backlog,
        session_id=session_id,
        s_tier_achieved=s_tier,
    )
    rpath = receipt_module.write_receipt(r, output_dir)
    all_receipts.append(str(rpath))

    now = datetime.now(timezone.utc).isoformat()
    report = ForgeReport(
        session_id=session_id,
        artifact_path=str(path),
        rubric_name=intake.rubric_name,
        artifact_type=intake.artifact_type,
        baseline_score=intake.rubric_result.overall_score,
        final_score=final_score,
        delta=final_score - intake.rubric_result.overall_score,
        s_tier_achieved=s_tier,
        loops_run=loops_run,
        improvements_applied=improvements,
        backlog=backlog,
        receipt_count=len(all_receipts),
        artifact_hash_before=hash_before,
        artifact_hash_after=hash_after,
        timestamp=now,
    )
    report.report_hash = report.compute_hash()

    # Write report
    artifact_stem = path.stem.replace(" ", "_")
    report_path = output_dir / f"FORGE_REPORT_{artifact_stem}.json"
    report_path.write_text(json.dumps(report.to_dict(), indent=2))

    report.print_summary()
    return report


# ── CLI ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="FORGE — Universal S-tier artifact upgrader"
    )
    parser.add_argument("artifact", help="Path to artifact to process")
    parser.add_argument(
        "--rubric",
        default=None,
        help="Rubric name (auto-detected if omitted). "
        "Options: RUBRIC_PYTHON, RUBRIC_JSON, RUBRIC_LESSON, RUBRIC_HTML",
    )
    parser.add_argument(
        "--output-dir",
        default="./forge_output",
        help="Directory for receipts and reports",
    )
    parser.add_argument(
        "--max-loops", type=int, default=3, help="Max improvement loops (default: 3)"
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Score only, do not apply improvements"
    )
    args = parser.parse_args()

    try:
        report = forge(
            artifact=args.artifact,
            rubric=args.rubric,
            output_dir=Path(args.output_dir),
            max_loops=args.max_loops,
            dry_run=args.dry_run,
        )
        sys.exit(0 if report.s_tier_achieved else 1)
    except RuntimeError as e:
        print(f"\n[FORGE ERROR] {e}", file=sys.stderr)
        sys.exit(2)
