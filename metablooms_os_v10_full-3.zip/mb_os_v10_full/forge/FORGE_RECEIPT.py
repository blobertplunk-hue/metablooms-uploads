"""
FORGE_RECEIPT.py — SHA-256 anchored receipt chain for FORGE

CDR V1 (Intent): Every FORGE action produces a cryptographically anchored
    receipt. No improvement is claimed without a receipt proving it happened.
    Receipts are append-only. Nothing is ever overwritten.

CDR V2 (Trust): content_hash is SHA-256 over all receipt fields except
    content_hash itself, with sort_keys=True for determinism.
    Same inputs always produce the same hash.

CDR V3 (Boundary): FORGE_RECEIPT writes and reads receipts. It does not
    score, improve, or classify artifacts. Receipt chain is append-only.

CDR V4 (Failure): If receipt cannot be written, raises RuntimeError with
    RECEIPT_WRITE_FAIL. Never silently drops a receipt.

CDR V5 (Integration):
    Inputs:  receipt data dict
    Outputs: ForgeReceipt dataclass, written to FORGE_RECEIPT_CHAIN.ndjson
    Side effects: appends to FORGE_RECEIPT_CHAIN.ndjson
    Assumptions: output directory is writable
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


@dataclass
class ForgeReceipt:
    receipt_id: str
    artifact_path: str
    rubric_name: str
    action: str  # INTAKE | SCORE | IMPROVE | PROMOTE | BACKLOG
    baseline_score: float
    final_score: float
    delta: float
    s_tier_achieved: bool
    gaps_found: list[str]
    improvements_applied: list[str]
    remaining_gaps: list[str]
    session_id: str
    timestamp: str
    content_hash: str = ""

    def compute_hash(self) -> str:
        payload = {
            "receipt_id": self.receipt_id,
            "artifact_path": self.artifact_path,
            "rubric_name": self.rubric_name,
            "action": self.action,
            "baseline_score": self.baseline_score,
            "final_score": self.final_score,
            "delta": self.delta,
            "s_tier_achieved": self.s_tier_achieved,
            "improvements_applied": self.improvements_applied,
            "timestamp": self.timestamp,
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "forge.receipt.v1",
            "receipt_id": self.receipt_id,
            "artifact_path": self.artifact_path,
            "rubric_name": self.rubric_name,
            "action": self.action,
            "baseline_score": round(self.baseline_score, 4),
            "final_score": round(self.final_score, 4),
            "delta": round(self.delta, 4),
            "s_tier_achieved": self.s_tier_achieved,
            "gaps_found": self.gaps_found,
            "improvements_applied": self.improvements_applied,
            "remaining_gaps": self.remaining_gaps,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "content_hash": self.content_hash,
        }


def make_receipt(
    artifact_path: str,
    rubric_name: str,
    action: str,
    baseline_score: float,
    final_score: float,
    gaps_found: list[str],
    improvements_applied: list[str],
    remaining_gaps: list[str],
    session_id: str,
    s_tier_achieved: bool = False,
) -> ForgeReceipt:
    now = datetime.now(timezone.utc).isoformat()
    r = ForgeReceipt(
        receipt_id=f"FORGE-{uuid.uuid4().hex[:12].upper()}",
        artifact_path=artifact_path,
        rubric_name=rubric_name,
        action=action,
        baseline_score=baseline_score,
        final_score=final_score,
        delta=final_score - baseline_score,
        s_tier_achieved=s_tier_achieved,
        gaps_found=gaps_found,
        improvements_applied=improvements_applied,
        remaining_gaps=remaining_gaps,
        session_id=session_id,
        timestamp=now,
    )
    r.content_hash = r.compute_hash()
    return r


def write_receipt(receipt: ForgeReceipt, output_dir: Path) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    # Individual receipt file
    receipt_path = output_dir / f"FORGE_RECEIPT_{receipt.receipt_id}.json"
    try:
        receipt_path.write_text(json.dumps(receipt.to_dict(), indent=2))
    except OSError as e:
        raise RuntimeError(f"RECEIPT_WRITE_FAIL: {e}") from e
    # Append to chain
    chain_path = output_dir / "FORGE_RECEIPT_CHAIN.ndjson"
    try:
        with chain_path.open("a") as f:
            f.write(
                json.dumps(
                    {
                        "receipt_id": receipt.receipt_id,
                        "artifact": receipt.artifact_path,
                        "action": receipt.action,
                        "score": receipt.final_score,
                        "s_tier": receipt.s_tier_achieved,
                        "hash": receipt.content_hash,
                        "ts": receipt.timestamp,
                    }
                )
                + "\n"
            )
    except OSError as e:
        raise RuntimeError(f"RECEIPT_CHAIN_WRITE_FAIL: {e}") from e
    return receipt_path
