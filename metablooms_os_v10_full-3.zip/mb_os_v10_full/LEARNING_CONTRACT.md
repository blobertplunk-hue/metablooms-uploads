# LEARNING_CONTRACT.md
# MetaBlooms Learning Contract — How to Use the Registries
# Authority: This document defines the bidirectional learning mechanism.

---

## THE CORE AXIOMS

"Fix the class, not the instance."
One observed failure → permanently prevented class. Not just this instance.

"If it worked and is measured, do it again."
One proven pattern → reusable template. Not improvised each time.

---

## WHAT THE REGISTRIES ARE

MISTAKE_REGISTRY.json — 75+ named failure classes
  Each entry has: code (ME-XXX-NNN), name, severity, domain,
  description, detection_pattern, prevention_strategy, example.
  NOT a log of specific failures. A taxonomy of failure CLASSES.

SUCCESS_REGISTRY.json — 19+ proven patterns
  Each entry has: code (MS-XXX-NNN), name, domain,
  description, repeat_when, do_not_use_when, evidence, score, times_applied.
  NOT a collection of good outputs. A library of REUSABLE APPROACHES.

LEARNING_LEDGER.ndjson — append-only event log
  Every pre-action check and outcome recording goes here.
  Never truncated. Never overwritten.

---

## PRE-ACTION CHECK PROTOCOL

Before every significant action, consult both registries.

STEP 1 — Classify the action:
  What type is this? Choose the most specific:
  code_generation | architecture_decision | packaging_export |
  verification_check | state_update | research_gathering |
  engine_modification | bundle_build

STEP 2 — Query MISTAKE_REGISTRY for matching classes:
  Match by: domain (code/architecture/packaging/epistemic/etc.)
           AND severity (S4_CRITICAL first, then S3_HIGH)
  For each match: is this action at risk for this class?
  Example: packaging action → check ME-EXPORT-001 through ME-OS-001

STEP 3 — Query SUCCESS_REGISTRY for matching patterns:
  Match by: domain and repeat_when condition
  For each match: does my current action fit the repeat_when condition?
  If yes: use this pattern in governed_choice.

STEP 4 — Surface in BTS decision:
  known_risks: [list of ME-XXX codes that match, or "none found for this class"]
  success_patterns: [list of MS-XXX codes that match, or "none found"]

STEP 5 — Blocking check:
  If any S4_CRITICAL risk matches this action with no override: STOP.
  You must address the risk before proceeding.
  S4_CRITICAL risks are not advisory — they block.

---

## KEY MISTAKE CLASSES TO ALWAYS CHECK

For any packaging/export action:
  ME-EXPORT-003 [S4]: MISSING_BOOT_ARTIFACTS
  ME-OS-001 [S4]: EXECUTION_KERNEL_WITHOUT_GOVERNANCE_LAYER ← new
  ME-OS-002 [S4]: BOOT_CONTRACT_AS_SYSTEM_COMPLETENESS ← new
  ME-EXPORT-006 [S4]: SKELETON_SHIPPED_AS_COMPLETE
  ME-ERAC-006 [S4]: NARRATIVE_THEATER

For any code generation:
  ME-MPP-002 [S3]: AUTO_PASS_PAYLOAD
  ME-CODE-009 [S3]: LLM_CODING_OVERCONFIDENCE
  ME-ERAC-001 [S3]: CANNED_VERIFICATION_CONTENT
  ME-VERIF-001 [S4]: NO_OR_INCOMPLETE_VERIFICATION

For any architectural decision:
  ME-ARCH-007 [S4]: GHOST_ENGINE_DEPENDENCY
  ME-ARCH-010 [S4]: FRANKEN_INTEGRATION
  ME-OS-003 [S3]: TASK_SCOPING_MYOPIA ← new

For any epistemic claim:
  ME-ERAC-006 [S4]: NARRATIVE_THEATER (claiming execution without tool call)
  ME-STATE-005 [S4]: CONVERSATION_AS_STATE
  ME-ERAC-009 [S3]: AUTHORITY_ILLUSION

---

## KEY SUCCESS PATTERNS TO ALWAYS APPLY

MS-BTS-001 [governance] DELIBERATENESS_MECHANISM
  repeat_when: Before any significant action
  What to do: Write BTS decision with instinctive/governed/rejected fields

MS-ERAC-001 [epistemic] FAIL_CLOSED_OVER_IMPROVISE
  repeat_when: Always. If required input missing: stop.

MS-EXPORT-001 [packaging] GATE_BEFORE_PRESENT
  repeat_when: Every bundle build. No exceptions.

MS-SEE-001 [research] CHAT_HISTORY_BEFORE_BUILDING
  repeat_when: Before building any engine that might have prior history

MS-VERIF-001 [verification] FAIL_TO_FIX_GATE
  repeat_when: Every turn in production operation

MS-PLAN-002 [planning] MULTI_AI_ORCHESTRATION
  repeat_when: Any high-stakes architecture decision

---

## POST-ACTION RECORDING PROTOCOL

After every completed action, record the outcome:

STEP 1 — Outcome classification:
  success | partial_success | failure | blocked

STEP 2 — If failure: add or update MISTAKE_REGISTRY:
  - Is this a new failure class? → add new ME-XXX entry
  - Is this an instance of existing class? → increment times_caught
  - What was the detection pattern that caught this? → update entry

STEP 3 — If success: update SUCCESS_REGISTRY:
  - Is this a new reusable pattern? → add new MS-XXX entry
  - Is this an application of existing pattern? → increment times_applied, update score

STEP 4 — Write to LEARNING_LEDGER.ndjson:
  {
    "timestamp": "<iso8601>",
    "turn_id": "<turn_id>",
    "action_class": "<action type>",
    "module": "<engine or component>",
    "outcome": "success|failure",
    "mistake_codes_triggered": [],
    "success_patterns_applied": [],
    "new_classes_added": []
  }

---

## REGISTRY GROWTH MODEL

The registries are LIVING ARTIFACTS. They grow with the system.

This session added three new mistake classes:
  ME-OS-001: EXECUTION_KERNEL_WITHOUT_GOVERNANCE_LAYER
  ME-OS-002: BOOT_CONTRACT_AS_SYSTEM_COMPLETENESS
  ME-OS-003: TASK_SCOPING_MYOPIA

Every session where a new failure class is discovered: add it.
Every session where a pattern succeeds and is measured: record it.

The session that adds zero entries to either registry either:
  a) Was a perfect session with no new learnings (rare), or
  b) Did not complete the post-action recording protocol (common)

If (b): this is ME-STATE-001 (CONTEXT_LOSS) — fix it.

---

## MEMORY LOOP INTEGRITY CHECK

The learning loop only works if all three components are present:
  □ MISTAKE_REGISTRY.json — failure taxonomy
  □ SUCCESS_REGISTRY.json — success patterns
  □ LEARNING_LEDGER.ndjson — event log

If any is missing:
  - You have Loop 4 partially, not fully
  - Pre-action checks will return empty results
  - Known mistakes will repeat
  - Proven patterns will be abandoned
  - Add to HARDENING_BACKLOG immediately

The memory loop combined with Loop 3 (state persistence):
  SESSION_HANDOFF = what happened and what is next
  LEARNING registries = how to do it better

Together they give a stateless LLM the equivalent of episodic memory
(what happened) and procedural memory (how to do things well).
Neither substitutes for the other. Both are required.
