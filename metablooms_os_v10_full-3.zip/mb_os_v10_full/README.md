# MetaBlooms OS v10
**Governed code production: MPP → FORGE**

Every piece of code you write goes through a 19-stage governance pipeline and then an S-tier upgrade system. The system has no choice but to produce better code because it cannot pass unless it does.

---

## Quick Start

```bash
# Validate and upgrade a Python file
python run.py engines/my_engine.py --request "implements a cache with TTL expiry"

# Pipe code from stdin
cat my_code.py | python run.py --module cache_engine.py --request "TTL cache"

# From Python
from metablooms_os import run
result = run(
    request="a function that validates email addresses",
    code=open("email_validator.py").read(),
    module_name="email_validator.py",
)
print(result.improved_code)
print(f"FIR: {result.fir_composite:.3f}  FORGE: {result.forge_score:.3f}")
```

---

## What Happens to Your Code

```
YOUR CODE
    ↓
TASK_BUILDER  — assembles full MPP task from code + request
    ↓
MPP PIPELINE (19 stages)
    SEE            — evidence gathering (local.inspect mode)
    NORMALIZE      — structure extraction
    MMD            — missing middle detection
    DRS            — decision records
    CDR            — 7-pillar coding standards
    OFM            — outcome framing
    ADS            — architecture decisions + circular dep check
    UXR            — user requirements
    NUF            — non-functional requirements
    SSO            — scope outline
    RRP            — recovery plan
    IMPLEMENTATION — syntax check + hash verification
    VERIFICATION   — 7-check multi-stage gate
    TRACE_ANALYSIS — integrity gate (blocks if score < 0.80)
    ANALYSIS_EVAL  — reasoning quality gate (FAIL → FIR rejected)
    DEBUGGING      — root cause (skipped if VERIFICATION passes)
    ECL            — end condition lock (enforces 16 stages ran)
    FIR_STAGE      — fitness gate (composite < 0.60 → blocked)
    MONITOR        — health score + feedback signals
    ↓
FORGE (S-tier upgrade)
    RUBRIC_PYTHON  — 6 criteria: no sentinels, SHA-256, failure modes,
                     integration contract, CDR V1-V5, type annotations
    Auto-fixes:    hashlib import, CDR blocks, integration contract, annotations
    Backlog:       human-required gaps written to HARDENING_BACKLOG.json
    ↓
OUTPUT
    metablooms_output/
        {module_name}          ← improved code (FORGE-upgraded)
        OS_AUDIT.json          ← session audit with all scores
        forge_receipts/        ← SHA-256 anchored improvement receipts
            FORGE_RECEIPT_CHAIN.ndjson
            FORGE_REPORT_{module}.json
```

---

## Hard Rules

| Rule | Engine | Effect |
|------|--------|--------|
| ANALYSIS_EVALUATION verdict=FAIL | FIR_ENGINE | Force REJECTED regardless of score |
| TRACE integrity < 0.80 | TRACE_ANALYSIS | Pipeline blocked |
| FIR composite < 0.60 | FIR_STAGE | Pipeline blocked |
| ECL missing stages | ECL | Pipeline blocked |
| FORGE score < 0.95 | FORGE | Remaining gaps → HARDENING_BACKLOG.json |

---

## FIR Fitness Criteria (weights sum to 1.0)

| Criterion | Weight | Source |
|-----------|--------|--------|
| stage_completion_rate | 0.25 | stages ran / 19 |
| erac_clean_rate | 0.20 | stages with no error artifacts |
| verification_pass_rate | 0.20 | VERIFICATION checks passed / 7 |
| rca_quality_rate | 0.15 | DEBUGGING root_cause present |
| reasoning_quality_rate | 0.20 | ANALYSIS_EVALUATION score / 100 |

---

## FORGE S-tier Criteria

| ID | Criterion | Auto-fix |
|----|-----------|----------|
| ST-001 | No auto-pass sentinels | ✗ human |
| ST-002 | SHA-256 byte-backed artifacts | ✓ adds hashlib |
| ST-003 | Named failure modes (RuntimeError) | ✗ human |
| ST-004 | Integration contract (Inputs/Outputs/Side effects/Assumptions) | ✓ adds stub |
| ST-005 | CDR V1-V5 docstring blocks | ✓ adds stubs |
| ST-006 | Type annotations ≥ 80% public functions | ✓ adds `-> None` |

---

## Directory Layout

```
metablooms_os/
├── run.py                  ← CLI entry point
├── metablooms_os.py        ← Python API (import and call run())
├── README.md
├── engines/                ← MPP pipeline stages + infrastructure
│   ├── STAGES.py           ← 14 MPP stages
│   ├── MPP_RUNTIME.py      ← 19-stage orchestrator
│   ├── STAGE_BASE.py
│   ├── STAGE_RUNNER.py
│   ├── PIPELINE_STATE.py
│   ├── NORMALIZE_EVIDENCE.py
│   ├── POLICY_ENGINE.py
│   ├── TRACE_ANALYSIS.py
│   ├── ANALYSIS_EVALUATION.py
│   ├── ANALYSIS_EVALUATION_ENGINE.py
│   ├── FIR_ENGINE.py
│   ├── FIR_STAGE.py
│   ├── MONITOR.py
│   ├── LFIS_SCAFFOLD.py    ← Layered Forced Improvement System
│   ├── LFIS_SCORER.py
│   ├── LOCAL_SEE.py        ← local evidence generator
│   ├── TASK_BUILDER.py     ← task dict assembler
│   └── MPP_BRIDGE.py       ← LLM output → MPP task converter
├── forge/                  ← FORGE S-tier upgrade system
│   ├── FORGE.py            ← entry point: forge(artifact)
│   ├── FORGE_INTAKE.py
│   ├── FORGE_RUNNER.py
│   ├── FORGE_RECEIPT.py
│   └── rubrics/
│       ├── RUBRIC_PYTHON.py
│       ├── RUBRIC_JSON.py
│       ├── RUBRIC_LESSON.py
│       └── RUBRIC_HTML.py
└── docs/
    ├── MPP_PROTOCOL.md     ← cognitive protocol for LLM code generation
    └── MPP_SYSTEM_PROMPT.md ← drop-in ChatGPT system prompt
```

---

## Output Files

After a run, `metablooms_output/` contains:

- **`{module_name}`** — the improved code (FORGE-upgraded in-place)
- **`OS_AUDIT.json`** — session audit: MPP pass/fail, FIR score, FORGE score
- **`forge_receipts/FORGE_RECEIPT_CHAIN.ndjson`** — SHA-256 anchored improvement chain
- **`forge_receipts/FORGE_REPORT_{module}.json`** — full FORGE report
- **`forge_receipts/HARDENING_BACKLOG.json`** — gaps requiring human implementation

---

## Session IDs and SHA-256 Receipts

Every run produces a unique session ID (`MB-XXXXXXXX`) and a SHA-256 pipeline hash. The audit trail is cryptographically anchored — you can verify any improvement claim against the receipt chain.
