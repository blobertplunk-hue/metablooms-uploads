"""
MPP_RUNTIME.py — Full lifecycle pipeline (v2 — CI/CD + observability model)
============================================================================

CDR V1 (Rationale):
    v1 ended at ECL. v2 extends to full lifecycle: SEE → ... → ECL →
    TRACE_ANALYSIS → DEBUGGING → ECL → MONITOR. Modeled on CI/CD + OpenTelemetry.
    Every execution now produces health metrics, feedback signals, and FIR data.

CDR V2 (Trust):
    Stage order is hardcoded — no runtime reordering possible.
    REQUIRED_PIPELINE_STAGES patched at import to match actual 17-stage list.
    ECL checks all 15 pre-ECL stages before issuing governance verdict.

CDR V3 (Boundary):
    Inputs:  task dict (validated by individual stages, deep-copied by runner)
    Outputs: PipelineState with all 17 stage artifacts and trace spans
    Side effects: FIR_ENGINE writes COEVOLUTION_LOG.ndjson when called post-run
    Assumptions: all engine modules importable from engines/ directory on sys.path

CDR V4 (Failure):
    Any stage RuntimeError propagates unchanged — no swallowing, no wrapping.
    safe_state: caller receives RuntimeError, no partial or ambiguous result.
    Pipeline is atomic: all 17 stages complete or exception raised at first failure.

CDR V5 (S-tier):
    pipeline_hash() returns SHA-256 result_hash of completed stage names.
    Comparable to: GitLab CI pipeline, Apache Airflow DAG, Netflix Metaflow.
    Industry pattern: single orchestration entry point, stages as composable units.

Stage order (18 stages):
    1  SEE                  — evidence gathering + hash verification
    2  NORMALIZE_EVIDENCE   — ETL transform: raw receipts → structured atoms
    3  MMD                  — missing middle detection + coverage blocking
    4  DRS                  — decision records
    5  CDR                  — 7-pillar coding standards + POLICY_ENGINE
    6  OFM                  — outcome framing
    7  ADS                  — architecture decisions
    8  UXR                  — user requirements
    9  NUF                  — non-functional requirements
    10 SSO                  — scope outline
    11 RRP                  — repair and recovery plan
    12 IMPLEMENTATION       — build artifact
    13 VERIFICATION         — multi-check verification + POLICY_ENGINE
    14 TRACE_ANALYSIS       — span aggregation + anomaly detection
    15 ANALYSIS_EVALUATION  — reasoning quality gate (verdict=FAIL blocks FIR)
    16 DEBUGGING            — conditional on VERIFICATION (handled by runner)
    17 ECL                  — end condition lock (checks 16 prior stages)
    18 FIR_STAGE            — R12 fitness gate (composite_score < 0.60 blocks)
    19 MONITOR              — health score + feedback loop

Post-run: call FIREngine.evaluate_session(state) for R12 meta-reflection.
ANALYSIS_EVALUATION verdict=FAIL causes FIR to force REJECTED regardless of composite.
"""

from __future__ import annotations

import hashlib
from typing import Any

# Update ECL's required stages list to include new stages
import STAGES as _stages_module
from ANALYSIS_EVALUATION import ANALYSIS_EVALUATION
from FIR_STAGE import FIR_STAGE
from MONITOR import MONITOR
from NORMALIZE_EVIDENCE import NORMALIZE_EVIDENCE
from STAGE_RUNNER import StageRunner
from STAGES import (
    ADS,
    CDR,
    DEBUGGING,
    DRS,
    ECL,
    IMPLEMENTATION,
    MMD,
    NUF,
    OFM,
    RRP,
    SEE,
    SSO,
    UXR,
    VERIFICATION,
)
from TRACE_ANALYSIS import TRACE_ANALYSIS

_stages_module.REQUIRED_PIPELINE_STAGES = [
    "SEE",
    "NORMALIZE_EVIDENCE",
    "MMD",
    "DRS",
    "CDR",
    "OFM",
    "ADS",
    "UXR",
    "NUF",
    "SSO",
    "RRP",
    "IMPLEMENTATION",
    "VERIFICATION",
    "TRACE_ANALYSIS",
    "DEBUGGING",
]


def pipeline_hash(state: Any) -> str:
    """SHA-256 of all completed stage names — integrity verification for a run."""
    stage_names = "|".join(state.data.keys()) if hasattr(state, "data") else ""
    result_hash = hashlib.sha256(stage_names.encode()).hexdigest()
    return result_hash


def run_mpp(task: dict[str, Any]) -> Any:
    """Execute the full 17-stage MPP pipeline.

    Failure modes:
      - Empty or None task: raises RuntimeError (MPP_EMPTY_TASK)
      - Any stage failure: RuntimeError propagates from StageRunner unchanged
      safe_state: pipeline halts at first failure, no partial result returned
    """
    if not task:
        raise RuntimeError(
            "MPP_EMPTY_TASK: task dict must be non-empty. "
            "All 19 stages require at minimum: input, sie_receipts, cdr_constraints."
        )
    stages = [
        SEE(),
        NORMALIZE_EVIDENCE(),
        MMD(),
        DRS(),
        CDR(),
        OFM(),
        ADS(),
        UXR(),
        NUF(),
        SSO(),
        RRP(),
        IMPLEMENTATION(),
        VERIFICATION(),
        TRACE_ANALYSIS(),
        ANALYSIS_EVALUATION(),  # reasoning quality gate — verdict=FAIL blocks FIR
        DEBUGGING(),
        ECL(),
        FIR_STAGE(),
        MONITOR(),
    ]
    runner = StageRunner(stages)
    return runner.run(task)
