"""
SESSION_HANDOFF.py — MetaBlooms Cross-Session Knowledge Transfer Engine v1

CDR V1 (Intent): Solve the problem where knowledge built up across a multi-hour
session — decisions made, failures diagnosed, architecture understood — disappears
at session end. SESSION_HANDOFF is the per-session equivalent of STATE_LEDGER.
It is written by ECL at the end of the final turn. It is read at boot of the
next session before any objectives are accepted.

CDR V2 (Trust): Every handoff section is written from actual turn state, not
summarized from memory. The decisions_made section records what BTS decision
artifacts captured. The failures_diagnosed section records named failure modes
with root causes, not incident descriptions.

CDR V3 (Boundary): SESSION_HANDOFF writes and reads cross-session state. It
does not execute objectives, evaluate fitness, or govern the pipeline. It is
the memory substrate. StateLedger owns per-turn memory. SESSION_HANDOFF owns
per-session memory.

CDR V4 (State): SESSION_HANDOFF.json is overwritten each session (it is
current-session state). SESSION_HANDOFF_HISTORY.json is append-only (last 10
sessions). The history file is never truncated — only extended.

CDR V5 (Failure): If SESSION_HANDOFF.json cannot be written, ECL logs
HANDOFF_WRITE_FAILED to BTS and boot of the next session notes
HANDOFF_MISSING. The system degrades gracefully but the gap is named.

constraint_mapping:
  - Must NOT store raw artifact content — pointers and hashes only
  - Must NOT block ECL if write fails — ECL completes, failure is logged
  - Must NOT overwrite SESSION_HANDOFF_HISTORY.json — append only

integration_reciprocity:
  Inputs:  turn_state (StateLedger), prior handoff (prior session JSON)
  Outputs: state/SESSION_HANDOFF.json, state/SESSION_HANDOFF_HISTORY.json
  Side effects: reads prior handoff on init, writes both files at ECL
  Promises: next session boot can read prior_session_id, open_gaps, next_actions
  Callers: MetaBloomsOS.run_turn() at ECL, MetaBloomsOS.boot() at session start

legacy_impact_statement:
  Replaces the implicit session memory where GPT would "remember" prior work
  through context window. That approach fails at context limit and across
  sessions. SESSION_HANDOFF makes cross-session continuity explicit,
  file-backed, and auditable.

ChatGPT behavioral contract:
  At ECL: write SESSION_HANDOFF.json with all seven sections populated.
  At boot: read SESSION_HANDOFF.json before accepting any objectives.
  If prior handoff has open_gaps: surface them in boot report.
  If prior handoff has next_actions: use next_actions[0] as default objective.
  NEVER skip handoff write. NEVER skip handoff read.
"""

from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = ["BTS", "STATE_LEDGER"]
REQUIRES_HASH = "301111426c8121594f3d3fcfad999161d1677b6f9854521e14e7be0dfaee1d29"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import json
import hashlib
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


SCHEMA = "mb.session_handoff.v1"
HANDOFF_REL = Path("state/SESSION_HANDOFF.json")
HANDOFF_HISTORY_REL = Path("state/SESSION_HANDOFF_HISTORY.json")
MAX_HISTORY = 10  # keep last 10 session handoffs in history


class SessionHandoff:
    """
    Cross-session knowledge transfer engine.

    Write at end of session (ECL):
        handoff = SessionHandoff(runtime_root)
        record = handoff.write({
            "architectural_knowledge": [...],
            "decisions_made": [...],
            "failures_diagnosed": [...],
            "open_gaps": [...],
            "next_actions": [...],
            "transferable_knowledge": [...],
        })

    Read at start of next session (boot):
        handoff = SessionHandoff(runtime_root)
        content = handoff.read()
        if content:
            # internalize sections 2-7
            pass

    ChatGPT contract:
        On boot, if SESSION_HANDOFF.json exists, read it fully before
        accepting any objective. Treat sections 2-4 as known context.
        Treat section 5 as your open work queue.
        Treat section 6 as your first candidate objective.
    """

    def __init__(self, runtime_root: str | Path = ".") -> None:
        self.root = Path(runtime_root)
        self._path = self.root / HANDOFF_REL
        self._history_path = self.root / HANDOFF_HISTORY_REL
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def write(self, content: Dict[str, Any],
              session_id: Optional[str] = None,
              turn_count: int = 0,
              bundle_version: str = "v6.3") -> Dict[str, Any]:
        """
        Write session handoff. Call at ECL of the final turn.

        content must include at least one of the seven sections.
        Missing sections are written as empty lists with a note.

        Returns the written handoff dict.
        """
        sid = session_id or f"SESSION-{uuid.uuid4().hex[:8].upper()}"

        handoff = {
            "schema": SCHEMA,
            "session_id": sid,
            "written_at": self._now(),
            "bundle_version": bundle_version,
            "turn_count": turn_count,

            # Section 1: identity (auto-populated)
            "session_identity": {
                "session_id": sid,
                "runtime_root": str(self.root),
                "bundle_version": bundle_version,
                "turn_count": turn_count,
                "written_at": self._now(),
            },

            # Sections 2-7: operator-supplied content
            "architectural_knowledge": content.get("architectural_knowledge", []),
            "decisions_made": content.get("decisions_made", []),
            "failures_diagnosed": content.get("failures_diagnosed", []),
            "open_gaps": content.get("open_gaps", []),
            "next_actions": content.get("next_actions", []),
            "transferable_knowledge": content.get("transferable_knowledge", []),
        }

        # SHA256 for integrity
        canonical = json.dumps(handoff, sort_keys=True).encode()
        handoff["sha256"] = hashlib.sha256(canonical).hexdigest()

        # Write current
        self._path.write_text(json.dumps(handoff, indent=2), encoding="utf-8")

        # Append to history
        self._append_history(handoff)

        return handoff

    def read(self) -> Optional[Dict[str, Any]]:
        """Read current session handoff. Returns None if no handoff exists."""
        if not self._path.exists():
            return None
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def _append_history(self, handoff: Dict[str, Any]) -> None:
        history = []
        if self._history_path.exists():
            try:
                data = json.loads(self._history_path.read_text(encoding="utf-8"))
                history = data.get("sessions", [])
            except Exception:
                history = []

        # Store summary in history, not full content
        summary = {
            "session_id": handoff["session_id"],
            "written_at": handoff["written_at"],
            "bundle_version": handoff["bundle_version"],
            "turn_count": handoff["turn_count"],
            "open_gaps_count": len(handoff.get("open_gaps", [])),
            "next_actions_count": len(handoff.get("next_actions", [])),
            "sha256": handoff["sha256"],
        }
        history.append(summary)
        if len(history) > MAX_HISTORY:
            history = history[-MAX_HISTORY:]

        out = {
            "schema": "mb.session_handoff_history.v1",
            "updated_at": self._now(),
            "session_count": len(history),
            "sessions": history,
        }
        self._history_path.write_text(json.dumps(out, indent=2), encoding="utf-8")

    def summary(self) -> Dict[str, Any]:
        """Quick summary of current handoff state."""
        current = self.read()
        history = []
        if self._history_path.exists():
            try:
                data = json.loads(self._history_path.read_text(encoding="utf-8"))
                history = data.get("sessions", [])
            except Exception:
                pass
        return {
            "current_session_id": current.get("session_id") if current else None,
            "current_written_at": current.get("written_at") if current else None,
            "open_gaps": len(current.get("open_gaps", [])) if current else 0,
            "next_actions": len(current.get("next_actions", [])) if current else 0,
            "session_history_count": len(history),
        }
