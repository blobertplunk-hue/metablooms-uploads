"""
BTS.py — MetaBlooms Behind The Scenes v3 (Canonical Merged)
Cross-Platform: Claude Python execution + ChatGPT behavioral governance

WHAT BTS IS

BTS is not a logger.
BTS is a reasoning reconstruction substrate. Everything a future analyst needs
to reconstruct WHY a decision was made, without the chain of thought itself.

THE DELIBERATENESS EFFECT:
  Having to log the decision changes the decision.
  The BTS logging requirement IS the governance mechanism — not the log itself.
  Before executing, the model must produce: instinctive choice, governed choice,
  rejected alternatives, gates. That production forces deliberate reasoning.
  The log is a side effect. The deliberateness is the product.

CDR CONTRACTS (binding, auditable):
  CDR V1 (Intent):   Every function named for what it proves, not what it does.
  CDR V2 (Trust):    No T1 receipt without actual OS-level output.
  CDR V3 (Boundary): BTS does NOT execute business logic. Records proof only.
  CDR V4 (State):    Append-only. Nothing ever overwritten.
  CDR V5 (Failure):  If proof cannot be produced, raise. Never return degraded receipt.
  CDR V6 (Decision): No significant action without prior BTS decision artifact on disk.

RECEIPT TIERS:
  T1: Real execution proof. sha256sum ran. subprocess output captured. Cannot be faked.
  T2: Hash-chained to prior T1. Hard to fabricate retroactively.
  T3: Advisory only. NEVER gates a phase. Explicitly labeled.
  MISSING: Evidence requested but not obtained. Never silently dropped.

TOOL TRACKING PIPELINE (enforced order):
  BTS_TOOL_INTENT → BTS_TOOL_EVALUATION → BTS_TOOL_SELECTION
  → [BTS_TOOL_SWITCH] → BTS_TOOL_EXECUTION → BTS_TOOL_RESULT → BTS_COMMIT

BTS_TOOL_SWITCH reason codes (required):
  CAPABILITY_MISMATCH | EXECUTION_FAILURE | PERFORMANCE_INADEQUATE
  | OUTPUT_INVALID | RESOURCE_CONSTRAINT

CHATGPT BEHAVIORAL CONTRACT:
  Before any significant action:
    1. Emit BTS_DECISION: instinctive, governed, rejected, gates, confidence
    2. Run tool tracking pipeline: INTENT → ... → COMMIT
    3. If switching mid-turn: BTS_TOOL_SWITCH with reason code
  HARD RULE: No BTS_COMMIT on prior turn = next turn cannot start.
  HARD RULE: BTS write failure raises — never silently drops.
  HARD RULE: T3 alone cannot gate any blocking phase.
"""

from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = ["LEARNING_ENGINE", "SEE"]
REQUIRES_HASH = "325f17ed9e5bd44560311f3c742e4aaf3fe362ed70fdd00679003dd7c4c33df0"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import hashlib
import json
import subprocess
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── Constants ─────────────────────────────────────────────────────────────────

# Soft import LEARNING_ENGINE — BTS works without it
try:
    import os as _os, sys as _sys
    _here = _os.path.dirname(_os.path.abspath(__file__))
    if _here not in _sys.path:
        _sys.path.insert(0, _here)
    from LEARNING_ENGINE import LearningEngine
    _LEARNING_AVAILABLE = True
except ImportError:
    LearningEngine = None
    _LEARNING_AVAILABLE = False

SCHEMA        = "mb.bts.v3"
RECEIPTS_REL  = Path("_bts/receipts")
LOG_REL       = Path("bts/bts_log.ndjson")
TRACKING_REL  = Path("_bts/tool_tracking")
MANIFESTS_REL = Path("_bts/manifests")
AUDIT_REL     = Path("_audit/tool_competence.json")

REQUIRED_TOOL_ORDER = [
    "BTS_TOOL_INTENT", "BTS_TOOL_EVALUATION", "BTS_TOOL_SELECTION",
    "BTS_TOOL_EXECUTION", "BTS_TOOL_RESULT", "BTS_COMMIT",
]

SWITCH_REASON_CODES = {
    "CAPABILITY_MISMATCH", "EXECUTION_FAILURE", "PERFORMANCE_INADEQUATE",
    "OUTPUT_INVALID", "RESOURCE_CONSTRAINT",
}


# ── Utilities ─────────────────────────────────────────────────────────────────

def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def _compact() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

def _hash_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def _hash_file(p: Path) -> str:
    if not p.exists():
        raise FileNotFoundError(f"BTS: cannot hash missing file: {p}")
    return _hash_bytes(p.read_bytes())

def _receipt_id() -> str:
    return f"RCP-{uuid.uuid4().hex[:8].upper()}"


# ── Decision artifact ─────────────────────────────────────────────────────────

@dataclass
class BTSDecision:
    """
    The core deliberateness artifact. Produced BEFORE any significant action.
    The production of this artifact IS the governance intervention.
    instinctive_choice: what the model would do without governance
    governed_choice:    what rules and evidence require
    rejected_choices:   alternatives considered and WHY rejected
    """
    task_class: str
    objective: str
    instinctive_choice: str
    governed_choice: str
    rejected_choices: List[str]
    reasoning_summary: str
    gates: List[Dict[str, Any]]
    confidence: float
    evidence_available: List[str] = field(default_factory=list)
    revision_count: int = 0
    stage: str = ""
    decision_id: str = field(default_factory=lambda: f"DEC-{uuid.uuid4().hex[:8].upper()}")
    created_utc: str = field(default_factory=_now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema": SCHEMA, "artifact_type": "bts_decision",
            "decision_id": self.decision_id, "created_utc": self.created_utc,
            "task_class": self.task_class, "objective": self.objective,
            "stage": self.stage, "revision_count": self.revision_count,
            "instinctive_choice": self.instinctive_choice,
            "governed_choice": self.governed_choice,
            "rejected_choices": self.rejected_choices,
            "reasoning_summary": self.reasoning_summary,
            "gates": self.gates, "confidence": self.confidence,
            "evidence_available": self.evidence_available,
        }


# ── Turn tracker ──────────────────────────────────────────────────────────────

class TurnTracker:
    """
    Enforces BTS tool pipeline within a single turn.
    Events must arrive in required order.
    Switching allowed but mandatory reason code required.
    Commit required before next turn starts.
    """

    def __init__(self, root: Path, turn_id: str) -> None:
        self.root = root
        self.turn_id = turn_id
        self._dir = root / TRACKING_REL
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path = self._dir / f"turn_{turn_id}.jsonl"
        self._events: List[Dict[str, Any]] = []
        self._selected_tool: Optional[str] = None
        self._executed_tool: Optional[str] = None
        self._committed = False

    def _emit(self, event: Dict[str, Any]) -> None:
        event.update({"ts_utc": _now(), "turn_id": self.turn_id,
                      "seq": len(self._events)})
        event["hash"] = _hash_bytes(json.dumps(event, sort_keys=True).encode())
        self._events.append(event)
        try:
            with self._path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(event) + "\n")
        except Exception as e:
            raise RuntimeError(f"BTS TurnTracker write failed: {e}") from e

    def emit_intent(self, intent: str, objective: str = "", stage: str = "") -> None:
        self._emit({"event": "BTS_TOOL_INTENT", "intent": intent,
                    "objective": objective, "stage": stage})

    def emit_evaluation(self, candidates: List[Dict[str, Any]]) -> None:
        """At least one REJECTED required when multiple candidates exist."""
        if len(candidates) > 1 and not any(c.get("verdict") == "REJECTED" for c in candidates):
            raise ValueError(
                "BTS: EVALUATION must reject at least one candidate when "
                "multiple exist. Evaluation without rejection is rationalization, not deliberation."
            )
        self._emit({"event": "BTS_TOOL_EVALUATION", "candidates": candidates,
                    "candidate_count": len(candidates)})

    def emit_selection(self, tool: str, rationale: str) -> None:
        self._selected_tool = tool
        self._emit({"event": "BTS_TOOL_SELECTION", "tool": tool, "rationale": rationale})

    def emit_switch(self, from_tool: str, to_tool: str,
                    reason_code: str, detail: str = "") -> None:
        """Optional mid-turn correction. Normalizes course correction — documented, not hidden."""
        if reason_code not in SWITCH_REASON_CODES:
            raise ValueError(f"BTS_TOOL_SWITCH: reason_code must be one of {SWITCH_REASON_CODES}")
        self._selected_tool = to_tool
        self._emit({"event": "BTS_TOOL_SWITCH", "from_tool": from_tool, "to_tool": to_tool,
                    "reason_code": reason_code, "detail": detail})

    def emit_execution(self, tool: str, cmd: Any = None,
                       op_span_start: Optional[str] = None) -> None:
        self._executed_tool = tool
        if self._selected_tool and tool != self._selected_tool:
            raise RuntimeError(
                f"BTS: executed '{tool}' but selected '{self._selected_tool}' "
                f"without BTS_TOOL_SWITCH. Protocol violation."
            )
        self._emit({"event": "BTS_TOOL_EXECUTION", "tool": tool,
                    "cmd": str(cmd) if cmd else None,
                    "op_span_start": op_span_start or _now()})

    def emit_result(self, tool: str, status: str, intent_satisfied: bool,
                    correctness_score: float = 1.0, output_summary: str = "",
                    op_span_end: Optional[str] = None,
                    extra: Optional[Dict] = None) -> None:
        self._emit({"event": "BTS_TOOL_RESULT", "tool": tool, "status": status,
                    "intent_satisfied": intent_satisfied,
                    "correctness_score": correctness_score,
                    "output_summary": output_summary[:500],
                    "op_span_end": op_span_end or _now(), **(extra or {})})

    def commit(self) -> Dict[str, Any]:
        """Finalize turn. Enforces event order. Raises on violation."""
        kinds = [e["event"] for e in self._events]
        kinds_no_switch = [k for k in kinds if k != "BTS_TOOL_SWITCH"]
        expected = [e for e in REQUIRED_TOOL_ORDER if e != "BTS_COMMIT"]
        if kinds_no_switch != expected:
            raise RuntimeError(
                f"BTS: turn event order invalid.\n"
                f"  Required: {expected}\n"
                f"  Got:      {kinds_no_switch}"
            )
        result = {"event": "BTS_COMMIT", "tool_events_count": len(self._events),
                  "selected_tool": self._selected_tool,
                  "executed_tool": self._executed_tool, "integrity": "OK"}
        self._emit(result)
        self._committed = True
        return result

    @property
    def is_committed(self) -> bool:
        return self._committed


# ── BTS class ─────────────────────────────────────────────────────────────────

class BTS:
    """
    Behind The Scenes v3 — reasoning reconstruction substrate.
    Manages: turn lifecycle, decision artifacts, receipt production,
    append-only log, tool tracking, competence audit, turn manifests.
    """

    def __init__(self, runtime_root: str | Path = ".") -> None:
        self.root = Path(runtime_root)
        self._receipts      = self.root / RECEIPTS_REL
        self._log           = self.root / LOG_REL
        self._manifests     = self.root / MANIFESTS_REL
        self._decisions_dir = self.root / "_bts" / "decisions"
        for d in [self._receipts, self._log.parent, self._manifests,
                  self._decisions_dir, self.root / TRACKING_REL]:
            d.mkdir(parents=True, exist_ok=True)
        self._turn_receipts: Dict[str, List[str]] = {}
        # Learning engine — enriches decisions with known risks and success patterns
        self._learning: Optional[Any] = (
            LearningEngine(runtime_root) if LearningEngine else None
        )

    def _log_entry(self, event: Dict[str, Any]) -> None:
        entry = {**event, "ts_utc": _now()}
        try:
            with self._log.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            raise RuntimeError(f"BTS: log write failed: {e}") from e

    def _write_receipt(self, receipt: Dict[str, Any], label: str) -> Path:
        path = self._receipts / f"{label}_{_compact()}.json"
        path.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
        return path

    def _register_receipt(self, turn_id: str, path: str) -> None:
        self._turn_receipts.setdefault(turn_id, []).append(path)

    # ── Turn lifecycle ────────────────────────────────────────────────────────

    def turn_start(self, turn_id: str, objective: str) -> None:
        self._turn_receipts[turn_id] = []
        self._log_entry({"event": "TURN_START", "turn_id": turn_id, "objective": objective})
        # TRACE_SPAN — side-effect safe, failure-tolerant (COEV-019)
        try:
            import sys as _s, os as _o
            _utils = _o.path.join(_o.path.dirname(__file__), "utils")
            if _utils not in _s.path: _s.path.insert(0, _utils)
            from TRACE_SPAN_EMITTER import get_emitter
            _e = get_emitter(self.root)
            _sid = _e.start("BTS", turn_id=turn_id)
            # Store span_id keyed by turn for turn_end to close
            if not hasattr(self, "_span_ids"): self._span_ids = {}
            self._span_ids[turn_id] = (_e, _sid)
        except Exception:
            pass

    def turn_end(self, turn_id: str) -> Dict[str, Any]:
        receipts = self._turn_receipts.get(turn_id, [])
        receipt_hashes = {rp: _hash_file(Path(rp))
                         for rp in receipts if Path(rp).exists()}
        manifest = {
            "schema": SCHEMA, "artifact_type": "turn_manifest",
            "turn_id": turn_id, "ts_utc": _now(),
            "receipt_count": len(receipts),
            "receipt_hashes": receipt_hashes,
            "chain_hash": _hash_bytes(json.dumps(receipt_hashes, sort_keys=True).encode()),
        }
        mpath = self._manifests / f"TURN_MANIFEST_{turn_id}_{_compact()}.json"
        mpath.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
        manifest["manifest_path"] = str(mpath)
        self._log_entry({"event": "TURN_END", "turn_id": turn_id,
                         "receipt_count": len(receipts), "manifest_path": str(mpath)})
        # Close BTS span for this turn (COEV-019)
        try:
            if hasattr(self, "_span_ids") and turn_id in self._span_ids:
                _e, _sid = self._span_ids.pop(turn_id)
                _e.end(_sid, success=True, metadata={
                    "turn_id": turn_id,
                    "receipt_count": len(receipts),
                })
        except Exception:
            pass
        return manifest

    def boot_receipt(self, boot_id: str, files_to_check: List[str]) -> Dict[str, Any]:
        verified = [f for f in files_to_check if (self.root / f).exists()]
        missing  = [f for f in files_to_check if f not in verified]
        status   = "BOOT_OK" if not missing else "BOOT_INCOMPLETE"
        receipt  = {
            "schema": SCHEMA, "tier": "T1", "artifact_type": "boot_receipt",
            "boot_id": boot_id, "ts_utc": _now(), "status": status,
            "verified_count": len(verified), "missing_count": len(missing),
            "verified": verified, "missing": missing,
        }
        path = self._write_receipt(receipt, f"BOOT_{boot_id}")
        receipt.update({"receipt_path": str(path), "receipt_sha256": _hash_file(path)})
        self._log_entry({"event": "BOOT_RECEIPT", "boot_id": boot_id,
                         "status": status, "missing": missing})
        return receipt

    # ── Decision (the deliberateness mechanism) ───────────────────────────────

    def decide(self, task_class: str, objective: str,
               instinctive_choice: str, governed_choice: str,
               rejected_choices: List[str], reasoning_summary: str,
               gates: List[Dict[str, Any]], confidence: float,
               stage: str = "", revision_count: int = 0,
               evidence_available: Optional[List[str]] = None,
               turn_id: str = "") -> BTSDecision:
        """
        Produce BTS decision artifact BEFORE any significant action.
        CDR V6: claiming you thought about it is not evidence. The artifact is.
        """
        # Pre-action learning check — surface known risks before committing to decision
        learning_result = None
        if self._learning:
            try:
                learning_result = self._learning.pre_action_check(
                    action_class=task_class,
                    module=stage or "BTS",
                    context={"objective": objective, "stage": stage},
                )
                # S4_CRITICAL risk: inject into reasoning_summary as warning
                if learning_result.should_block:
                    risk_names = [r.name for r in learning_result.known_risks if r.severity == "S4_CRITICAL"]
                    reasoning_summary = (
                        f"[LEARNING WARNING — S4 KNOWN RISKS: {risk_names}] "
                        + reasoning_summary
                    )
                # Add known risks to evidence_available
                if learning_result.known_risks:
                    evidence_available = (evidence_available or []) + [
                        f"KNOWN_RISK:{r.mistake_id}:{r.name}"
                        for r in learning_result.known_risks[:3]
                    ]
                # Add top success pattern to governed_choice hint
                if learning_result.success_patterns:
                    top = learning_result.success_patterns[0]
                    governed_choice = governed_choice + f" [SUCCESS_PATTERN:{top.pattern_id}:{top.name}]"
            except Exception:
                pass  # Learning failure never blocks decision

        decision = BTSDecision(
            task_class=task_class, objective=objective,
            instinctive_choice=instinctive_choice, governed_choice=governed_choice,
            rejected_choices=rejected_choices, reasoning_summary=reasoning_summary,
            gates=gates, confidence=confidence, stage=stage,
            revision_count=revision_count, evidence_available=evidence_available or [],
        )
        path = self._decisions_dir / f"{decision.decision_id}_{_compact()}.json"
        path.write_text(json.dumps(decision.to_dict(), indent=2), encoding="utf-8")
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({
            "event": "BTS_DECISION", "decision_id": decision.decision_id,
            "task_class": task_class, "stage": stage,
            "governed_choice": governed_choice, "confidence": confidence,
            "rejected_count": len(rejected_choices), "path": str(path),
        })
        return decision

    # ── Tool tracking ─────────────────────────────────────────────────────────

    def start_turn_tracker(self, turn_id: str) -> TurnTracker:
        return TurnTracker(self.root, turn_id)

    # ── Receipt production ────────────────────────────────────────────────────

    def t1_file(self, stage: str, artifact_path: Path,
                turn_id: str = "", extra: Optional[Dict] = None) -> Dict[str, Any]:
        """T1 receipt for file. All three checks must pass or raises. CDR V5."""
        p = Path(artifact_path)
        if not p.exists():
            raise FileNotFoundError(f"BTS T1: artifact not found: {p}")
        stat = p.stat()
        if stat.st_size == 0:
            raise ValueError(f"BTS T1: artifact is empty (0 bytes): {p}")
        receipt = {
            "schema": SCHEMA, "tier": "T1", "receipt_id": _receipt_id(),
            "artifact_type": "file_receipt", "stage": stage, "ts_utc": _now(),
            "artifact": str(p), "sha256": _hash_file(p), "bytes": stat.st_size,
            **(extra or {}),
        }
        path = self._write_receipt(receipt, f"T1_FILE_{stage}")
        receipt.update({"receipt_path": str(path), "receipt_sha256": _hash_file(path)})
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({"event": "T1_FILE_RECEIPT", "stage": stage,
                         "artifact": str(p), "sha256": receipt["sha256"],
                         "receipt_id": receipt["receipt_id"]})
        return receipt

    def t1_subprocess(self, stage: str, cmd: List[str],
                      turn_id: str = "", expected_rc: int = 0,
                      extra: Optional[Dict] = None) -> Dict[str, Any]:
        """
        T1 receipt by running real subprocess. stdout IS the proof.
        CDR V2: T1 only when actual execution occurs.
        CDR V5: raises if rc != expected_rc.
        """
        t0 = time.monotonic()
        result = subprocess.run(cmd, capture_output=True, text=True)
        duration_ms = (time.monotonic() - t0) * 1000
        if result.returncode != expected_rc:
            raise RuntimeError(
                f"BTS T1 subprocess [{stage}]: cmd={cmd} "
                f"rc={result.returncode} expected={expected_rc}\n"
                f"stderr: {result.stderr.strip()[:400]}"
            )
        receipt = {
            "schema": SCHEMA, "tier": "T1", "receipt_id": _receipt_id(),
            "artifact_type": "subprocess_receipt", "stage": stage, "ts_utc": _now(),
            "cmd": cmd, "rc": result.returncode,
            "stdout_sha256": _hash_bytes(result.stdout.encode()),
            "stdout_sample": result.stdout.strip()[:500],
            "stderr_sample": result.stderr.strip()[:200] if result.stderr else None,
            "duration_ms": round(duration_ms, 1), **(extra or {}),
        }
        path = self._write_receipt(receipt, f"T1_SUBPROCESS_{stage}")
        receipt.update({"receipt_path": str(path), "receipt_sha256": _hash_file(path)})
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({"event": "T1_SUBPROCESS_RECEIPT", "stage": stage,
                         "cmd": cmd, "rc": result.returncode,
                         "stdout_sha256": receipt["stdout_sha256"],
                         "receipt_id": receipt["receipt_id"]})
        return receipt

    def t2_chained(self, stage: str, prior_receipt: Dict[str, Any],
                   summary: str, turn_id: str = "",
                   extra: Optional[Dict] = None) -> Dict[str, Any]:
        """T2 chained to prior receipt via sha256. CDR V5: raises if no prior hash."""
        prior_hash = prior_receipt.get("receipt_sha256") or prior_receipt.get("sha256")
        if not prior_hash:
            raise ValueError(f"BTS T2 [{stage}]: prior_receipt has no hash to chain from")
        receipt = {
            "schema": SCHEMA, "tier": "T2", "receipt_id": _receipt_id(),
            "artifact_type": "chained_receipt", "stage": stage, "ts_utc": _now(),
            "prior_receipt_sha256": prior_hash,
            "prior_stage": prior_receipt.get("stage"), "summary": summary,
            **(extra or {}),
        }
        path = self._write_receipt(receipt, f"T2_{stage}")
        receipt.update({"receipt_path": str(path), "receipt_sha256": _hash_file(path)})
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({"event": "T2_CHAINED_RECEIPT", "stage": stage,
                         "chained_from": prior_receipt.get("stage"),
                         "receipt_id": receipt["receipt_id"]})
        return receipt

    def t3_advisory(self, stage: str, summary: str,
                    turn_id: str = "",
                    extra: Optional[Dict] = None) -> Dict[str, Any]:
        """T3 advisory. ADVISORY ONLY — cannot gate any blocking phase."""
        receipt = {
            "schema": SCHEMA, "tier": "T3", "receipt_id": _receipt_id(),
            "artifact_type": "advisory_receipt",
            "WARNING": "ADVISORY_ONLY — this receipt cannot satisfy a blocking gate",
            "stage": stage, "ts_utc": _now(), "summary": summary, **(extra or {}),
        }
        path = self._write_receipt(receipt, f"T3_ADVISORY_{stage}")
        receipt["receipt_path"] = str(path)
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({"event": "T3_ADVISORY_RECEIPT", "stage": stage,
                         "WARNING": "T3_ADVISORY — not gating",
                         "receipt_id": receipt["receipt_id"]})
        return receipt

    def t_missing(self, stage: str, source: str, reason: str,
                  turn_id: str = "") -> Dict[str, Any]:
        """MISSING receipt — never silently drop missing evidence."""
        receipt = {
            "schema": SCHEMA, "tier": "MISSING", "receipt_id": _receipt_id(),
            "artifact_type": "missing_receipt",
            "WARNING": "EVIDENCE_MISSING — source could not be fetched",
            "stage": stage, "ts_utc": _now(), "source": source, "reason": reason,
        }
        path = self._write_receipt(receipt, f"MISSING_{stage}")
        receipt["receipt_path"] = str(path)
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({"event": "T_MISSING_RECEIPT", "stage": stage,
                         "source": source, "reason": reason,
                         "receipt_id": receipt["receipt_id"]})
        return receipt

    # ── Tier enforcement ──────────────────────────────────────────────────────

    def check_tier_satisfied(self, receipt_path: str, required_tier: str,
                             label: str = "") -> Dict[str, Any]:
        """
        Verify receipt meets minimum tier. T1 > T2 > T3.
        Use at phase gates to enforce evidence quality.
        """
        tier_rank = {"T1": 3, "T2": 2, "T3": 1, "MISSING": 0}
        name = label or receipt_path
        p = Path(receipt_path)
        if not p.exists():
            return {"passed": False, "message": f"RECEIPT_MISSING: {name}"}
        try:
            receipt = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            return {"passed": False, "message": f"RECEIPT_PARSE_ERROR: {name}: {e}"}
        actual = receipt.get("tier", "T3")
        if tier_rank.get(actual, 0) < tier_rank.get(required_tier, 1):
            return {"passed": False, "actual_tier": actual, "required_tier": required_tier,
                    "message": f"TIER_INSUFFICIENT: {name} is {actual}, requires >= {required_tier}"}
        return {"passed": True, "actual_tier": actual, "required_tier": required_tier,
                "message": f"OK: {name} tier={actual} >= {required_tier}"}

    # ── MPP cycle receipt ─────────────────────────────────────────────────────

    def mpp_cycle_receipt(self, cycle_dict: Dict[str, Any],
                          turn_id: str = "") -> Dict[str, Any]:
        receipt = {
            "schema": SCHEMA, "tier": "T2", "receipt_id": _receipt_id(),
            "artifact_type": "mpp_cycle_receipt", "ts_utc": _now(),
            "cycle_id": cycle_dict.get("cycle_id"),
            "status": cycle_dict.get("status"),
            "pipeline_complete": cycle_dict.get("pipeline_complete", False),
            "completed_stages": cycle_dict.get("completed_stages", []),
            "failed_stages": cycle_dict.get("failed_stages", []),
        }
        path = self._write_receipt(receipt, f"MPP_CYCLE_{cycle_dict.get('cycle_id','UNKNOWN')}")
        receipt.update({"receipt_path": str(path), "receipt_sha256": _hash_file(path)})
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({"event": "MPP_CYCLE_RECEIPT", **receipt})
        return receipt

    # ── Competence audit ──────────────────────────────────────────────────────

    def run_competence_audit(self, min_score: float = 0.6) -> Dict[str, Any]:
        """
        Cross-turn tool competence audit.
        Score = 1.0 - switches*0.2 - failures*0.5 - intent_mismatches*0.3
        Tools below min_score flagged FAIL.
        """
        from collections import defaultdict
        tracking_dir = self.root / TRACKING_REL
        stats: Dict[str, Dict] = defaultdict(
            lambda: {"uses": 0, "switches": 0, "failures": 0, "intent_mismatches": 0}
        )
        for jsonl_path in sorted(tracking_dir.glob("turn_*.jsonl")):
            try:
                events = [json.loads(l) for l in jsonl_path.read_text().splitlines() if l.strip()]
            except Exception:
                continue
            selected = None
            for e in events:
                evt = e.get("event")
                if evt == "BTS_TOOL_SELECTION":
                    selected = e.get("tool")
                    if selected:
                        stats[selected]["uses"] += 1
                elif evt == "BTS_TOOL_SWITCH":
                    ft = e.get("from_tool")
                    if ft:
                        stats[ft]["switches"] += 1
                    selected = e.get("to_tool")
                elif evt == "BTS_TOOL_RESULT":
                    tool = e.get("tool")
                    if tool:
                        if e.get("status") == "failure":
                            stats[tool]["failures"] += 1
                        if not e.get("intent_satisfied", True):
                            stats[tool]["intent_mismatches"] += 1

        results = {}
        for tool, s in stats.items():
            score = max(0.0, 1.0 - s["switches"]*0.2 - s["failures"]*0.5 - s["intent_mismatches"]*0.3)
            results[tool] = {**s, "score": round(score, 3),
                             "status": "PASS" if score >= min_score else "FAIL",
                             "min_score": min_score}

        audit = {
            "schema": SCHEMA, "artifact_type": "tool_competence_audit", "ts_utc": _now(),
            "tool_count": len(results),
            "failing_tools": [t for t, r in results.items() if r["status"] == "FAIL"],
            "results": results,
        }
        audit_path = self.root / AUDIT_REL
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        audit_path.write_text(json.dumps(audit, indent=2), encoding="utf-8")
        self._log_entry({"event": "COMPETENCE_AUDIT", "failing": audit["failing_tools"]})
        return audit

    # ── Introspection ─────────────────────────────────────────────────────────

    def last_n_entries(self, n: int = 10) -> List[Dict[str, Any]]:
        if not self._log.exists():
            return []
        try:
            lines = self._log.read_text(encoding="utf-8").splitlines()
            return [json.loads(l) for l in lines[-n:] if l.strip()]
        except Exception:
            return []


    def stage_entry(self, turn_id: str, stage: str) -> None:
        """Log stage entry. Thin wrapper kept for OS kernel compatibility."""
        self._log_entry({"event": "STAGE_ENTRY", "turn_id": turn_id, "stage": stage})

    def stage_exit(self, turn_id: str, stage: str,
                   verdict: str = "", receipt_ids: Optional[List[str]] = None) -> None:
        """Log stage exit. Thin wrapper kept for OS kernel compatibility."""
        self._log_entry({"event": "STAGE_EXIT", "turn_id": turn_id, "stage": stage,
                         "verdict": verdict, "receipt_ids": receipt_ids or []})

    def t1_execution(self, stage: str, summary: str,
                     turn_id: str = "",
                     extra: Optional[Dict] = None) -> Dict[str, Any]:
        """
        T1 execution receipt for code interpreter output.
        Used when actual execution occurred but no subprocess is available.
        summary should be the actual output text, not a description.
        """
        receipt = {
            "schema": SCHEMA, "tier": "T1", "receipt_id": _receipt_id(),
            "artifact_type": "execution_receipt",
            "stage": stage, "ts_utc": _now(),
            "output_sha256": _hash_bytes(summary.encode()),
            "output_sample": summary[:500],
            **(extra or {}),
        }
        path = self._write_receipt(receipt, f"T1_EXEC_{stage}")
        receipt.update({"receipt_path": str(path), "receipt_sha256": _hash_file(path)})
        if turn_id:
            self._register_receipt(turn_id, str(path))
        self._log_entry({"event": "T1_EXECUTION_RECEIPT", "stage": stage,
                         "output_sha256": receipt["output_sha256"],
                         "receipt_id": receipt["receipt_id"]})
        return receipt

    def summary(self) -> Dict[str, Any]:
        entries = self.last_n_entries(1000)
        receipts = list(self._receipts.glob("*.json"))
        t1 = sum(1 for e in entries if e.get("event") in
                 ("T1_FILE_RECEIPT", "T1_SUBPROCESS_RECEIPT", "BOOT_RECEIPT"))
        t2 = sum(1 for e in entries if e.get("event") == "T2_CHAINED_RECEIPT")
        t3 = sum(1 for e in entries if e.get("event") == "T3_ADVISORY_RECEIPT")
        return {"log_entries": len(entries), "receipts_on_disk": len(receipts),
                "t1_entries": t1, "t2_entries": t2, "t3_entries": t3,
                "log_path": str(self._log), "receipts_path": str(self._receipts)}


# ── Self-test ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, tempfile
    print("BTS v3 self-test...")
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        bts = BTS(root)

        bts.turn_start("TURN-001", "Test BTS v3")
        print("  Turn start ✓")

        decision = bts.decide(
            task_class="system_mutation", objective="Write BTS v3",
            instinctive_choice="port old BTS directly",
            governed_choice="synthesize from all four generations",
            rejected_choices=["port directly — misses deliberateness",
                              "start from scratch — loses receipt logic"],
            reasoning_summary="Old BTS lacked instinctive/governed/rejected pattern",
            gates=[{"gate": "SEE_REQUIRED", "result": "PASS"}],
            confidence=0.94, stage="ADS", turn_id="TURN-001",
        )
        assert decision.instinctive_choice and len(decision.rejected_choices) >= 1
        print(f"  Decision artifact: {decision.decision_id} ✓")

        tracker = bts.start_turn_tracker("TURN-001")
        tracker.emit_intent("Write BTS canonical engine")
        tracker.emit_evaluation([
            {"tool": "direct_port", "verdict": "REJECTED", "reason": "Misses deliberateness"},
            {"tool": "synthesis", "verdict": "SELECTED", "reason": "Captures full design"},
        ])
        tracker.emit_selection("synthesis", "Only approach capturing full intent")
        tracker.emit_execution("synthesis")
        tracker.emit_result("synthesis", status="success", intent_satisfied=True, correctness_score=0.96)
        commit = tracker.commit()
        assert tracker.is_committed
        print("  Tool tracking pipeline ✓")

        test_file = root / "test.py"
        test_file.write_text("# test")
        r1 = bts.t1_file("IMPLEMENTATION", test_file, turn_id="TURN-001")
        assert r1["tier"] == "T1" and r1["receipt_sha256"]
        print(f"  T1 file: {r1['receipt_id']} ✓")

        r2 = bts.t1_subprocess("VERIFICATION", ["python3", "--version"], turn_id="TURN-001")
        assert r2["tier"] == "T1" and r2["stdout_sha256"]
        print(f"  T1 subprocess: {r2['receipt_id']} ✓")

        r3 = bts.t2_chained("AUDIT", r1, "Verified IMPL", turn_id="TURN-001")
        assert r3["prior_receipt_sha256"] == r1["receipt_sha256"]
        print(f"  T2 chained: {r3['receipt_id']} ✓")

        r4 = bts.t3_advisory("PLANNING", "Advisory note", turn_id="TURN-001")
        assert "ADVISORY_ONLY" in r4["WARNING"]
        print(f"  T3 advisory: {r4['receipt_id']} ✓")

        r5 = bts.t_missing("SEE", "external_url", "fetch_failed", turn_id="TURN-001")
        assert r5["tier"] == "MISSING"
        print(f"  MISSING: {r5['receipt_id']} ✓")

        chk = bts.check_tier_satisfied(r1["receipt_path"], "T1")
        chk2 = bts.check_tier_satisfied(r4["receipt_path"], "T1")
        assert chk["passed"] and not chk2["passed"]
        print("  Tier enforcement ✓")

        tracker2 = bts.start_turn_tracker("TURN-002")
        bts.turn_start("TURN-002", "Switch test")
        tracker2.emit_intent("Parse JSON")
        tracker2.emit_evaluation([
            {"tool": "jq", "verdict": "SELECTED", "reason": "Fast"},
            {"tool": "python", "verdict": "REJECTED", "reason": "Slower"},
        ])
        tracker2.emit_selection("jq", "Fast for simple queries")
        tracker2.emit_switch("jq", "python", reason_code="EXECUTION_FAILURE",
                             detail="jq parse error on malformed JSON")
        tracker2.emit_execution("python")
        tracker2.emit_result("python", status="success", intent_satisfied=True)
        tracker2.commit()
        print("  BTS_TOOL_SWITCH with reason code ✓")

        manifest = bts.turn_end("TURN-001")
        assert manifest["receipt_count"] > 0 and manifest["chain_hash"]
        print(f"  Turn manifest: {manifest['receipt_count']} receipts ✓")

        audit = bts.run_competence_audit(min_score=0.6)
        print(f"  Competence audit: {audit['tool_count']} tools ✓")

        s = bts.summary()
        assert s["log_entries"] > 0 and s["t1_entries"] >= 2
        print(f"  Summary: {s['log_entries']} entries, T1={s['t1_entries']} ✓")

        print()
        print("BTS v3 SELF-TEST PASSED")
        sys.exit(0)
