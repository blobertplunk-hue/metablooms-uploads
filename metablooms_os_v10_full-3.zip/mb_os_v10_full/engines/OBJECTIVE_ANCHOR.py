"""
OBJECTIVE_ANCHOR.py — MetaBlooms Intent Integrity Engine v1

CDR V1 (Intent): Prevent goal drift — objectives changing meaning across turns
even when execution is technically correct. Reconciliation prevents execution
drift. Objective Anchoring prevents the subtler problem: the objective itself
drifting. Without an anchor, goal drift is invisible. With one, it is named
and requires explicit justification to proceed.

CDR V2 (Trust): The anchor hash is SHA256 of normalized objective text
(stripped, lowercased). This means minor whitespace/case variations are treated
as the same objective (ANCHORED), while substantive changes (DRIFTED) require
explicit authorization. The hash is computed from the actual text, not
summarized.

CDR V3 (Boundary): ObjectiveAnchor tracks intent. It does not block execution.
DRIFTED is advisory — it logs a T3 receipt and surfaces in the turn report.
Only the operator can authorize_drift(). The engine detects; the operator decides.

CDR V4 (State): state/OBJECTIVE_ANCHOR.json stores the current anchor. It is
overwritten when a new objective is set or drift is authorized. The drift log
(state/OBJECTIVE_DRIFT_LOG.json) is append-only — never truncated.

CDR V5 (Failure): If OBJECTIVE_ANCHOR.json cannot be read, read() returns None
(first session, no prior anchor). If it cannot be written, set() raises rather
than silently losing the anchor. A lost anchor means drift is undetectable.

constraint_mapping:
  - Jaccard distance threshold: 0.3 (word-level, above = DRIFTED)
  - Hash normalization: strip + lowercase (whitespace/case = not drift)
  - Must NOT block turn on DRIFTED — log and surface, do not block
  - Must NOT authorize drift without explicit reason string

integration_reciprocity:
  Inputs:  objective (str) for set/verify, reason (str) for authorize_drift
  Outputs: state/OBJECTIVE_ANCHOR.json, state/OBJECTIVE_DRIFT_LOG.json
  Side effects: calls bts.t3_advisory() on DRIFTED
  Promises: set() always writes before returning, verify() never blocks execution
  Callers: MetaBloomsOS.run_turn() before each turn, MetaBloomsOS.boot() for status

legacy_impact_statement:
  Before this engine, goal drift was only detectable by human review of turn
  history. This engine makes drift machine-detectable and logged with evidence.

ChatGPT behavioral contract:
  At first turn: set anchor with objective text.
  Before each subsequent turn: verify() the current objective.
  If DRIFTED: surface in turn report. Do not block. Log T3 receipt.
  To intentionally change objective: call authorize_drift() with reason.
"""

from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = []
REQUIRES_HASH = "14f7b8087c39bd79ef72ed920dd0d608045106be161cc9118f28ec23de219f7d"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


SCHEMA = "mb.objective_anchor.v1"
ANCHOR_REL = Path("state/OBJECTIVE_ANCHOR.json")
DRIFT_LOG_REL = Path("state/OBJECTIVE_DRIFT_LOG.json")


def _hash_objective(text: str) -> str:
    """Stable SHA256 of objective text, normalized (strip + lower)."""
    normalized = text.strip().lower()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


@dataclass
class AnchorCheck:
    """Result of verifying current objective against anchor."""
    status: str               # ANCHORED | DRIFTED | NO_ANCHOR
    current_hash: str
    anchor_hash: Optional[str]
    original_objective: Optional[str]
    current_objective: str
    drift_pct: float          # 0.0 = identical, 1.0 = completely different
    authorized: bool = False
    message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "status": self.status,
            "current_hash": self.current_hash,
            "anchor_hash": self.anchor_hash,
            "original_objective": self.original_objective,
            "current_objective": self.current_objective,
            "drift_pct": round(self.drift_pct, 3),
            "authorized": self.authorized,
            "message": self.message,
        }


class ObjectiveAnchor:
    """
    Intent integrity engine. Prevents goal drift across turns.

    Usage:
        anchor = ObjectiveAnchor(runtime_root)

        # Start of a multi-turn objective:
        anchor.set("Build the RECONCILIATION_VALIDATOR", turn_id="TURN-001")

        # Before each subsequent turn:
        check = anchor.verify("Build the reconciliation engine")
        # → ANCHORED (same objective, different case/whitespace)

        check2 = anchor.verify("Redesign the MPP pipeline")
        # → DRIFTED — requires authorization

        # To authorize the drift:
        anchor.authorize_drift(
            new_objective="Redesign the MPP pipeline",
            drift_reason="Reconciliation engine exposed deeper MPP issues",
            turn_id="TURN-004"
        )
    """

    def __init__(self, runtime_root: str | Path = ".") -> None:
        self.root = Path(runtime_root)
        self._anchor_path = self.root / ANCHOR_REL
        self._drift_log_path = self.root / DRIFT_LOG_REL
        self._anchor_path.parent.mkdir(parents=True, exist_ok=True)

    def read(self) -> Optional[Dict[str, Any]]:
        """Read current anchor. Returns None if no anchor set."""
        if not self._anchor_path.exists():
            return None
        try:
            return json.loads(self._anchor_path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def set(self, objective: str, turn_id: str,
            multi_turn: bool = True) -> Dict[str, Any]:
        """
        Set or reset the objective anchor.
        Call at the start of a new multi-turn objective.
        Always overwrites prior anchor — call only when starting fresh.
        """
        h = _hash_objective(objective)
        anchor = {
            "schema": SCHEMA,
            "original_objective": objective,
            "original_hash": h,
            "set_at": _now(),
            "set_turn_id": turn_id,
            "multi_turn": multi_turn,
            "drift_count": 0,
            "last_authorized_at": None,
        }
        self._anchor_path.write_text(
            json.dumps(anchor, indent=2), encoding="utf-8"
        )
        return anchor

    def verify(self, current_objective: str) -> AnchorCheck:
        """
        Verify current objective against anchor.
        Returns AnchorCheck with status ANCHORED, DRIFTED, or NO_ANCHOR.
        """
        anchor = self.read()
        current_hash = _hash_objective(current_objective)

        if anchor is None:
            return AnchorCheck(
                status="NO_ANCHOR",
                current_hash=current_hash,
                anchor_hash=None,
                original_objective=None,
                current_objective=current_objective,
                drift_pct=0.0,
                message="No anchor set. Call set() to anchor this objective.",
            )

        original_hash = anchor["original_hash"]
        original_text = anchor["original_objective"]

        if current_hash == original_hash:
            return AnchorCheck(
                status="ANCHORED",
                current_hash=current_hash,
                anchor_hash=original_hash,
                original_objective=original_text,
                current_objective=current_objective,
                drift_pct=0.0,
                message="Objective matches anchor.",
            )

        # Compute semantic drift as normalized edit distance proxy
        # (word-level Jaccard distance — simple, no deps)
        orig_words = set(original_text.lower().split())
        curr_words = set(current_objective.lower().split())
        if orig_words | curr_words:
            jaccard = len(orig_words & curr_words) / len(orig_words | curr_words)
            drift_pct = 1.0 - jaccard
        else:
            drift_pct = 1.0

        return AnchorCheck(
            status="DRIFTED",
            current_hash=current_hash,
            anchor_hash=original_hash,
            original_objective=original_text,
            current_objective=current_objective,
            drift_pct=drift_pct,
            authorized=False,
            message=(
                f"Objective drift detected ({drift_pct:.0%} divergence). "
                f"Original: '{original_text[:60]}'. "
                f"Current: '{current_objective[:60]}'. "
                f"Call authorize_drift() to proceed."
            ),
        )

    def authorize_drift(self, new_objective: str, drift_reason: str,
                        turn_id: str) -> Dict[str, Any]:
        """
        Authorize an objective change. Updates anchor to new objective.
        Appends entry to drift log for traceability.
        """
        anchor = self.read()
        prior_objective = anchor["original_objective"] if anchor else ""
        prior_hash = anchor["original_hash"] if anchor else ""

        # Log the drift before updating
        drift_entry = {
            "timestamp": _now(),
            "turn_id": turn_id,
            "prior_objective": prior_objective,
            "prior_hash": prior_hash,
            "new_objective": new_objective,
            "new_hash": _hash_objective(new_objective),
            "drift_reason": drift_reason,
            "authorized_by": "operator",
        }
        self._append_drift_log(drift_entry)

        # Update anchor to new objective
        new_anchor = self.set(new_objective, turn_id)
        if anchor:
            new_anchor["drift_count"] = anchor.get("drift_count", 0) + 1
            new_anchor["last_authorized_at"] = _now()
            self._anchor_path.write_text(
                json.dumps(new_anchor, indent=2), encoding="utf-8"
            )

        return {
            "status": "DRIFT_AUTHORIZED",
            "new_anchor": new_anchor,
            "drift_logged": drift_entry,
        }

    def drift_log(self) -> list:
        """Read full drift log."""
        if not self._drift_log_path.exists():
            return []
        try:
            return json.loads(self._drift_log_path.read_text(encoding="utf-8"))
        except Exception:
            return []

    def _append_drift_log(self, entry: Dict[str, Any]) -> None:
        log = self.drift_log()
        log.append(entry)
        self._drift_log_path.write_text(
            json.dumps(log, indent=2), encoding="utf-8"
        )

    def summary(self) -> Dict[str, Any]:
        anchor = self.read()
        return {
            "anchor_set": anchor is not None,
            "original_objective": anchor.get("original_objective") if anchor else None,
            "drift_count": anchor.get("drift_count", 0) if anchor else 0,
            "drift_log_entries": len(self.drift_log()),
        }


# ── Self-test ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import tempfile, sys

    print("OBJECTIVE_ANCHOR self-test...")
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        anchor = ObjectiveAnchor(root)

        # No anchor yet
        check0 = anchor.verify("some objective")
        assert check0.status == "NO_ANCHOR"
        print(f"  No anchor: {check0.status} ✓")

        # Set anchor
        anchor.set("Fix the DEBUGGING exit contract", "TURN-001")
        print(f"  Anchor set ✓")

        # Same objective — ANCHORED
        check1 = anchor.verify("Fix the DEBUGGING exit contract")
        assert check1.status == "ANCHORED", f"Expected ANCHORED got {check1.status}"
        assert check1.drift_pct == 0.0
        print(f"  Same objective: {check1.status} ✓")

        # Capitalization / whitespace variation — still ANCHORED (normalized)
        check2 = anchor.verify("  fix the debugging exit contract  ")
        assert check2.status == "ANCHORED", f"Expected ANCHORED got {check2.status}"
        print(f"  Whitespace variation: {check2.status} ✓")

        # Minor wording change — DRIFTED but low %
        check3 = anchor.verify("Improve the DEBUGGING exit contract")
        assert check3.status == "DRIFTED"
        assert 0 < check3.drift_pct < 0.5
        print(f"  Minor drift: {check3.status} ({check3.drift_pct:.0%} divergence) ✓")

        # Major objective change — DRIFTED high %
        check4 = anchor.verify("Redesign the entire MPP pipeline architecture")
        assert check4.status == "DRIFTED"
        assert check4.drift_pct > 0.5
        print(f"  Major drift: {check4.status} ({check4.drift_pct:.0%} divergence) ✓")

        # Authorize the drift
        result = anchor.authorize_drift(
            "Improve the DEBUGGING exit contract",
            "Root cause analysis revealed a broader improvement opportunity",
            "TURN-004"
        )
        assert result["status"] == "DRIFT_AUTHORIZED"
        print(f"  Drift authorized ✓")

        # After authorization, new objective is now anchored
        check5 = anchor.verify("Improve the DEBUGGING exit contract")
        assert check5.status == "ANCHORED"
        print(f"  Post-authorization: {check5.status} ✓")

        # Drift log has one entry
        log = anchor.drift_log()
        assert len(log) == 1
        assert log[0]["prior_objective"] == "Fix the DEBUGGING exit contract"
        print(f"  Drift log: {len(log)} entry ✓")

        # Summary
        s = anchor.summary()
        assert s["drift_count"] == 1
        print(f"  Summary: {s}")

        print()
        print("OBJECTIVE_ANCHOR SELF-TEST PASSED")
        sys.exit(0)
