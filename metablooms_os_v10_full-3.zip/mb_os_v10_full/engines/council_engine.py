"""
council_engine.py — MetaBlooms CouncilEngine v1

CDR V1 (Intent): Replace single-voice Critic with four named councils that vote
independently, produce structured rationale, and require weighted quorum before
any output passes. The single-voice pattern fails because the same model that
produced the output is also evaluating it — self-approval bias. Four councils
with different weights forces adversarial review within the same model invocation.

CDR V2 (Trust): Each council produces a score (0.0-1.0), rationale (str), and
escalate flag. The weighted quorum formula is deterministic and auditable:
quorum = sum(weight × score) for all councils. Quorum >= 0.85 = PASS.
Below threshold = REVISE or ESCALATE depending on whether any council escalated.

CDR V3 (Boundary): CouncilEngine judges outputs. It does not produce them,
repair them, or re-run the stage. It receives a completed result and returns
a verdict with full per-council rationale. Revision requests go back to the
stage handler, not to CouncilEngine.

CDR V4 (State): Council votes are written to working memory as governance
artifacts. They are not persisted to disk directly — they travel with the
MPP cycle result and are included in BTS receipts at VERIFICATION.

CDR V5 (Failure): If quorum is not reached, verdict is REVISE or ESCALATE —
never a silent pass. Any council can ESCALATE regardless of quorum, immediately
triggering ESCALATE verdict. Escalation bypasses quorum calculation.

constraint_mapping:
  - Quorum threshold: 0.85 (hardcoded, not configurable per-call)
  - Council weights must sum to 1.0
  - Any single council ESCALATE = full ESCALATE regardless of quorum
  - Must NOT produce PASS if any CRITICAL ERAC violation present
  - Council independence is logical not structural (same model instance)

integration_reciprocity:
  Inputs:  content (str), context (str), erac_violations (list)
  Outputs: CouncilVerdict (verdict, quorum, votes, rationale_json)
  Side effects: none — stateless per-call
  Promises: always returns verdict, never raises on valid input
  Callers: MPP VERIFICATION stage, MPP_RUNTIME._run_verification_governance()

legacy_impact_statement:
  Replaces the single-Critic model where one voice evaluated its own output.
  Four councils with weighted quorum makes approval harder to game and produces
  per-council rationale that is auditable and improvable over time.

ChatGPT behavioral contract:
  At VERIFICATION: run CouncilEngine.evaluate() on the IMPLEMENTATION output.
  Include all four council scores and rationale in governance dict.
  PASS requires quorum >= 0.85 AND no ESCALATE flags AND no CRITICAL ERAC.
  Surface council rationale in BTS T2 receipt.
"""
from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = ["BTS", "MPP_RUNTIME", "erac_engine"]
REQUIRES_HASH = "5e8e7c087a77b3f28e1346f046537e07b38b56be0b08e719a3e792a59e2ccda9"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from erac_engine import ERACEngine


QUORUM_THRESHOLD = 0.85  # 85% weighted quorum required

COUNCIL_WEIGHTS = {
    "RATIONALITY": 0.35,
    "RELIABILITY":  0.30,
    "ETHICS":       0.20,
    "BUILDER":      0.15,
}

# Minimum score (0–10) for a council to vote PASS
COUNCIL_PASS_THRESHOLD = 6


@dataclass
class CouncilVote:
    council: str
    vote: str          # PASS | FAIL | ESCALATE
    score: int         # 0–10
    weight: float
    rationale: str
    flags: List[str] = field(default_factory=list)


@dataclass
class CouncilVerdict:
    verdict: str                    # PASS | REVISE | ESCALATE
    quorum_score: float
    quorum_reached: bool
    votes: List[CouncilVote]
    blocking_flags: List[str]
    feedback_for_executor: str
    duration_ms: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "verdict": self.verdict,
            "quorum_score": round(self.quorum_score, 3),
            "quorum_threshold": QUORUM_THRESHOLD,
            "quorum_reached": self.quorum_reached,
            "councils": {
                v.council: {
                    "vote": v.vote,
                    "score": v.score,
                    "weight": v.weight,
                    "rationale": v.rationale,
                    "flags": v.flags,
                }
                for v in self.votes
            },
            "blocking_flags": self.blocking_flags,
            "feedback_for_executor": self.feedback_for_executor,
            "duration_ms": round(self.duration_ms, 1),
        }


class CouncilEngine:
    """
    Multi-council governance judgment engine.

    Usage:
        council = CouncilEngine()
        verdict = council.judge(
            objective="Write a bilingual vocabulary activity",
            content="...",
            domain="classroom",
            cognitive_fn_output=exec_result.output,
            verify_passed=True,
            revision_count=0,
            tags=["bilingual", "3rd_grade"],
        )
        print(verdict.verdict)          # PASS
        print(verdict.to_dict())        # full rationale
    """

    def judge(
        self,
        objective: str,
        content: Any,
        domain: str,
        cognitive_fn_output: Dict[str, Any],
        verify_passed: bool,
        revision_count: int,
        max_revisions: int = 2,
        tags: Optional[List[str]] = None,
    ) -> CouncilVerdict:
        t0 = time.monotonic()
        tags = tags or []
        content_str = str(content) if not isinstance(content, str) else content

        # Gather votes from all four councils
        votes = [
            self._council_rationality(objective, content_str, cognitive_fn_output, verify_passed),
            self._council_reliability(content_str, cognitive_fn_output, revision_count),
            self._council_ethics(objective, content_str, domain, tags),
            self._council_builder(objective, content_str, domain, tags),
        ]

        # Compute weighted quorum
        passing_weight = sum(
            v.weight for v in votes if v.vote == "PASS"
        )
        quorum_reached = passing_weight >= QUORUM_THRESHOLD

        # Collect all flags from failing/escalating councils
        blocking_flags = []
        for v in votes:
            if v.vote in ("FAIL", "ESCALATE"):
                blocking_flags.extend(v.flags)

        # Determine verdict
        escalating = [v for v in votes if v.vote == "ESCALATE"]
        if escalating:
            verdict = "ESCALATE"
        elif quorum_reached:
            verdict = "PASS"
        elif revision_count >= max_revisions:
            verdict = "ESCALATE"
        else:
            verdict = "REVISE"

        # Build feedback for executor
        feedback = self._build_feedback(votes, verdict, blocking_flags, revision_count)

        return CouncilVerdict(
            verdict=verdict,
            quorum_score=passing_weight,
            quorum_reached=quorum_reached,
            votes=votes,
            blocking_flags=blocking_flags,
            feedback_for_executor=feedback,
            duration_ms=(time.monotonic() - t0) * 1000,
        )

    # ── Four Councils ──────────────────────────────────────────────────────────

    def _council_rationality(
        self,
        objective: str,
        content: str,
        output: Dict[str, Any],
        verify_passed: bool,
    ) -> CouncilVote:
        """
        RATIONALITY: Is this correct? Does the reasoning hold?
        Now includes ERAC protocol scan for epistemic failure modes.
        """
        flags = []
        score = 10

        # Verifier already failed — structural issue
        if not verify_passed:
            flags.append("RATIONALITY:verifier_failed")
            score -= 4

        # Contradiction check: output claims passed=False but content exists
        if output.get("passed") is False and content and len(content) > 50:
            flags.append("RATIONALITY:contradictory_passed_flag")
            score -= 2

        # Placeholder detection
        placeholder_markers = [
            "write your complete",
            "content goes here",
            "todo:",
            "placeholder",
            "insert content",
            "your activity here",
        ]
        content_lower = content.lower()
        for marker in placeholder_markers:
            if marker in content_lower:
                flags.append(f"RATIONALITY:placeholder_detected:{marker}")
                score -= 5
                break

        # Very short output
        if len(content) < 50:
            flags.append("RATIONALITY:output_trivially_short")
            score -= 3

        # ERAC scan — detect epistemic failure modes in the content
        erac = ERACEngine()
        erac_report = erac.scan_text(content, context_label="executor_output")
        if not erac_report.erac_clean:
            for violation in erac_report.violations:
                flags.append(f"RATIONALITY:{violation.erac_code}:{violation.name}")
                # Dynamic penalty: severity × confidence
                # Confidence is estimated from detection pattern strength:
                # - CRITICAL violations (ERAC-001, ERAC-003): full penalty
                # - HIGH violations (ERAC-002, ERAC-004): reduced penalty
                # - Multiple violations of same code: diminishing returns (cap at 2×)
                if violation.severity == "CRITICAL":
                    base_penalty = 3
                else:  # HIGH
                    base_penalty = 2
                # Confidence modifier: longer evidence match = higher confidence
                evidence_len = len(violation.evidence) if violation.evidence else 20
                confidence = min(1.0, evidence_len / 80.0)  # 80+ chars = full confidence
                penalty = round(base_penalty * confidence)
                penalty = max(1, penalty)  # floor at 1 — never zero-penalty for a violation
                score -= penalty

        score = max(0, score)
        vote = "PASS" if score >= COUNCIL_PASS_THRESHOLD and not flags else "FAIL"

        rationale = (
            f"Correctness + ERAC check: verify_passed={verify_passed}, "
            f"content_length={len(content)}, "
            f"erac_clean={erac_report.erac_clean}, score={score}/10."
        )
        if not erac_report.erac_clean:
            rationale += f" ERAC: {erac_report.summary}"
        if flags:
            rationale += f" Flags: {flags}"

        return CouncilVote(
            council="RATIONALITY",
            vote=vote,
            score=score,
            weight=COUNCIL_WEIGHTS["RATIONALITY"],
            rationale=rationale,
            flags=flags,
        )

    def _council_reliability(
        self,
        content: str,
        output: Dict[str, Any],
        revision_count: int,
    ) -> CouncilVote:
        """
        RELIABILITY: Is this complete and robust? No stubs, no gaps.
        """
        flags = []
        score = 10

        # Stub markers
        stub_markers = ["...", "tbd", "coming soon", "[stub]", "not implemented"]
        content_lower = content.lower()
        for marker in stub_markers:
            if marker in content_lower:
                flags.append(f"RELIABILITY:stub_marker:{marker}")
                score -= 3

        # Dry-run output after revision
        if "[DRY RUN]" in content and revision_count > 0:
            flags.append("RELIABILITY:dry_run_after_revision")
            score -= 5

        # Truncation signal
        if content.rstrip().endswith("...") or content.rstrip().endswith("etc."):
            flags.append("RELIABILITY:possible_truncation")
            score -= 2

        # Minimal content
        if len(content) < 100:
            flags.append("RELIABILITY:content_below_minimum_length")
            score -= 3

        score = max(0, score)
        vote = "PASS" if score >= COUNCIL_PASS_THRESHOLD and not flags else "FAIL"

        rationale = (
            f"Completeness check: length={len(content)}, "
            f"revision_count={revision_count}, score={score}/10."
        )
        if flags:
            rationale += f" Flags: {flags}"

        return CouncilVote(
            council="RELIABILITY",
            vote=vote,
            score=score,
            weight=COUNCIL_WEIGHTS["RELIABILITY"],
            rationale=rationale,
            flags=flags,
        )

    def _council_ethics(
        self,
        objective: str,
        content: str,
        domain: str,
        tags: List[str],
    ) -> CouncilVote:
        """
        ETHICS: Is this appropriate for the domain and intended audience?
        """
        flags = []
        score = 10

        # Educational domain — check age-appropriateness
        if domain == "classroom" or any(t in tags for t in ["3rd_grade", "student", "bilingual"]):
            inappropriate = ["violence", "explicit", "adult content", "profanity"]
            content_lower = content.lower()
            for term in inappropriate:
                if term in content_lower:
                    flags.append(f"ETHICS:inappropriate_educational_content:{term}")
                    score -= 8

        # Enterprise audit domain — check for unsupported claims
        if domain == "enterprise_audit":
            if "guaranteed" in content.lower() or "100% compliant" in content.lower():
                flags.append("ETHICS:unsupported_compliance_claim")
                score -= 3

        score = max(0, score)
        # Ethics council escalates on severe flags, not just fails
        if any("inappropriate" in f for f in flags) and score < 3:
            vote = "ESCALATE"
        elif score >= COUNCIL_PASS_THRESHOLD and not flags:
            vote = "PASS"
        else:
            vote = "FAIL" if flags else "PASS"

        rationale = (
            f"Ethics check for domain={domain}, tags={tags}, score={score}/10."
        )
        if flags:
            rationale += f" Flags: {flags}"
        else:
            rationale += " No ethical concerns detected."

        return CouncilVote(
            council="ETHICS",
            vote=vote,
            score=score,
            weight=COUNCIL_WEIGHTS["ETHICS"],
            rationale=rationale,
            flags=flags,
        )

    def _council_builder(
        self,
        objective: str,
        content: str,
        domain: str,
        tags: List[str],
    ) -> CouncilVote:
        """
        BUILDER: Is this actually useful? Does it solve the stated problem?
        """
        flags = []
        score = 10

        # Check if objective keywords appear anywhere in the content
        # (basic signal that the output addresses the request)
        objective_words = [
            w.lower() for w in objective.split()
            if len(w) > 4  # skip short words
        ]
        content_lower = content.lower()
        matched = sum(1 for w in objective_words if w in content_lower)
        coverage = matched / max(len(objective_words), 1)

        if coverage < 0.2 and len(objective_words) > 3:
            flags.append(f"BUILDER:low_objective_coverage:{coverage:.0%}")
            score -= 3

        # Domain-specific utility checks
        if domain == "classroom":
            # A classroom activity should have some structure
            structure_signals = [
                "part", "section", "activity", "write", "circle",
                "match", "draw", "complete", "answer", "question",
                "actividad", "escribe", "completa",  # Spanish signals
            ]
            has_structure = any(sig in content_lower for sig in structure_signals)
            if not has_structure:
                flags.append("BUILDER:classroom_content_lacks_activity_structure")
                score -= 2

        score = max(0, score)
        vote = "PASS" if score >= COUNCIL_PASS_THRESHOLD and not flags else "FAIL"

        rationale = (
            f"Utility check: objective_coverage={coverage:.0%}, "
            f"domain={domain}, score={score}/10."
        )
        if flags:
            rationale += f" Flags: {flags}"

        return CouncilVote(
            council="BUILDER",
            vote=vote,
            score=score,
            weight=COUNCIL_WEIGHTS["BUILDER"],
            rationale=rationale,
            flags=flags,
        )

    # ── Feedback builder ───────────────────────────────────────────────────────

    def _build_feedback(
        self,
        votes: List[CouncilVote],
        verdict: str,
        blocking_flags: List[str],
        revision_count: int,
    ) -> str:
        if verdict == "PASS":
            passing = [v.council for v in votes if v.vote == "PASS"]
            return f"Council PASS — quorum reached. Approved by: {', '.join(passing)}."

        failing = [(v.council, v.flags) for v in votes if v.vote != "PASS"]
        lines = [f"Council {verdict} — quorum not reached."]
        for council, flags in failing:
            lines.append(f"  {council}: {'; '.join(flags) if flags else 'score below threshold'}")
        if revision_count > 0:
            lines.append(f"  This is revision {revision_count} — address all flags above.")
        return " ".join(lines)



# ── Self-test ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    print("council_engine self-test...")
    from council_engine import CouncilEngine

    ce = CouncilEngine()

    # Test 1: good content with real judge() API
    result = ce.judge(
        objective="Verify file integrity",
        content="After reading engines/BTS.py and computing sha256, the file hash is confirmed. TurnTracker.commit() at line 224 enforces event order.",
        domain="technical",
        cognitive_fn_output={"steps": ["read file", "hash bytes", "compare"], "domain": "technical"},
        verify_passed=True,
        revision_count=0,
    )
    assert result.verdict in ("PASS", "REVISE", "ESCALATE")
    print(f"  Good content verdict: {result.verdict} quorum={result.quorum_score:.2f} ✓")

    # Test 2: empty content fails
    result2 = ce.judge(
        objective="Test empty",
        content="",
        domain="general",
        cognitive_fn_output={},
        verify_passed=False,
        revision_count=0,
    )
    assert result2.verdict in ("REVISE", "ESCALATE")
    print(f"  Empty content verdict: {result2.verdict} ✓")

    # Test 3: per-council votes present
    assert len(result.votes) == 4
    councils = {v.council for v in result.votes}
    assert "RATIONALITY" in councils
    assert "RELIABILITY" in councils
    print(f"  Four councils: {sorted(councils)} ✓")

    print()
    print("council_engine SELF-TEST PASSED")
    sys.exit(0)
