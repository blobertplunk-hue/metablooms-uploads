import subprocess  # nosec B404 — intentional: lint_gate.py is a subprocess runner

COMMANDS: list[list[str]] = [
    ["ruff", "check", "."],
    ["black", "--check", "."],
    ["mypy", "."],
    ["bandit", "-r", ".", "-x", "tests,receipts,traces"],
]


def run_cmd(cmd: list[str]) -> None:
    proc = subprocess.run(cmd, check=False)  # nosec B603 — cmd is hardcoded list, not user input
    if proc.returncode != 0:
        raise SystemExit(f"LINT_GATE_FAIL: {' '.join(cmd)}")


def main() -> None:
    for cmd in COMMANDS:
        run_cmd(cmd)
    print("LINT_GATE: ALL PASS")


if __name__ == "__main__":
    main()
