"""
STAGE_BASE.py — Abstract base class for all MPP stage implementations
=====================================================================

CDR V1 (Rationale):
    StageBase defines the enforcement contract that all 14 MPP stages must satisfy.
    Every stage must: validate input state, execute business logic, produce a
    structured artifact dict, and include a trace_span. The __init_subclass__
    guard prevents stages from inheriting the default 'BASE' name silently.

CDR V2 (Trust):
    run() hardcodes status='COMPLETE' — the only way a stage can fail is via
    RuntimeError in execute(). validate_output() is defensive programming for
    subclasses that override run(). No stage can claim completion without
    producing all 4 required fields.

CDR V3 (Boundary):
    Inputs:  PipelineState instance (must not be None)
    Outputs: dict with keys: stage, status, artifact, trace_span
    Side effects: none — StageBase is stateless
    Assumptions: execute() is implemented by every concrete subclass

CDR V4 (Failure):
    state is None → {name}_INPUT_INVALID raised immediately.
    Missing required output field → {name}_OUTPUT_INVALID raised.
    status != COMPLETE → {name}_NOT_COMPLETE raised.
    safe_state: raise, never return partial result.

CDR V5 (S-tier):
    __init_subclass__ guard enforces name != 'BASE' on all concrete subclasses.
    Comparable to: Python's ABC abstract methods, Dagster's OpDefinition contract.
    Industry pattern: template method pattern with enforced output schema.
"""

from __future__ import annotations

import hashlib
from typing import Any


class StageBase:
    name: str = "BASE"

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if "execute" in cls.__dict__ and cls.name == "BASE":
            raise TypeError(f"{cls.__name__} must define class attribute 'name' — " "do not inherit the default 'BASE' value")

    def validate_input(self, state: Any) -> None:
        if state is None:
            raise RuntimeError(f"{self.name}_INPUT_INVALID")

    def validate_output(self, result: dict[str, Any]) -> None:
        required = ["stage", "status", "artifact", "trace_span"]
        for key in required:
            if key not in result:
                raise RuntimeError(f"{self.name}_OUTPUT_INVALID: missing {key}")
        if result["status"] != "COMPLETE":
            raise RuntimeError(f"{self.name}_NOT_COMPLETE")

    def execute(self, state: Any) -> dict[str, Any]:
        raise NotImplementedError

    def run(self, state: Any) -> dict[str, Any]:
        self.validate_input(state)
        artifact = self.execute(state)
        result = {
            "stage": self.name,
            "status": "COMPLETE",
            "artifact": artifact,
            "trace_span": {"stage": self.name, "artifacts": artifact},
        }
        self.validate_output(result)
        # artifact_hash: SHA-256 of artifact content for integrity
        result_hash = hashlib.sha256(str(result["artifact"]).encode()).hexdigest()
        result["artifact_hash"] = result_hash
        return result
