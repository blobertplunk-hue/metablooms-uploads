"""
MULTIPASS_ENGINE.py — MetaBlooms Multi-Pass Convergence Engine

CDR V1 (Intent): The pasted "intelligence-grade" code contributed one real
    architectural insight: wrap the execution pipeline in a convergence loop
    that re-runs until quality improves or terminates on named conditions.
    This engine takes that structure and makes it real by replacing the
    random SHA256 scoring function with FIR composite — a meaningful,
    multi-dimensional fitness score grounded in actual pipeline behavior.

CDR V2 (Trust): Score is extracted from FIR_STAGE artifact in pipeline state.
    If FIR_STAGE didn't run, score is 0.0 (fail-closed — no fabricated scores).
    Convergence decisions are deterministic: same state → same decision.

CDR V3 (Boundary):
    Inputs:  request (str), code (str), module_name (str),
             output_dir (Path), context (dict), max_passes (int)
    Outputs: MultiPassResult with best_state, scores, pass_count, reason
    Side effects: calls run() from metablooms_os.py each pass,
                  writes MULTIPASS_HISTORY.ndjson to output_dir
    Assumptions: metablooms_os.run() is importable, METABLOOMS_LOCAL_MODE=1

CDR V4 (Failure): run_mpp() raises on pipeline failure — propagates unchanged.
    No FIR score in state: returns 0.0 (fail-closed).
    Max passes reached: terminates with reason MAX_PASSES.
    safe_state: always return best result seen, even on failure.

CDR V5 (Integration):
    This is the MetaBlooms answer to the multi-pass pattern from research:
    Reflexion (Shinn et al. NeurIPS 2023) — re-run until quality improves
    Voyager (Wang et al. TMLR 2024) — accumulate skill improvement across trials
    AgentPRM (2025) — score each step, iterate until convergence

    MetaBlooms improvement: FIR composite is a real fitness signal
    (5 measurable criteria, weighted sum) vs the pasted code's SHA256
    of state string (random noise that converges by chance, not quality).

Research grounding:
    "The best-performing scoring strategy takes the product of step-level
    scores and considers neutral steps positive." — Let's Verify Step by Step
    (OpenAI, ICLR 2024). FIR uses weighted sum of step-level criteria,
    which is the arithmetic equivalent for discrete pipeline stages.

    "Reflexion eliminates hallucination by using self-reflection to distill
    failed trajectories into relevant experiences." — Reflexion (NeurIPS 2023).
    MetaBlooms BTS + ERAC_CONTRACT provide the same mechanism pre-action,
    not post-hoc.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# ── Constants ──────────────────────────────────────────────────────────────────

MAX_PASSES: int = 3
CONVERGENCE_THRESHOLD: float = 0.95  # FIR composite >= this → TARGET
MIN_DELTA: float = 0.02  # Less improvement than this → NO_IMPROVEMENT
COMMIT_THRESHOLD: float = 0.60  # FIR composite >= this → COMMITTED (minimum acceptable)


# ── Result dataclass ───────────────────────────────────────────────────────────


@dataclass
class MultiPassResult:
    request: str
    module_name: str
    pass_count: int
    scores: list[float]
    stop_reason: str  # TARGET | MAX_PASSES | NO_IMPROVEMENT | PIPELINE_FAIL
    best_score: float
    best_improved_code: str
    best_mpp_passed: bool
    best_forge_score: float
    best_forge_s_tier: bool
    pass_history: list[dict[str, Any]] = field(default_factory=list)
    timestamp: str = ""
    result_hash: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "mb.multipass_result.v1",
            "request": self.request,
            "module_name": self.module_name,
            "pass_count": self.pass_count,
            "scores": [round(s, 4) for s in self.scores],
            "stop_reason": self.stop_reason,
            "best_score": round(self.best_score, 4),
            "best_mpp_passed": self.best_mpp_passed,
            "best_forge_score": round(self.best_forge_score, 4),
            "best_forge_s_tier": self.best_forge_s_tier,
            "pass_history": self.pass_history,
            "timestamp": self.timestamp,
            "result_hash": self.result_hash,
        }

    def print_summary(self) -> None:
        print(f"\n{'='*60}")
        print(f"MULTIPASS ENGINE — {self.module_name}")
        print(f"{'='*60}")
        print(f"Passes:      {self.pass_count}/{MAX_PASSES}")
        print(f"Stop reason: {self.stop_reason}")
        print(f"Score path:  {' → '.join(f'{s:.3f}' for s in self.scores)}")
        print(f"Best score:  {self.best_score:.3f}")
        print(
            f"FORGE:       {self.best_forge_score:.3f}  s_tier={self.best_forge_s_tier}"
        )
        print(f"{'='*60}\n")


# ── Convergence engine ─────────────────────────────────────────────────────────


class ConvergenceEngine:
    """
    Determines when the multi-pass loop should stop.

    Termination conditions (in priority order):
    1. TARGET:         score >= CONVERGENCE_THRESHOLD
    2. NO_IMPROVEMENT: improvement between last two passes < MIN_DELTA
    3. MAX_PASSES:     iteration >= max_passes
    """

    def __init__(
        self,
        threshold: float = CONVERGENCE_THRESHOLD,
        min_delta: float = MIN_DELTA,
        max_passes: int = MAX_PASSES,
    ) -> None:
        self.threshold = threshold
        self.min_delta = min_delta
        self.max_passes = max_passes

    def should_stop(self, scores: list[float], iteration: int) -> tuple[bool, str]:
        """Return (should_stop, reason_code)."""
        if not scores:
            return False, ""

        # Target reached
        if scores[-1] >= self.threshold:
            return True, "TARGET"

        # Max passes reached
        if iteration + 1 >= self.max_passes:
            return True, "MAX_PASSES"

        # No improvement between last two passes
        if len(scores) >= 2:
            delta = scores[-1] - scores[-2]
            if delta < self.min_delta:
                return True, "NO_IMPROVEMENT"

        return False, ""


# ── Main engine ────────────────────────────────────────────────────────────────


def _extract_fir_score(os_result: Any) -> float:
    """
    Extract FIR composite score from OSResult.
    FIR composite is the real fitness signal — grounded in pipeline behavior:
      stage_completion_rate   × 0.25
      erac_clean_rate         × 0.20
      verification_pass_rate  × 0.20
      rca_quality_rate        × 0.15
      reasoning_quality_rate  × 0.20
    Returns 0.0 if not available (fail-closed).
    """
    if not os_result.mpp_passed:
        return 0.0
    fir = os_result.fir_composite
    if fir is None or not isinstance(fir, (int, float)):
        return 0.0
    return float(fir)


def run_multipass(
    request: str,
    code: str,
    module_name: str,
    output_dir: Path | None = None,
    context: dict[str, Any] | None = None,
    max_passes: int = MAX_PASSES,
) -> MultiPassResult:
    """
    Run code through MetaBlooms MPP→FORGE in multiple passes until convergence.

    Unlike the pasted code's SHA256-based scoring, this uses FIR composite —
    a real 5-criterion fitness score grounded in pipeline behavior.

    Args:
        request:     plain-language description of what the code does
        code:        Python source code to validate and improve
        module_name: filename (e.g. "my_engine.py")
        output_dir:  where to write output
        context:     optional constraints and context
        max_passes:  maximum iterations (default 3)

    Returns:
        MultiPassResult with best result across all passes
    """
    from metablooms_os import run as os_run  # type: ignore[import]

    output_dir = output_dir or Path("./metablooms_multipass_output")
    output_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(UTC).isoformat()

    conv = ConvergenceEngine(max_passes=max_passes)
    scores: list[float] = []
    pass_history: list[dict[str, Any]] = []

    best_score = 0.0
    best_result = None
    best_code = code
    current_code = code
    stop_reason = "MAX_PASSES"

    print(f"\n[MultiPass] Starting {max_passes}-pass convergence for {module_name}")
    print(
        f"[MultiPass] Threshold: FIR >= {CONVERGENCE_THRESHOLD} | min delta: {MIN_DELTA}"
    )

    for iteration in range(max_passes):
        pass_num = iteration + 1
        print(f"\n[MultiPass] Pass {pass_num}/{max_passes}...")

        pass_output = output_dir / f"pass_{pass_num}"
        pass_output.mkdir(exist_ok=True)

        try:
            result = os_run(
                request=request,
                code=current_code,
                module_name=module_name,
                output_dir=pass_output,
                context=context,
            )
        except RuntimeError as e:
            print(f"[MultiPass] Pass {pass_num} pipeline error: {e}")
            stop_reason = "PIPELINE_FAIL"
            break

        score = _extract_fir_score(result)
        scores.append(score)

        pass_record = {
            "pass": pass_num,
            "fir_score": round(score, 4),
            "fir_status": result.fir_status,
            "forge_score": round(result.forge_score, 4),
            "forge_s_tier": result.forge_s_tier,
            "mpp_passed": result.mpp_passed,
            "improvements": len(result.improvements_applied),
        }
        pass_history.append(pass_record)

        print(
            f"[MultiPass] Pass {pass_num}: FIR={score:.3f} FORGE={result.forge_score:.3f}"
        )

        # Track best result
        if score > best_score or best_result is None:
            best_score = score
            best_result = result
            best_code = result.improved_code

        # Check convergence
        should_stop, reason = conv.should_stop(scores, iteration)
        if should_stop:
            stop_reason = reason
            print(f"[MultiPass] Converged: {stop_reason}")
            break

        # Use improved code for next pass
        current_code = result.improved_code

    # Write multipass history
    history_path = output_dir / "MULTIPASS_HISTORY.ndjson"
    for record in pass_history:
        with open(history_path, "a") as f:
            f.write(
                json.dumps({**record, "timestamp": now, "module": module_name}) + "\n"
            )

    # Build result hash
    payload = f"{module_name}:{best_score:.4f}:{stop_reason}:{now}"
    result_hash = hashlib.sha256(payload.encode()).hexdigest()

    mp_result = MultiPassResult(
        request=request,
        module_name=module_name,
        pass_count=len(scores),
        scores=scores,
        stop_reason=stop_reason,
        best_score=best_score,
        best_improved_code=best_code,
        best_mpp_passed=best_result.mpp_passed if best_result else False,
        best_forge_score=best_result.forge_score if best_result else 0.0,
        best_forge_s_tier=best_result.forge_s_tier if best_result else False,
        pass_history=pass_history,
        timestamp=now,
        result_hash=result_hash,
    )
    mp_result.print_summary()

    # Write final report
    report_path = output_dir / "MULTIPASS_REPORT.json"
    report_path.write_text(json.dumps(mp_result.to_dict(), indent=2))

    return mp_result
