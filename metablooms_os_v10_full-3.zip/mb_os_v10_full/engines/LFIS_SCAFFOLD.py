"""
LFIS_SCAFFOLD.py — Layered Forced Improvement System (v2)
==========================================================

CDR V1 (Rationale):
    The LFIS is the automated execution engine for the LFIS prompt/plan.
    It takes the 17-stage MPP pipeline, defines S-tier per stage, runs
    the improvement loop (research → score → implement → delta → meta),
    writes SHA-256 anchored receipts per stage, and produces a final report.
    This scaffold makes the plan machine-executable rather than a document.

CDR V2 (Trust):
    All receipts are SHA-256 anchored. The receipt chain is append-only.
    No score is claimed without a corresponding receipt proving the measurement.
    No stage is promoted without all 6 S-tier criteria verified.

CDR V3 (Boundary):
    LFIS_SCAFFOLD orchestrates the improvement loop.
    It does not implement stage upgrades directly.
    Stage upgrade implementations are separate files consumed here.

CDR V4 (Failure):
    Max 3 improvement loops per stage per session.
    Remaining gaps → HARDENING_BACKLOG.json.
    Operator (Robert) must approve backlog before system is declared complete.

CDR V5 (Gap classification — closes rubric gap on meta-improvement):
    New gaps discovered during meta-improvement are classified into:
      UPSTREAM   — affects a stage earlier in the pipeline (insert before current)
      DOWNSTREAM — affects a stage later in the pipeline (append after current)
      LATERAL    — affects a parallel concern (e.g., POLICY_ENGINE policy count)
      INTERNAL   — affects only the current stage (next loop iteration)
    Priority rules:
      UPSTREAM gaps are inserted at HEAD of remaining queue (highest priority)
      DOWNSTREAM gaps are appended after the current stage's final loop
      LATERAL gaps go to end of current wave
      INTERNAL gaps are the next loop iteration target

Integration contract:
    Inputs:  stage registry, improvement functions, SIE queries per stage
    Outputs: STAGE_UPGRADE_RECEIPT_<name>.json per stage, LFIS_FINAL_REPORT.json
    Side effects: writes receipt files, appends to RECEIPT_CHAIN.ndjson
    Assumptions: pipeline is importable and all 17 stages are functional
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

# ── S-tier criteria definitions ───────────────────────────────────────────────

S_TIER_CRITERIA: list[dict[str, Any]] = [
    {
        "id": "ST-001",
        "name": "no_auto_pass_sentinels",
        "description": "Zero auto-pass sentinels (governance_compliant=True with no evidence, etc.)",
        "measurable": True,
        "threshold": 1.0,  # sentinel_count == 0
    },
    {
        "id": "ST-002",
        "name": "byte_backed_artifacts",
        "description": "All outputs are byte-backed artifacts with SHA-256 hash verification",
        "measurable": True,
        "threshold": 1.0,  # all artifacts have result_hash
    },
    {
        "id": "ST-003",
        "name": "failure_modes_declared",
        "description": "Failure modes pre-declared and tested (at least 1 per stage)",
        "measurable": True,
        "threshold": 1.0,  # failure_modes list non-empty
    },
    {
        "id": "ST-004",
        "name": "integration_contract_explicit",
        "description": "Integration contract explicit and machine-checkable (inputs/outputs/side_effects/assumptions)",
        "measurable": True,
        "threshold": 1.0,  # all 4 contract fields present
    },
    {
        "id": "ST-005",
        "name": "fir_contribution_score",
        "description": "FIR composite score >= 0.95 for this stage's contribution",
        "measurable": True,
        "threshold": 0.95,
    },
    {
        "id": "ST-006",
        "name": "trace_anomaly_free",
        "description": "TRACE_ANALYSIS shows no anomalies for this stage across 3 consecutive runs",
        "measurable": True,
        "threshold": 1.0,  # anomaly_count == 0 for 3 runs
    },
]

# ── Priority order with full justification ────────────────────────────────────

STAGE_PRIORITY_ORDER: list[dict[str, Any]] = [
    # WAVE 1 — Foundation (upstream dependencies for everything)
    {
        "stage": "SEE",
        "wave": 1,
        "reason": "Root of evidence chain. Every downstream stage depends on SEE evidence quality. A weak SEE invalidates all 16 downstream stages.",
        "key_gap": "Evidence quality scoring absent — syntactically valid but semantically thin evidence passes.",
        "s_tier_fix": "Add word-count threshold per atom AND keyword overlap check between query and result dimension.",
    },
    {
        "stage": "NORMALIZE_EVIDENCE",
        "wave": 1,
        "reason": "Second in chain. Transforms raw SEE output into structured atoms. Must be S-tier before MMD can operate on quality-graded evidence.",
        "key_gap": "Quality classification stops at GOOD/THIN/EMPTY — no semantic relevance scoring.",
        "s_tier_fix": "Add keyword overlap score between query and result. Atoms below threshold → IRRELEVANT, pipeline blocks.",
    },
    {
        "stage": "MMD",
        "wave": 1,
        "reason": "Structural gap detector. Depends on SEE and NORMALIZE_EVIDENCE. ACA (semantic invariant detection) is defined but not wired into MMD as a sub-check.",
        "key_gap": "ACA is missing as inline sub-check. MMD detects structural gaps but not missing invariants.",
        "s_tier_fix": "Wire ACA inline. MMD must call ACA and block on missing invariants, not just chain gaps.",
    },
    # WAVE 2 — Enforcement (define what quality means, must precede implementation verification)
    {
        "stage": "CDR",
        "wave": 2,
        "reason": "Defines code quality law. Pillar 2 constraint verification must be S-tier before IMPLEMENTATION and VERIFICATION can be trusted.",
        "key_gap": "Pillar 2 accepts any non-empty constraint list. Constraints are not machine-verifiable.",
        "s_tier_fix": "Each constraint must be a testable assertion (e.g., has operator, left_operand, right_operand). Prose-only constraints are rejected.",
    },
    {
        "stage": "POLICY_ENGINE",
        "wave": 2,
        "reason": "Central policy registry. Currently has 6 policies. Must have 12 before VERIFICATION and ECL can be considered S-tier (one per R12-FI gate).",
        "key_gap": "P-007 through P-012 not yet defined (R3 ethical probe, R6 redundancy, R7 testability, R8 failure, R9 docs, R10 integration).",
        "s_tier_fix": "Define and register P-007 through P-012 mapping to R3/R6/R7/R8/R9/R10.",
    },
    {
        "stage": "IMPLEMENTATION",
        "wave": 2,
        "reason": "Builds the artifact. Must verify syntactic validity before issuing receipt. Upstream from VERIFICATION.",
        "key_gap": "No compile/parse check on .py artifacts. Hash is verified but syntax is not.",
        "s_tier_fix": "compile() check on any .py artifact. RuntimeError on SyntaxError before hash receipt is written.",
    },
    {
        "stage": "VERIFICATION",
        "wave": 2,
        "reason": "Central gate. Depends on CDR, OFM, SSO, IMPLEMENTATION. Must be S-tier before DEBUGGING can claim meaningful root causes.",
        "key_gap": "Check 5 verifies OFM success_criteria exist but does not check any criterion is satisfied.",
        "s_tier_fix": "At least one success criterion must have measurable=True and a testable value. VERIFICATION checks it.",
    },
    # WAVE 3 — Planning (feeds IMPLEMENTATION, must be S-tier so IMPLEMENTATION operates on verified plans)
    {
        "stage": "DRS",
        "wave": 3,
        "reason": "Decision records. Auto-generation means records are never reviewed. Must be S-tier before IMPLEMENTATION can claim decisions were deliberate.",
        "key_gap": "Auto-generated decisions have no review flag. VERIFICATION cannot distinguish reviewed from auto-generated.",
        "s_tier_fix": "Auto-generated records must carry auto_generated=True. VERIFICATION emits warning when auto_generated=True.",
    },
    {
        "stage": "OFM",
        "wave": 3,
        "reason": "Success/failure criteria. Feeds VERIFICATION check 5. Must be S-tier so VERIFICATION can actually evaluate criteria.",
        "key_gap": "success_criteria is a list of strings. No measurability flag. VERIFICATION cannot evaluate any of them.",
        "s_tier_fix": "Each criterion requires measurable: true/false. At least one must be measurable: true. VERIFICATION evaluates it.",
    },
    {
        "stage": "ADS",
        "wave": 3,
        "reason": "Architecture decisions. Ghost dependency check done. Missing: circular dependency detection (a DAG violation would silently corrupt execution order).",
        "key_gap": "No topological sort check on dependency_map. Circular deps would cause infinite loops at runtime.",
        "s_tier_fix": "Topological sort of dependency_map. RuntimeError on cycle detection: ADS_CIRCULAR_DEPENDENCY.",
    },
    {
        "stage": "RRP",
        "wave": 3,
        "reason": "Recovery planning. Failure modes must be detectable to be actionable. Without detectable_by, DEBUGGING cannot know which mode triggered.",
        "key_gap": "failure_modes have no detectable_by field. DEBUGGING cannot link root_cause to RRP mode.",
        "s_tier_fix": "Each failure mode requires detectable_by field: how the system would know this failure occurred.",
    },
    # WAVE 4 — Observability (validates and measures everything, depends on all prior waves)
    {
        "stage": "TRACE_ANALYSIS",
        "wave": 4,
        "reason": "Anomaly detection depends on knowing expected artifact schemas per stage. Without per-stage schemas, THIN_ARTIFACT detection is heuristic-only.",
        "key_gap": "Anomaly detection checks key count but not key names. Wrong keys with correct count passes silently.",
        "s_tier_fix": "Per-stage artifact schema registry. TRACE_ANALYSIS validates artifact keys against schema, not just count.",
    },
    {
        "stage": "FIR_ENGINE",
        "wave": 4,
        "reason": "R12 meta-reflection. Currently 4 criteria. S-tier requires 8 (one per R12-FI gate in the current pipeline), delta tracking across sessions, and COEVOLUTION_LOG writes.",
        "key_gap": "4 criteria only. No cross-session delta. No COEVOLUTION_LOG writes on commit.",
        "s_tier_fix": "Expand to 8 criteria. Add prior_session_score tracking. Write COEVOLUTION_LOG on every COMMITTED result.",
    },
    # WAVE 5 — Supporting (important but not blocking for the core pipeline)
    {
        "stage": "UXR",
        "wave": 5,
        "reason": "User constraints. After WAVE 4 is S-tier, UXR constraints can be linked to specific stage outputs that enforce them.",
        "key_gap": "Constraints are unattached — auditability constraint exists but nothing enforces it maps to NORMALIZE_EVIDENCE.",
        "s_tier_fix": "Each constraint requires enforced_by field naming the stage that enforces it. Unattached constraints are rejected.",
    },
    {
        "stage": "NUF",
        "wave": 5,
        "reason": "Non-functional requirements. Ordered before SSO because NUF requirements constrain what goes in-scope (you cannot scope in a performance feature without a performance requirement).",
        "key_gap": "Requirements have category and description but no measurable threshold.",
        "s_tier_fix": "Each requirement requires threshold field (e.g., threshold: '< 100ms'). Prose-only requirements are WARN-level.",
    },
    {
        "stage": "SSO",
        "wave": 5,
        "reason": "Scope outline. Ordered after NUF because scope items should only be admitted if they have a corresponding NUF requirement. MONITOR is last because it reads all other stages.",
        "key_gap": "in_scope items have no stage owner. A scope item with no enforcing stage is a design gap.",
        "s_tier_fix": "Each in_scope item requires enforced_by naming the stage responsible for it.",
    },
    {
        "stage": "MONITOR",
        "wave": 5,
        "reason": "MONITOR reads all 17 stages to compute health score. It is last because it cannot be meaningfully S-tier until all stages it monitors are themselves S-tier. Upgrading MONITOR before its inputs are reliable produces misleading health scores.",
        "key_gap": "Health score from 5 signals only. Requeue threshold hardcoded. All 17 stages should contribute a signal.",
        "s_tier_fix": "Each stage registers a health signal. Threshold becomes configurable. MONITOR reaches S-tier when all 17 signals are wired.",
    },
]

# ── Receipt data structures ───────────────────────────────────────────────────


@dataclass
class StageUpgradeReceipt:
    """SHA-256 anchored receipt for a single stage upgrade."""

    receipt_id: str
    stage_name: str
    wave: int
    session_id: str
    baseline_score: float
    final_score: float
    delta: float
    s_tier_achieved: bool
    criteria_results: list[dict[str, Any]]
    research_findings: list[str]
    improvements_applied: list[str]
    remaining_gaps: list[str]
    fir_result: dict[str, Any]
    timestamp: str
    content_hash: str = ""  # SHA-256 of all fields except content_hash

    def compute_hash(self) -> str:
        """Compute SHA-256 over all receipt content. Anchors receipt to content."""
        payload = {
            "receipt_id": self.receipt_id,
            "stage_name": self.stage_name,
            "baseline_score": self.baseline_score,
            "final_score": self.final_score,
            "delta": self.delta,
            "s_tier_achieved": self.s_tier_achieved,
            "improvements_applied": self.improvements_applied,
            "timestamp": self.timestamp,
        }
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        d = {
            "schema": "mb.lfis_receipt.v1",
            "receipt_id": self.receipt_id,
            "stage_name": self.stage_name,
            "wave": self.wave,
            "session_id": self.session_id,
            "baseline_score": round(self.baseline_score, 4),
            "final_score": round(self.final_score, 4),
            "delta": round(self.delta, 4),
            "s_tier_achieved": self.s_tier_achieved,
            "criteria_results": self.criteria_results,
            "research_findings": self.research_findings,
            "improvements_applied": self.improvements_applied,
            "remaining_gaps": self.remaining_gaps,
            "fir_result": self.fir_result,
            "timestamp": self.timestamp,
            "content_hash": self.content_hash,
        }
        return d


@dataclass
class MetaGap:
    """A gap discovered during meta-improvement research."""

    gap_id: str
    source_stage: str
    gap_type: str  # UPSTREAM | DOWNSTREAM | LATERAL | INTERNAL
    description: str
    target_stage: str  # which stage is affected
    priority: int  # lower = higher priority

    def to_dict(self) -> dict[str, Any]:
        return {
            "gap_id": self.gap_id,
            "source_stage": self.source_stage,
            "gap_type": self.gap_type,
            "description": self.description,
            "target_stage": self.target_stage,
            "priority": self.priority,
        }


# ── Gap classifier ────────────────────────────────────────────────────────────

STAGE_INDEX: dict[str, int] = {
    s["stage"]: i for i, s in enumerate(STAGE_PRIORITY_ORDER)
}


def classify_meta_gap(
    source_stage: str,
    gap_description: str,
    affected_stage: str,
) -> MetaGap:
    """
    Classify a gap discovered during meta-improvement research.

    Rules:
      UPSTREAM   → affected_stage comes before source_stage in priority order
                   → inserted at HEAD of remaining queue
      DOWNSTREAM → affected_stage comes after source_stage
                   → appended after current stage's final loop
      LATERAL    → affected_stage is in a different wave but same level
                   → sent to end of current wave
      INTERNAL   → affected_stage is same as source_stage
                   → next loop iteration target

    Priority assignment:
      UPSTREAM: 0 (highest — fix foundation before continuing)
      INTERNAL: 1 (fix current stage before advancing)
      LATERAL:  2 (fix same-wave peer before advancing to next wave)
      DOWNSTREAM: 3 (fix after current stage completes)
    """
    source_idx = STAGE_INDEX.get(source_stage, 999)
    affected_idx = STAGE_INDEX.get(affected_stage, 999)

    if affected_stage == source_stage:
        gap_type = "INTERNAL"
        priority = 1
    elif affected_idx < source_idx:
        gap_type = "UPSTREAM"
        priority = 0
    elif affected_idx > source_idx:
        # Check if same wave
        source_wave = next(
            (s["wave"] for s in STAGE_PRIORITY_ORDER if s["stage"] == source_stage), 0
        )
        affected_wave = next(
            (s["wave"] for s in STAGE_PRIORITY_ORDER if s["stage"] == affected_stage), 0
        )
        if source_wave == affected_wave:
            gap_type = "LATERAL"
            priority = 2
        else:
            gap_type = "DOWNSTREAM"
            priority = 3
    else:
        gap_type = "INTERNAL"
        priority = 1

    return MetaGap(
        gap_id=f"MGAP-{uuid.uuid4().hex[:8]}",
        source_stage=source_stage,
        gap_type=gap_type,
        description=gap_description,
        target_stage=affected_stage,
        priority=priority,
    )


# ── LFIS runner ───────────────────────────────────────────────────────────────


class LFISRunner:
    """
    Orchestrates the Layered Forced Improvement System.

    Usage:
        runner = LFISRunner(output_dir=Path("./lfis_output"), session_id="SESSION-001")
        runner.run_wave(wave=1)
        # or
        runner.run_all_waves()

    Each wave runs improvement loops for all stages in that wave.
    Each stage gets max MAX_LOOPS_PER_STAGE improvement iterations.
    Remaining gaps go to HARDENING_BACKLOG.
    """

    MAX_LOOPS_PER_STAGE: int = 3
    MIN_DELTA_TO_CONTINUE: float = 0.05
    S_TIER_THRESHOLD: float = 0.95

    def __init__(self, output_dir: Path, session_id: str) -> None:
        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.session_id = session_id
        self.receipt_chain: list[dict[str, Any]] = []
        self.hardening_backlog: list[dict[str, Any]] = []
        self.s_tier_stages: list[str] = []
        self.meta_gap_queue: list[MetaGap] = []

    def score_stage(self, stage_name: str, stage_data: dict[str, Any]) -> float:
        """
        Score a stage against S-tier criteria.
        Returns composite score 0.0 - 1.0.
        This is the baseline scorer — each criterion contributes equally.
        Real implementation extends this with stage-specific checks.
        """
        scores: list[float] = []

        # ST-001: no auto-pass sentinels
        auto_pass_fields = [
            "governance_compliant",
            "tests_passed",
            "complete",
            "all_passed",
        ]
        has_sentinel = any(
            stage_data.get(f) is True and len(stage_data) == 1 for f in auto_pass_fields
        )
        scores.append(0.0 if has_sentinel else 1.0)

        # ST-002: byte-backed artifacts
        has_hash = bool(
            stage_data.get("result_hash")
            or stage_data.get("artifact_hash")
            or stage_data.get("content_hash")
        )
        scores.append(1.0 if has_hash else 0.0)

        # ST-003: failure modes declared
        has_failure_modes = bool(
            stage_data.get("failure_modes")
            or stage_data.get("anticipated_failure_intent")
        )
        scores.append(1.0 if has_failure_modes else 0.0)

        # ST-004: integration contract
        contract = stage_data.get("integration_contract", {})
        contract_complete = all(
            k in contract for k in ("inputs", "outputs", "side_effects", "assumptions")
        )
        scores.append(1.0 if contract_complete else 0.0)

        # ST-005: FIR contribution >= 0.95 (placeholder until FIR is wired)
        fir_score = stage_data.get("fir_contribution_score", 0.0)
        scores.append(1.0 if fir_score >= self.S_TIER_THRESHOLD else 0.0)

        # ST-006: trace anomaly free (placeholder until 3-run history exists)
        anomaly_free = stage_data.get("trace_anomaly_free", False)
        scores.append(1.0 if anomaly_free else 0.0)

        return sum(scores) / len(scores)

    def write_receipt(self, receipt: StageUpgradeReceipt) -> Path:
        """Write SHA-256 anchored receipt to disk and append to chain."""
        receipt.content_hash = receipt.compute_hash()
        receipt_dict = receipt.to_dict()

        # Write individual receipt
        path = self.output_dir / f"STAGE_UPGRADE_RECEIPT_{receipt.stage_name}.json"
        path.write_text(json.dumps(receipt_dict, indent=2))

        # Append to chain (append-only)
        chain_path = self.output_dir / "RECEIPT_CHAIN.ndjson"
        with chain_path.open("a") as f:
            f.write(
                json.dumps(
                    {
                        "receipt_id": receipt.receipt_id,
                        "stage": receipt.stage_name,
                        "hash": receipt.content_hash,
                        "timestamp": receipt.timestamp,
                    }
                )
                + "\n"
            )

        self.receipt_chain.append(receipt_dict)
        return path

    def run_stage(
        self,
        stage_config: dict[str, Any],
        stage_data: dict[str, Any],
        improvement_fn: Any = None,
    ) -> StageUpgradeReceipt:
        """
        Run the improvement loop for a single stage.

        improvement_fn: callable(stage_name, gap) -> (improved_data, findings, applied)
                        If None, uses a stub that logs the gap without changing data.
        """
        stage_name = stage_config["stage"]
        now = datetime.now(timezone.utc).isoformat()

        baseline = self.score_stage(stage_name, stage_data)
        current_score = baseline
        current_data = dict(stage_data)
        all_findings: list[str] = []
        all_applied: list[str] = []
        remaining_gaps: list[str] = []
        meta_gaps_found: list[MetaGap] = []

        for loop_num in range(self.MAX_LOOPS_PER_STAGE):
            if current_score >= self.S_TIER_THRESHOLD:
                break  # already S-tier

            # Step 1: Research — what gap exists right now
            current_gap = stage_config["key_gap"]
            s_tier_fix = stage_config["s_tier_fix"]

            # Step 2: Implement improvement (or stub)
            if improvement_fn is not None:
                improved_data, findings, applied = improvement_fn(
                    stage_name, current_gap
                )
                current_data.update(improved_data)
                all_findings.extend(findings)
                all_applied.extend(applied)
            else:
                # Stub: record what would be done
                all_findings.append(f"Loop {loop_num + 1}: {current_gap}")
                all_applied.append(f"PLANNED: {s_tier_fix}")

            # Step 3: Re-score
            new_score = self.score_stage(stage_name, current_data)
            delta = new_score - current_score

            if delta < self.MIN_DELTA_TO_CONTINUE and loop_num > 0:
                remaining_gaps.append(current_gap)
                break  # diminishing returns

            current_score = new_score

            # Step 4: Meta-improvement — did this fix reveal new gaps?
            # Check upstream and downstream stage contracts
            upstream_stages = [
                s["stage"]
                for s in STAGE_PRIORITY_ORDER
                if s["stage"] != stage_name
                and STAGE_INDEX.get(s["stage"], 999) < STAGE_INDEX.get(stage_name, 999)
            ]
            for upstream in upstream_stages[-2:]:  # check nearest 2 upstream
                # Heuristic: if our fix changes interface expectations, upstream may need update
                if "contract" in s_tier_fix.lower() or "input" in s_tier_fix.lower():
                    gap = classify_meta_gap(
                        source_stage=stage_name,
                        gap_description=f"{stage_name} S-tier fix changes input contract — {upstream} may need update",
                        affected_stage=upstream,
                    )
                    meta_gaps_found.append(gap)

        # Add meta-gaps to queue with proper routing
        for mg in meta_gaps_found:
            self.meta_gap_queue.append(mg)

        # Gaps that didn't close → hardening backlog
        if current_score < self.S_TIER_THRESHOLD:
            remaining_gaps.append(
                f"{stage_name} did not reach S-tier ({current_score:.3f} < {self.S_TIER_THRESHOLD}). "
                f"Requires operator review."
            )
            self.hardening_backlog.append(
                {
                    "stage": stage_name,
                    "final_score": current_score,
                    "gap": stage_config["key_gap"],
                    "fix": stage_config["s_tier_fix"],
                }
            )

        s_tier_achieved = current_score >= self.S_TIER_THRESHOLD
        if s_tier_achieved:
            self.s_tier_stages.append(stage_name)

        receipt = StageUpgradeReceipt(
            receipt_id=f"RECEIPT-{uuid.uuid4().hex[:12]}",
            stage_name=stage_name,
            wave=stage_config["wave"],
            session_id=self.session_id,
            baseline_score=baseline,
            final_score=current_score,
            delta=current_score - baseline,
            s_tier_achieved=s_tier_achieved,
            criteria_results=[
                {"criterion": c["name"], "threshold": c["threshold"]}
                for c in S_TIER_CRITERIA
            ],
            research_findings=all_findings,
            improvements_applied=all_applied,
            remaining_gaps=remaining_gaps,
            fir_result={"status": "COMMITTED" if s_tier_achieved else "REJECTED"},
            timestamp=now,
        )
        return receipt

    def run_wave(self, wave: int) -> list[StageUpgradeReceipt]:
        """Run all stages in a given wave."""
        wave_stages = [s for s in STAGE_PRIORITY_ORDER if s["wave"] == wave]
        receipts: list[StageUpgradeReceipt] = []

        for stage_config in wave_stages:
            # Stub stage_data — real implementation passes actual pipeline state
            stage_data: dict[str, Any] = {}
            receipt = self.run_stage(stage_config, stage_data)
            path = self.write_receipt(receipt)
            receipts.append(receipt)
            print(
                f"  Wave {wave} | {stage_config['stage']}: "
                f"score={receipt.final_score:.3f} "
                f"s_tier={receipt.s_tier_achieved} "
                f"receipt={path.name}"
            )

        # Process meta-gap queue after each wave
        upstream_gaps = [g for g in self.meta_gap_queue if g.gap_type == "UPSTREAM"]
        if upstream_gaps:
            print(
                f"  ⚠ {len(upstream_gaps)} UPSTREAM meta-gaps flagged — will be addressed before Wave {wave + 1}"
            )

        return receipts

    def run_all_waves(self) -> dict[str, Any]:
        """Run all 5 waves in order. Write final report."""
        print(f"\n=== LFIS SESSION {self.session_id} ===\n")
        all_receipts: list[StageUpgradeReceipt] = []

        for wave in range(1, 6):
            print(f"\n--- Wave {wave} ---")
            receipts = self.run_wave(wave)
            all_receipts.extend(receipts)

        # Final report
        total_stages = len(STAGE_PRIORITY_ORDER)
        s_tier_count = len(self.s_tier_stages)
        now = datetime.now(timezone.utc).isoformat()

        report = {
            "schema": "mb.lfis_final_report.v1",
            "session_id": self.session_id,
            "timestamp": now,
            "total_stages": total_stages,
            "s_tier_achieved": s_tier_count,
            "s_tier_stages": self.s_tier_stages,
            "hardening_backlog_count": len(self.hardening_backlog),
            "hardening_backlog": self.hardening_backlog,
            "meta_gaps_generated": len(self.meta_gap_queue),
            "meta_gaps": [g.to_dict() for g in self.meta_gap_queue],
            "receipt_count": len(all_receipts),
            "system_complete": s_tier_count == total_stages,
            "completion_percentage": round(s_tier_count / total_stages * 100, 1),
        }

        report_path = self.output_dir / "LFIS_FINAL_REPORT.json"
        report_path.write_text(json.dumps(report, indent=2))
        print(f"\n=== FINAL REPORT: {s_tier_count}/{total_stages} stages S-tier ===")
        print(f"Backlog: {len(self.hardening_backlog)} stages need operator review")
        print(f"Report: {report_path}")

        return report
