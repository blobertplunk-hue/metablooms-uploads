"""
KERNEL_SUPERVISOR.py — MetaBlooms Kernel Supervisor v1

CDR V1 (Intent): The GovernanceKernel runs once at boot and issues an approval
token. After that, nothing re-checks whether engine files changed during the
session. This engine closes that gap. It runs a lightweight heartbeat at the
start of every turn, re-verifying the engines that are critical to that turn's
operation. Architecture drift that happens mid-session is caught before the
next turn executes — not silently.

CDR V2 (Trust): Every heartbeat spot-checks real SHA256 hashes against the
ENGINE_REGISTRY.json that was verified at boot. It does not trust in-memory
state. It reads the actual files from disk.

CDR V3 (Boundary): KERNEL_SUPERVISOR monitors and reports. It does not repair
engine files, regenerate receipts, or modify the registry. When it finds drift,
it blocks the turn and tells the operator what changed. The operator fixes it.

CDR V4 (State): KERNEL_SUPERVISOR writes a KERNEL_HEARTBEAT receipt to
_bts/receipts/ on every turn. The receipt chain proves continuous integrity
across all turns of a session.

CDR V5 (Failure): Any SHA256 mismatch → turn BLOCKED. Missing engine file →
turn BLOCKED. Registry unreadable → DEGRADED (warn but allow). The kernel
never silently passes on a suspected violation.

constraint_mapping:
  - Full re-check (all engines) only at boot — use GovernanceKernel for that
  - Per-turn: spot-check CRITICAL_ENGINES list only (fast, ~5 files)
  - CRITICAL_ENGINES are the ones that gate execution: BTS, MPP_RUNTIME, SEE, governance_kernel, STAGE_PAYLOAD_VALIDATOR
  - BLOCKED status must prevent turn from accepting objectives
  - Heartbeat receipt is T1 (real file hash verified)

integration_reciprocity:
  Inputs:  runtime_root (Path), bts (BTS instance), turn_id (str)
  Outputs: HeartbeatResult (status, checks_passed, violations)
           T1 receipt written to _bts/receipts/KERNEL_HEARTBEAT_*.json
  Side effects: writes heartbeat receipt, logs to BTS
  Promises: PASS only when all CRITICAL_ENGINES match registry SHA256
  Callers: MetaBloomsOS.run_turn() at start, before SEE runs

legacy_impact_statement:
  Before this engine, the kernel token was issued once at boot and never
  re-validated. An engine modified during a session would run undetected.
  This engine makes kernel integrity continuous, not one-time.

ChatGPT behavioral contract:
  At start of every turn (before SEE):
    1. Run KERNEL_SUPERVISOR.heartbeat(turn_id)
    2. If status=BLOCKED: stop. Do not run SEE or any stage.
       Report which engines drifted. Operator must regenerate receipts.
    3. If status=DEGRADED: warn in turn report. Continue with caution.
    4. If status=PASS: proceed normally.
  Include heartbeat_status in turn result dict.
"""

from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = ["BTS", "SEE", "MPP_RUNTIME"]
REQUIRES_HASH = "a2ef2f6248d688af8bcb9417a97742b1a765a7070d9ee2929787669829428199"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


SCHEMA = "mb.kernel_supervisor.v1"

# The engines that must be clean every turn — the execution-critical ones
CRITICAL_ENGINES = [
    "BTS.py",
    "MPP_RUNTIME.py",
    "SEE.py",
    "governance_kernel.py",
    "STAGE_PAYLOAD_VALIDATOR.py",
    "RECONCILIATION_VALIDATOR.py",
]


@dataclass
class HeartbeatResult:
    """Result of per-turn kernel heartbeat check."""
    turn_id: str
    status: str = "PENDING"  # PASS | DEGRADED | BLOCKED
    checks_passed: List[str] = field(default_factory=list)
    violations: List[str] = field(default_factory=list)
    engines_checked: int = 0
    receipt_path: str = ""
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    @property
    def safe_to_proceed(self) -> bool:
        return self.status in ("PASS", "DEGRADED")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema": SCHEMA,
            "turn_id": self.turn_id,
            "status": self.status,
            "checks_passed": self.checks_passed,
            "violations": self.violations,
            "engines_checked": self.engines_checked,
            "receipt_path": self.receipt_path,
            "timestamp": self.timestamp,
        }


class KernelSupervisor:
    """
    Per-turn kernel integrity monitor.

    Runs a fast SHA256 spot-check of CRITICAL_ENGINES at the start of
    every turn. Compared against ENGINE_REGISTRY.json verified at boot.
    Issues T1 heartbeat receipt for each passing check.
    """

    def __init__(self, runtime_root: str | Path, bts=None) -> None:
        self.root      = Path(runtime_root)
        self.bts       = bts
        self._registry = self.root / "ENGINE_REGISTRY.json"
        self._engines  = self.root / "engines"
        self._receipts = self.root / "_bts" / "receipts"
        self._receipts.mkdir(parents=True, exist_ok=True)
        self._registry_cache: Optional[Dict] = None

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _compact(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    def _load_registry(self) -> Optional[Dict]:
        """Load ENGINE_REGISTRY.json. Cache it — it shouldn't change mid-session."""
        if self._registry_cache is not None:
            return self._registry_cache
        if not self._registry.exists():
            return None
        try:
            data = json.loads(self._registry.read_text(encoding="utf-8"))
            # Build lookup: engine_name → sha256
            self._registry_cache = {
                e["engine"]: e["sha256"]
                for e in data.get("engines", [])
            }
            return self._registry_cache
        except Exception:
            return None

    def heartbeat(self, turn_id: str) -> HeartbeatResult:
        """
        Run per-turn kernel heartbeat.
        Spot-checks CRITICAL_ENGINES against registry SHA256.
        Writes T1 receipt. Returns HeartbeatResult.
        Emits TRACE_SPAN (COEV-019).
        """
        # TRACE_SPAN — side-effect safe, failure-tolerant
        _emitter = None; _span_id = ""
        try:
            import sys as _s, os as _o
            _utils = _o.path.join(_o.path.dirname(__file__), "utils")
            if _utils not in _s.path: _s.path.insert(0, _utils)
            from TRACE_SPAN_EMITTER import get_emitter
            _emitter = get_emitter(self.root)
            _span_id = _emitter.start("KERNEL_SUPERVISOR", turn_id=turn_id)
        except Exception:
            pass

        result = HeartbeatResult(turn_id=turn_id)

        registry = self._load_registry()
        if registry is None:
            # Registry unreadable — DEGRADED, not BLOCKED
            # (first session before registry generated)
            result.status = "DEGRADED"
            result.violations.append(
                "ENGINE_REGISTRY_MISSING: cannot verify engine integrity. "
                "Run build_bundle() to generate registry."
            )
            self._write_heartbeat_receipt(result)
            return result

        # Spot-check each critical engine
        # Pre-check: ENGINE_DEPENDENCY_GRAPH.json must exist (COEV-011 — constitutional artifact)
        dep_graph = self.root / "ENGINE_DEPENDENCY_GRAPH.json"
        if not dep_graph.exists():
            result.violations.append(
                "DEPENDENCY_GRAPH_MISSING: ENGINE_DEPENDENCY_GRAPH.json not found. "
                "This artifact is constitutionally required. Rebuild bundle."
            )
            result.status = "BLOCKED"
            self._write_heartbeat_receipt(result)
            try:
                if _emitter and _span_id:
                    _emitter.fail(_span_id, error="DEPENDENCY_GRAPH_MISSING",
                                  metadata={"turn_id": turn_id, "status": "BLOCKED"})
            except Exception:
                pass
            return result

        for engine_name in CRITICAL_ENGINES:
            engine_path = self._engines / engine_name
            engine_key  = Path(engine_name).stem  # "BTS.py" → "BTS"

            if not engine_path.exists():
                result.violations.append(
                    f"ENGINE_MISSING: {engine_name} not found at {engine_path}"
                )
                result.engines_checked += 1
                continue

            # Hash actual file
            actual_sha = hashlib.sha256(engine_path.read_bytes()).hexdigest()
            result.engines_checked += 1

            # Compare against registry
            if engine_key not in registry:
                # Not in registry — might be a new engine added this session
                result.checks_passed.append(f"{engine_name}: not in registry (new engine)")
                continue

            expected_sha = registry[engine_key]
            if actual_sha != expected_sha:
                result.violations.append(
                    f"SHA256_DRIFT: {engine_name} "
                    f"expected={expected_sha[:12]} actual={actual_sha[:12]} "
                    f"— engine was modified after boot"
                )
            else:
                result.checks_passed.append(f"{engine_name}: SHA256 verified")

        # Determine status
        if result.violations:
            # SHA256 drift on any critical engine = BLOCKED
            drift_violations = [v for v in result.violations if "SHA256_DRIFT" in v]
            missing_violations = [v for v in result.violations if "ENGINE_MISSING" in v]
            if drift_violations or missing_violations:
                result.status = "BLOCKED"
            else:
                result.status = "DEGRADED"
        else:
            result.status = "PASS"

        self._write_heartbeat_receipt(result)

        try:
            if _emitter and _span_id:
                _emitter.end(_span_id, success=(result.status == "PASS"), metadata={
                    "turn_id": turn_id,
                    "status": result.status,
                    "engines_checked": result.engines_checked,
                    "violations": len(result.violations),
                })
        except Exception:
            pass

        return result

    def _write_heartbeat_receipt(self, result: HeartbeatResult) -> None:
        """Write T1 heartbeat receipt."""
        receipt = {
            "schema": SCHEMA,
            "tier": "T1",
            "receipt_id": f"HB-{uuid.uuid4().hex[:8].upper()}",
            "artifact_type": "kernel_heartbeat",
            "turn_id": result.turn_id,
            "status": result.status,
            "engines_checked": result.engines_checked,
            "checks_passed_count": len(result.checks_passed),
            "violations_count": len(result.violations),
            "violations": result.violations,
            "timestamp": self._now(),
        }
        receipt_path = self._receipts / f"KERNEL_HEARTBEAT_{result.turn_id}_{self._compact()}.json"
        receipt_path.write_text(json.dumps(receipt, indent=2), encoding="utf-8")
        result.receipt_path = str(receipt_path)

        # Log to BTS
        if self.bts:
            try:
                self.bts._log_entry({
                    "event": "KERNEL_HEARTBEAT",
                    "turn_id": result.turn_id,
                    "status": result.status,
                    "engines_checked": result.engines_checked,
                    "violations": result.violations,
                })
            except Exception:
                pass

        # AUTO-RECORD violations to learning engine
        if result.violations:
            self._record_violations_to_learning(result)

    _VIOLATION_MAP = {
        "SHA256_DRIFT":    "ME-BTS-001",
        "ENGINE_MISSING":  "ME-BTS-001",
    }

    def _record_violations_to_learning(self, result: HeartbeatResult) -> None:
        """Auto-record KERNEL_SUPERVISOR violations to LEARNING_ENGINE."""
        try:
            import sys as _sys, os as _os
            _here = _os.path.dirname(_os.path.abspath(__file__))
            if _here not in _sys.path: _sys.path.insert(0, _here)
            from LEARNING_ENGINE import LearningEngine
            le = LearningEngine(self.root)
            for v in result.violations:
                mc = next((mc_id for pat, mc_id in self._VIOLATION_MAP.items() if pat in v), None)
                le.record_outcome(
                    action_class="kernel_integrity",
                    module="KERNEL_SUPERVISOR",
                    outcome={"violation": v[:100], "turn_id": result.turn_id},
                    success=False,
                    mistake_class=mc,
                    notes=f"Kernel heartbeat BLOCKED: {v[:80]}",
                )
        except Exception:
            pass

    def full_audit(self) -> Dict[str, Any]:
        """
        Full audit — check ALL engines in registry, not just critical ones.
        Use at end of session, not per-turn.
        """
        registry = self._load_registry()
        if not registry:
            return {"status": "REGISTRY_MISSING", "engines_checked": 0}

        passed, failed = [], []
        for engine_name, expected_sha in registry.items():
            engine_path = self._engines / f"{engine_name}.py"
            if not engine_path.exists():
                failed.append(f"MISSING: {engine_name}.py")
                continue
            actual = hashlib.sha256(engine_path.read_bytes()).hexdigest()
            if actual == expected_sha:
                passed.append(engine_name)
            else:
                failed.append(f"DRIFT: {engine_name} expected={expected_sha[:12]} actual={actual[:12]}")

        return {
            "status": "PASS" if not failed else "DRIFT_DETECTED",
            "engines_checked": len(passed) + len(failed),
            "passed": len(passed),
            "failed": len(failed),
            "failures": failed,
        }


# ── Self-test ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, tempfile, shutil
    from pathlib import Path

    print("KERNEL_SUPERVISOR self-test...")

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        engines_dir = root / "engines"
        engines_dir.mkdir(parents=True)
        receipts_dir = root / "_bts" / "receipts"
        receipts_dir.mkdir(parents=True)

        # Create test engines
        for name in CRITICAL_ENGINES:
            (engines_dir / name).write_text(f"# {name}", encoding="utf-8")

        # Build ENGINE_REGISTRY.json
        entries = []
        for name in CRITICAL_ENGINES:
            p = engines_dir / name
            entries.append({
                "engine": Path(name).stem,
                "path": f"engines/{name}",
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
            })
        (root / "ENGINE_REGISTRY.json").write_text(json.dumps({
            "engines": entries, "engine_count": len(entries)
        }))

        # Create ENGINE_DEPENDENCY_GRAPH.json — constitutionally required (COEV-011)
        # Fixture must mirror canonical runtime structure.
        (root / "ENGINE_DEPENDENCY_GRAPH.json").write_text(json.dumps({
            "schema": "mb.engine_dependency_graph.v1",
            "runtime_dependency_edges": {"edges": []},
            "artifact_authority": {"artifacts": []},
            "authority_edges": {"edges": []},
        }))

        ks = KernelSupervisor(root)

        # TEST 1: Clean engines pass
        r1 = ks.heartbeat("TURN-001")
        assert r1.status == "PASS", f"Expected PASS, got {r1.status}: {r1.violations}"
        assert r1.engines_checked == len(CRITICAL_ENGINES)
        assert r1.receipt_path and Path(r1.receipt_path).exists()
        print(f"  Clean engines: PASS ({r1.engines_checked} checked) ✓")

        # TEST 2: Modified engine → BLOCKED
        (engines_dir / "BTS.py").write_text("# MODIFIED", encoding="utf-8")
        ks._registry_cache = None  # force reload
        r2 = ks.heartbeat("TURN-002")
        assert r2.status == "BLOCKED", f"Expected BLOCKED, got {r2.status}"
        assert any("SHA256_DRIFT" in v and "BTS" in v for v in r2.violations)
        assert not r2.safe_to_proceed
        print(f"  Modified engine BLOCKED: {r2.violations[0][:60]} ✓")

        # TEST 3: Missing engine → BLOCKED
        (engines_dir / "MPP_RUNTIME.py").unlink()
        ks._registry_cache = None
        r3 = ks.heartbeat("TURN-003")
        assert r3.status == "BLOCKED"
        assert any("ENGINE_MISSING" in v for v in r3.violations)
        print(f"  Missing engine BLOCKED ✓")

        # TEST 4: No registry → DEGRADED (not BLOCKED)
        (root / "ENGINE_REGISTRY.json").unlink()
        ks._registry_cache = None
        r4 = ks.heartbeat("TURN-004")
        assert r4.status == "DEGRADED"
        assert r4.safe_to_proceed  # DEGRADED allows proceeding with warning
        print(f"  No registry: DEGRADED (safe_to_proceed=True) ✓")

        # TEST 5: Full audit
        (root / "ENGINE_REGISTRY.json").write_text(json.dumps({
            "engines": entries, "engine_count": len(entries)
        }))
        ks._registry_cache = None
        audit = ks.full_audit()
        # Some engines are missing/drifted from tests above
        assert "status" in audit
        print(f"  Full audit: status={audit['status']} passed={audit['passed']} failed={audit['failed']} ✓")

        print()
        print("KERNEL_SUPERVISOR SELF-TEST PASSED")
        sys.exit(0)
