"""
MPP_TASK_SCHEMA.py — JSON Schema for the MPP task dict
=======================================================

CDR V1 (Rationale):
    This is the bridge between the LLM cognitive layer (MPP_PROTOCOL.md)
    and the Python enforcement layer (MPP pipeline).
    The LLM reasons through 14 stages in prose.
    This schema defines what the Python pipeline expects to receive.
    The bridge converter (MPP_BRIDGE.py) maps prose → validated task dict.

CDR V2 (Trust):
    The schema is the contract. Every field is required unless marked optional.
    The Python pipeline trusts nothing not validated by this schema.
    schema_version is recorded on every task for rollback traceability.

CDR V3 (Boundary):
    Inputs:  LLM MPP trace (structured prose or JSON from MPP_PROTOCOL.md template)
    Outputs: Validated task dict passable directly to run_mpp()
    Side effects: none
    Assumptions: LLM has completed all 14 stages before submitting

CDR V4 (Failure):
    Schema validation failure → MPP_BRIDGE raises MPPSchemaError with field path.
    safe_state: reject task, return errors to LLM for correction. Never run
    a partially valid task through the pipeline.

CDR V5 (S-tier):
    schema_version field enables rollback and audit.
    result_hash on validated task for pipeline integrity.
    Comparable to: OpenAI function calling schema, Anthropic tool use schema.
"""

from __future__ import annotations

# ── JSON Schema (Draft 7 compatible) ─────────────────────────────────────────
# This is what jsonschema.validate() runs against the task dict.
# Every field maps to a specific MPP stage output.

MPP_TASK_SCHEMA: dict = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "title": "MPP Task",
    "description": "Validated input to the MPP Python pipeline. Produced by LLM following MPP_PROTOCOL.md.",
    "type": "object",
    "required": [
        "schema_version",
        "objective_id",
        "input",
        "sie_receipts",
        "cdr_constraints",
        "ofm",
        "ads",
        "uxr",
        "nuf",
        "sso",
        "rrp",
        "implementation",
    ],
    "additionalProperties": True,
    "properties": {
        # ── Meta ────────────────────────────────────────────────────────────
        "schema_version": {
            "type": "string",
            "description": "MPP task schema version. Use 'mpp.task.v1'.",
            "const": "mpp.task.v1",
        },
        "objective_id": {
            "type": "string",
            "minLength": 3,
            "description": "Unique identifier for this objective. Format: OBJ-<name>.",
        },
        "input": {
            "type": "string",
            "minLength": 10,
            "description": "Plain-language description of what is being built or improved.",
        },
        # ── Stage 1: SEE ─────────────────────────────────────────────────────
        "sie_receipts": {
            "type": "array",
            "minItems": 3,
            "description": "Evidence gathered by LLM in SEE stage. Must cover all 3 dimensions.",
            "items": {
                "type": "object",
                "required": ["dimension", "result", "result_hash", "source"],
                "properties": {
                    "dimension": {
                        "type": "string",
                        "enum": ["theory", "implementation", "failure_modes"],
                    },
                    "result": {
                        "type": "string",
                        "minLength": 10,
                        "description": "Evidence text. Minimum 10 characters (5+ words enforced by SEE stage).",
                    },
                    "result_hash": {
                        "type": "string",
                        "minLength": 64,
                        "maxLength": 64,
                        "description": "SHA-256 of result field.",
                    },
                    "source": {
                        "type": "string",
                        "description": "Evidence source. 'web.run' for web research, 'analysis' for artifact inspection.",
                    },
                },
            },
        },
        # ── Stage 4: CDR ─────────────────────────────────────────────────────
        "cdr_constraints": {
            "type": "object",
            "required": [
                "rationale",
                "constraints",
                "module_name",
                "failure_modes",
                "integration_contract",
                "attestation",
            ],
            "description": "CDR 7-pillar compliance record. All pillars must be addressed.",
            "properties": {
                "rationale": {
                    "type": "string",
                    "minLength": 20,
                    "description": "Pillar 1: WHY this exists. Proactive rationale before any WHAT.",
                },
                "constraints": {
                    "type": "array",
                    "minItems": 1,
                    "items": {"type": "string", "minLength": 5},
                    "description": "Pillar 2: Explicit constraints this implementation must satisfy.",
                },
                "module_name": {
                    "type": "string",
                    "pattern": "^[A-Z][A-Z0-9_]+\\.py$",
                    "description": "Pillar 3: Semantic domain authority. SCREAMING_SNAKE.py required. No utils/helpers/misc.",
                },
                "failure_modes": {
                    "type": "array",
                    "minItems": 1,
                    "description": "Pillar 4: Anticipated failure modes with safe states.",
                    "items": {
                        "type": "object",
                        "required": ["mode", "safe_state", "strategy", "detectable_by"],
                        "properties": {
                            "mode": {"type": "string"},
                            "safe_state": {"type": "string"},
                            "strategy": {
                                "type": "string",
                                "enum": [
                                    "rollback",
                                    "retry",
                                    "fallback",
                                    "halt",
                                    "escalate",
                                    "degrade",
                                ],
                            },
                            "detectable_by": {"type": "string", "minLength": 5},
                        },
                    },
                },
                "integration_contract": {
                    "type": "object",
                    "required": ["inputs", "outputs", "side_effects", "assumptions"],
                    "description": "Pillar 5: Integration reciprocity. Declare inputs, outputs, effects, assumptions.",
                    "properties": {
                        "inputs": {"type": "array", "items": {"type": "string"}},
                        "outputs": {"type": "array", "items": {"type": "string"}},
                        "side_effects": {"type": "array", "items": {"type": "string"}},
                        "assumptions": {"type": "array", "items": {"type": "string"}},
                    },
                },
                "supersedes": {
                    "type": "string",
                    "description": "Pillar 6 (optional): What prior implementation this replaces and why.",
                },
                "attestation": {
                    "type": "string",
                    "minLength": 10,
                    "description": "Pillar 7: LLM attestation — who, when, and that reasoning chain is reconstructible.",
                },
            },
        },
        # ── Stage 5: OFM ─────────────────────────────────────────────────────
        "ofm": {
            "type": "object",
            "required": ["objective_id", "success_criteria", "failure_criteria"],
            "properties": {
                "objective_id": {"type": "string"},
                "success_criteria": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "required": ["criterion", "measurable"],
                        "properties": {
                            "criterion": {"type": "string", "minLength": 5},
                            "measurable": {"type": "boolean"},
                            "threshold": {"type": "string"},
                        },
                    },
                    "description": "At least one criterion must have measurable=true.",
                },
                "failure_criteria": {
                    "type": "array",
                    "minItems": 1,
                    "items": {"type": "string"},
                },
            },
        },
        # ── Stage 6: ADS ─────────────────────────────────────────────────────
        "ads": {
            "type": "object",
            "required": ["engine_list", "dependency_map", "authority_map"],
            "properties": {
                "engine_list": {
                    "type": "array",
                    "minItems": 1,
                    "items": {"type": "string"},
                },
                "dependency_map": {
                    "type": "object",
                    "description": "Must be a DAG. Topological sort enforced by ADS stage.",
                },
                "authority_map": {
                    "type": "object",
                    "description": "Who owns what state or resource.",
                },
            },
        },
        # ── Stage 7: UXR ─────────────────────────────────────────────────────
        "uxr": {
            "type": "object",
            "required": ["operator"],
            "properties": {
                "operator": {"type": "string"},
                "constraints": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["name", "description"],
                        "properties": {
                            "name": {"type": "string"},
                            "description": {"type": "string"},
                        },
                    },
                },
                "no_constraints_justification": {"type": "string"},
            },
        },
        # ── Stage 8: NUF ─────────────────────────────────────────────────────
        "nuf": {
            "type": "object",
            "required": ["requirements"],
            "properties": {
                "requirements": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "required": ["category", "description", "threshold"],
                        "properties": {
                            "category": {
                                "type": "string",
                                "enum": [
                                    "performance",
                                    "reliability",
                                    "security",
                                    "determinism",
                                    "memory",
                                    "latency",
                                    "throughput",
                                ],
                            },
                            "description": {"type": "string"},
                            "threshold": {
                                "type": "string",
                                "description": "Measurable threshold — not prose. E.g. '< 100ms', '100%', '>= 0.99'",
                            },
                        },
                    },
                },
            },
        },
        # ── Stage 9: SSO ─────────────────────────────────────────────────────
        "sso": {
            "type": "object",
            "required": ["in_scope", "out_of_scope"],
            "properties": {
                "in_scope": {
                    "type": "array",
                    "minItems": 1,
                    "items": {"type": "string"},
                },
                "out_of_scope": {
                    "type": "array",
                    "minItems": 1,
                    "items": {"type": "string"},
                    "description": "Cannot be empty. There is always something out of scope.",
                },
            },
        },
        # ── Stage 10: RRP ────────────────────────────────────────────────────
        "rrp": {
            "type": "object",
            "required": ["failure_modes"],
            "properties": {
                "failure_modes": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "required": ["mode", "strategy", "detectable_by"],
                        "properties": {
                            "mode": {"type": "string"},
                            "strategy": {
                                "type": "string",
                                "enum": [
                                    "rollback",
                                    "retry",
                                    "fallback",
                                    "halt",
                                    "escalate",
                                    "degrade",
                                ],
                            },
                            "rollback_path": {"type": "string"},
                            "recovery_action": {"type": "string"},
                            "detectable_by": {"type": "string", "minLength": 5},
                        },
                    },
                },
            },
        },
        # ── Stage 11: IMPLEMENTATION ─────────────────────────────────────────
        "implementation": {
            "type": "object",
            "required": ["artifact_path", "artifact_hash", "artifact_content"],
            "properties": {
                "artifact_path": {
                    "type": "string",
                    "description": "Relative path to the artifact file.",
                },
                "artifact_hash": {
                    "type": "string",
                    "minLength": 64,
                    "maxLength": 64,
                    "description": "SHA-256 of artifact_content. Computed by LLM, verified by IMPLEMENTATION stage.",
                },
                "artifact_content": {
                    "type": "string",
                    "minLength": 1,
                    "description": "Full source code of the artifact. Must be syntactically valid Python if .py.",
                },
            },
        },
        # ── Stage 3: DRS (optional — auto-generated if absent) ───────────────
        "decisions": {
            "type": "array",
            "description": "DRS decision records. If absent, DRS auto-generates and flags auto_generated=True.",
            "items": {
                "type": "object",
                "required": [
                    "decision_id",
                    "decision",
                    "rationale",
                    "alternatives_considered",
                ],
                "properties": {
                    "decision_id": {"type": "string"},
                    "decision": {"type": "string"},
                    "rationale": {"type": "string"},
                    "alternatives_considered": {
                        "type": "array",
                        "minItems": 2,
                        "items": {"type": "string"},
                    },
                },
            },
        },
    },
}
