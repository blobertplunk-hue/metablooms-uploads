"""
STATE_LEDGER.py — MetaBlooms Turn State Ledger v2

CDR V1 (Intent): Give a stateless LLM continuity across turns. Without the
ledger, every turn starts from scratch. With it, every turn knows what was
accomplished, what failed, what artifacts exist, and what to do next.
The ledger IS the turn-to-turn memory.

CDR V2 (Trust): Every ledger write is backed by actual turn state from
MPP cycle results and BTS receipts. The session history is hash-chained —
each entry contains the SHA256 of the prior entry. The chain makes
retroactive modification detectable.

CDR V3 (Boundary): StateLedger reads and writes turn state. It does not
execute turns, evaluate fitness, or govern the pipeline. The causal execution
ledger records what caused what. The artifact ledger records what was written
where. Both are append-only.

CDR V4 (State): Three ledgers, all append-only:
  1. TURN_STATE_LEDGER.json — current turn state (overwritten each ECL)
  2. CAUSAL_EXECUTION_LEDGER.json — append-only causal chain
  3. SESSION_HISTORY.json — last 20 turns, SHA256-chained

constraint_mapping:
  - TURN_STATE_LEDGER.json is current state — overwritten each turn
  - SESSION_HISTORY.json is history — append only, never truncated past 20
  - CAUSAL_EXECUTION_LEDGER.json is causal chain — append only, never modified
  - Must NOT write ledger without actual turn_id and objective
  - Must NOT claim ledger_written=True if write failed

integration_reciprocity:
  Inputs:  turn_id, objective, mpp_result, see_result, artifacts_written
  Outputs: state/TURN_STATE_LEDGER.json, state/SESSION_HISTORY.json
  Side effects: appends to SESSION_HISTORY, updates CAUSAL_EXECUTION_LEDGER
  Promises: read_current() returns None on missing (not exception), write raises on failure
  Callers: MetaBloomsOS.run_turn() at SEE (read) and ECL (write)

legacy_impact_statement:
  Before the ledger, GPT maintained state through context window only.
  That approach fails at context limit, fails across sessions, and cannot
  be verified externally. The ledger makes state machine-readable and auditable.

ChatGPT behavioral contract:
  At SEE: read TURN_STATE_LEDGER.json — this is what happened last turn.
  At ECL: write TURN_STATE_LEDGER.json — this is what happened this turn.
  NEVER skip ledger read at SEE.
  NEVER skip ledger write at ECL.
  ledger_written=True in turn result only when write actually succeeded.
"""

from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = ["BTS", "SEE"]
REQUIRES_HASH = "509a3b52df015ba2231756a908969f8de01f6a3bfda5769054348a794032f1af"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import json
import uuid
import hashlib
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── Constants ─────────────────────────────────────────────────────────────────

SCHEMA = "mb.state_ledger.v2"
MAX_HISTORY = 20
LEDGER_REL       = Path("state/TURN_STATE_LEDGER.json")
CAUSAL_REL       = Path("state/CAUSAL_EXECUTION_LEDGER.json")
ARTIFACT_REL     = Path("state/ARTIFACT_LEDGER.json")
SESSION_HIST_REL = Path("state/SESSION_HISTORY.json")


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class TurnState:
    """State for the current/last completed turn."""
    turn_id: str
    objective: str
    started_at: str
    completed_at: Optional[str] = None
    status: str = "RUNNING"          # RUNNING | COMPLETE | FAILED | ESCALATED
    completed_stages: List[str] = field(default_factory=list)
    failed_stages: List[str] = field(default_factory=list)
    artifacts_written: List[str] = field(default_factory=list)
    open_gaps: List[str] = field(default_factory=list)
    failures: List[Dict[str, Any]] = field(default_factory=list)
    last_mpp_cycle_id: Optional[str] = None
    last_see_verdict: Optional[str] = None
    next_objective: Optional[str] = None
    notes: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema": SCHEMA,
            "turn_id": self.turn_id,
            "objective": self.objective,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "status": self.status,
            "completed_stages": self.completed_stages,
            "failed_stages": self.failed_stages,
            "artifacts_written": self.artifacts_written,
            "open_gaps": self.open_gaps,
            "failures": self.failures,
            "last_mpp_cycle_id": self.last_mpp_cycle_id,
            "last_see_verdict": self.last_see_verdict,
            "next_objective": self.next_objective,
            "notes": self.notes,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "TurnState":
        return TurnState(
            turn_id=d.get("turn_id", "UNKNOWN"),
            objective=d.get("objective", ""),
            started_at=d.get("started_at", ""),
            completed_at=d.get("completed_at"),
            status=d.get("status", "UNKNOWN"),
            completed_stages=d.get("completed_stages", []),
            failed_stages=d.get("failed_stages", []),
            artifacts_written=d.get("artifacts_written", []),
            open_gaps=d.get("open_gaps", []),
            failures=d.get("failures", []),
            last_mpp_cycle_id=d.get("last_mpp_cycle_id"),
            last_see_verdict=d.get("last_see_verdict"),
            next_objective=d.get("next_objective"),
            notes=d.get("notes", ""),
        )


@dataclass
class CausalEntry:
    """One entry in the causal execution ledger."""
    engine: str
    action: str           # write | modify | delete | execute | fetch
    artifact: str         # file path or resource identifier
    cause: str            # why this action was taken
    turn_id: str
    timestamp: str = field(default_factory=lambda:
                           datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "engine": self.engine,
            "action": self.action,
            "artifact": self.artifact,
            "cause": self.cause,
            "turn_id": self.turn_id,
            "timestamp": self.timestamp,
        }


@dataclass
class ArtifactEntry:
    """One entry in the artifact ledger."""
    path: str
    sha256: str
    bytes: int
    written_by: str       # engine name
    turn_id: str
    purpose: str
    timestamp: str = field(default_factory=lambda:
                           datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "path": self.path,
            "sha256": self.sha256,
            "bytes": self.bytes,
            "written_by": self.written_by,
            "turn_id": self.turn_id,
            "purpose": self.purpose,
            "timestamp": self.timestamp,
        }


# ── State Ledger Engine ───────────────────────────────────────────────────────

class StateLedger:
    """
    Manages all ledgers for MetaBlooms OS.

    On Python: reads/writes JSON files directly.
    On ChatGPT: this class definition is the behavioral contract for
    how GPT manages state across turns.

    Usage:
        ledger = StateLedger(runtime_root)

        # Start of turn (after SEE reads it):
        state = ledger.read_current()  # returns TurnState or None

        # During turn:
        ledger.record_causal("mpp_engine", "write", "output.json",
                             "IMPLEMENTATION produced artifact", turn_id)
        ledger.record_artifact("output.json", path_obj, "mpp_engine",
                               turn_id, "primary output")

        # End of turn (ECL):
        ledger.write_turn_complete(turn_state)
    """

    def __init__(self, runtime_root: str | Path = ".") -> None:
        self.root = Path(runtime_root)
        self._ledger_path   = self.root / LEDGER_REL
        self._causal_path   = self.root / CAUSAL_REL
        self._artifact_path = self.root / ARTIFACT_REL
        self._history_path  = self.root / SESSION_HIST_REL
        for p in [self._ledger_path, self._causal_path,
                  self._artifact_path, self._history_path]:
            p.parent.mkdir(parents=True, exist_ok=True)

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    # ── Current turn state ────────────────────────────────────────────────────

    def read_current(self) -> Optional[TurnState]:
        """
        Read current turn state. Returns None if no ledger exists (first turn
        or session reset).
        """
        if not self._ledger_path.exists():
            return None
        try:
            data = json.loads(self._ledger_path.read_text(encoding="utf-8"))
            return TurnState.from_dict(data)
        except Exception:
            return None

    def new_turn(self, objective: str,
                 turn_id: Optional[str] = None) -> TurnState:
        """Create a new TurnState for the current turn. Emits TRACE_SPAN (COEV-019)."""
        tid = turn_id or f"TURN-{uuid.uuid4().hex[:8].upper()}"

        # TRACE_SPAN — side-effect safe, failure-tolerant
        try:
            import sys as _s, os as _o
            _utils = _o.path.join(_o.path.dirname(__file__), "utils")
            if _utils not in _s.path: _s.path.insert(0, _utils)
            from TRACE_SPAN_EMITTER import get_emitter
            _e = get_emitter(self.root)
            _sid = _e.start("STATE_LEDGER", turn_id=tid)
            _state = TurnState(turn_id=tid, objective=objective,
                               started_at=self._now(), status="RUNNING")
            _e.end(_sid, success=True, metadata={
                "turn_id": tid,
                "state_transition": "INIT→RUNNING",
            })
            return _state
        except Exception:
            pass

        return TurnState(
            turn_id=tid,
            objective=objective,
            started_at=self._now(),
            status="RUNNING",
        )

    def write_turn_complete(self, state: TurnState) -> Dict[str, Any]:
        """
        Write turn state at ECL. Returns the written dict.
        This is the primary ECL deliverable — it MUST be called.
        """
        state.completed_at = self._now()
        d = state.to_dict()
        self._ledger_path.write_text(json.dumps(d, indent=2), encoding="utf-8")

        # Append to session history
        self._append_history(state)

        return d

    def _append_history(self, state: TurnState) -> None:
        """Append a turn summary to session history (append-only, last 20)."""
        history = []
        if self._history_path.exists():
            try:
                raw = json.loads(self._history_path.read_text(encoding="utf-8"))
                history = raw.get("turns", [])
            except Exception:
                history = []

        summary = {
            "turn_id": state.turn_id,
            "objective": state.objective,
            "status": state.status,
            "completed_at": state.completed_at,
            "artifacts_written": state.artifacts_written,
            "open_gaps": state.open_gaps,
            "failed_stages": state.failed_stages,
        }
        history.append(summary)

        # Prune to last MAX_HISTORY, but SHA256-chain the dropped entries
        if len(history) > MAX_HISTORY:
            dropped = history[:-MAX_HISTORY]
            dropped_hash = hashlib.sha256(
                json.dumps(dropped, sort_keys=True).encode()
            ).hexdigest()
            history = history[-MAX_HISTORY:]
            chain_anchor = {
                "_pruned_entries": len(dropped),
                "_chain_sha256": dropped_hash,
            }
        else:
            chain_anchor = None

        out = {
            "schema": "mb.session_history.v2",
            "updated_at": self._now(),
            "turn_count": len(history),
            "turns": history,
        }
        if chain_anchor:
            out["_chain_anchor"] = chain_anchor

        self._history_path.write_text(json.dumps(out, indent=2), encoding="utf-8")

    # ── Causal execution ledger ───────────────────────────────────────────────

    def record_causal(self, engine: str, action: str, artifact: str,
                      cause: str, turn_id: str) -> CausalEntry:
        """
        Record a causal action: engine → action → artifact → cause.
        Append-only. Called by every engine when it writes/modifies an artifact.
        """
        entry = CausalEntry(
            engine=engine, action=action, artifact=artifact,
            cause=cause, turn_id=turn_id,
        )
        data = []
        if self._causal_path.exists():
            try:
                data = json.loads(self._causal_path.read_text(encoding="utf-8"))
            except Exception:
                data = []
        data.append(entry.to_dict())
        self._causal_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return entry

    def query_causal_by_artifact(self, artifact_path: str) -> List[Dict]:
        """Who wrote this artifact and why?"""
        if not self._causal_path.exists():
            return []
        try:
            data = json.loads(self._causal_path.read_text(encoding="utf-8"))
            return [e for e in data if e.get("artifact") == artifact_path]
        except Exception:
            return []

    def query_causal_by_turn(self, turn_id: str) -> List[Dict]:
        """What did this turn do causally?"""
        if not self._causal_path.exists():
            return []
        try:
            data = json.loads(self._causal_path.read_text(encoding="utf-8"))
            return [e for e in data if e.get("turn_id") == turn_id]
        except Exception:
            return []

    # ── Artifact ledger ───────────────────────────────────────────────────────

    def record_artifact(self, artifact_path: str | Path, written_by: str,
                        turn_id: str, purpose: str) -> ArtifactEntry:
        """
        Record an artifact that was written. Auto-hashes the file.
        Called whenever an engine produces an output file.
        """
        p = Path(artifact_path)
        if not p.exists():
            raise FileNotFoundError(f"Artifact ledger: cannot record missing file: {p}")

        data_bytes = p.read_bytes()
        entry = ArtifactEntry(
            path=str(p.relative_to(self.root)) if self.root in p.parents else str(p),
            sha256=hashlib.sha256(data_bytes).hexdigest(),
            bytes=len(data_bytes),
            written_by=written_by,
            turn_id=turn_id,
            purpose=purpose,
        )
        data = []
        if self._artifact_path.exists():
            try:
                data = json.loads(self._artifact_path.read_text(encoding="utf-8"))
            except Exception:
                data = []
        data.append(entry.to_dict())
        self._artifact_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return entry

    def artifacts_this_turn(self, turn_id: str) -> List[Dict]:
        """What artifacts were written this turn?"""
        if not self._artifact_path.exists():
            return []
        try:
            data = json.loads(self._artifact_path.read_text(encoding="utf-8"))
            return [e for e in data if e.get("turn_id") == turn_id]
        except Exception:
            return []

    # ── Session history queries ───────────────────────────────────────────────

    def session_history(self, last_n: int = 5) -> List[Dict]:
        """Get last N turn summaries."""
        if not self._history_path.exists():
            return []
        try:
            data = json.loads(self._history_path.read_text(encoding="utf-8"))
            turns = data.get("turns", [])
            return turns[-last_n:]
        except Exception:
            return []

    def open_gaps_from_last_turn(self) -> List[str]:
        """What gaps were open at end of last turn?"""
        state = self.read_current()
        if state is None:
            return []
        return state.open_gaps or []

    def last_objective(self) -> Optional[str]:
        """What was the last turn's objective?"""
        state = self.read_current()
        if state is None:
            return None
        return state.objective

    def summary(self) -> Dict[str, Any]:
        """Full ledger summary for SEE evidence."""
        current = self.read_current()
        history = self.session_history(last_n=5)
        artifacts = []
        if self._artifact_path.exists():
            try:
                artifacts = json.loads(self._artifact_path.read_text())
            except Exception:
                pass
        causal = []
        if self._causal_path.exists():
            try:
                causal = json.loads(self._causal_path.read_text())
            except Exception:
                pass
        return {
            "current_turn": current.to_dict() if current else None,
            "session_history_last_5": history,
            "total_artifacts": len(artifacts),
            "total_causal_entries": len(causal),
            "open_gaps": current.open_gaps if current else [],
        }


# ── Self-test ─────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import tempfile, sys

    print("StateLedger self-test...")
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        ledger = StateLedger(root)

        # First turn — no prior state
        prior = ledger.read_current()
        assert prior is None, "First turn should have no prior state"
        print("  First turn — no prior state ✓")

        # Create and complete a turn
        state = ledger.new_turn("Build output.json")
        state.completed_stages = ["SEE", "CDR", "IMPLEMENTATION", "ECL"]
        state.artifacts_written = ["state/output.json"]
        state.last_see_verdict = "CLEAN"
        state.next_objective = "Verify output.json"

        # Write a fake artifact
        (root / "state").mkdir(exist_ok=True)
        artifact = root / "state" / "output.json"
        artifact.write_text('{"result": "test"}')

        # Record causal
        ledger.record_causal("mpp_engine", "write", "state/output.json",
                              "IMPLEMENTATION produced artifact", state.turn_id)

        # Record artifact
        ledger.record_artifact(artifact, "mpp_engine", state.turn_id, "primary output")

        # Complete the turn
        ledger.write_turn_complete(state)
        print(f"  Turn completed: {state.turn_id} ✓")

        # Second turn reads the state
        prior2 = ledger.read_current()
        assert prior2 is not None
        assert prior2.turn_id == state.turn_id
        assert "state/output.json" in prior2.artifacts_written
        assert prior2.next_objective == "Verify output.json"
        print(f"  Second turn reads prior state: {prior2.turn_id} ✓")

        # Causal query
        causal = ledger.query_causal_by_artifact("state/output.json")
        assert len(causal) == 1
        assert causal[0]["engine"] == "mpp_engine"
        print(f"  Causal query works: {causal[0]['engine']} wrote output.json ✓")

        # Artifact query
        arts = ledger.artifacts_this_turn(state.turn_id)
        assert len(arts) == 1
        print(f"  Artifact ledger: {len(arts)} artifact this turn ✓")

        # Session history
        hist = ledger.session_history()
        assert len(hist) == 1
        print(f"  Session history: {len(hist)} entries ✓")

        print()
        print("STATE_LEDGER SELF-TEST PASSED")
        sys.exit(0)
