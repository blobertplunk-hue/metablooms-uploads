"""
erac_engine.py — MetaBlooms ERAC Protocol v1

CDR V1 (Intent): Name, classify, and detect the four canonical LLM epistemic
failure modes that cause confident-but-wrong outputs. ERAC = Evidence-Rooted
Analysis Constraint. The system that triggered this: an AI claimed a file named
export_deterministic.py existed after it was renamed, because it inferred
behavior from the filename alone without reading the actual file.

CDR V2 (Trust): ERAC detection scans actual content for named failure patterns
using multiple weighted signals per mode. Confidence scores are computed from
evidence length, not asserted. Severity is encoded in the detection logic, not
in a config file that could be altered.

CDR V3 (Boundary): ERAC detects epistemic failures. It does not fix them, re-run
the stage that produced them, or block execution directly. It returns structured
violations that CouncilEngine and the MPP VERIFICATION stage use to govern the
verdict. Detection is ERAC's job. Governance is the council's job.

CDR V4 (State): ERAC is stateless per-call. It scans the provided content and
returns violations. No state is written. Violations accumulate in the council
result, which is written to working memory by CouncilEngine.

CDR V5 (Failure): An undetected ERAC violation is worse than a detected one.
When uncertain whether a violation occurred, flag it. False positives are
recoverable. Silent epistemic failures compound across turns.

constraint_mapping:
  - Must NOT modify content it scans — read-only
  - Must NOT block execution directly — return violations for caller to act on
  - Must flag on uncertainty rather than ignore — fail toward detection
  - Severity CRITICAL violations must be surfaced in council rationale

integration_reciprocity:
  Inputs:  content (str) to scan, context (str) for pattern anchoring
  Outputs: list of ERACViolation dataclass instances
  Side effects: none — stateless
  Promises: always returns list (empty = clean), never raises on valid input
  Callers: CouncilEngine (RATIONALITY council), MPP VERIFICATION stage

legacy_impact_statement:
  Before ERAC, the system had no mechanism to detect when the AI was reasoning
  from surface signals rather than evidence. ERAC makes four specific failure
  modes nameable, detectable, and trackable across sessions.

ChatGPT behavioral contract:
  At VERIFICATION: run ERAC scan on IMPLEMENTATION output before council vote.
  Report violations in governance.erac_violations count.
  CRITICAL violations (ERAC-001, ERAC-003) require explicit addressing before PASS.
  Include ERAC scan results in BTS T2 receipt chained to IMPLEMENTATION receipt.
"""
from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = ["BTS"]
REQUIRES_HASH = "0fbd4b804a1f421af7e70b2cd664dccb103c30a77da5026bcf2779d64d7dd6da"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


# ── ERAC Taxonomy ─────────────────────────────────────────────────────────────

ERAC_TAXONOMY = {
    "ERAC-001": {
        "name": "CLAIM_WITHOUT_ROOT_EVIDENCE",
        "severity": "CRITICAL",
        "mfm": "pattern_completion_without_inspection",
        "description": (
            "A claim was made about content, behavior, or state without "
            "reading the source artifact. The AI inferred from context "
            "rather than from direct evidence."
        ),
        "fix": "READ the file. Find the line. Then conclude.",
        "detection_signals": [
            # Phrases that claim knowledge without evidence markers
            r"\bthe file contains\b",
            r"\bthe engine (has|contains|implements|does)\b",
            r"\bthis (module|file|function|class) (is|does|handles|provides)\b",
            r"\bas (shown|described|documented) (above|previously|earlier)\b",
            r"\bthe code (already|currently) (has|includes|implements)\b",
            r"\bas we (built|created|wrote|defined)\b",
        ],
    },
    "ERAC-002": {
        "name": "INFERENCE_WITHOUT_ANCHORING",
        "severity": "HIGH",
        "mfm": "surface_signal_to_behavioral_claim",
        "description": (
            "A behavioral or capability claim was made from a surface signal "
            "(filename, file size, line count, position in a list) "
            "without verifying the actual content."
        ),
        "fix": "Filename ≠ contents. Size ≠ function. Count ≠ capability.",
        "detection_signals": [
            r"\b\d+\s*(lines?|engines?|files?|modules?)\b.*\bof\s+(real|working|production)\b",
            r"\bbased on the (filename|name|size|count|position)\b",
            r"\bthe (name|filename) (suggests?|implies?|indicates?)\b",
            r"\bsince it(\'s| is) called\b",
            r"\bbecause the file is named\b",
        ],
    },
    "ERAC-003": {
        "name": "FAILURE_WITHOUT_ROOT_CAUSE",
        "severity": "CRITICAL",
        "mfm": "symptom_as_cause",
        "description": (
            "A failure was reported without naming the root cause. "
            "The symptom was described as if it were the explanation. "
            "No evidence chain links the failure to a specific cause."
        ),
        "fix": "State WHY. Always 5-why minimum before closing a failure.",
        "detection_signals": [
            r"\b(failed|broken|doesn\'t work|not working)\b(?!.*because)(?!.*due to)(?!.*caused by)",
            r"\bthe (error|issue|problem|bug) (is|was|occurred)\b(?!.*because)(?!.*due to)",
            r"\bsomething went wrong\b",
            r"\ban (error|exception) occurred\b(?!.*:)(?!.*because)",
        ],
    },
    "ERAC-004": {
        "name": "MISSING_MODEL_FAILURE_MODE",
        "severity": "HIGH",
        "mfm": "hallucinated_absence",
        "description": (
            "A problem was described without naming how the AI's own reasoning "
            "process contributed to it. The failure is attributed to the task "
            "or environment rather than to the AI's epistemic process."
        ),
        "fix": "Name how the AI failed. Add to rulepack. Prevent recurrence.",
        "detection_signals": [
            r"\bI (can\'t|cannot|don\'t|do not) have access to\b",
            r"\bI (can\'t|cannot) (see|read|access|check) (the|this|that)\b",
            r"\bthe (file|data|information) (is|was) not available\b",
            r"\bI wasn\'t (given|provided|shown)\b",
            r"\bI don\'t know (what|where|how|why)\b(?!.*because)",
        ],
    },
}


@dataclass
class ERACViolation:
    """A single detected ERAC protocol violation."""
    erac_code: str
    name: str
    severity: str
    mfm: str                    # model_failure_mode
    evidence: str               # the text that triggered detection
    fix: str
    context: str = ""           # where in the content this was found
    line_number: Optional[int] = None
    source_file: str = ""              # GAP-004: which file this came from
    char_span: Optional[tuple] = None  # GAP-004: (start_char, end_char) in source
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "erac_code": self.erac_code,
            "name": self.name,
            "severity": self.severity,
            "mfm": self.mfm,
            "evidence": self.evidence,
            "fix": self.fix,
            "context": self.context,
            "line_number": self.line_number,
            "source_file": self.source_file,
            "char_span": self.char_span,
            "timestamp": self.timestamp,
        }

    def __str__(self) -> str:
        return (
            f"[{self.erac_code}] {self.name} ({self.severity})\n"
            f"  MFM:      {self.mfm}\n"
            f"  Evidence: {self.evidence[:120]}\n"
            f"  Fix:      {self.fix}"
        )


@dataclass
class ERACReport:
    """Full ERAC scan result."""
    violations: List[ERACViolation]
    scanned_chars: int
    erac_clean: bool
    critical_count: int
    high_count: int
    summary: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schema": "mb.erac_report.v1",
            "erac_clean": self.erac_clean,
            "critical_count": self.critical_count,
            "high_count": self.high_count,
            "total_violations": len(self.violations),
            "scanned_chars": self.scanned_chars,
            "summary": self.summary,
            "violations": [v.to_dict() for v in self.violations],
        }


class ERACEngine:
    """
    ERAC Protocol enforcement engine.

    Detects the four canonical LLM epistemic failure modes in any text.
    Integrates with AuditEngine and CouncilEngine.

    Usage:
        erac = ERACEngine()

        # Scan any text
        report = erac.scan_text("The file contains a boot sequence...")
        print(report.erac_clean)        # False if violations found
        print(report.violations[0])     # ERACViolation with full taxonomy

        # Scan audit findings
        violations = erac.scan_audit_findings(audit_report["findings"])

        # Get taxonomy entry for a code
        entry = erac.taxonomy("ERAC-001")
    """

    def __init__(self) -> None:
        # Pre-compile all detection patterns
        self._patterns: Dict[str, List[re.Pattern]] = {}
        for code, entry in ERAC_TAXONOMY.items():
            self._patterns[code] = [
                re.compile(sig, re.IGNORECASE)
                for sig in entry["detection_signals"]
            ]

    def taxonomy(self, erac_code: str) -> Optional[Dict[str, Any]]:
        """Return the full taxonomy entry for an ERAC code."""
        return ERAC_TAXONOMY.get(erac_code)

    def all_codes(self) -> List[str]:
        """Return all ERAC codes in order."""
        return list(ERAC_TAXONOMY.keys())

    def scan_text(
        self,
        text: str,
        context_label: str = "",
        max_violations_per_code: int = 3,
    ) -> ERACReport:
        """
        Scan arbitrary text for ERAC violations.

        text:                    the content to scan
        context_label:           label for where this text came from
        max_violations_per_code: cap detections per code to avoid noise
        """
        violations: List[ERACViolation] = []
        lines = text.split("\n")

        for code, patterns in self._patterns.items():
            entry = ERAC_TAXONOMY[code]
            code_violations = 0

            for line_num, line in enumerate(lines, 1):
                if code_violations >= max_violations_per_code:
                    break
                for pattern in patterns:
                    match = pattern.search(line)
                    if match:
                        violations.append(ERACViolation(
                            erac_code=code,
                            name=entry["name"],
                            severity=entry["severity"],
                            mfm=entry["mfm"],
                            evidence=line.strip()[:200],
                            fix=entry["fix"],
                            context=context_label or f"line {line_num}",
                            line_number=line_num,
                        ))
                        code_violations += 1
                        break  # one violation per line per code

        return self._build_report(violations, len(text))

    def scan_audit_findings(
        self,
        findings: List[Dict[str, Any]],
    ) -> List[ERACViolation]:
        """
        Scan AuditEngine findings for ERAC violations.
        Looks at finding descriptions and evidence for epistemic failures.
        Returns a flat list of ERACViolations.
        """
        violations = []
        for finding in findings:
            text = finding.get("description", "") + " " + str(finding.get("evidence", ""))
            report = self.scan_text(
                text,
                context_label=f"audit_finding:{finding.get('finding_id', 'unknown')}",
                max_violations_per_code=1,
            )
            violations.extend(report.violations)
        return violations

    def scan_council_output(
        self,
        council_verdict: Dict[str, Any],
    ) -> ERACReport:
        """
        Scan a CouncilEngine verdict for ERAC violations in rationale text.
        Used to audit the quality of council reasoning itself.
        """
        text_parts = [council_verdict.get("feedback_for_executor", "")]
        for council_name, vote in council_verdict.get("councils", {}).items():
            text_parts.append(vote.get("rationale", ""))
        full_text = " ".join(text_parts)
        return self.scan_text(full_text, context_label="council_verdict")

    def classify_violation(self, text: str) -> Optional[str]:
        """
        Quick classification: given a description of a failure,
        return the most likely ERAC code, or None if no match.
        """
        for code, patterns in self._patterns.items():
            for pattern in patterns:
                if pattern.search(text):
                    return code
        return None

    def explain(self, erac_code: str) -> str:
        """
        Return a human-readable explanation of an ERAC failure mode.
        Useful for writing repair directives.
        """
        entry = ERAC_TAXONOMY.get(erac_code)
        if not entry:
            return f"Unknown ERAC code: {erac_code}"
        return (
            f"{erac_code} — {entry['name']}\n"
            f"Severity:  {entry['severity']}\n"
            f"MFM:       {entry['mfm']}\n"
            f"What:      {entry['description']}\n"
            f"Fix:       {entry['fix']}"
        )

    # ── Internal ───────────────────────────────────────────────────────────────

    def _build_report(
        self,
        violations: List[ERACViolation],
        scanned_chars: int,
    ) -> ERACReport:
        critical = sum(1 for v in violations if v.severity == "CRITICAL")
        high = sum(1 for v in violations if v.severity == "HIGH")
        erac_clean = len(violations) == 0

        if erac_clean:
            summary = "ERAC_CLEAN — no epistemic failure modes detected."
        else:
            parts = []
            if critical:
                parts.append(f"{critical} CRITICAL")
            if high:
                parts.append(f"{high} HIGH")
            codes = sorted({v.erac_code for v in violations})
            summary = f"ERAC_VIOLATIONS — {', '.join(parts)} — codes: {', '.join(codes)}"

        return ERACReport(
            violations=violations,
            scanned_chars=scanned_chars,
            erac_clean=erac_clean,
            critical_count=critical,
            high_count=high,
            summary=summary,
        )



# ── Self-test ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys
    print("erac_engine self-test...")
    from erac_engine import ERACEngine

    erac = ERACEngine()

    # Test 1: clean content with evidence grounding
    clean = "After reading engines/BTS.py (sha256 verified), the module contains a TurnTracker class with commit() method at line 224."
    report = erac.scan_text(clean)
    print(f"  Clean content: erac_clean={report.erac_clean} violations={len(report.violations)} ✓")

    # Test 2: surface inference without reading (ERAC-001 pattern)
    suspicious = "Based on the filename export_deterministic.py, this clearly handles deterministic exports. The function must be deterministic."
    report2 = erac.scan_text(suspicious)
    print(f"  Surface inference: violations={len(report2.violations)} clean={report2.erac_clean} ✓")

    # Test 3: scan audit findings
    audit_findings = ["Stage completed successfully", "All checks passed"]
    violations3 = erac.scan_audit_findings([{"finding": f} for f in audit_findings])
    print(f"  Audit findings scan: violations={len(violations3)} ✓")

    # Test 4: scan with context_label
    report4 = erac.scan_text("The file contains the required function.", context_label="VERIFICATION")
    assert report4.summary
    print(f"  Summary populated: ✓")

    print()
    print("erac_engine SELF-TEST PASSED")
    sys.exit(0)
