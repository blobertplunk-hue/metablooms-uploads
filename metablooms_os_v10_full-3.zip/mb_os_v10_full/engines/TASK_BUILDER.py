"""
TASK_BUILDER.py — Converts a plain coding request into a complete MPP task dict

CDR V1 (Intent): The MPP pipeline requires a fully populated task dict with
    sie_receipts, cdr_constraints, implementation, ofm, ads, uxr, nuf, sso,
    rrp, and objective_id. TASK_BUILDER assembles all of these from a human
    request string so the operator doesn't have to construct the dict manually.
    The result is a valid input to run_mpp().

CDR V2 (Trust): No field is fabricated. sie_receipts come from LOCAL_SEE
    (real content derived from the request). The implementation artifact_content
    is the actual code to be validated, provided by the caller. All SHA-256
    hashes are computed from actual content.

CDR V3 (Boundary): TASK_BUILDER assembles task dicts. It does not execute
    code, run the pipeline, or modify files. Output is a dict.

CDR V4 (Failure): Missing request: raises TASK_BUILDER_EMPTY_REQUEST.
    Missing code content: raises TASK_BUILDER_NO_CODE if implementation
    content is required but not provided.

CDR V5 (Integration):
    Inputs:  request (str), code (str), module_name (str), context (dict optional)
    Outputs: task dict ready for run_mpp()
    Side effects: none
    Assumptions: LOCAL_SEE importable from same directory
"""

from __future__ import annotations

import hashlib
import uuid
from typing import Any

from LOCAL_SEE import build_receipts


def build(
    request: str,
    code: str,
    module_name: str,
    context: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """
    Build a complete MPP task dict from a coding request and code content.

    Args:
        request:     plain-language description of what the code does
        code:        the Python source code to validate and improve
        module_name: filename for the module (e.g. "my_engine.py")
        context:     optional dict: existing_files, constraints, language

    Returns:
        Complete task dict for run_mpp()
    """
    if not request or not request.strip():
        raise RuntimeError("TASK_BUILDER_EMPTY_REQUEST: request is empty")
    if not code or not code.strip():
        raise RuntimeError("TASK_BUILDER_NO_CODE: code content is empty")

    ctx = context or {}
    objective_id = f"OBJ-{uuid.uuid4().hex[:8].upper()}"
    code_hash = hashlib.sha256(code.encode()).hexdigest()

    # Build receipts from local context
    see_context = {
        "module_name": module_name,
        "language": ctx.get("language", "python"),
        "constraints": ctx.get("constraints", []),
        "existing_files": ctx.get("existing_files", []),
    }
    sie_receipts = build_receipts(request, see_context)

    # CDR constraints derived from request
    constraints_list = [
        f"Module: {module_name}",
        "Fail closed on all errors — raise RuntimeError with named error codes",
        "All outputs are dicts with SHA-256 hash fields",
        "Type annotations required on all public functions",
        "CDR V1-V5 docstring blocks required",
    ]
    if ctx.get("constraints"):
        constraints_list.extend(ctx["constraints"])

    failure_modes = [
        {
            "mode": "invalid_input",
            "strategy": "halt",
            "safe_state": "raise RuntimeError with INPUT_INVALID error code",
            "rollback_path": "caller handles exception",
            "detectable_by": "TypeError or ValueError raised on bad input",
        },
        {
            "mode": "empty_input",
            "strategy": "halt",
            "safe_state": "raise RuntimeError with EMPTY_INPUT error code",
            "rollback_path": "caller handles exception",
            "detectable_by": "RuntimeError raised with EMPTY_INPUT in message",
        },
        {
            "mode": "unexpected_exception",
            "strategy": "escalate",
            "safe_state": "let exception propagate with original traceback",
            "rollback_path": "caller handles exception",
            "detectable_by": "any unhandled exception type",
        },
    ]

    task: dict[str, Any] = {
        "input": request,
        "objective_id": objective_id,
        # Evidence (SEE + NORMALIZE_EVIDENCE)
        "sie_receipts": sie_receipts,
        # CDR constraints (7-pillar governance)
        "cdr_constraints": {
            "rationale": (
                f"This module ({module_name}) implements: {request.strip()}. "
                "All constraints below are enforced before implementation proceeds."
            ),
            "constraints": constraints_list,
            "module_name": module_name,
            "failure_modes": failure_modes,
            "integration_contract": {
                "inputs": ctx.get("inputs_description", ["See function signatures"]),
                "outputs": ctx.get(
                    "outputs_description", ["See return type annotations"]
                ),
                "side_effects": ctx.get(
                    "side_effects", ["None unless documented in function"]
                ),
                "assumptions": ctx.get(
                    "assumptions", ["Caller validates inputs before passing"]
                ),
            },
            "attestation": f"MetaBlooms OS task builder — {objective_id}",
        },
        # Implementation artifact
        "implementation": {
            "artifact_path": module_name,
            "artifact_hash": code_hash,
            "artifact_content": code,
        },
        # OFM — outcome framing
        "ofm": {
            "objective_id": objective_id,
            "success_criteria": [
                {
                    "criterion": "Code passes all MPP stages without FAIL",
                    "measurable": True,
                    "threshold": "0 pipeline failures",
                },
                {
                    "criterion": "FORGE S-tier score >= 0.95",
                    "measurable": True,
                    "threshold": "0.95",
                },
                {
                    "criterion": "All public functions have type annotations",
                    "measurable": True,
                    "threshold": "100%",
                },
            ],
            "failure_criteria": [
                "Any MPP stage raises RuntimeError",
                "FORGE S-tier score < 0.80",
                "ANALYSIS_EVALUATION verdict=FAIL",
            ],
        },
        # ADS — architecture decisions
        "ads": {
            "engine_list": [module_name.replace(".py", "")],
            "dependency_map": {
                module_name.replace(".py", ""): [],
            },
            "authority_map": {
                module_name.replace(".py", ""): f"owns all logic in {module_name}",
            },
        },
        # UXR — user requirements
        "uxr": {
            "operator": "Robert",
            "constraints": [
                {
                    "name": "auditability",
                    "description": "All outputs must be SHA-256 verifiable",
                },
                {
                    "name": "fail_closed",
                    "description": "Never return partial results on error",
                },
            ],
        },
        # NUF — non-functional requirements (categories must match NUF.VALID_CATEGORIES)
        "nuf": {
            "requirements": [
                {
                    "category": "reliability",
                    "description": "All edge cases handled with named error codes — no silent failures",
                    "threshold": "0 unhandled RuntimeError",
                },
                {
                    "category": "determinism",
                    "description": "Same input always produces same output — no hidden state",
                    "threshold": "100% reproducible",
                },
            ]
        },
        # SSO — scope
        "sso": {
            "in_scope": [
                f"Implementation of {module_name}",
                "Type annotations on all public functions",
                "CDR V1-V5 docstring compliance",
                "SHA-256 hash on all artifact outputs",
            ],
            "out_of_scope": [
                "UI or display logic",
                "Database persistence",
                "Network I/O unless explicitly requested",
            ],
        },
        # RRP — recovery plan
        "rrp": {
            "failure_modes": failure_modes,
        },
    }

    return task
