"""
PIPELINE_STATE.py — Pipeline execution state container
=======================================================

CDR V1 (Rationale):
    PipelineState is the single shared object passed through all 17 MPP stages.
    It carries the task dict, per-stage artifacts (data), execution history,
    and trace spans. Every stage reads prior state and writes its own artifact.
    Deep-copying task on entry ensures idempotency across pipeline runs.

CDR V2 (Trust):
    state.data is append-only per run — stages write once, never overwrite.
    state.trace is append-only — every stage_span is permanent.
    state.update() enforces that every result has a 'stage' key and trace_span.
    No silent state changes — TRACE_MISSING raised if trace_span absent.

CDR V3 (Boundary):
    Inputs:  task dict (deep-copied by StageRunner before construction)
    Outputs: self (mutated by update() calls from each stage)
    Side effects: none — PipelineState is in-memory only
    Assumptions: StageRunner calls copy.deepcopy(task) before PipelineState(task)

CDR V4 (Failure):
    Missing 'stage' key in update() → STATE_UPDATE_INVALID raised.
    Missing trace_span in result → TRACE_MISSING raised.
    safe_state: raise immediately, do not continue with corrupted state.

CDR V5 (S-tier):
    state_hash() method produces SHA-256 of all stage names that have run.
    Comparable to: Dagster's asset materialization state, Airflow's task instance.
    Industry pattern: immutable stage results, append-only audit trail.
"""

from __future__ import annotations

import hashlib
from typing import Any


class PipelineState:
    def __init__(self, task: dict[str, Any]) -> None:
        self.task = task
        self.data: dict[str, Any] = {}
        self.history: list[dict[str, Any]] = []
        self.trace: list[dict[str, Any]] = []

    def update(self, stage_result: dict[str, Any]) -> None:
        if "stage" not in stage_result:
            raise RuntimeError("STATE_UPDATE_INVALID: missing stage")
        self.history.append(stage_result)
        self.data[stage_result["stage"]] = stage_result
        span = stage_result.get("trace_span")
        if not span:
            raise RuntimeError(f"TRACE_MISSING: {stage_result['stage']}")
        self.trace.append(span)

    def state_hash(self) -> str:
        """SHA-256 of all completed stage names — integrity anchor for this run."""
        content = "|".join(sorted(self.data.keys()))
        result_hash = hashlib.sha256(content.encode()).hexdigest()
        return result_hash
