"""
FIR_STAGE.py — Runtime fitness gate (thin pipeline stage wrapping FIREngine)
=============================================================================

CDR V1 (Rationale):
    FIREngine.evaluate_session() previously ran as a post-run manual call.
    This stage wraps it as a first-class MPP stage so it runs inside the
    pipeline with hard-gate enforcement. A fitness score below FIR_THRESHOLD
    blocks the pipeline before MONITOR runs, preventing a degraded run from
    being reported as healthy.

CDR V2 (Trust):
    FIR_STAGE reads fitness from FIREngine.evaluate_session() result.
    It does not fabricate or default scores. FIRDataError propagates if
    pipeline_state.data is empty — same fail-closed contract as FIREngine.

CDR V3 (Boundary):
    Inputs:  PipelineState with all prior stage artifacts populated
    Outputs: dict with fitness_score, metrics, proposals, decision
    Side effects: FIREngine writes COEVOLUTION_LOG.ndjson on COMMITTED result
    Assumptions: VERIFICATION, TRACE_ANALYSIS, ECL have already run and passed

CDR V4 (Failure):
    fitness_score missing from result: raises FIR_MISSING_SCORE
    fitness_score < FIR_THRESHOLD: raises FIR_REJECTED with score
    safe_state: raise immediately, do not advance to MONITOR on degraded run

CDR V5 (S-tier):
    result_hash anchors the FIR decision artifact for audit trail integrity.
    FIR_THRESHOLD = 0.60 — matches COMMIT_THRESHOLD in FIR_ENGINE.
    Comparable to: MLflow model quality gate, Seldon deployment threshold.
"""

from __future__ import annotations

import hashlib
from typing import Any

from FIR_ENGINE import FIRDataError, FIREngine
from STAGE_BASE import StageBase

FIR_THRESHOLD: float = 0.60


class FIR_STAGE(StageBase):
    name = "FIR"

    def __init__(self) -> None:
        self.engine = FIREngine()

    def execute(self, state: Any) -> dict[str, Any]:
        """Run FIREngine against completed pipeline state. Block on low score."""
        # Pre-check: surface ANALYSIS_EVALUATION failure before FIR runs
        # FIREngine will also enforce this, but we produce a cleaner error here
        state_data: dict[str, Any] = getattr(state, "data", {})
        ae_art = state_data.get("ANALYSIS_EVALUATION", {}).get("artifact", {})
        if ae_art and ae_art.get("verdict") == "FAIL":
            raise RuntimeError(
                "FIR_REASONING_GATE: ANALYSIS_EVALUATION verdict=FAIL. "
                "FIR stage cannot proceed — reasoning quality gate failed. "
                f"score={ae_art.get('score')} "
                f"truth_gate_blocked={ae_art.get('truth_gate_blocked', False)}. "
                "Fix analysis grounding before re-running pipeline."
            )

        try:
            fir_result = self.engine.evaluate_session(
                pipeline_state=state,
                session_id=state.task.get("objective_id", "SESSION-UNKNOWN"),
            )
        except FIRDataError as e:
            raise RuntimeError(f"FIR_DATA_ERROR: {e}") from e

        fitness = fir_result.fitness
        if fitness is None:
            raise RuntimeError(
                "FIR_MISSING_SCORE: FIREngine returned no fitness metrics. " "Pipeline state may be empty or malformed."
            )

        score = fitness.composite_score

        # HARD GATE: reject pipeline on low fitness score
        if score < FIR_THRESHOLD:
            raise RuntimeError(
                f"FIR_REJECTED: composite_score={score:.3f} < threshold={FIR_THRESHOLD}. "
                f"proposals={[p.proposal_id for p in fir_result.proposals]}"
            )

        # Anchor artifact with result_hash for integrity
        payload = f"{fir_result.fir_id}:{score:.4f}:{fir_result.timestamp}"
        result_hash = hashlib.sha256(payload.encode()).hexdigest()

        return {
            "fitness_score": score,
            "fir_status": fir_result.status,
            "metrics": fitness.to_dict(),
            "proposals": [p.to_dict() for p in fir_result.proposals],
            "proposal_count": len(fir_result.proposals),
            "decision": "ACCEPT",
            "fir_id": fir_result.fir_id,
            "result_hash": result_hash,
        }
