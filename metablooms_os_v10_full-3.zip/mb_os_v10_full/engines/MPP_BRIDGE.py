"""
MPP_BRIDGE.py — Bridge between LLM MPP trace and Python pipeline task dict
===========================================================================

CDR V1 (Rationale):
    The LLM reasons through MPP in two steps:
      Step 1: Free reasoning — prose through all 14 stages (no format constraint)
      Step 2: Structured output — fills the MPP output template from MPP_PROTOCOL.md
    This bridge takes Step 2 output and produces a validated task dict that
    run_mpp() accepts directly. It is the mechanical connection between the
    cognitive layer and the enforcement layer.

CDR V2 (Trust):
    The bridge validates before it passes. A task dict that fails schema
    validation never reaches run_mpp(). The LLM cannot fool the pipeline
    by omitting fields — MPPSchemaError names the exact missing field path.

CDR V3 (Boundary):
    Inputs:  LLM MPP trace dict OR JSON string (from MPP_PROTOCOL.md template)
    Outputs: Validated task dict ready for run_mpp()
    Side effects: none
    Assumptions: jsonschema installed; LLM has completed all 14 stages

CDR V4 (Failure):
    Schema validation fails: raises MPPSchemaError with field path and value.
    JSON parse fails: raises MPPParseError.
    Missing measurable criterion: raises MPPSchemaError("ofm.success_criteria").
    safe_state: always raise, never pass invalid task to pipeline.

CDR V5 (S-tier):
    task_hash (SHA-256) computed after validation for pipeline integrity.
    Comparable to: Pydantic model validation, OpenAI response_format enforcement.
    Two-step pattern: LLM reasons freely, bridge enforces structure.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any

try:
    import jsonschema

    _JSONSCHEMA_AVAILABLE = True
except ImportError:
    _JSONSCHEMA_AVAILABLE = False

from MPP_TASK_SCHEMA import MPP_TASK_SCHEMA

# ── Exceptions ────────────────────────────────────────────────────────────────


class MPPBridgeError(Exception):
    """Base error for all bridge failures."""


class MPPParseError(MPPBridgeError):
    """LLM output could not be parsed as JSON."""


class MPPSchemaError(MPPBridgeError):
    """Validated task dict failed schema validation."""

    def __init__(self, field_path: str, message: str, value: Any = None) -> None:
        self.field_path = field_path
        self.value = value
        super().__init__(
            f"MPP_SCHEMA_FAIL at '{field_path}': {message}"
            + (f" (got: {repr(value)[:80]})" if value is not None else "")
        )


# ── Bridge ────────────────────────────────────────────────────────────────────


class MPPBridge:
    """
    Validates and converts LLM MPP trace to a pipeline-ready task dict.

    Usage:
        bridge = MPPBridge()
        task = bridge.from_llm_output(llm_json_string)
        state = run_mpp(task)
    """

    SCHEMA_VERSION = "mpp.task.v1"

    def from_llm_output(self, raw: str | dict) -> dict[str, Any]:
        """
        Parse and validate LLM output. Returns pipeline-ready task dict.

        Args:
            raw: JSON string from LLM (Step 2 structured output)
                 OR pre-parsed dict (for programmatic use)

        Returns:
            Validated task dict with task_hash injected.

        Raises:
            MPPParseError: if raw is a string that isn't valid JSON
            MPPSchemaError: if the parsed dict fails any validation check
        """
        # Step 1: Parse
        if isinstance(raw, str):
            task = self._parse_json(raw)
        elif isinstance(raw, dict):
            task = dict(raw)
        else:
            raise MPPParseError(f"Expected str or dict, got {type(raw).__name__}")

        # Step 2: Inject schema_version if missing (bridge sets it)
        task.setdefault("schema_version", self.SCHEMA_VERSION)

        # Step 3: JSON Schema validation
        self._validate_schema(task)

        # Step 4: Semantic validations (things JSON Schema cannot express)
        self._validate_sie_dimensions(task)
        self._validate_ofm_measurable(task)
        self._validate_sso_no_overlap(task)
        self._validate_module_name(task)
        self._validate_artifact_hash(task)

        # Step 5: Compute task_hash for pipeline integrity
        task_content = json.dumps(task, sort_keys=True)
        task["task_hash"] = hashlib.sha256(task_content.encode()).hexdigest()

        return task

    def _parse_json(self, raw: str) -> dict:
        """Strip markdown fences and parse JSON."""
        cleaned = raw.strip()
        # Strip ```json fences if present
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            # Remove first line (```json or ```) and last line (```) if present
            start = 1
            end = len(lines) - 1 if lines[-1].strip() == "```" else len(lines)
            cleaned = "\n".join(lines[start:end]).strip()
        try:
            parsed = json.loads(cleaned)
        except json.JSONDecodeError as e:
            raise MPPParseError(
                f"LLM output is not valid JSON: {e}. "
                f"Ensure Step 2 output is pure JSON, no prose."
            ) from e
        if not isinstance(parsed, dict):
            raise MPPParseError(
                "LLM output parsed to non-dict type. Expected JSON object."
            )
        return parsed

    def _validate_schema(self, task: dict) -> None:
        """Run JSON Schema validation."""
        if not _JSONSCHEMA_AVAILABLE:
            # Fallback: manual required field check
            for field in MPP_TASK_SCHEMA["required"]:
                if field not in task:
                    raise MPPSchemaError(field, "required field missing")
            return

        validator = jsonschema.Draft7Validator(MPP_TASK_SCHEMA)
        errors = list(validator.iter_errors(task))
        if errors:
            # Report the most critical error first
            error = errors[0]
            path = ".".join(str(p) for p in error.absolute_path) or "(root)"
            raise MPPSchemaError(path, error.message, error.instance)

    def _validate_sie_dimensions(self, task: dict) -> None:
        """SEE: all three dimensions must be covered."""
        receipts = task.get("sie_receipts", [])
        covered = {r.get("dimension") for r in receipts}
        required = {"theory", "implementation", "failure_modes"}
        missing = required - covered
        if missing:
            raise MPPSchemaError(
                "sie_receipts.dimension",
                f"Missing evidence dimensions: {sorted(missing)}. "
                f"All three (theory, implementation, failure_modes) required.",
            )

    def _validate_ofm_measurable(self, task: dict) -> None:
        """OFM: at least one success criterion must be measurable=True."""
        criteria = task.get("ofm", {}).get("success_criteria", [])
        if not any(c.get("measurable") for c in criteria):
            raise MPPSchemaError(
                "ofm.success_criteria",
                "At least one success criterion must have measurable=true. "
                "A criterion with no measurement threshold cannot be verified.",
            )

    def _validate_sso_no_overlap(self, task: dict) -> None:
        """SSO: in_scope and out_of_scope cannot share items."""
        sso = task.get("sso", {})
        in_scope = set(sso.get("in_scope", []))
        out_scope = set(sso.get("out_of_scope", []))
        overlap = in_scope & out_scope
        if overlap:
            raise MPPSchemaError(
                "sso",
                f"Scope conflict: items appear in both in_scope and out_of_scope: {overlap}",
            )

    def _validate_module_name(self, task: dict) -> None:
        """CDR Pillar 3: module_name must not be utils/helpers/misc."""
        name = task.get("cdr_constraints", {}).get("module_name", "")
        stem = name.split(".")[0].upper()
        forbidden_stems = {"UTILS", "HELPERS", "MISC", "COMMON", "SHARED"}
        if stem in forbidden_stems:
            raise MPPSchemaError(
                "cdr_constraints.module_name",
                f"'{name}' violates CDR Pillar 3 (Semantic Domain Authority). "
                f"Name must be law-bearing and discoverable, not a junk drawer.",
                name,
            )

    def _validate_artifact_hash(self, task: dict) -> None:
        """IMPLEMENTATION: artifact_hash must match SHA-256 of artifact_content."""
        impl = task.get("implementation", {})
        content = impl.get("artifact_content", "")
        claimed_hash = impl.get("artifact_hash", "")
        if content and claimed_hash:
            actual_hash = hashlib.sha256(content.encode()).hexdigest()
            if actual_hash != claimed_hash:
                raise MPPSchemaError(
                    "implementation.artifact_hash",
                    f"Hash mismatch. Claimed: {claimed_hash[:16]}... "
                    f"Actual: {actual_hash[:16]}... "
                    f"Recompute SHA-256 of artifact_content.",
                )

    def errors(self, raw: str | dict) -> list[str]:
        """
        Return all validation errors without raising. Useful for LLM feedback.
        Returns empty list if valid.
        """
        errors: list[str] = []
        try:
            self.from_llm_output(raw)
        except (MPPParseError, MPPSchemaError) as e:
            errors.append(str(e))
            # Continue collecting if jsonschema available
            if _JSONSCHEMA_AVAILABLE and isinstance(raw, (str, dict)):
                try:
                    task = raw if isinstance(raw, dict) else json.loads(raw)
                    validator = jsonschema.Draft7Validator(MPP_TASK_SCHEMA)
                    for err in validator.iter_errors(task):
                        path = ".".join(str(p) for p in err.absolute_path) or "(root)"
                        errors.append(f"MPP_SCHEMA_FAIL at '{path}': {err.message}")
                except Exception:
                    pass
        return errors
