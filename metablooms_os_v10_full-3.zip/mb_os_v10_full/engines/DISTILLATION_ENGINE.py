"""
DISTILLATION_ENGINE.py — MetaBlooms Forced Distillation Engine

CDR V1 (Intent): On any detected failure, force distillation of what went wrong
    into a named mistake class with prevention strategy, then force strategy update
    into SUCCESS_REGISTRY. Informed by external research when available.
    If no external research found: reason internally to find prevention method.
    This is the mandatory correction trigger — not optional, not passive.

CDR V2 (Trust): Every distilled mistake class is SHA-256 receipted.
    Research evidence is fetched and hashed from real sources.
    Internal reasoning is clearly labeled as such (not dressed as external evidence).
    No class is promoted without a prevention_strategy — reasoning fills the gap.

CDR V3 (Boundary): Distillation engine ONLY distills. It does not execute,
    does not re-run failed operations, does not modify the runtime that failed.
    Input: failure event. Output: new or updated mistake class + strategy.

CDR V4 (Failure): Research fetch fails → fall through to internal reasoning.
    Internal reasoning produces prevention_strategy from failure pattern.
    No distillation result → log DISTILLATION_FAILED in ledger, never silent.

CDR V5 (Integration):
    Inputs:  failure_event dict (error, stage, module, context),
             learning engine instance, root path
    Outputs: DistillationResult with mistake_id, mistake_class, strategy,
             research_receipts, promotion_status
    Side effects: adds to MISTAKE_REGISTRY, adds to SUCCESS_REGISTRY,
                  appends to LEARNING_LEDGER.ndjson
"""

from __future__ import annotations

import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Optional

SCHEMA = "mb.distillation.v1"

# Severity mapping from error type
_SEVERITY_MAP = {
    "SEE_":          "S3_HIGH",
    "ERAC-":         "S4_CRITICAL",
    "MPP_FAIL":      "S3_HIGH",
    "STAGE_":        "S3_HIGH",
    "FIR_":          "S3_HIGH",
    "ECL_":          "S3_HIGH",
    "OS_KERNEL":     "S4_CRITICAL",
    "OS_BTS":        "S4_CRITICAL",
    "FORGE_ERROR":   "S2_MED",
    "VERIFICATION":  "S3_HIGH",
    "TRACE":         "S3_HIGH",
}

def _now() -> str:
    return datetime.now(UTC).isoformat()

def _hash(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()


@dataclass
class DistillationResult:
    mistake_id: str
    mistake_class: dict[str, Any]
    strategy_id: str
    strategy: dict[str, Any]
    research_receipts: list[dict] = field(default_factory=list)
    research_source: str = "internal_reasoning"  # or "external_research"
    promotion_status: str = "PENDING"  # PROMOTED | ALREADY_EXISTS | FAILED
    distillation_id: str = field(default_factory=lambda: f"DIST-{uuid.uuid4().hex[:8].upper()}")
    ts_utc: str = field(default_factory=_now)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": SCHEMA,
            "distillation_id": self.distillation_id,
            "ts_utc": self.ts_utc,
            "mistake_id": self.mistake_id,
            "strategy_id": self.strategy_id,
            "research_source": self.research_source,
            "promotion_status": self.promotion_status,
            "research_receipts": self.research_receipts,
        }


class DistillationEngine:
    """
    Mandatory correction trigger.
    Fires on any detected failure. Forces distillation + strategy update.
    Informed by external research when available. Reasons internally when not.
    """

    def __init__(self, root: str | Path) -> None:
        self.root = Path(root)
        self._distillation_log = self.root / "learning" / "DISTILLATION_LOG.ndjson"
        self._distillation_log.parent.mkdir(parents=True, exist_ok=True)

    # ── Main entry point ───────────────────────────────────────────────────────

    def distill(
        self,
        failure_event: dict[str, Any],
        learning_engine: Any,
        use_research: bool = True,
    ) -> DistillationResult:
        """
        On any detected failure: distill → research → promote → update strategy.
        This is the mandatory correction trigger. Not optional.

        failure_event keys:
            error (str):    the error string or failure description
            stage (str):    which stage/plane failed
            module (str):   which module
            context (dict): additional context (request, code snippet, etc.)
            session_id (str): session that failed
        """
        error = failure_event.get("error", "UNKNOWN_ERROR")
        stage = failure_event.get("stage", "UNKNOWN_STAGE")
        module = failure_event.get("module", "UNKNOWN_MODULE")
        session_id = failure_event.get("session_id", "")
        context = failure_event.get("context", {})

        # 1. Classify the failure
        mistake_id, severity = self._classify(error, stage, module)

        # 2. Check if already in registry
        existing = self._get_existing(mistake_id, learning_engine)

        # 3. Research or reason
        research_receipts: list[dict] = []
        research_source = "internal_reasoning"

        if use_research:
            research_receipts = self._fetch_research(error, stage, context)
            if research_receipts:
                research_source = "external_research"

        # 4. Build prevention strategy
        prevention = self._build_prevention(
            error, stage, module, research_receipts, existing
        )

        # 5. Build mistake class
        mistake_class = {
            "name": self._make_name(error, stage),
            "severity": severity,
            "domain": stage.lower().split("_")[0] if stage else "unknown",
            "description": (
                f"Auto-distilled from failure in {module} at {stage}. "
                f"Error: {error[:200]}"
            ),
            "detection_pattern": self._make_detection_pattern(error, stage),
            "prevention_strategy": prevention["strategy"],
            "self_check": prevention["self_check"],
            "fix": prevention["fix"],
            "research_source": research_source,
            "research_evidence": [r.get("summary", "") for r in research_receipts[:3]],
            "distillation_id": f"DIST-{uuid.uuid4().hex[:8].upper()}",
            "auto_distilled": True,
            "times_caught": 1,
            "session_first_seen": session_id,
            "added_session": _now()[:10],
        }

        # 6. Build success strategy (what to do instead)
        strategy_id = f"MS-DIST-{uuid.uuid4().hex[:6].upper()}"
        strategy = {
            "name": f"AVOID_{self._make_name(error, stage)}",
            "domain": mistake_class["domain"],
            "description": prevention["strategy"],
            "repeat_when": f"Before any action in {stage} that could trigger {error[:60]}",
            "protocol": prevention["steps"],
            "research_source": research_source,
            "evidence": [r.get("summary","") for r in research_receipts[:2]],
            "score": 0.8,
            "times_applied": 0,
            "auto_distilled": True,
            "added_session": _now()[:10],
        }

        # 7. Promote to registries
        status = "ALREADY_EXISTS"
        if learning_engine and not existing:
            promoted = learning_engine.add_mistake(mistake_id, mistake_class)
            if promoted:
                learning_engine.add_success(strategy_id, strategy)
                status = "PROMOTED"
        elif learning_engine and existing:
            # Update times_caught on existing class
            learning_engine.record_outcome(
                action_class=stage, module=module,
                outcome={"error": error[:100], "session": session_id},
                success=False,
                mistake_class=mistake_id,
            )
            status = "UPDATED_EXISTING"

        # 8. Log distillation event
        result = DistillationResult(
            mistake_id=mistake_id,
            mistake_class=mistake_class,
            strategy_id=strategy_id,
            strategy=strategy,
            research_receipts=research_receipts,
            research_source=research_source,
            promotion_status=status,
        )
        self._log(result, failure_event)
        return result

    # ── Classification ─────────────────────────────────────────────────────────

    def _classify(self, error: str, stage: str, module: str) -> tuple[str, str]:
        """
        Derive mistake_id and severity from error string.
        Checks known prefixes first, falls back to auto-generated ID.
        """
        # Check if this matches a known error prefix
        for prefix, sev in _SEVERITY_MAP.items():
            if error.upper().startswith(prefix):
                slug = error.split(":")[0].upper()[:30].replace(" ", "_")
                return f"ME-AUTO-{slug[:20]}", sev

        # Fall back: stage-based ID
        stage_slug = stage.upper()[:15].replace(" ", "_")
        error_slug = error[:20].upper().replace(" ", "_").replace(":", "")
        mistake_id = f"ME-{stage_slug[:10]}-{error_slug[:10]}"
        # Clean to valid ID chars
        import re
        mistake_id = re.sub(r"[^A-Z0-9-]", "", mistake_id)[:30]
        return mistake_id, "S3_HIGH"

    def _get_existing(self, mistake_id: str, learning_engine: Any) -> Optional[dict]:
        if learning_engine is None:
            return None
        try:
            mistakes = learning_engine._load_mistakes()
            return mistakes.get("classes", {}).get(mistake_id)
        except Exception:
            return None

    # ── Research ───────────────────────────────────────────────────────────────

    def _fetch_research(
        self, error: str, stage: str, context: dict
    ) -> list[dict]:
        """
        Fetch external research to inform prevention strategy.
        Uses WEB_SEE_ENGINE if available. Falls through silently if not.
        Returns list of receipt dicts with summary, source, sha256.
        """
        receipts = []
        try:
            import sys
            if str(self.root / "engines") not in sys.path:
                sys.path.insert(0, str(self.root / "engines"))
            from WEB_SEE_ENGINE import build_receipts_web

            # Build research query from failure
            query = self._build_research_query(error, stage, context)
            raw = build_receipts_web(query, context={"stage": stage, "error": error[:100]})

            for r in raw[:3]:  # max 3 external receipts
                receipts.append({
                    "source": r.get("source", "web"),
                    "dimension": r.get("dimension", "failure_modes"),
                    "summary": str(r.get("result", ""))[:300],
                    "sha256": r.get("result_hash", _hash(str(r.get("result","")))),
                    "confidence": r.get("evidence_confidence", 0.5),
                })
        except Exception:
            pass  # Research failure is non-blocking — fall through to internal reasoning

        return receipts

    def _build_research_query(self, error: str, stage: str, context: dict) -> str:
        """Build a targeted research query from the failure."""
        # Extract the core failure concept
        error_core = error.split(":")[0].replace("_", " ").lower()
        stage_core = stage.replace("_", " ").lower()

        # Map common failure patterns to good research queries
        query_map = {
            "see_no_evidence":       "evidence gathering LLM pipeline best practices",
            "see_hash_mismatch":     "hash verification content integrity pipeline",
            "see_coverage":          "evidence coverage validation completeness check",
            "erac":                  "LLM epistemic failure modes prevention",
            "mpp_fail":              "pipeline stage failure recovery patterns",
            "fir_":                  "fitness scoring pipeline improvement",
            "trace_analysis":        "code integrity trace analysis patterns",
            "verification":          "code verification testing best practices",
            "forge_error":           "code improvement automation reliability",
        }

        for key, research_q in query_map.items():
            if key in error.lower() or key in stage.lower():
                return research_q

        # Default: use error + stage
        return f"{error_core} {stage_core} prevention best practice"

    # ── Prevention reasoning ───────────────────────────────────────────────────

    def _build_prevention(
        self,
        error: str,
        stage: str,
        module: str,
        research_receipts: list[dict],
        existing: Optional[dict],
    ) -> dict[str, Any]:
        """
        Build prevention strategy.
        If research receipts available: synthesize from evidence.
        If not: reason internally from failure pattern.
        Never returns empty strategy.
        """
        # If we have research, synthesize from it
        if research_receipts:
            evidence_text = " ".join(r.get("summary","") for r in research_receipts[:2])[:500]
            strategy = self._synthesize_from_evidence(error, stage, evidence_text)
        else:
            # Internal reasoning: derive from failure pattern
            strategy = self._reason_prevention(error, stage, module)

        return strategy

    def _synthesize_from_evidence(
        self, error: str, stage: str, evidence: str
    ) -> dict[str, Any]:
        """Synthesize prevention strategy from research evidence."""
        error_type = error.split(":")[0]
        return {
            "strategy": (
                f"External research for {error_type} at {stage} indicates: {evidence[:200]}. "
                f"Apply evidence-driven prevention: validate inputs before stage entry, "
                f"fail closed on missing evidence, verify outputs before advancement."
            ),
            "self_check": f"Before {stage}: does this input satisfy the requirements that caused {error_type}?",
            "fix": f"Apply research-informed validation for {error_type}. See research_evidence field.",
            "steps": [
                f"1. Before {stage}: validate all required inputs exist and are non-empty",
                f"2. Apply specific check for {error_type}: {evidence[:100]}",
                f"3. If check fails: report {error_type} with specific missing element",
                f"4. Do not advance stage without passing check",
            ],
        }

    def _reason_prevention(
        self, error: str, stage: str, module: str
    ) -> dict[str, Any]:
        """
        Internal reasoning: derive prevention from failure pattern.
        Uses the error structure to infer what the check should have been.
        """
        error_upper = error.upper()

        # Pattern-based reasoning
        if "MISSING" in error_upper or "NOT FOUND" in error_upper or "ABSENT" in error_upper:
            return {
                "strategy": (
                    f"Failure class: presence assumption without verification. "
                    f"At {stage} in {module}: check existence of required artifact/input "
                    f"before attempting to use it. Fail closed if absent, not with runtime error."
                ),
                "self_check": f"Before {stage}: does the required input/artifact exist? Check first.",
                "fix": f"Add existence check before the operation that produced '{error[:60]}'.",
                "steps": [
                    f"1. Before {stage}: explicitly check if required input exists",
                    "2. If missing: raise named error BEFORE attempting to use it",
                    "3. Report what is missing and what would satisfy the requirement",
                    "4. Do not proceed without confirmed presence",
                ],
            }

        if "MISMATCH" in error_upper or "HASH" in error_upper or "INVALID" in error_upper:
            return {
                "strategy": (
                    f"Failure class: integrity assumption without verification. "
                    f"At {stage}: verify integrity (hash, schema, format) before processing. "
                    f"A thing that looks valid may not be valid."
                ),
                "self_check": f"Before {stage}: have I verified the integrity of this input, not just its presence?",
                "fix": f"Add integrity verification (hash/schema/format check) before '{stage}'.",
                "steps": [
                    "1. Compute expected hash/schema before use",
                    "2. Verify actual matches expected",
                    "3. If mismatch: report specific discrepancy with both values",
                    "4. Do not process mismatched input",
                ],
            }

        if "EMPTY" in error_upper or "THIN" in error_upper or "INCOMPLETE" in error_upper:
            return {
                "strategy": (
                    f"Failure class: content assumption without depth check. "
                    f"At {stage}: verify content has minimum required depth, not just existence. "
                    f"Present ≠ sufficient."
                ),
                "self_check": f"Before {stage}: is this input not just present but substantive enough to proceed?",
                "fix": "Add minimum content depth check (word count, field completeness) before stage entry.",
                "steps": [
                    "1. Check presence (exists)",
                    "2. Check depth (meets minimum threshold)",
                    "3. Check completeness (all required fields/dimensions present)",
                    "4. Report which check failed with specific measurement",
                ],
            }

        if "TIMEOUT" in error_upper or "RATE" in error_upper or "CONNECT" in error_upper:
            return {
                "strategy": (
                    f"Failure class: external dependency without fallback. "
                    f"At {stage}: external calls need fallback chain. "
                    f"If primary source fails, try secondary, then degrade gracefully."
                ),
                "self_check": "Does this operation have a fallback if the external dependency fails?",
                "fix": "Add fallback chain: primary → secondary → local → degrade with named status.",
                "steps": [
                    "1. Attempt primary source",
                    "2. On failure: attempt secondary source",
                    "3. On secondary failure: use local/cached data if available",
                    "4. If all fail: report DEGRADED with specific failure and continue",
                ],
            }

        # Generic reasoning fallback
        return {
            "strategy": (
                f"Failure at {stage} in {module}: '{error[:100]}'. "
                f"Reasoning: this failure was not anticipated by a pre-condition check. "
                f"Prevention: add explicit pre-condition check for the state that caused this error "
                f"before the operation that triggered it. Fail closed on pre-condition failure "
                f"rather than allowing the downstream RuntimeError."
            ),
            "self_check": f"Before {stage}: what pre-condition does this operation assume? Is that pre-condition verified?",
            "fix": f"Add pre-condition check before operation. Fail closed if pre-condition not met.",
            "steps": [
                f"1. Identify what precondition '{error[:60]}' assumed",
                "2. Add explicit check for that precondition before the operation",
                "3. If precondition fails: raise named error with specific description",
                "4. Test that the check would have caught this failure",
            ],
        }

    # ── Naming ─────────────────────────────────────────────────────────────────

    def _make_name(self, error: str, stage: str) -> str:
        import re
        slug = error.split(":")[0].upper()[:30].replace(" ", "_")
        slug = re.sub(r"[^A-Z0-9_]", "", slug)
        return f"{slug}_AT_{stage.upper()[:15]}"[:40]

    def _make_detection_pattern(self, error: str, stage: str) -> str:
        return (
            f"Error string starts with or contains: '{error.split(':')[0][:50]}'. "
            f"Stage: {stage}. "
            f"Detection: scan for this error pattern before and during {stage} execution."
        )

    # ── Logging ────────────────────────────────────────────────────────────────

    def _log(self, result: DistillationResult, failure_event: dict) -> None:
        entry = {
            "event": "DISTILLATION_COMPLETE",
            "ts_utc": _now(),
            "distillation_id": result.distillation_id,
            "mistake_id": result.mistake_id,
            "strategy_id": result.strategy_id,
            "promotion_status": result.promotion_status,
            "research_source": result.research_source,
            "research_receipts_count": len(result.research_receipts),
            "failure_stage": failure_event.get("stage", ""),
            "failure_error": failure_event.get("error", "")[:100],
        }
        try:
            with self._distillation_log.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass  # log failure is non-blocking


# ── Convenience function for direct wiring ────────────────────────────────────

def force_distill(
    error: str,
    stage: str,
    module: str,
    root: str | Path,
    learning_engine: Any = None,
    context: dict | None = None,
    session_id: str = "",
    use_research: bool = True,
) -> DistillationResult:
    """
    Convenience wrapper. Call this on any failure.
    Instantiates engine, runs distillation, returns result.
    Never raises — distillation failure is logged, not propagated.
    """
    try:
        engine = DistillationEngine(root)
        failure_event = {
            "error": error,
            "stage": stage,
            "module": module,
            "context": context or {},
            "session_id": session_id,
        }
        # Soft-import learning engine if not provided
        if learning_engine is None:
            try:
                import sys
                if str(Path(root) / "engines") not in sys.path:
                    sys.path.insert(0, str(Path(root) / "engines"))
                from LEARNING_ENGINE import LearningEngine
                learning_engine = LearningEngine(root)
            except Exception:
                pass

        return engine.distill(failure_event, learning_engine, use_research=use_research)
    except Exception as e:
        # Never crash the caller — return a minimal failed result
        return DistillationResult(
            mistake_id="ME-DISTILLATION-FAILED",
            mistake_class={},
            strategy_id="",
            strategy={},
            promotion_status="FAILED",
            research_source="none",
        )


if __name__ == "__main__":
    import sys, tempfile
    print("DISTILLATION_ENGINE self-test...")

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        # Create minimal learning dirs
        (root / "learning").mkdir()
        (root / "learning" / "MISTAKE_REGISTRY.json").write_text(
            '{"schema":"test","classes":{},"patterns":{}}')
        (root / "learning" / "SUCCESS_REGISTRY.json").write_text(
            '{"schema":"test","patterns":{}}')

        engine = DistillationEngine(root)

        # Test 1: missing artifact failure
        result = engine.distill(
            failure_event={
                "error": "SEE_NO_EVIDENCE: sie_receipts missing or empty",
                "stage": "SEE",
                "module": "metablooms_os",
                "context": {"request": "sort a list"},
                "session_id": "TEST-001",
            },
            learning_engine=None,
            use_research=False,
        )
        assert result.promotion_status in ("PROMOTED","ALREADY_EXISTS","UPDATED_EXISTING","FAILED")
        assert result.mistake_class.get("prevention_strategy")
        print(f"  Test 1 PASS: {result.mistake_id} [{result.promotion_status}]")
        print(f"  Prevention: {result.mistake_class['prevention_strategy'][:80]}...")

        # Test 2: hash mismatch failure
        result2 = engine.distill(
            failure_event={
                "error": "SEE_HASH_MISMATCH: receipt[0] expected=abc123",
                "stage": "SEE",
                "module": "metablooms_os",
                "context": {},
                "session_id": "TEST-002",
            },
            learning_engine=None,
            use_research=False,
        )
        assert "integrity" in result2.mistake_class.get("prevention_strategy","").lower() or                "verif" in result2.mistake_class.get("prevention_strategy","").lower()
        print(f"  Test 2 PASS: {result2.mistake_id}")

        # Test 3: forge error
        result3 = engine.distill(
            failure_event={
                "error": "FORGE_ERROR: syntax error in injected code",
                "stage": "FORGE",
                "module": "FORGE_RUNNER",
                "context": {},
                "session_id": "TEST-003",
            },
            learning_engine=None,
            use_research=False,
        )
        print(f"  Test 3 PASS: {result3.mistake_id}")

        # Test 4: distillation log written
        log = root / "learning" / "DISTILLATION_LOG.ndjson"
        assert log.exists()
        entries = [json.loads(l) for l in log.read_text().splitlines() if l]
        assert len(entries) == 3
        print(f"  Test 4 PASS: {len(entries)} log entries")

        # Test 5: force_distill convenience wrapper
        r5 = force_distill(
            error="VERIFICATION_FAIL: hash does not match",
            stage="VERIFICATION",
            module="MPP_RUNTIME",
            root=root,
            use_research=False,
        )
        assert r5.mistake_class.get("prevention_strategy")
        print(f"  Test 5 PASS: force_distill wrapper: {r5.mistake_id}")

    print()
    print("DISTILLATION_ENGINE SELF-TEST PASSED")
