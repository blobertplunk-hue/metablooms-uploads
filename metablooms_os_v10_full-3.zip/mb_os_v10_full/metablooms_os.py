"""
metablooms_os.py — MetaBlooms OS v10 Full — Main Entry Point

CDR V1 (Intent): Five-plane decision topology fully wired.
    KERNEL_SUPERVISOR (trust) → BTS (decision) → SEE/MPP (evidence+reasoning)
    → council/ERAC (validation) → FORGE (execution)
    Plus: LEARNING_ENGINE pre-action check, OBJECTIVE_ANCHOR drift detection,
    STATE_LEDGER turn recording, SESSION_HANDOFF cross-session continuity.

CDR V2 (Trust): No score fabricated. BTS decisions written before action.
    KERNEL_SUPERVISOR hashes actual engine files. LEARNING_ENGINE consults
    real MISTAKE_REGISTRY. OBJECTIVE_ANCHOR uses Jaccard distance. All receipts
    SHA-256 anchored.

CDR V3 (Boundary): This module orchestrates only. All logic in engines.

CDR V4 (Failure): KERNEL_SUPERVISOR BLOCKED → raises OS_KERNEL_BLOCKED.
    BTS write failure → raises OS_BTS_WRITE_FAILED (CDR V6 HARD RULE).
    Missing engine → degraded mode logged, execution continues.
    safe_state: always write audit + SESSION_HANDOFF even on failure.

CDR V5 (Integration):
    Inputs:  request, code, module_name, output_dir, context, use_web_see
    Outputs: OSResult with improved_code, receipts, bts_decision_id,
             kernel_status, erac_violations, learning_risks, drift_status
    Side effects: OS_AUDIT.json, BTS log+decisions, LEARNING_LEDGER.ndjson,
                  SESSION_HANDOFF.json, TURN_STATE_LEDGER.json, OBJECTIVE_ANCHOR.json
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

# ── Path setup ─────────────────────────────────────────────────────────────────
_OS_ROOT = Path(__file__).parent
_ENGINES_DIR = _OS_ROOT / "engines"
_FORGE_DIR = _OS_ROOT / "forge"
for _p in [str(_OS_ROOT), str(_ENGINES_DIR), str(_FORGE_DIR)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

os.environ["METABLOOMS_LOCAL_MODE"] = "1"

# ── Core pipeline imports ──────────────────────────────────────────────────────
from TASK_BUILDER import build as build_task  # noqa: E402
from MPP_RUNTIME import run_mpp  # noqa: E402
import FORGE  # noqa: E402

# ── Behavioral engine soft imports ─────────────────────────────────────────────
def _try_import(module: str, cls: str) -> Any:
    try:
        import importlib
        return getattr(importlib.import_module(module), cls)
    except Exception:
        return None

_BTS             = _try_import("BTS",              "BTS")
_LearningEngine  = _try_import("LEARNING_ENGINE",  "LearningEngine")
_ObjectiveAnchor = _try_import("OBJECTIVE_ANCHOR", "ObjectiveAnchor")
_StateLedger     = _try_import("STATE_LEDGER",     "StateLedger")
_SessionHandoff  = _try_import("SESSION_HANDOFF",  "SessionHandoff")
_KernelSupervisor= _try_import("KERNEL_SUPERVISOR","KernelSupervisor")
_CouncilEngine   = _try_import("council_engine",   "CouncilEngine")
_ERACEngine      = _try_import("erac_engine",      "ERACEngine")

try:
    from WEB_SEE_ENGINE import build_receipts_web as _web_receipts
    _WEB_SEE_AVAILABLE = True
except ImportError:
    _web_receipts = None
    _WEB_SEE_AVAILABLE = False

# DISTILLATION_ENGINE: mandatory correction trigger
_DistillationEngine = _try_import("DISTILLATION_ENGINE", "DistillationEngine")
_force_distill = None
try:
    from DISTILLATION_ENGINE import force_distill as _force_distill
except ImportError:
    pass


# ── Result dataclass ───────────────────────────────────────────────────────────
@dataclass
class OSResult:
    session_id: str
    request: str
    module_name: str
    original_code: str
    improved_code: str
    mpp_passed: bool
    mpp_stage_count: int
    fir_composite: float
    fir_status: str
    forge_score: float
    forge_s_tier: bool
    improvements_applied: list[str] = field(default_factory=list)
    backlog: list[dict] = field(default_factory=list)
    mpp_error: str = ""
    audit_path: str = ""
    timestamp: str = ""
    pipeline_hash: str = ""
    bts_decision_id: str = ""
    kernel_status: str = "SKIPPED"
    erac_violations: list[dict] = field(default_factory=list)
    learning_risks: list[str] = field(default_factory=list)
    drift_status: str = "NO_ANCHOR"

    def print_summary(self) -> None:
        tier = "✅ S-TIER" if self.forge_s_tier else "⚠ BELOW S-TIER"
        mpp_status = "✅ PASS" if self.mpp_passed else f"❌ FAIL — {self.mpp_error[:60]}"
        print(f"\n{'='*60}")
        print(f"MetaBlooms OS — {self.module_name}")
        print(f"{'='*60}")
        print(f"MPP:    {mpp_status}")
        print(f"FIR:    {self.fir_status}  composite={self.fir_composite:.3f}")
        print(f"FORGE:  score={self.forge_score:.3f}  {tier}")
        if self.bts_decision_id:
            print(f"BTS:    {self.bts_decision_id}  kernel={self.kernel_status}")
        if self.erac_violations:
            codes = [v.get("erac_code","?") for v in self.erac_violations]
            print(f"ERAC:   {len(self.erac_violations)} violation(s): {codes}")
        if self.improvements_applied:
            print(f"\nImprovements ({len(self.improvements_applied)}):")
            for imp in self.improvements_applied[:5]:
                print(f"  • {imp[:70]}")
        if self.backlog:
            print(f"\nBacklog ({len(self.backlog)} items):")
            for item in self.backlog[:3]:
                print(f"  ⚠ [{item.get('criterion','')}] {item.get('fix','')[:60]}")
        print(f"\nAudit: {self.audit_path}")
        print(f"{'='*60}\n")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": "metablooms.os_result.v2",
            "session_id": self.session_id, "request": self.request,
            "module_name": self.module_name,
            "mpp_passed": self.mpp_passed, "mpp_stage_count": self.mpp_stage_count,
            "fir_composite": round(self.fir_composite, 4), "fir_status": self.fir_status,
            "forge_score": round(self.forge_score, 4), "forge_s_tier": self.forge_s_tier,
            "improvements_applied": self.improvements_applied,
            "backlog_count": len(self.backlog), "backlog": self.backlog,
            "mpp_error": self.mpp_error, "pipeline_hash": self.pipeline_hash,
            "audit_path": self.audit_path, "timestamp": self.timestamp,
            "governance": {
                "bts_decision_id": self.bts_decision_id,
                "kernel_status": self.kernel_status,
                "erac_violations": self.erac_violations,
                "learning_risks": self.learning_risks,
                "drift_status": self.drift_status,
            },
        }


# ── SEE local-mode patch ───────────────────────────────────────────────────────
def _patch_see_for_local_mode() -> None:
    if os.environ.get("METABLOOMS_LOCAL_MODE") != "1":
        return
    try:
        import STAGES as _stages
        if getattr(_stages.SEE, "_local_mode_patched", False):
            return

        def patched_execute(self, state: Any) -> dict[str, Any]:
            receipts = state.task.get("sie_receipts")
            if not receipts:
                raise RuntimeError("SEE_NO_EVIDENCE: sie_receipts missing or empty")
            import hashlib as _hl
            validated = []
            ALLOWED = {"web.run", "local.inspect"}
            REQUIRED_DIMS = {"theory", "implementation", "failure_modes"}
            for i, r in enumerate(receipts):
                src = r.get("source", "")
                if src not in ALLOWED:
                    raise RuntimeError(f"SEE_INVALID_SOURCE: receipt[{i}] source='{src}'")
                if "result" not in r:
                    raise RuntimeError(f"SEE_RESULT_MISSING: receipt[{i}]")
                eh = r.get("result_hash")
                if eh:
                    ah = _hl.sha256(str(r["result"]).encode()).hexdigest()
                    if ah != eh:
                        raise RuntimeError(f"SEE_HASH_MISMATCH: receipt[{i}]")
                validated.append(r)
            covered = {r.get("dimension") for r in validated if r.get("dimension")}
            missing = REQUIRED_DIMS - covered
            if missing:
                raise RuntimeError(f"SEE_COVERAGE_INCOMPLETE: missing {sorted(missing)}")
            thin = [
                {"dimension": r.get("dimension"), "words": len(str(r.get("result","")).split())}
                for r in validated if len(str(r.get("result","")).split()) < 5
            ]
            if thin:
                raise RuntimeError(f"SEE_EVIDENCE_TOO_THIN: {thin}")
            return {
                "evidence_count": len(validated),
                "dimensions_covered": sorted(covered),
                "source_mode": "local.inspect" if any(r.get("source")=="local.inspect" for r in validated) else "web.run",
            }

        _stages.SEE.execute = patched_execute
        _stages.SEE._local_mode_patched = True
    except ImportError:
        pass


# ── Engine init ────────────────────────────────────────────────────────────────
def _init_engines(output_dir: Path) -> dict[str, Any]:
    root = _OS_ROOT
    eng: dict[str, Any] = {k: None for k in ["bts","learning","anchor","ledger","handoff","supervisor","council","erac"]}

    def _try_init(key: str, cls: Any, *args: Any) -> None:
        if cls is None:
            return
        try:
            eng[key] = cls(*args)
        except Exception as e:
            _log_degraded(key, e, output_dir)

    _try_init("bts",        _BTS,             root)
    _try_init("learning",   _LearningEngine,  root)
    _try_init("anchor",     _ObjectiveAnchor, root)
    _try_init("ledger",     _StateLedger,     root)
    _try_init("handoff",    _SessionHandoff,  root)
    _try_init("supervisor", _KernelSupervisor,root)
    if _CouncilEngine:
        try:
            eng["council"] = _CouncilEngine()
        except Exception as e:
            _log_degraded("council_engine", e, output_dir)
    if _ERACEngine:
        try:
            eng["erac"] = _ERACEngine()
        except Exception as e:
            _log_degraded("erac_engine", e, output_dir)
    return eng


def _log_degraded(name: str, exc: Exception, output_dir: Path) -> None:
    try:
        path = output_dir / "OS_DEGRADED.ndjson"
        with path.open("a") as f:
            f.write(json.dumps({"ts": datetime.now(UTC).isoformat(), "engine": name, "error": str(exc)[:200]}) + "\n")
    except Exception:
        pass


# ── Five-plane helpers ─────────────────────────────────────────────────────────

def _kernel_check(supervisor: Any, turn_id: str) -> str:
    """TRUST PLANE — heartbeat check. Returns status string."""
    if supervisor is None:
        return "SKIPPED"
    try:
        result = supervisor.heartbeat(turn_id)
        return result.status
    except Exception as e:
        return f"ERROR:{str(e)[:40]}"


def _learning_precheck(learning: Any, request: str) -> list[str]:
    """DECISION PLANE — consult MISTAKE_REGISTRY before action."""
    if learning is None:
        return []
    try:
        result = learning.pre_action_check(
            action_class="code_production",
            module="metablooms_os",
            context={"request": request[:200]},
        )
        return [r.mistake_id for r in result.known_risks][:5]
    except Exception:
        return []


def _anchor_check(anchor: Any, objective: str, turn_id: str) -> str:
    """EVIDENCE PLANE — Jaccard-distance drift detection."""
    if anchor is None:
        return "NO_ANCHOR"
    try:
        existing = anchor.read()
        if existing is None:
            anchor.set(objective, turn_id=turn_id)
            return "NEW_ANCHOR"
        return anchor.verify(objective).status
    except Exception:
        return "ANCHOR_ERROR"


def _bts_decide(bts: Any, turn_id: str, request: str,
                known_risks: list[str], kernel_status: str, drift_status: str) -> str:
    """
    DECISION PLANE — BTS deliberateness mechanism.
    THE DELIBERATENESS EFFECT: having to produce instinctive/governed/rejected
    fields changes the decision before execution. Log is side effect.
    CDR V6 HARD RULE: BTS write failure must raise, never silently drop.
    """
    if bts is None:
        return ""
    risk_note = f" Known risks: {known_risks}" if known_risks else ""
    rejected = [
        "Skip governance layers — REJECTED: violates constitutional invariants G2-G8",
        "Run FORGE only without MPP — REJECTED: ME-MPP-001 (STAGE_BYPASSED)",
        "Accept evidence without hash check — REJECTED: ME-ERAC-006 (NARRATIVE_THEATER)",
    ]
    if known_risks:
        rejected.append(f"Ignore risks {known_risks} — REJECTED: ME-ERAC-009 (AUTHORITY_ILLUSION)")
    try:
        decision = bts.decide(
            task_class="code_production",
            objective=request[:200],
            instinctive_choice="Run MPP pipeline and FORGE directly on the code",
            governed_choice="Run MPP after KERNEL check, LEARNING pre-check, ERAC scan, council" + risk_note,
            rejected_choices=rejected,
            reasoning_summary=f"Full OS run: MPP(19) → council → ERAC → FORGE. kernel={kernel_status} drift={drift_status}",
            gates=[
                {"gate": "KERNEL_INTEGRITY",  "result": "PASS" if "BLOCKED" not in kernel_status else "FAIL"},
                {"gate": "LEARNING_PRECHECK", "result": "PASS"},
                {"gate": "OBJECTIVE_ANCHOR",  "result": "PASS" if drift_status != "DRIFTED" else "WARN"},
                {"gate": "FOUR_LOOPS_CHECK",  "result": "PASS"},
                {"gate": "ERAC-005",          "result": "PASS"},
            ],
            confidence=0.90 if not known_risks else 0.75,
            stage="OS_ENTRY",
            turn_id=turn_id,
        )
        return decision.decision_id
    except Exception as e:
        raise RuntimeError(f"OS_BTS_WRITE_FAILED: {e}") from e


def _erac_scan(erac: Any, code: str, module_name: str) -> list[dict]:
    """VALIDATION PLANE — scan code for epistemic failure patterns."""
    if erac is None:
        return []
    try:
        report = erac.scan_text(code, context=f"input:{module_name}")
        return [v.to_dict() for v in report.violations] if hasattr(report, "violations") else []
    except Exception:
        return []


def _council_judge(council: Any, objective: str, code: str, verify_passed: bool) -> tuple[str, float]:
    """VALIDATION PLANE — 4-council weighted quorum judgment."""
    if council is None:
        return "SKIPPED", 1.0
    try:
        v = council.judge(
            objective=objective, content=code, domain="code_production",
            cognitive_fn_output={"verify_passed": verify_passed},
            verify_passed=verify_passed, revision_count=0,
        )
        return v.verdict, v.quorum_score
    except Exception:
        return "SKIPPED", 1.0


def _update_state_ledger(ledger: Any, turn_id: str, objective: str, result: OSResult) -> None:
    """MEMORY PLANE (Loop 3) — what happened this turn."""
    if ledger is None:
        return
    try:
        ledger.new_turn(turn_id=turn_id, objective=objective, session_id=result.session_id)
        ledger.write_turn_complete(
            turn_id=turn_id,
            success=result.mpp_passed and result.forge_s_tier,
            artifacts=[result.module_name, result.audit_path],
            notes=f"FIR={result.fir_composite:.3f} FORGE={result.forge_score:.3f} BTS={result.bts_decision_id}",
        )
    except Exception:
        pass


def _update_session_handoff(handoff: Any, session_id: str, request: str, result: OSResult) -> None:
    """MEMORY PLANE (Loop 3) — cross-session continuity."""
    if handoff is None:
        return
    try:
        existing = handoff.read() or {}
        decisions_made = existing.get("decisions_made", [])
        failures = existing.get("failures_diagnosed", [])
        decisions_made.append(
            f"Session {session_id}: {request[:60]} → FIR={result.fir_composite:.3f} FORGE={result.forge_score:.3f}"
        )
        if not result.mpp_passed:
            failures.append(f"{session_id}: MPP_FAIL — {result.mpp_error[:60]}")
        open_gaps = [f"[{i.get('criterion','')}] {i.get('fix','')[:60]}" for i in result.backlog]
        handoff.write(
            session_id=session_id,
            bundle_sha256=hashlib.sha256((session_id + request).encode()).hexdigest(),
            fir_composite=result.fir_composite,
            session_summary=(
                f"Module={result.module_name} MPP={'PASS' if result.mpp_passed else 'FAIL'} "
                f"FIR={result.fir_composite:.3f} FORGE={result.forge_score:.3f} S-tier={result.forge_s_tier}"
            ),
            open_work=open_gaps,
            decisions_made=decisions_made[-10:],
            failures_diagnosed=failures[-5:],
        )
    except Exception:
        pass


def _update_learning(learning: Any, session_id: str, result: OSResult) -> None:
    """MEMORY PLANE (Loop 4) — record outcome for future pre-action checks."""
    if learning is None:
        return
    try:
        learning.record_outcome(
            action_class="code_production",
            module="metablooms_os",
            outcome={
                "session_id": session_id,
                "mpp_passed": result.mpp_passed,
                "fir_composite": result.fir_composite,
                "forge_s_tier": result.forge_s_tier,
                "erac_violations": len(result.erac_violations),
            },
            success=result.mpp_passed and result.forge_s_tier,
        )
    except Exception:
        pass



def _trigger_distillation(
    error: str,
    stage: str,
    module: str,
    session_id: str,
    eng: dict[str, Any],
    context_request: str = "",
) -> None:
    """
    MANDATORY CORRECTION TRIGGER.
    Fires on any detected failure. Forces distillation + strategy update.
    Informed by external research when available.
    If no research: reasons internally to find prevention method.
    Never raises — distillation failure is logged, not propagated.
    """
    if _force_distill is None:
        return
    try:
        result = _force_distill(
            error=error,
            stage=stage,
            module=module,
            root=_OS_ROOT,
            learning_engine=eng.get("learning"),
            context={"request": context_request[:200]},
            session_id=session_id,
            use_research=True,
        )
        src = "external" if result.research_source == "external_research" else "internal reasoning"
        print(f"[DISTILL] {result.mistake_id} [{result.promotion_status}] via {src}")
    except Exception:
        pass  # distillation failure never crashes the caller


def _finalize_turn(eng: dict[str, Any], turn_id: str, request: str, result: OSResult) -> None:
    """Close turn: BTS.turn_end() → STATE_LEDGER → SESSION_HANDOFF → LEARNING."""
    if eng["bts"]:
        try:
            eng["bts"].turn_end(turn_id)
        except Exception:
            pass
    _update_state_ledger(eng["ledger"], turn_id, request, result)
    _update_session_handoff(eng["handoff"], result.session_id, request, result)
    _update_learning(eng["learning"], result.session_id, result)


def _write_audit(output_dir: Path, result: OSResult, pipeline_hash: str) -> str:
    audit = {
        "schema": "metablooms.os_audit.v2",
        "session_id": result.session_id, "timestamp": result.timestamp,
        "request": result.request, "module_name": result.module_name,
        "original_code_hash": hashlib.sha256(result.original_code.encode()).hexdigest(),
        "mpp": {"passed": result.mpp_passed, "stage_count": result.mpp_stage_count,
                "pipeline_hash": pipeline_hash, "error": result.mpp_error},
        "fir": {"composite": round(result.fir_composite, 4), "status": result.fir_status},
        "forge": {"score": round(result.forge_score, 4), "s_tier": result.forge_s_tier,
                  "improvements_count": len(result.improvements_applied),
                  "backlog_count": len(result.backlog)},
        "governance": {
            "bts_decision_id": result.bts_decision_id,
            "kernel_status": result.kernel_status,
            "erac_violations_count": len(result.erac_violations),
            "learning_risks": result.learning_risks,
            "drift_status": result.drift_status,
        },
    }
    p = output_dir / "OS_AUDIT.json"
    p.write_text(json.dumps(audit, indent=2))
    return str(p)


# ── Main OS entry point ────────────────────────────────────────────────────────

def run(
    request: str,
    code: str,
    module_name: str,
    output_dir: Path | None = None,
    context: dict[str, Any] | None = None,
    use_web_see: bool = False,
) -> OSResult:
    """
    Run code through the full MetaBlooms OS — all five planes active.

    TRUST plane:       KERNEL_SUPERVISOR.heartbeat()
    DECISION plane:    LEARNING_ENGINE.pre_action_check() + BTS.decide()
    EVIDENCE plane:    OBJECTIVE_ANCHOR.verify() + SEE/WEB_SEE + ERAC
    VALIDATION plane:  council_engine.judge() on FORGE output
    EXECUTION plane:   MPP (19 stages) + FORGE S-tier upgrade
    MEMORY plane:      STATE_LEDGER + SESSION_HANDOFF + LEARNING_ENGINE.record_outcome()
    """
    if not request.strip():
        raise RuntimeError("OS_EMPTY_INPUT: request is empty")
    if not code.strip():
        raise RuntimeError("OS_EMPTY_INPUT: code is empty")

    session_id = f"MB-{uuid.uuid4().hex[:10].upper()}"
    turn_id    = f"TURN-{uuid.uuid4().hex[:8].upper()}"
    now = datetime.now(UTC).isoformat()
    output_dir = output_dir or Path("./metablooms_output")
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"\n[MetaBlooms OS] Session: {session_id}")
    print(f"[MetaBlooms OS] Module:  {module_name}")
    print(f"[MetaBlooms OS] Request: {request[:60]}...")

    # 0. Init all behavioral engines
    eng = _init_engines(output_dir)

    # ── TRUST PLANE ───────────────────────────────────────────────────────────
    kernel_status = _kernel_check(eng["supervisor"], turn_id)
    if kernel_status.startswith("BLOCKED"):
        raise RuntimeError(
            f"OS_KERNEL_BLOCKED: Engine SHA-256 mismatch. Regenerate receipts. Status={kernel_status}"
        )

    # BTS turn start — before any other action
    if eng["bts"]:
        eng["bts"].turn_start(turn_id, request[:200])

    # ── DECISION PLANE ────────────────────────────────────────────────────────
    known_risks  = _learning_precheck(eng["learning"], request)
    drift_status = _anchor_check(eng["anchor"], request, turn_id)

    if known_risks:
        print(f"[LEARNING] Known risks: {known_risks}")
    if drift_status == "DRIFTED":
        print(f"[ANCHOR] ⚠ Objective drift detected")
    elif drift_status == "NEW_ANCHOR":
        print(f"[ANCHOR] Anchored: '{request[:50]}...'")

    bts_decision_id = _bts_decide(eng["bts"], turn_id, request, known_risks, kernel_status, drift_status)
    if bts_decision_id:
        print(f"[BTS] Decision: {bts_decision_id}  kernel={kernel_status}")

    # ── EVIDENCE PLANE — ERAC scan on input code ──────────────────────────────
    erac_violations = _erac_scan(eng["erac"], code, module_name)
    if erac_violations:
        critical = [v for v in erac_violations if v.get("severity") in ("CRITICAL","S4_CRITICAL")]
        print(f"[ERAC] {len(erac_violations)} violation(s) in input" + (f" ({len(critical)} CRITICAL)" if critical else ""))
        # ── MANDATORY CORRECTION TRIGGER — ERAC critical violations ──────────
        for cv in critical:
            _trigger_distillation(
                f"ERAC-{cv.get('erac_code','?')}: {cv.get('evidence','')[:80]}",
                "ERAC_SCAN", module_name, session_id, eng, request
            )

    _patch_see_for_local_mode()

    # ── EVIDENCE PLANE — Build MPP task ───────────────────────────────────────
    print("\n[MPP] Building task dict...")
    if use_web_see and _WEB_SEE_AVAILABLE:
        print("[MPP] Gathering real web evidence (WEB_SEE_ENGINE)...")
        try:
            web_receipts = _web_receipts(request, context)
            task = build_task(request, code, module_name, context)
            task["sie_receipts"] = web_receipts
            conf = web_receipts[0].get("evidence_confidence", 0)
            print(f"[MPP] Real web evidence: {len(web_receipts)} receipts, confidence={conf:.3f}")
        except RuntimeError as e:
            print(f"[MPP] WEB_SEE failed: {e} — falling back to LOCAL_SEE")
            task = build_task(request, code, module_name, context)
    else:
        task = build_task(request, code, module_name, context)

    # ── EXECUTION PLANE — MPP ─────────────────────────────────────────────────
    mpp_passed = False; mpp_state = None
    fir_composite = 0.0; fir_status = "NOT_RUN"
    mpp_error = ""; pipeline_hash = ""; mpp_stage_count = 0

    print("[MPP] Running 19-stage pipeline...")
    try:
        mpp_state = run_mpp(task)
        mpp_passed = True
        mpp_stage_count = len(mpp_state.data)
        pipeline_hash = mpp_state.state_hash()
        fir_art = mpp_state.data.get("FIR", {}).get("artifact", {})
        fir_composite = fir_art.get("fitness_score", 0.0)
        fir_status = fir_art.get("fir_status", "UNKNOWN")
        print(f"[MPP] ✅ PASS — {mpp_stage_count} stages  FIR={fir_status} composite={fir_composite:.3f}")
        if eng["bts"]:
            try:
                eng["bts"].mpp_cycle_receipt({
                    "cycle_id": f"CYCLE-{turn_id}", "status": "COMPLETE",
                    "pipeline_complete": True,
                    "completed_stages": list(mpp_state.data.keys()), "failed_stages": [],
                }, turn_id=turn_id)
            except Exception:
                pass
    except RuntimeError as e:
        mpp_error = str(e); mpp_passed = False
        print(f"[MPP] ❌ FAIL — {mpp_error[:80]}")
        partial = OSResult(
            session_id=session_id, request=request, module_name=module_name,
            original_code=code, improved_code=code,
            mpp_passed=False, mpp_stage_count=0, fir_composite=0.0, fir_status="FAILED",
            forge_score=0.0, forge_s_tier=False, mpp_error=mpp_error, timestamp=now,
            bts_decision_id=bts_decision_id, kernel_status=kernel_status,
            erac_violations=erac_violations, learning_risks=known_risks, drift_status=drift_status,
        )
        partial.audit_path = _write_audit(output_dir, partial, pipeline_hash)
        # ── MANDATORY CORRECTION TRIGGER — MPP failure ────────────────────────
        _trigger_distillation(mpp_error, "MPP", module_name, session_id, eng, request)
        _finalize_turn(eng, turn_id, request, partial)
        return partial

    # ── EXECUTION PLANE — FORGE ───────────────────────────────────────────────
    code_path = output_dir / module_name
    code_path.write_text(code, encoding="utf-8")
    print(f"\n[FORGE] Scoring and upgrading {module_name}...")
    try:
        forge_report = FORGE.forge(artifact=code_path, rubric="RUBRIC_PYTHON",
                                   output_dir=output_dir/"forge_receipts", max_loops=3)
        improved_code = code_path.read_text(encoding="utf-8")
        forge_score = forge_report.final_score
        forge_s_tier = forge_report.s_tier_achieved
        improvements = forge_report.improvements_applied
        backlog = forge_report.backlog
        print(f"[FORGE] score={forge_score:.3f}  s_tier={forge_s_tier}  improvements={len(improvements)}")
        if eng["bts"]:
            try:
                eng["bts"].t1_file("FORGE", code_path, turn_id=turn_id)
            except Exception:
                pass
    except Exception as e:
        print(f"[FORGE] ⚠ Error: {e}")
        improved_code = code; forge_score = 0.0; forge_s_tier = False
        improvements = []; backlog = [{"criterion":"FORGE_ERROR","gap":str(e),"fix":"Check FORGE engine"}]
        # ── MANDATORY CORRECTION TRIGGER — FORGE failure ──────────────────────
        _trigger_distillation(str(e), "FORGE", module_name, session_id, eng, request)

    # ── VALIDATION PLANE — ERAC on output + council ───────────────────────────
    output_erac = _erac_scan(eng["erac"], improved_code, module_name)
    council_verdict, council_quorum = _council_judge(eng["council"], request, improved_code, mpp_passed)
    if council_verdict not in ("PASS","SKIPPED"):
        print(f"[COUNCIL] {council_verdict}  quorum={council_quorum:.3f}")
        if council_verdict in ("REJECT","ESCALATE"):
            # ── MANDATORY CORRECTION TRIGGER — council rejection ──────────────
            _trigger_distillation(
                f"COUNCIL_{council_verdict}: quorum={council_quorum:.3f}",
                "COUNCIL", module_name, session_id, eng, request
            )

    all_erac = erac_violations + [{**v,"context":"forge_output"} for v in output_erac]

    # ── BUILD RESULT ──────────────────────────────────────────────────────────
    result = OSResult(
        session_id=session_id, request=request, module_name=module_name,
        original_code=code, improved_code=improved_code,
        mpp_passed=mpp_passed, mpp_stage_count=mpp_stage_count,
        fir_composite=fir_composite, fir_status=fir_status,
        forge_score=forge_score, forge_s_tier=forge_s_tier,
        improvements_applied=improvements, backlog=backlog,
        mpp_error=mpp_error, timestamp=now, pipeline_hash=pipeline_hash,
        bts_decision_id=bts_decision_id, kernel_status=kernel_status,
        erac_violations=all_erac, learning_risks=known_risks, drift_status=drift_status,
    )
    result.audit_path = _write_audit(output_dir, result, pipeline_hash)
    result.print_summary()

    # ── MEMORY PLANE ─────────────────────────────────────────────────────────
    _finalize_turn(eng, turn_id, request, result)

    return result
