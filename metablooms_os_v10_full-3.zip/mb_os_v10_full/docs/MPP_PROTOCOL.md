# MetaBlooms Mandatory Process Pipeline (MPP)
## Cognitive Protocol for LLM Code Generation

**Version:** v10 canonical  
**Authority:** This document governs how an LLM reasons before writing any code.  
**Hard rule:** No implementation before all pre-implementation stages are complete.

---

## What This Is

MPP is not a checklist. It is the reasoning process an LLM must run through before producing any code, architecture, or technical artifact. When an LLM follows MPP, broken input becomes world-class output — because the LLM cannot proceed to implementation without first understanding what it is building, why, for whom, under what constraints, and how it will know when it is done.

**The contract:** Every stage must produce real findings before the next stage opens. A stage cannot pass by asserting completion. It must show work.

---

## The 14 Stages

```
SEE → MMD → DRS → CDR → OFM → ADS → UXR → NUF → SSO → RRP
→ IMPLEMENTATION → VERIFICATION → DEBUGGING → ECL
```

---

## Stage 1: SEE — Sandcrawler Evidence Engine

**Question:** What do I actually know? What evidence exists right now?

**The LLM must:**
- Read and inspect every file, artifact, or input provided
- Run AST or structural analysis on any code input — is it parseable? What does it contain?
- Identify what is missing from the input vs what would be needed to implement correctly
- State evidence classification: E0 (contradicted — blocks), E1 (none yet — sandbox only), E2 (partial — proceed with warning), E3 (strong — proceed), E4 (validated — preferred)
- Ground every subsequent stage in this evidence — no stage may make claims that exceed the evidence gathered here

**Blocks if:** No evidence gathered. E0 evidence exists for the objective.

**Output format:**
```
SEE:
  evidence_count: N
  dimensions_covered: [theory, implementation, failure_modes]
  input_artifact_status: [parseable|broken|missing]
  key_findings: [...]
  evidence_classification: E0|E1|E2|E3|E4
```

---

## Stage 2: MMD — Missing Middle Detector

**Question:** What gaps exist between what I know and what I need to implement correctly?

**The LLM must:**
- Check Plan→Code gap: is there a concrete plan? Does the plan cover all requirements?
- Check Code→Evidence gap: does evidence support every implementation claim?
- Check ACA (Assumption/Context Analysis): what is being assumed true that was never stated?
  - Examples: assumed Python version, assumed directory structure, assumed prior state
- Flag every missing middle as a gap with severity (critical | high | warn)
- **Critical gaps block the pipeline.** High gaps must be addressed before IMPLEMENTATION.

**Blocks if:** Any critical gap exists (zero evidence for a mandatory dimension, broken input with no repair plan).

**Output format:**
```
MMD:
  gaps: [
    {gap: "NAME", severity: "critical|high|warn", detail: "..."}
  ]
  aca_findings: ["unstated assumption 1", ...]
  gap_count: N
```

---

## Stage 3: DRS — Decision Record System

**Question:** What decisions am I making, and why am I making them this way instead of another way?

**The LLM must:**
- Record every architectural or implementation decision explicitly
- For each decision: state the decision, the rationale, and at least two alternatives considered and rejected
- Decisions made without recorded alternatives are not decisions — they are assumptions masquerading as decisions

**Required fields per decision:**
- `decision_id`: unique identifier
- `decision`: what was decided
- `rationale`: why this option over alternatives
- `alternatives_considered`: list of at least 2 rejected options with reasons

**Blocks if:** No decisions recorded (zero decisions implies the implementation was not deliberated).

---

## Stage 4: CDR — Coding Done Right

**Question:** What constraints must my code satisfy? What would make this code unacceptable?

**The 7 Pillars — all must pass:**

1. **Proactive Rationale** — WHY before WHAT. Every function must explain its existence before describing its behavior. Rationale is not a comment — it is a design decision record.

2. **Explicit Constraint Mapping** — What limits apply? What must NOT be violated? State performance constraints, memory limits, invariants that must hold.

3. **Semantic Domain Authority** — No junk-drawer names. `utils.py`, `helpers.py`, `misc.py` are forbidden. Every module name must be law-bearing and discoverable. The LLM must understand the domain it is touching.

4. **Anticipated Failure Intent** — How does this fail? What is the safe state? Every function that can fail must declare how and what the system does when it fails. Fail-closed is the default.

5. **Integration Reciprocity** — Declare inputs, outputs, side effects, assumptions. What does this module promise to its callers? What does it require from them?

6. **History-Aware Evolution** — If this replaces something, say what it replaces and why the prior logic became invalid. Every delta must name what it supersedes.

7. **Mandatory Attestation** — The LLM must be able to reconstruct the reasoning chain for every decision in the code. Unattested code — code the LLM cannot explain — must not be written.

**Also at CDR:** Run static analysis mentally (or literally if tools are available):
- Would ruff/flake8 flag anything?
- Would mypy catch type errors?
- Would bandit flag security issues?
- Does black formatting apply?

**Blocks if:** Any pillar critically fails. Blocking violations halt the pipeline.

---

## Stage 5: OFM — Outcome Framing Matrix

**Question:** What does done look like? What does failure look like?

**The LLM must define:**
- `success_criteria`: list of specific, measurable conditions that must be true when implementation is complete
- `failure_criteria`: list of specific conditions that indicate failure
- At least one success criterion must be measurable (not "works correctly" — "returns correct output for input X")

**Blocks if:** No success criteria defined, or no failure criteria defined. Both are required — defining only success is wishful thinking.

---

## Stage 6: ADS — Architecture Decision Set

**Question:** What is the structure of what I'm building?

**The LLM must declare:**
- `engine_list`: every module, class, or function involved
- `dependency_map`: which components depend on which (must be a DAG — circular dependencies block)
- `authority_map`: who owns state? Who calls whom?

**Topological sort required:** The dependency map must be a directed acyclic graph. If A depends on B depends on A, that is a circular dependency and blocks the pipeline.

**Blocks if:** No engine list, no dependency map, circular dependencies detected.

---

## Stage 7: UXR — User Experience Requirements

**Question:** What does the operator actually need from this?

**The LLM must state:**
- Who is the operator (Robert, a developer, an LLM system, etc.)
- What constraints does the operator's context impose?
- If no constraints: explicitly state `no_constraints_justification`

**Blocks if:** No constraints stated AND no explicit justification for having none.

---

## Stage 8: NUF — Non-Functional Requirements

**Question:** How must this perform, behave under load, and handle edge cases?

**Categories to address (at least one required):**
- `performance`: response time, throughput constraints
- `reliability`: failure recovery, uptime requirements
- `security`: authentication, data handling, injection prevention
- `determinism`: same input always produces same output
- `memory`: memory limits, leak prevention
- `latency`: acceptable delay bounds

Each requirement must include a measurable threshold, not just a description.

**Blocks if:** No non-functional requirements stated.

---

## Stage 9: SSO — System Scope Outline

**Question:** What is explicitly in scope and explicitly out of scope?

**The LLM must list:**
- `in_scope`: everything this implementation covers
- `out_of_scope`: everything this implementation explicitly does NOT cover

Both lists required. An empty `out_of_scope` list is a scope creep risk — there is always something out of scope.

**Scope conflict check:** Nothing can appear on both lists.

**Blocks if:** Either list is empty, or a scope conflict exists.

---

## Stage 10: RRP — Repair and Recovery Plan

**Question:** When this fails, what happens?

**For each failure mode:**
- `mode`: name of the failure scenario
- `strategy`: one of rollback | retry | fallback | halt | escalate | degrade
- `rollback_path` or `recovery_action`: concrete recovery steps
- `detectable_by`: how would the system know this failure occurred?

The `detectable_by` field is critical. A failure mode that cannot be detected cannot be repaired.

**Blocks if:** No failure modes defined, unknown strategy, or no recovery path.

---

## Stage 11: IMPLEMENTATION

**Question:** Now build it.

**The LLM writes code here — and only here.**

The code must:
- Satisfy every CDR pillar defined in Stage 4
- Implement exactly the architecture defined in Stage 6
- Stay within the scope defined in Stage 9
- Handle every failure mode defined in Stage 10
- Meet every success criterion defined in Stage 5

**Hash the artifact:** Compute SHA-256 of the output. Record it. This anchors the artifact for VERIFICATION.

**Syntax check:** If writing Python, the code must compile. SyntaxError → DEBUGGING before proceeding.

**Blocks if:** No artifact produced, hash not computed, syntax errors present.

---

## Stage 12: VERIFICATION

**Verification is not "does it look right." Verification is "does it satisfy every prior stage."**

The LLM must check:

1. IMPLEMENTATION artifact exists and hash matches
2. Artifact path is defined
3. CDR compliance — run the 7 pillars against the actual code produced
4. OFM success criteria — evaluate each criterion against the actual output
5. SSO scope — does the artifact stay within in_scope?
6. ADS architecture — does the code match the declared dependency map?
7. Lint gate — would ruff, black, mypy, bandit pass on this code?

**If ANY check fails:** Do not proceed to ECL. Go to DEBUGGING.

**Blocks if:** Any verification check fails.

---

## Stage 13: DEBUGGING (conditional — only if VERIFICATION fails)

**Question:** Why did verification fail? What is the root cause?

**The LLM must:**
- Identify the specific VERIFICATION check that failed
- Derive the root cause (not the symptom — the underlying reason)
- Apply a patch that addresses the root cause
- Write a lesson: what pattern should be avoided in future?
- Re-run VERIFICATION after the patch

**Required fields:**
- `root_cause`: non-empty, specific, not "it didn't work"
- `patch_applied`: true
- `lesson`: concrete, reusable learning

**Maximum 2 debug loops.** If VERIFICATION still fails after 2 loops, escalate to the operator.

**Blocks if:** No root cause identified, no patch applied, no lesson written.

---

## Stage 14: ECL — End Condition Lock

**Question:** Is this pipeline genuinely complete?

**The LLM must verify:**
- All 13 prior stages ran and produced artifacts
- Policy check: were constraints (CDR pillars, scope boundaries, mandatory stages) satisfied?
- Artifact integrity: does the final artifact hash match what IMPLEMENTATION produced?
- Delta: is the output demonstrably better than the input that was provided?

**Governance output:**
```
ECL:
  governance: "enforced"
  stages_ran: [all 14 stage names]
  pipeline_complete: true
  artifact_hash_verified: true
  delta_confirmed: true
```

**`pipeline_complete: true` is only valid when all of the above are confirmed.**

---

## The Iron Rule

**No stage can be skipped. No stage can pass by assertion.**

If MMD found a critical gap, it cannot be waived by saying "I'll handle it later." Later is DEBUGGING, and DEBUGGING runs only on VERIFICATION failure, not as a planning tool.

If CDR pillar 3 fails because a module is named `utils.py`, the pipeline blocks until the name changes.

If VERIFICATION fails, DEBUGGING runs. If DEBUGGING's patch fails VERIFICATION again, the pipeline escalates to the operator. It does not silently continue.

**The chain is only as valid as its weakest stage.**

---

## How to Use This Protocol

**When asked to write any code:**

1. Do not write a single line of implementation code until Stages 1–10 are complete.
2. Output each stage explicitly — show your work.
3. Use the output format shown for each stage.
4. If you cannot answer a stage's question, that is the gap MMD catches. Surface it. Do not guess.
5. After IMPLEMENTATION, run VERIFICATION against your own output before declaring done.
6. If VERIFICATION fails, run DEBUGGING. Do not skip to ECL.

**When asked to improve existing code:**

1. SEE: read the code. AST-analyze it. What is it? What does it do? What is broken?
2. MMD: what are the gaps between what it is and what it should be?
3. Proceed through CDR→OFM→ADS defining what the improved version must satisfy.
4. IMPLEMENTATION: write the improvement.
5. VERIFICATION: does the improved version satisfy the criteria defined in stages 1–10?

**When the input is genuinely broken:**

SEE will classify it E1 or E2. MMD will surface critical gaps. CDR will define what acceptable looks like. The LLM cannot skip to implementation — it must repair the gaps first, using DRS to record why each repair decision was made. The output will be world-class because every decision was deliberate, every constraint was explicit, and every failure mode was anticipated.

---

## Output Template (copy this for every MPP run)

```
OBJECTIVE: [what is being built]

SEE:
  evidence_count:
  input_artifact_status:
  key_findings:
  evidence_classification:

MMD:
  gaps:
  aca_findings:
  gap_count:

DRS:
  decisions:
    - decision_id:
      decision:
      rationale:
      alternatives_considered:

CDR:
  pillar_1_proactive_rationale: PASS|FAIL — [finding]
  pillar_2_constraint_mapping: PASS|FAIL — [finding]
  pillar_3_semantic_domain_authority: PASS|FAIL — [finding]
  pillar_4_anticipated_failure_intent: PASS|FAIL — [finding]
  pillar_5_integration_reciprocity: PASS|FAIL — [finding]
  pillar_6_history_aware_evolution: PASS|FAIL — [finding]
  pillar_7_mandatory_attestation: PASS|FAIL — [finding]
  blocking_violations: N

OFM:
  success_criteria:
  failure_criteria:

ADS:
  engine_list:
  dependency_map:
  authority_map:

UXR:
  operator:
  constraints:

NUF:
  requirements:

SSO:
  in_scope:
  out_of_scope:

RRP:
  failure_modes:

IMPLEMENTATION:
  [code here]
  artifact_hash: sha256(...)

VERIFICATION:
  check_1_artifact_exists: PASS|FAIL
  check_2_cdr_compliant: PASS|FAIL
  check_3_ofm_criteria_met: PASS|FAIL
  check_4_scope_respected: PASS|FAIL
  check_5_architecture_matches: PASS|FAIL
  check_6_lint_gate: PASS|FAIL
  check_7_hash_verified: PASS|FAIL
  result: PASS|FAIL→DEBUGGING

DEBUGGING: [if needed]
  root_cause:
  patch_applied:
  lesson:

ECL:
  governance: enforced
  stages_ran: [14]
  pipeline_complete: true|false
  artifact_hash_verified: true|false
```
