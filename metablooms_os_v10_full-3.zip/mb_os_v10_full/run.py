"""
run.py — MetaBlooms OS CLI

USAGE:
    # Validate and upgrade a Python file:
    python run.py engines/my_engine.py --request "implements a cache with TTL"

    # Pass code via stdin:
    cat my_code.py | python run.py --module cache_engine.py --request "TTL cache"

    # Dry-run (MPP only, no FORGE):
    python run.py engines/my_engine.py --request "..." --mpp-only

    # Specify output directory:
    python run.py engines/my_engine.py --request "..." --output ./my_output

    # Score only (no improvements applied):
    python run.py engines/my_engine.py --request "..." --dry-run
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

_ROOT = Path(__file__).parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))
if str(_ROOT / "engines") not in sys.path:
    sys.path.insert(0, str(_ROOT / "engines"))
if str(_ROOT / "forge") not in sys.path:
    sys.path.insert(0, str(_ROOT / "forge"))

from metablooms_os import run  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(
        description="MetaBlooms OS — governed code production: MPP → FORGE",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "file",
        nargs="?",
        help="Python file to validate and upgrade (or stdin if omitted)",
    )
    parser.add_argument(
        "--request",
        "-r",
        required=True,
        help="Plain-language description of what the code does",
    )
    parser.add_argument(
        "--module",
        "-m",
        default=None,
        help="Module filename (default: derived from input file name)",
    )
    parser.add_argument(
        "--output",
        "-o",
        default="./metablooms_output",
        help="Output directory (default: ./metablooms_output)",
    )
    parser.add_argument(
        "--mpp-only",
        action="store_true",
        help="Run MPP only — skip FORGE upgrade",
    )
    parser.add_argument(
        "--constraint",
        action="append",
        default=[],
        dest="constraints",
        help="Add a constraint (can be used multiple times)",
    )

    args = parser.parse_args()

    # Read code
    if args.file:
        path = Path(args.file)
        if not path.exists():
            print(f"Error: file not found: {args.file}", file=sys.stderr)
            sys.exit(1)
        code = path.read_text(encoding="utf-8")
        module_name = args.module or path.name
    elif not sys.stdin.isatty():
        code = sys.stdin.read()
        module_name = args.module or "stdin_module.py"
    else:
        print("Error: provide a file argument or pipe code via stdin", file=sys.stderr)
        sys.exit(1)

    if not module_name.endswith(".py"):
        module_name += ".py"

    context: dict = {}
    if args.constraints:
        context["constraints"] = args.constraints
    if args.mpp_only:
        context["mpp_only"] = True

    try:
        result = run(
            request=args.request,
            code=code,
            module_name=module_name,
            output_dir=Path(args.output),
            context=context,
        )
        sys.exit(0 if result.mpp_passed and result.forge_s_tier else 1)
    except RuntimeError as e:
        print(f"\n[MetaBlooms OS ERROR] {e}", file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
