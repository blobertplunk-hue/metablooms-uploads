# TURN_PROTOCOL.md
# MetaBlooms Turn Protocol — Complete Turn Structure
# Every session turn follows this protocol. No exceptions.
# Authority: This document defines what a complete turn looks like.

---

## WHAT A TURN IS

A turn is one cycle of governed reasoning and action.

A turn is NOT:
- A single message
- A stream of responses
- An answer to a question

A turn IS:
- A governed unit of work with verifiable inputs, decisions, and outputs
- A unit that must prove prior turn completion before starting
- A unit that advances the system state, leaves a receipt, and updates learning

---

## TURN PRECONDITIONS

Before this turn can begin, verify:

□ 1. Prior turn BTS_COMMIT exists on disk (BTS HARD RULE)
      If missing: this turn cannot start. Report TURN_BLOCKED_NO_PRIOR_COMMIT.
      Exception: first turn of a session — note as SESSION_START.

□ 2. KERNEL_SUPERVISOR heartbeat passes (trust plane)
      If BLOCKED: report which engines drifted. Do not accept objectives.
      If DEGRADED: warn but continue.

□ 3. SESSION_HANDOFF read (memory loop)
      Read state/SESSION_HANDOFF.json if present.
      Extract: decisions_made, open_gaps, next_actions[0]
      If missing: note HANDOFF_MISSING. Treat as first session.

□ 4. OBJECTIVE_ANCHOR checked (drift prevention)
      Read state/OBJECTIVE_ANCHOR.json if present.
      If current objective differs by >30% Jaccard from anchor: log DRIFTED.
      DRIFTED is advisory, not blocking — but must be logged and surfaced.

If any precondition fails: handle it explicitly. Do not silently proceed.

---

## PHASE 1: SHORT HORIZON (Evidence)

**Question: What does the filesystem actually show RIGHT NOW?**

This phase is evidence-only. No inference. No pattern completion.
No claims about what things do — only what things ARE.

SEE QUERIES to run (from knowledge/SEE_QUERIES.json):
  SEE-Q-001: Read state/TURN_STATE_LEDGER.json — what happened last turn
  SEE-Q-002: Scan canonical root — what files actually exist
  SEE-Q-003: Last BTS log entries
  SEE-Q-004: Open failure receipts (if any)
  SEE-Q-005: Uploaded files or new inputs
  SEE-Q-006: Confirm governance artifacts present

SHORT HORIZON OUTPUT:
  - Factual file inventory (not "the system has X" — "file X exists at path Y")
  - Evidence classification: E1 (none) / E2 (partial) / E3 (strong) / E4 (validated)
  - Open gaps from prior session
  - Current anchor status (ANCHORED / DRIFTED / NO_ANCHOR)

ERAC-001 CHECK: Every claim in this phase must cite the file read that
proves it. "The file contains X" requires showing the read.

---

## PHASE 2: MIDDLE HORIZON (Gap Analysis)

**Question: What is the gap between current evidence and objective completion?**

Run MMD (Missing Middle Detector):
  - What needs to exist that doesn't?
  - What needs to be true that isn't yet?
  - What needs to run that hasn't?

MIDDLE HORIZON OUTPUT:
  - Gap list with priority (critical / high / warn)
  - Dependency map (what must happen before what)
  - Risk assessment (which gaps create downstream failures)

This phase uses SHORT HORIZON evidence as its only input.
No new inferences from pattern completion. Gaps must be grounded in
the evidence inventory from Phase 1.

ERAC-003 CHECK: Every identified gap must have a named cause, not just
a description. "X is missing" needs "because Y" to be actionable.

---

## BTS DECISION POINT

Before proceeding to Phase 3, write BTS decision artifact.

This is the deliberateness gate. You cannot proceed to execution without
completing this decision. The artifact is the evidence of deliberation.

REQUIRED FIELDS:
{
  "decision_id": "DEC-<8hex>",
  "task_class": "<what kind of action — code_generation|architecture|packaging|diagnosis>",
  "objective": "<current objective verbatim>",
  "stage": "<current MPP stage>",
  "instinctive_choice": "<REQUIRED: what you would do without governance>",
  "governed_choice": "<REQUIRED: what rules and evidence require>",
  "rejected_choices": ["<REQUIRED: at least one rejected alternative with reason>"],
  "reasoning_summary": "<compact rationale>",
  "gates": [
    {"gate": "ERAC-001", "result": "PASS|FAIL"},
    {"gate": "ERAC-005", "result": "PASS|FAIL"},
    {"gate": "FOUR_LOOPS_CHECK", "result": "PASS|FAIL"},
    {"gate": "CONTRACT_COMPLETENESS", "result": "PASS|FAIL"}
  ],
  "confidence": 0.0-1.0,
  "evidence_available": ["<list of sources read in Phase 1>"]
}

VALIDATION: If instinctive_choice == governed_choice, you have not deliberated.
VALIDATION: If rejected_choices is empty, you have not deliberated.
VALIDATION: If FOUR_LOOPS_CHECK is FAIL, do not proceed to execution.

---

## PHASE 3: LONG HORIZON (Planning)

**Question: What does successful completion look like, and what are three ways this could fail?**

OFM (Outcome Framing):
  - Define measurable success criteria (at least one with numeric threshold)
  - Define failure criteria (at least two named failure modes)

RRP (Recovery Plan):
  - For each failure mode: named strategy (halt/fallback/retry/escalate)
  - Rollback path if the action fails mid-execution

LEARNING CHECK (pre-action):
  - Consult MISTAKE_REGISTRY for known risk classes matching this action
  - Consult SUCCESS_REGISTRY for proven patterns to prefer
  - If S4_CRITICAL risk found: surface in BTS decision as known_risks
  - If success pattern found: use it as governed_choice preference

LONG HORIZON OUTPUT:
  - Success criteria (measurable)
  - Failure modes (named, not described)
  - Recovery strategies
  - Known risks from learning (or "no matching classes found")
  - Success patterns from learning (or "no matching patterns found")

ERAC-005 CHECK: Does the long horizon address the SYSTEM PURPOSE, not
just the stated task? "It will boot" is not sufficient. "All four loops
will be functional" is.

---

## PHASE 4: EXECUTION (MPP Stages 1→19)

Run the MPP pipeline. Each stage advances only when StagePayloadValidator
returns PASS on real evidence.

STAGE ORDER (v10 Standalone + Governance):
SEE → NORMALIZE_EVIDENCE → MMD → DRS → CDR → OFM → ADS → UXR → NUF →
SSO → RRP → IMPLEMENTATION → VERIFICATION → TRACE_ANALYSIS →
ANALYSIS_EVALUATION → DEBUGGING → ECL → FIR → MONITOR

HARD GATES:
- TRACE_ANALYSIS: integrity < 0.80 → BLOCKED
- ANALYSIS_EVALUATION: verdict=FAIL → FIR force-REJECTED
- FIR: composite < 0.60 → BLOCKED
- ECL: any of 16 pre-ECL stages missing → BLOCKED

STAGE ADVANCEMENT RULE: No stage advances on narrative claim.
StagePayloadValidator PASS required. Evidence required.

---

## PHASE 5: VERIFICATION

COUNCIL JUDGMENT on output before finalizing:

RATIONALITY (0.35): Is every claim grounded in evidence read in Phase 1?
RELIABILITY (0.30): Has the output been tested, not just described?
ETHICS (0.20): Does this respect all constraints and stakeholders?
BUILDER (0.15): Does this advance the system, or create debt?

Quorum threshold: 0.85. Below threshold: REVISE or ESCALATE.
Any council ESCALATE = full ESCALATE.

ERAC FINAL SCAN (run before output):
  □ No ERAC-001 violations in output
  □ No ERAC-002 violations in output
  □ All failures have named root causes (ERAC-003 clear)
  □ Model failure modes named where relevant (ERAC-004 clear)
  □ System purpose addressed not just stated task (ERAC-005 clear)
  □ Both explicit and implicit contracts satisfied (ERAC-006 clear)

---

## PHASE 6: STATE UPDATE AND LEARNING

After output is verified and finalized:

1. Write TURN_STATE_LEDGER entry:
   - turn_id, timestamp, objective, stages_completed, artifacts_produced
   - open_gaps, next_actions, council_verdict, fir_score

2. Update SESSION_HANDOFF:
   - Add to decisions_made (settled — do not re-litigate)
   - Add to failures_diagnosed (if any new failure classes found)
   - Update open_gaps (remove completed, add new)
   - Update next_actions[0] (your first objective candidate for next turn)

3. Update LEARNING registries:
   - If new mistake class discovered: add to MISTAKE_REGISTRY
   - If successful pattern used: increment times_applied
   - Write to LEARNING_LEDGER.ndjson (append-only)

4. Write BTS_COMMIT:
   - This is the turn boundary. Prior turn cannot start without this.
   - turn_id, timestamp, artifact_hashes[], outcome_summary

---

## TURN REPORT FORMAT

At end of every turn, produce:

```
TURN REPORT — [turn_id]
Objective: [current objective]
Anchor status: [ANCHORED|DRIFTED|NO_ANCHOR]
Phases completed: [1|2|BTS|3|4|5|6]
Council verdict: [PASS|REVISE|ESCALATE] quorum=[score]
ERAC violations: [count] — [list if any]
New artifacts: [list with hashes]
Open gaps: [list]
Next action: [next_actions[0]]
Learning updates: [mistake classes added] [success patterns updated]
BTS_COMMIT: [decision_id]
```

---

## PROTOCOL VIOLATIONS

| Violation | Code | Action |
|-----------|------|--------|
| Prior turn BTS_COMMIT missing | TV-001 | Block turn, report |
| KERNEL_SUPERVISOR BLOCKED | TV-002 | Block turn, report engine drift |
| ERAC violation in output | TV-003 | Revise before finalizing |
| BTS instinctive_choice == governed_choice | TV-004 | Deliberate again |
| Stage advanced without validator PASS | TV-005 | Revert, require evidence |
| State update not written | TV-006 | Write before next turn |
| FOUR_LOOPS_CHECK failed in BTS | TV-007 | Address missing loops before export |
