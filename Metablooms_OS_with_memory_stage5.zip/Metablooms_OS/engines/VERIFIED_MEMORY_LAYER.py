from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Literal

VerifiedStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class VerifiedMemoryAnswer:
    summary: str
    memory_support_present: bool
    web_support_present: bool
    memory_ids: List[str]
    web_refs: List[str]


@dataclass
class VerifiedMemoryResult:
    status: VerifiedStatus
    reasons: List[str]
    answer: VerifiedMemoryAnswer | None


def verify_memory_answer(
    summary: str,
    memory_ids: List[str],
    web_refs: List[str],
) -> Dict[str, Any]:
    if not summary.strip():
        return asdict(
            VerifiedMemoryResult(status="FAIL_CLOSED", reasons=["empty_summary"], answer=None)
        )

    memory_support_present = bool(memory_ids)
    web_support_present = bool(web_refs)

    if not memory_support_present:
        return asdict(
            VerifiedMemoryResult(
                status="FAIL_CLOSED",
                reasons=["missing_memory_support"],
                answer=None,
            )
        )

    if not web_support_present:
        return asdict(
            VerifiedMemoryResult(
                status="FAIL_CLOSED",
                reasons=["missing_web_support"],
                answer=None,
            )
        )

    return asdict(
        VerifiedMemoryResult(
            status="PASS",
            reasons=[],
            answer=VerifiedMemoryAnswer(
                summary=summary,
                memory_support_present=True,
                web_support_present=True,
                memory_ids=memory_ids,
                web_refs=web_refs,
            ),
        )
    )
