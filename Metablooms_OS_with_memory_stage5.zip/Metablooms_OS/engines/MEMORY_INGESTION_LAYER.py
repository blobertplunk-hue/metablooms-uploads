from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Literal

IngestStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class IngestRecord:
    id: str
    content: str
    tags: List[str]


@dataclass
class IngestResult:
    status: IngestStatus
    reasons: List[str]
    ingested_count: int
    records: List[IngestRecord]


def _chunk_text(text: str, chunk_size: int = 400) -> List[str]:
    normalized = " ".join((text or "").split())
    if not normalized:
        return []
    return [normalized[i:i + chunk_size] for i in range(0, len(normalized), chunk_size)]


def ingest_json_records(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not records:
        return asdict(IngestResult(status="FAIL_CLOSED", reasons=["empty_records"], ingested_count=0, records=[]))

    out: List[IngestRecord] = []
    index = 1

    for record in records:
        content = str(record.get("content", "")).strip()
        tags = list(record.get("tags", []))
        if not content:
            continue

        for chunk in _chunk_text(content):
            out.append(IngestRecord(id=f"mem_{index}", content=chunk, tags=tags))
            index += 1

    if not out:
        return asdict(IngestResult(status="FAIL_CLOSED", reasons=["no_valid_content"], ingested_count=0, records=[]))

    return asdict(IngestResult(status="PASS", reasons=[], ingested_count=len(out), records=out))


def load_json_file(path: str) -> Dict[str, Any]:
    source = Path(path)
    if not source.exists():
        return asdict(IngestResult(status="FAIL_CLOSED", reasons=["missing_source_file"], ingested_count=0, records=[]))
    payload = json.loads(source.read_text(encoding="utf-8"))
    if not isinstance(payload, list):
        return asdict(IngestResult(status="FAIL_CLOSED", reasons=["source_not_list"], ingested_count=0, records=[]))
    return ingest_json_records(payload)
