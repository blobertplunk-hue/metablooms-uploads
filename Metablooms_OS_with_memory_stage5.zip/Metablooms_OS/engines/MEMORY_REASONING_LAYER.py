from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Literal
import json
from pathlib import Path

ReasoningStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class ReasoningQuery:
    query: str
    max_items: int


@dataclass
class ReasoningAnswer:
    summary: str
    supporting_fact_ids: List[str]
    supporting_procedure_ids: List[str]
    fallback_used: bool


@dataclass
class ReasoningResult:
    status: ReasoningStatus
    reasons: List[str]
    answer: ReasoningAnswer | None


MEMORY_ROOT = Path("/mnt/data/Metablooms_OS/memory")


def _load_json(path: Path) -> Dict[str, Any] | List[Dict[str, Any]]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def _query_tokens(query: str) -> List[str]:
    return [token.strip().lower() for token in query.split() if token.strip()]


def _match_score(text: str, tokens: List[str]) -> int:
    lowered = (text or "").lower()
    return sum(1 for token in tokens if token in lowered)


def reason_over_memory(query: str, max_items: int = 5) -> Dict[str, Any]:
    normalized = (query or "").strip()
    if not normalized:
        return asdict(
            ReasoningResult(
                status="FAIL_CLOSED",
                reasons=["empty_query"],
                answer=None,
            )
        )

    consolidated = _load_json(MEMORY_ROOT / "memory_consolidated.json")
    facts = list(consolidated.get("fact_cards", [])) if isinstance(consolidated, dict) else []
    procedures = list(consolidated.get("procedure_cards", [])) if isinstance(consolidated, dict) else []
    tokens = _query_tokens(normalized)

    ranked_facts = sorted(
        facts,
        key=lambda item: _match_score(item.get("claim", ""), tokens),
        reverse=True,
    )
    ranked_procedures = sorted(
        procedures,
        key=lambda item: _match_score(item.get("title", ""), tokens),
        reverse=True,
    )

    selected_facts = [item for item in ranked_facts if _match_score(item.get("claim", ""), tokens) > 0][:max_items]
    selected_procedures = [
        item for item in ranked_procedures if _match_score(item.get("title", ""), tokens) > 0
    ][:max_items]

    if selected_facts or selected_procedures:
        fact_lines = [f"- {item.get('claim', '')}" for item in selected_facts]
        procedure_lines = [f"- {item.get('title', '')}" for item in selected_procedures]
        summary_parts = []
        if fact_lines:
            summary_parts.append("Matched fact cards:\n" + "\n".join(fact_lines))
        if procedure_lines:
            summary_parts.append("Matched procedure cards:\n" + "\n".join(procedure_lines))
        summary = "\n\n".join(summary_parts)
        return asdict(
            ReasoningResult(
                status="PASS",
                reasons=[],
                answer=ReasoningAnswer(
                    summary=summary,
                    supporting_fact_ids=[item.get("id", "") for item in selected_facts],
                    supporting_procedure_ids=[item.get("id", "") for item in selected_procedures],
                    fallback_used=False,
                ),
            )
        )

    # Fallback to raw corpus when consolidation is empty or has no matches
    corpus = _load_json(MEMORY_ROOT / "memory_corpus.json")
    if not isinstance(corpus, list):
        corpus = []

    selected_records = []
    for record in corpus:
        if _match_score(record.get("content", ""), tokens) > 0:
            selected_records.append(record)
        if len(selected_records) >= max_items:
            break

    if not selected_records:
        return asdict(
            ReasoningResult(
                status="FAIL_CLOSED",
                reasons=["no_matching_memory"],
                answer=None,
            )
        )

    summary = "Fallback matched raw memory records:\n" + "\n".join(
        f"- {record.get('content', '')}" for record in selected_records
    )

    return asdict(
        ReasoningResult(
            status="PASS",
            reasons=["used_raw_memory_fallback"],
            answer=ReasoningAnswer(
                summary=summary,
                supporting_fact_ids=[],
                supporting_procedure_ids=[],
                fallback_used=True,
            ),
        )
    )
