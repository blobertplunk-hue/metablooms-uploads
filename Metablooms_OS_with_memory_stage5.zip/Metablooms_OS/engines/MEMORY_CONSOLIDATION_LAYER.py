from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Literal

MemoryStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class MemoryChunk:
    id: str
    content: str
    tags: List[str]
    vector: List[float]


@dataclass
class FactCard:
    id: str
    claim: str
    support_count: int
    source_ids: List[str]
    tags: List[str]


@dataclass
class ProcedureCard:
    id: str
    title: str
    steps: List[str]
    source_ids: List[str]
    tags: List[str]


@dataclass
class ConsolidationResult:
    status: MemoryStatus
    fact_cards: List[FactCard]
    procedure_cards: List[ProcedureCard]
    reasons: List[str]


def _canonical_claim(text: str) -> str:
    return " ".join((text or "").strip().lower().split())


def consolidate_memory(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not records:
        return asdict(
            ConsolidationResult(
                status="FAIL_CLOSED",
                fact_cards=[],
                procedure_cards=[],
                reasons=["empty_memory_records"],
            )
        )

    fact_map: Dict[str, Dict[str, Any]] = {}
    procedure_cards: List[ProcedureCard] = []

    for record in records:
        rec_id = str(record.get("id", ""))
        content = str(record.get("content", "")).strip()
        tags = list(record.get("tags", []))

        if not content:
            continue

        canonical = _canonical_claim(content)
        if canonical not in fact_map:
            fact_map[canonical] = {
                "id": f"fact_{len(fact_map)+1}",
                "claim": content,
                "support_count": 0,
                "source_ids": [],
                "tags": tags,
            }

        fact_map[canonical]["support_count"] += 1
        fact_map[canonical]["source_ids"].append(rec_id)

        if "steps" in tags or "procedure" in tags:
            steps = [segment.strip() for segment in content.split(".") if segment.strip()]
            procedure_cards.append(
                ProcedureCard(
                    id=f"procedure_{len(procedure_cards)+1}",
                    title=content[:60],
                    steps=steps,
                    source_ids=[rec_id],
                    tags=tags,
                )
            )

    fact_cards = [
        FactCard(
            id=data["id"],
            claim=data["claim"],
            support_count=data["support_count"],
            source_ids=data["source_ids"],
            tags=data["tags"],
        )
        for data in fact_map.values()
    ]

    return asdict(
        ConsolidationResult(
            status="PASS",
            fact_cards=fact_cards,
            procedure_cards=procedure_cards,
            reasons=[],
        )
    )
