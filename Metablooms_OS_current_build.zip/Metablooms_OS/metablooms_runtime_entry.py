"""
metablooms_runtime_entry.py — enforced runtime entry for MetaBlooms OS.
"""

from __future__ import annotations

from typing import Any

from engines.ARTIFACT_GATE_PLUS_CITATION_GATE import validate_response
from engines.TASK_NORMALIZER import normalize_task


def run(
    request: str, draft: str, citations: dict[str, list[dict[str, Any]]]
) -> dict[str, Any]:
    """Normalize the task, then require citation-gate PASS before allowing a response."""
    normalized = normalize_task(request)
    if normalized["status"] != "PASS":
        return normalized

    validation = validate_response(draft, citations)
    if validation["status"] != "PASS":
        return {
            "status": "FAIL_CLOSED",
            "stage": "citation_gate",
            "normalized_task": normalized,
            "validation": validation,
        }

    return {
        "status": "PASS",
        "stage": "response_allowed",
        "normalized_task": normalized,
        "validation": validation,
    }
