# metablooms_enforced_pipeline.py

"""
Full Enforcement Pipeline:
- Memory Retrieval (SQLite)
- External Verification (LLM must call web.run externally)
- Citation Bundle Builder
- Citation Validator (fail-closed)

NOTE:
This script orchestrates structure only.
External citations must be injected by LLM after web.run.
"""

import re
import sqlite3
from pathlib import Path

DB = Path("/mnt/data/brain_v3_complete_1774214265.sqlite")

# -----------------------------
# MEMORY RETRIEVAL
# -----------------------------


def get_memory(query):
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()

    rows = cur.execute(
        """
        SELECT m.message_id, m.conversation_id, c.url, m.text
        FROM message_fts
        JOIN messages m ON m.rowid = message_fts.rowid
        JOIN conversations c ON c.conversation_id = m.conversation_id
        WHERE message_fts MATCH ?
        LIMIT 5
    """,
        (query,),
    ).fetchall()

    conn.close()

    return [
        {
            "claim_source": r["text"][:200],
            "conversation_id": r["conversation_id"],
            "message_id": r["message_id"],
            "url": r["url"],
        }
        for r in rows
    ]


# -----------------------------
# CLAIM EXTRACTION
# -----------------------------


def extract_claims(text):
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return [s.strip() for s in sentences if len(s.strip()) > 20]


# -----------------------------
# CITATION BUILDER
# -----------------------------


def build_memory_citations(claims, memory):
    citations = []

    for claim in claims:
        for m in memory:
            if claim[:20].lower() in m["claim_source"].lower():
                citations.append({"claim": claim, "memory": m})
                break

    return citations


# -----------------------------
# VALIDATOR
# -----------------------------


def validate(claims, mem_citations, ext_citations):
    failures = []

    for c in claims:
        mem_ok = any(mc["claim"] == c for mc in mem_citations)
        ext_ok = any(ec["claim"] == c for ec in ext_citations)

        if not mem_ok:
            failures.append({"claim": c, "missing": "memory"})
        if not ext_ok:
            failures.append({"claim": c, "missing": "external"})

    if failures:
        return {"status": "FAIL_CLOSED", "failures": failures}

    return {"status": "PASS"}


# -----------------------------
# PIPELINE ENTRY
# -----------------------------


def run_pipeline(query, draft_answer, external_citations):
    memory = get_memory(query)
    claims = extract_claims(draft_answer)

    mem_citations = build_memory_citations(claims, memory)

    result = validate(claims, mem_citations, external_citations)

    return {
        "memory": memory,
        "claims": claims,
        "memory_citations": mem_citations,
        "external_citations": external_citations,
        "validation": result,
    }


if __name__ == "__main__":
    q = "exporter telemetry"
    draft = "Telemetry must be visible before trusting execution."
    ext = []  # must be filled by web.run layer

    print(run_pipeline(q, draft, ext))
