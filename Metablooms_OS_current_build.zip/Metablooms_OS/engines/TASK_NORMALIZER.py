"""
TASK_NORMALIZER.py — mandatory user-input normalization gate for MetaBlooms OS.
"""

from __future__ import annotations

import re
from typing import Any

TASK_CLASS_RULES = [
    (
        "coding",
        [
            r"\bbuild\b",
            r"\bimplement\b",
            r"\bpatch\b",
            r"\bscript\b",
            r"\bwire\b",
            r"\brepair\b",
        ],
    ),
    (
        "research",
        [
            r"\bresearch\b",
            r"\bverify\b",
            r"\bvalidate\b",
            r"\bfind out\b",
            r"\blook up\b",
        ],
    ),
    (
        "debugging",
        [r"\bdebug\b", r"\bfix\b", r"\berror\b", r"\bfailure\b", r"\bstuck\b"],
    ),
    (
        "os_governance",
        [
            r"\bmetablooms\b",
            r"\bboot\b",
            r"\bruntime\b",
            r"\bartifact\b",
            r"\bgovernance\b",
        ],
    ),
    ("reasoning", [r"\bwhy\b", r"\bhow\b", r"\bwhat\b", r"\banalyze\b"]),
]
CONSTRAINT_HINTS = [
    ("sandbox_only", [r"\bsandbox\b", r"\bin chatgpt\b", r"\bnot on my computer\b"]),
    ("artifact_first", [r"\b/mnt/data\b", r"\bartifact\b", r"\bproject files\b"]),
    ("fail_closed", [r"\bfail closed\b", r"\bblock\b", r"\bmust not\b"]),
    ("citations_required", [r"\bcitation\b", r"\bcite\b", r"\bweb\.run\b"]),
    ("memory_required", [r"\bmemory\b", r"\bprior chat\b", r"\bchat history\b"]),
]
OUTPUT_HINTS = [
    ("python_artifact", [r"\bpython\b", r"\bscript\b", r"\bengine\b"]),
    ("json_artifact", [r"\bjson\b", r"\bschema\b", r"\bconfig\b"]),
    (
        "markdown_artifact",
        [r"\bprotocol\b", r"\bcontract\b", r"\bprompt\b", r"\bdoc\b"],
    ),
    ("receipt", [r"\breceipt\b", r"\bmanifest\b", r"\bproof\b"]),
]
VALIDATION_DEFAULTS = {
    "coding": [
        "artifact exists in canonical OS root",
        "imports or loads without syntax error",
        "registered in ENGINE_REGISTRY when engine-like",
    ],
    "research": [
        "claims have dual citations when applicable",
        "web.run used for external verification",
    ],
    "debugging": [
        "root cause is named",
        "repair artifact exists",
        "verification rerun passes",
    ],
    "os_governance": [
        "boot artifacts loaded first",
        "artifact gate enforced",
        "citation gate enforced",
    ],
    "reasoning": ["response grounded in memory citations"],
}


def _match_any(text: str, patterns: list[str]) -> bool:
    """Return True when any regex pattern matches."""
    return any(re.search(pattern, text, flags=re.I) for pattern in patterns)


def classify_task(request: str) -> str:
    """Classify a raw request into a task class."""
    for task_class, patterns in TASK_CLASS_RULES:
        if _match_any(request, patterns):
            return task_class
    return "reasoning"


def infer_constraints(request: str) -> list[str]:
    """Infer named constraints from the request."""
    inferred: list[str] = []
    for name, patterns in CONSTRAINT_HINTS:
        if _match_any(request, patterns):
            inferred.append(name)
    return inferred


def infer_required_output(request: str, task_class: str) -> list[str]:
    """Infer required output artifact types."""
    inferred: list[str] = []
    for name, patterns in OUTPUT_HINTS:
        if _match_any(request, patterns):
            inferred.append(name)
    if inferred:
        return inferred
    if task_class == "coding":
        return ["python_artifact", "receipt"]
    if task_class == "research":
        return ["json_artifact", "markdown_artifact"]
    return ["markdown_artifact"]


def infer_validation(
    task_class: str, constraints: list[str], outputs: list[str]
) -> list[str]:
    """Build validation checks for the task contract."""
    checks = list(VALIDATION_DEFAULTS.get(task_class, []))
    if "citations_required" in constraints:
        checks.append("every non-trivial claim has memory citation")
        checks.append("every external or factual claim has web.run citation")
    if "sandbox_only" in constraints:
        checks.append("no local-machine-only path required")
    if "receipt" in outputs:
        checks.append("receipt or manifest written")
    return checks


def normalize_task(request: str) -> dict[str, Any]:
    """Normalize raw user input into a governed task contract."""
    req = (request or "").strip()
    if not req:
        return {
            "status": "FAIL_CLOSED",
            "reasons": ["empty_request"],
            "task": "",
            "task_class": "unknown",
            "constraints": [],
            "required_output": [],
            "validation": [],
            "external_verification_required": False,
            "memory_required": False,
            "artifact_gate_required": False,
        }

    task_class = classify_task(req)
    constraints = infer_constraints(req)
    required_output = infer_required_output(req, task_class)
    validation = infer_validation(task_class, constraints, required_output)
    external_required = (
        task_class == "research"
        or "citations_required" in constraints
        or bool(
            re.search(
                r"\b(current|latest|verify|validate|fact check|web\.run)\b",
                req,
                flags=re.I,
            )
        )
    )
    memory_required = "memory_required" in constraints or bool(re.search(
        r"\b(prior chat|chat history|memory|across all chats)\b", req, flags=re.I))
    artifact_gate_required = (
        task_class in {"coding", "debugging", "os_governance"}
        or "artifact_first" in constraints
    )

    reasons: list[str] = []
    if artifact_gate_required and "artifact_first" not in constraints:
        reasons.append("artifact_gate_inferred")
    if external_required and "citations_required" not in constraints:
        reasons.append("external_verification_inferred")

    return {
        "status": "PASS",
        "reasons": reasons,
        "task": req,
        "task_class": task_class,
        "constraints": constraints,
        "required_output": required_output,
        "validation": validation,
        "external_verification_required": external_required,
        "memory_required": memory_required,
        "artifact_gate_required": artifact_gate_required,
    }
