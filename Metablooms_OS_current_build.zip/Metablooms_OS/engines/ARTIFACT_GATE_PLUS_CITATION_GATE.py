# artifact_gate_plus_citation_gate.py

import re
from typing import Any, Dict, List

REQUIRE_EXTERNAL = True


def extract_claims(text: str) -> List[str]:
    sentences = re.split(r"(?<=[.!?])\s+", text)
    return [s.strip() for s in sentences if len(s.strip()) > 20]


def has_memory_citation(claim: str, citations: Dict) -> bool:
    return any(c.get("claim") == claim for c in citations.get("memory", []))


def has_external_citation(claim: str, citations: Dict) -> bool:
    return any(c.get("claim") == claim for c in citations.get("external", []))


def validate_response(
        text: str, citations: Dict[str, List[Dict]]) -> Dict[str, Any]:
    claims = extract_claims(text)
    failures = []

    for claim in claims:
        mem_ok = has_memory_citation(claim, citations)
        ext_ok = has_external_citation(claim, citations)

        if not mem_ok:
            failures.append({"claim": claim, "missing": "memory_citation"})

        if REQUIRE_EXTERNAL and not ext_ok:
            failures.append({"claim": claim, "missing": "external_citation"})

    if failures:
        return {"status": "FAIL_CLOSED", "failures": failures}

    return {"status": "PASS", "claims_checked": len(claims)}


if __name__ == "__main__":
    test_text = "Boot is required before reasoning. Artifacts must be inspected first."

    citations = {
        "memory": [{"claim": "Boot is required before reasoning."}],
        "external": [],
    }

    print(validate_response(test_text, citations))
