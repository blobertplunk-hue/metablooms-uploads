
# MetaBlooms S-Tier Memory Citation System

## Purpose

This specification defines a **fail-closed citation system** for the MetaBlooms memory layer.

It is designed to stop the runtime from reverting to conversational reasoning when a claim should be grounded in:
1. **memory artifacts**
2. **external verification artifacts**

A response is valid only when every non-trivial claim is backed by an explicit citation bundle.

---

## Core Principle

**No claim without traceable provenance.**

For every claim, the system must answer:

- Which chat did this come from?
- Which message in that chat?
- Which span inside that message?
- Is it supported by one chat or multiple chats?
- Was it copied/reused across chats?
- Was it externally verified?
- Is it a quote, paraphrase, synthesis, or inference?

If any required answer is missing, the response must **FAIL CLOSED**.

---

## Two-Layer Citation Model

Every claim may carry up to two required citation layers.

### Layer A — Memory Citation
Required for any statement derived from the user's chats.

### Layer B — External Citation
Required for any statement that is factual, time-sensitive, normative, or about the outside world.

---

## Citation Classes

### 1. Direct Memory Citation
Use when a claim is stated explicitly in one message or chunk.

### 2. Multi-Chat Support Citation
Use when the same claim is supported by multiple chats.

### 3. Cross-Chat Reuse Citation
Use when text or instructions were copied/pasted between chats.

### 4. Memory Synthesis Citation
Use when a conclusion is derived from several cited memory fragments.

### 5. External Verification Citation
Use when the claim is validated or contradicted by web.run evidence.

---

## Required Data Model

### Claim Record

```json
{
  "claim_id": "claim:...",
  "claim_text": "The exporter required telemetry visibility.",
  "claim_type": "memory_direct | memory_synthesis | external_fact | procedure | preference | behavioral_pattern",
  "render_mode": "quote | paraphrase | synthesis",
  "requires_external_verification": false,
  "status": "supported | contradicted | uncertain | memory_only | externally_supported | externally_contradicted",
  "memory_citations": [],
  "external_citations": [],
  "support_summary": {}
}
```

---

## Layer A — Memory Citation Schema

### Memory Citation Object

```json
{
  "memory_citation_id": "mem:...",
  "support_type": "direct_message | direct_chunk | multi_chat | reuse_link | synthesized",
  "conversation_id": "8d7aae9bbc5622cb",
  "conversation_url": "https://chatgpt.com/c/...",
  "message_id": "msg:...",
  "message_position": 3,
  "chunk_id": "chunk:...",
  "span": {
    "char_start": 120,
    "char_end": 228,
    "text": "telemetry must be visible"
  },
  "text_hash": "sha256:...",
  "quote_exact": true,
  "role": "user | assistant",
  "support_weight": 1.0
}
```

### Rules

- `conversation_id` is mandatory
- `message_id` is mandatory unless citing a derived artifact like a fact card
- `span.text` is mandatory for quote mode
- `text_hash` is mandatory for exactness validation
- `quote_exact=true` only if the quoted text matches the source span exactly
- paraphrases must set `quote_exact=false`

---

## Multi-Chat Support Schema

```json
{
  "support_type": "multi_chat",
  "primary": { "...memory citation..." },
  "corroborating": [
    { "...memory citation..." },
    { "...memory citation..." }
  ],
  "support_count": 3,
  "conversation_count": 3
}
```

### Use Cases

- user preference repeated across chats
- procedure repeated across iterations
- system requirement repeated in multiple turns

---

## Cross-Chat Reuse Schema

```json
{
  "support_type": "reuse_link",
  "source_conversation_id": "source_chat",
  "source_message_id": "source_message",
  "target_conversation_id": "target_chat",
  "target_message_id": "target_message",
  "reuse_type": "exact_message_reuse | near_duplicate | pasted_block",
  "normalized_hash": "sha256:...",
  "normalized_len": 5585,
  "score": 1.0
}
```

### Use Case

This is a **first-class citation**, not a footnote.
In your corpus this matters because pasted blocks are evidence of:
- working-memory transfer
- cross-thread continuity
- instruction propagation

---

## Memory Synthesis Schema

Use when the answer is not a quote but a structured conclusion.

```json
{
  "support_type": "synthesized",
  "synthesis_method": "pattern_aggregation | timeline_reconstruction | procedure_reconstruction",
  "primary_fragments": [
    { "...memory citation..." },
    { "...memory citation..." }
  ],
  "derived_claim": "The system performs better when telemetry is required before execution."
}
```

### Rule

A synthesis claim is only allowed if it cites **at least two primary fragments**.

No single-fragment synthesis.

---

## Layer B — External Citation Schema

```json
{
  "external_citation_id": "web:...",
  "source_type": "web.run",
  "ref_id": "turnXsearchY",
  "claim_relation": "supports | contradicts | qualifies",
  "excerpt_mode": "paraphrase | exact_short_quote",
  "source_title": "SQLite FTS5 Extension",
  "source_domain": "sqlite.org"
}
```

### Rules

- any externally grounded claim must include at least one `ref_id`
- if the claim is time-sensitive, external citation is mandatory
- if external evidence contradicts memory, external status overrides memory-only status

---

## Claim Status Taxonomy

```json
{
  "supported": "Supported by memory citations only",
  "memory_only": "Memory evidence exists, but no external verification performed",
  "externally_supported": "Memory evidence plus web.run support",
  "externally_contradicted": "Memory evidence exists, but web.run contradicts it",
  "uncertain": "Evidence insufficient or mixed",
  "contradicted": "Memory evidence conflicts internally"
}
```

---

## Render Rules

### Exact Quote
Allowed only when:
- `quote_exact=true`
- exact `span.text` is present
- exact `text_hash` validates

### Paraphrase
Allowed only when:
- source span exists
- quote flags are false
- response explicitly treats it as paraphrase, not quotation

### Synthesis
Allowed only when:
- at least 2 source fragments
- synthesis method recorded
- all fragments cited

---

## Natural Language Rendering Format

### Compact In-Chat Form

```text
The exporter required visible telemetry.[M1][M2][W1]
```

### Citation Expansion

```json
{
  "M1": {
    "conversation_id": "...",
    "message_id": "...",
    "snippet": "telemetry must be visible",
    "type": "direct_message"
  },
  "M2": {
    "conversation_id": "...",
    "message_id": "...",
    "snippet": "show telemetry in the execution block",
    "type": "multi_chat_corroboration"
  },
  "W1": {
    "ref_id": "turn0search0",
    "domain": "sqlite.org",
    "relation": "supports"
  }
}
```

---

## Confidence and Weighting

Suggested internal scoring:

- direct exact message support: +1.0
- corroborating chat support: +0.6 each
- reuse-link support: +0.8
- synthesis penalty: -0.2
- external support: +1.2
- external contradiction: override to contradicted

These scores are for ranking, not for replacing citations.

---

## Hard Fail-Closed Rules

The system must block output when:

1. a non-trivial claim has no `memory_citations`
2. a factual/time-sensitive claim has no `external_citations`
3. quote text is not exact but is rendered as a quote
4. synthesis claim has fewer than two source fragments
5. cited `message_id` / `chunk_id` / `ref_id` does not resolve
6. a claim says "you often", "you usually", "you tend to" without multi-chat support

### Fail-Closed Output

```json
{
  "status": "FAIL_CLOSED",
  "missing": [
    "memory_citation",
    "external_citation"
  ],
  "claim_id": "claim:..."
}
```

---

## Citation Bundle Example

```json
{
  "claim_id": "claim:telemetry_requirement",
  "claim_text": "You repeatedly required telemetry visibility before trusting execution.",
  "claim_type": "behavioral_pattern",
  "render_mode": "synthesis",
  "requires_external_verification": false,
  "status": "supported",
  "memory_citations": [
    {
      "memory_citation_id": "mem:1",
      "support_type": "direct_message",
      "conversation_id": "convA",
      "conversation_url": "https://chatgpt.com/c/...",
      "message_id": "msgA",
      "message_position": 12,
      "span": {
        "char_start": 41,
        "char_end": 72,
        "text": "telemetry must be visible"
      },
      "text_hash": "sha256:abc",
      "quote_exact": false,
      "role": "user",
      "support_weight": 1.0
    },
    {
      "memory_citation_id": "mem:2",
      "support_type": "direct_message",
      "conversation_id": "convB",
      "conversation_url": "https://chatgpt.com/c/...",
      "message_id": "msgB",
      "message_position": 8,
      "span": {
        "char_start": 18,
        "char_end": 64,
        "text": "telemetry still isn't getting written"
      },
      "text_hash": "sha256:def",
      "quote_exact": false,
      "role": "user",
      "support_weight": 0.8
    }
  ],
  "external_citations": [],
  "support_summary": {
    "conversation_count": 2,
    "exact_quote_count": 0,
    "reuse_links": 0
  }
}
```

---

## Integration with Artifact Gate Plus

The runtime sequence becomes:

```text
task normalizer
→ artifact gate
→ memory retrieval
→ citation bundle construction
→ external verification
→ citation validation
→ response
```

No response may bypass citation bundle construction.

---

## Recommended Artifact Files

- `/mnt/data/memory_citation_schema.json`
- `/mnt/data/artifact_gate_plus_rules.json`
- `/mnt/data/citation_validator.py`
- `/mnt/data/claim_bundle_examples.json`

---

## Final Standard

The runtime must not merely say something plausible.

It must be able to prove:

- where it remembered it from
- where in the chat it came from
- whether it was repeated elsewhere
- whether external evidence still supports it
