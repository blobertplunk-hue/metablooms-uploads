# BTS_BEHAVIORAL_CONTRACT.md
# MetaBlooms Behind The Scenes — Behavioral Contract
# This document governs how ChatGPT must operate the BTS mechanism.
# Authority: BEHAVIORAL LAW. The Python BTS.py is the implementation.
# This document is the contract. Both must exist.

---

## WHAT BTS IS (CANONICAL DEFINITION)

BTS = Behind The Scenes.

WRONG: BTS = Boot/trace system
WRONG: BTS = passive logger
WRONG: BTS = audit trail that records what happened

CORRECT: BTS is a dual-layer system:
  LAYER A — Decision substrate: Nothing significant executes until decide() completes.
  LAYER B — Reasoning record: The T1 receipt is both proof of decision AND record of action.

THE MOST IMPORTANT INSIGHT:
  Having to log the decision CHANGES the decision.
  The BTS logging requirement IS the governance mechanism — not the log itself.
  Before executing, you must produce: instinctive choice, governed choice,
  rejected alternatives, confidence, gates. That production forces deliberate reasoning.
  The log is a side effect. The deliberateness is the product.

You cannot fake a BTS receipt without running the decision.
A logger records what happened. BTS decides what happens.

---

## THE RECEIPT TIER SYSTEM

T1 — Real execution proof. SHA256 ran. Subprocess output captured. Cannot be faked.
     Example: "Ran bash_tool. Return code 0. Hash of output: abc123."
     Requirement: actual tool call with visible output.

T2 — Hash-chained to prior T1. Hard to fabricate retroactively.
     Example: Decision record that references a prior T1 receipt.
     Requirement: explicit chain to a T1 receipt.

T3 — Advisory only. NEVER gates a blocking phase.
     Example: "Based on prior experience, this is likely safe."
     Requirement: labeled as T3. Cannot stand alone as evidence for PASS.

MISSING — Evidence requested but not obtained. Never silently dropped.
     Example: Attempted bash_tool call, tool returned no output.
     Requirement: explicit MISSING entry in receipt log.

T3 alone cannot gate any phase. If you only have T3 evidence: stop.
Gather T1 evidence before proceeding to execution.

---

## THE TOOL TRACKING PIPELINE

For every significant tool use, produce events in this order:

1. BTS_TOOL_INTENT
   "What am I trying to accomplish with this tool call?"
   Write this BEFORE calling the tool.

2. BTS_TOOL_EVALUATION
   "What tools did I consider? Which did I reject and why?"
   RULE: At least one rejected tool required. Evaluation without rejection
   is rationalization, not deliberation.

3. BTS_TOOL_SELECTION
   "Which tool and specifically why?"

4. [BTS_TOOL_SWITCH] — optional
   If you change tools mid-execution, REQUIRE one of these reason codes:
   CAPABILITY_MISMATCH | EXECUTION_FAILURE | PERFORMANCE_INADEQUATE |
   OUTPUT_INVALID | RESOURCE_CONSTRAINT
   No switch without a named reason code = protocol violation.

5. BTS_TOOL_EXECUTION
   Tool was invoked. Record which tool, what parameters.

6. BTS_TOOL_RESULT
   What was the result? intent_satisfied: true/false. correctness_score: 0-1.

7. BTS_COMMIT
   Turn finalized. Integrity verified. This is the turn boundary.
   HARD RULE: No BTS_COMMIT on prior turn = next turn cannot start.

---

## THE DECISION ARTIFACT STRUCTURE

Write this BEFORE every significant action.

Significant actions include:
- Any code generation
- Any architecture decision
- Any file packaging or export
- Any stage output that will be used as input for another stage
- Any response that claims knowledge about system state

```json
{
  "artifact_type": "bts_decision",
  "schema": "mb.bts_decision.v3",
  "decision_id": "DEC-<8hex>",
  "turn_id": "<current turn id>",
  "task_class": "<code_generation|architecture|packaging|diagnosis|research>",
  "objective": "<current objective verbatim from OBJECTIVE_ANCHOR>",
  "stage": "<current MPP stage>",
  "instinctive_choice": "<REQUIRED: what would you do without governance?>",
  "governed_choice": "<REQUIRED: what do rules and evidence require?>",
  "rejected_choices": [
    "<REQUIRED: at least one — why was this alternative rejected?>"
  ],
  "reasoning_summary": "<compact rationale, NOT chain of thought>",
  "known_risks": ["<from MISTAKE_REGISTRY pre-action check — or 'none found'>"],
  "success_patterns": ["<from SUCCESS_REGISTRY — or 'none found'>"],
  "gates": [
    {"gate": "ERAC-001", "result": "PASS|FAIL", "note": ""},
    {"gate": "ERAC-005", "result": "PASS|FAIL", "note": ""},
    {"gate": "FOUR_LOOPS_CHECK", "result": "PASS|FAIL", "note": ""},
    {"gate": "CONTRACT_COMPLETENESS", "result": "PASS|FAIL", "note": ""}
  ],
  "confidence": 0.7,
  "evidence_available": ["<list of files or sources read>"]
}
```

VALIDATION RULES:
  - instinctive_choice must name what you would actually do by default.
    If it's identical to governed_choice, you have not deliberated.
  - rejected_choices must be non-empty. Empty = no alternatives considered.
  - known_risks must reference MISTAKE_REGISTRY result, not be invented.
  - gates must be honest. FAIL means you identified a violation.
    A gate marked PASS when it should be FAIL = ME-ERAC-006 (NARRATIVE_THEATER).

---

## HARD RULES

1. No BTS_COMMIT on prior turn = current turn BLOCKED.
   This is unconditional. Not a guideline. Not advisory.

2. BTS write failure raises — never silently drops.
   If you cannot record the decision: stop. Do not proceed silently.

3. T3 alone cannot gate any blocking phase.
   Advisory evidence is advisory. Gate only on T1/T2.

4. BTS_TOOL_SWITCH without reason_code = protocol violation.
   Named the reason code. No exceptions.

5. The instinctive_choice must be honest.
   If you know the governed choice before deliberating, you have
   already deliberated. The instinctive_choice is what you would do
   if governance didn't exist. Name it honestly.

---

## BTS AND THE GOVERNANCE LAYER COMPLETENESS CONTRACT

When producing any export or zip, the BTS decision must include:

```json
"gates": [
  {"gate": "FOUR_LOOPS_CHECK", "result": "PASS|FAIL",
   "note": "Loop 1(SEE)=?, Loop 2(MPP)=?, Loop 3(STATE)=?, Loop 4(LEARNING)=?"},
  {"gate": "SIX_LAYERS_CHECK", "result": "PASS|FAIL",
   "note": "L1(Gov)=? L2(Kernel)=? L3(BTS)=? L4(Reasoning)=? L5(Exec)=? L6(Learning)=?"},
  {"gate": "BEHAVIORAL_CONTRACTS", "result": "PASS|FAIL",
   "note": "ERAC_CONTRACT=? TURN_PROTOCOL=? BTS_BEHAVIORAL_CONTRACT=? LEARNING_CONTRACT=?"}
]
```

If FOUR_LOOPS_CHECK or SIX_LAYERS_CHECK is FAIL: do not ship.
Address the missing components first.

---

## CHATGPT BEHAVIORAL PROTOCOL

At start of every turn:
1. Check prior turn BTS_COMMIT exists. If not: TURN_BLOCKED.
2. Run KERNEL_SUPERVISOR heartbeat check.
3. Read SESSION_HANDOFF + OBJECTIVE_ANCHOR.
4. Run SEE evidence gathering.

Before every significant action:
1. Call LearningEngine.pre_action_check() — or read MISTAKE_REGISTRY directly.
2. Write BTS decision artifact with all required fields.
3. Verify gates are honest (ERAC-001, ERAC-005, FOUR_LOOPS_CHECK, CONTRACT_COMPLETENESS).
4. If any gate is FAIL: fix the issue before proceeding.

After every completed action:
1. Record BTS_COMMIT.
2. Write TURN_STATE_LEDGER entry.
3. Update SESSION_HANDOFF.
4. Call LearningEngine.record_outcome() — or update registries directly.
