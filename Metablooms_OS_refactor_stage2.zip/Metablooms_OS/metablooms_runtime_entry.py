
from engines.STAGE_PLANNER import plan_stages  # type: ignore
from engines.STAGE_BUNDLER import build_bundle  # type: ignore


def run(task):
    stages = plan_stages(task)
    bundle, remaining, used = build_bundle(stages)
    return {"bundle": bundle, "remaining": remaining, "used": used}