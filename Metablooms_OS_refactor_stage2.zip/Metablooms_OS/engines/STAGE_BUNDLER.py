
def build_bundle(stages, max_budget=5, weights=None):
    if weights is None:
        weights = {
            "run_flake8": 1,
            "fix_flake8": 2,
            "run_pylint": 2,
            "fix_pylint": 3,
            "run_mypy": 2,
            "fix_mypy": 3,
            "verify_all": 2}
    bundle, used = [], 0
    for s in stages:
        w = weights.get(s, 2)
        if bundle and used + w > max_budget:
            break
        bundle.append(s)
        used += w
    return bundle, stages[len(bundle):], used