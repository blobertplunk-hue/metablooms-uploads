from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Literal

from engines.STAGE_BUNDLER import build_bundle
from engines.STAGE_PLANNER import plan_stages
from engines.TASK_NORMALIZER import normalize_task

RuntimeStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class RuntimePolicy:
    max_stage_budget: int
    weights: Dict[str, int]
    policy_path: str


@dataclass
class RuntimeHandoff:
    normalized_task: Dict[str, Any]
    stage_plan: Dict[str, Any]
    bundle_plan: Dict[str, Any]
    next_stage: str | None
    resume_instruction: str


@dataclass
class RuntimeResult:
    status: RuntimeStatus
    reasons: List[str]
    policy: RuntimePolicy | None
    handoff: RuntimeHandoff | None


def _load_runtime_policy() -> RuntimePolicy:
    policy_path = Path("/mnt/data/Metablooms_OS/governance/STREAM_STABILITY_POLICY.json")
    raw = json.loads(policy_path.read_text(encoding="utf-8"))
    return RuntimePolicy(
        max_stage_budget=int(raw.get("max_stage_budget", 5)),
        weights=dict(raw.get("weights", {})),
        policy_path=str(policy_path),
    )


def run(request: str) -> Dict[str, Any]:
    normalized = normalize_task(request)
    if normalized.get("status") != "PASS":
        return asdict(
            RuntimeResult(
                status="FAIL_CLOSED",
                reasons=["task_normalizer_failed"],
                policy=None,
                handoff=None,
            )
        )

    stage_plan = plan_stages(request)
    if stage_plan.get("status") != "PASS":
        return asdict(
            RuntimeResult(
                status="FAIL_CLOSED",
                reasons=["stage_planner_failed"],
                policy=None,
                handoff=None,
            )
        )

    policy = _load_runtime_policy()
    plan_payload = stage_plan.get("plan") or {}
    stages = list(plan_payload.get("stages", []))

    bundle_plan = build_bundle(
        stages=stages,
        max_budget=policy.max_stage_budget,
        weights=policy.weights,
    )
    if bundle_plan.get("status") != "PASS":
        return asdict(
            RuntimeResult(
                status="FAIL_CLOSED",
                reasons=["stage_bundler_failed"],
                policy=policy,
                handoff=None,
            )
        )

    bundle_payload = bundle_plan.get("plan") or {}
    remaining = list(bundle_payload.get("remaining", []))
    next_stage = remaining[0] if remaining else None

    return asdict(
        RuntimeResult(
            status="PASS",
            reasons=[],
            policy=policy,
            handoff=RuntimeHandoff(
                normalized_task=normalized,
                stage_plan=stage_plan,
                bundle_plan=bundle_plan,
                next_stage=next_stage,
                resume_instruction="Proceed",
            ),
        )
    )
