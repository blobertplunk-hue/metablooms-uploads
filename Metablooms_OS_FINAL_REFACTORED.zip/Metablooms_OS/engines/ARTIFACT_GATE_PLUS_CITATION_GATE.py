from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Literal

GateStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class CitationRequirement:
    memory_required: bool
    web_required: bool


@dataclass
class ArtifactRequirement:
    artifacts_required: bool
    receipt_required: bool


@dataclass
class GateResult:
    status: GateStatus
    reasons: List[str]
    citations: CitationRequirement | None
    artifacts: ArtifactRequirement | None


def enforce_gate(payload: Dict[str, Any]) -> Dict[str, Any]:
    reasons: List[str] = []

    has_memory = bool(payload.get("memory_citations"))
    has_web = bool(payload.get("web_citations"))
    has_artifacts = bool(payload.get("artifacts"))
    has_receipt = bool(payload.get("receipt"))

    citation_req = CitationRequirement(
        memory_required=True,
        web_required=True
    )

    artifact_req = ArtifactRequirement(
        artifacts_required=True,
        receipt_required=True
    )

    if citation_req.memory_required and not has_memory:
        reasons.append("missing_memory_citations")

    if citation_req.web_required and not has_web:
        reasons.append("missing_web_citations")

    if artifact_req.artifacts_required and not has_artifacts:
        reasons.append("missing_artifacts")

    if artifact_req.receipt_required and not has_receipt:
        reasons.append("missing_receipt")

    if reasons:
        return asdict(GateResult(
            status="FAIL_CLOSED",
            reasons=reasons,
            citations=citation_req,
            artifacts=artifact_req
        ))

    return asdict(GateResult(
        status="PASS",
        reasons=[],
        citations=citation_req,
        artifacts=artifact_req
    ))
