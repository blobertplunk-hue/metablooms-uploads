from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Literal

from engines.ARTIFACT_GATE_PLUS_CITATION_GATE import enforce_gate
from metablooms_runtime_entry import run as runtime_run

PipelineStatus = Literal["PASS","FAIL_CLOSED"]


@dataclass
class PipelineResult:
    status: PipelineStatus
    reasons: List[str]
    runtime_output: Dict[str, Any] | None
    gate_output: Dict[str, Any] | None


def execute(request: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    # Step 1: run runtime orchestration
    runtime_output = runtime_run(request)
    if runtime_output.get("status") != "PASS":
        return asdict(PipelineResult(
            status="FAIL_CLOSED",
            reasons=["runtime_failed"],
            runtime_output=runtime_output,
            gate_output=None
        ))

    # Step 2: enforce artifact + citation gate
    gate_output = enforce_gate(payload)
    if gate_output.get("status") != "PASS":
        return asdict(PipelineResult(
            status="FAIL_CLOSED",
            reasons=["artifact_or_citation_gate_failed"],
            runtime_output=runtime_output,
            gate_output=gate_output
        ))

    # Step 3: success
    return asdict(PipelineResult(
        status="PASS",
        reasons=[],
        runtime_output=runtime_output,
        gate_output=gate_output
    ))
