from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Literal

BundlerStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class BundlePolicy:
    max_stage_budget: int
    default_stage_weight: int
    weights: Dict[str, int]


@dataclass
class BundlePlan:
    input_stages: List[str]
    bundle: List[str]
    remaining: List[str]
    used_budget: int
    max_budget: int
    policy_source: str


@dataclass
class BundlerResult:
    status: BundlerStatus
    reasons: List[str]
    plan: BundlePlan | None


DEFAULT_POLICY = BundlePolicy(
    max_stage_budget=5,
    default_stage_weight=2,
    weights={
        "run_flake8": 1,
        "fix_flake8": 2,
        "run_pylint": 2,
        "fix_pylint": 3,
        "run_mypy": 2,
        "fix_mypy": 3,
        "verify_all": 2,
    },
)


def _stage_weight(stage: str, policy: BundlePolicy) -> int:
    return int(policy.weights.get(stage, policy.default_stage_weight))


def build_bundle(
    stages: List[str],
    max_budget: int | None = None,
    weights: Dict[str, int] | None = None,
) -> dict[str, Any]:
    if not stages:
        return asdict(
            BundlerResult(
                status="FAIL_CLOSED",
                reasons=["empty_stage_list"],
                plan=None,
            )
        )

    policy = BundlePolicy(
        max_stage_budget=max_budget if max_budget is not None else DEFAULT_POLICY.max_stage_budget,
        default_stage_weight=DEFAULT_POLICY.default_stage_weight,
        weights=weights if weights is not None else dict(DEFAULT_POLICY.weights),
    )

    if policy.max_stage_budget <= 0:
        return asdict(
            BundlerResult(
                status="FAIL_CLOSED",
                reasons=["invalid_max_stage_budget"],
                plan=None,
            )
        )

    bundle: List[str] = []
    used_budget = 0

    for stage in stages:
        weight = _stage_weight(stage, policy)

        if weight <= 0:
            return asdict(
                BundlerResult(
                    status="FAIL_CLOSED",
                    reasons=[f"invalid_stage_weight:{stage}"],
                    plan=None,
                )
            )

        if bundle and (used_budget + weight) > policy.max_stage_budget:
            break

        if not bundle and weight > policy.max_stage_budget:
            bundle.append(stage)
            used_budget = policy.max_stage_budget
            break

        bundle.append(stage)
        used_budget += weight

    remaining = stages[len(bundle):]

    return asdict(
        BundlerResult(
            status="PASS",
            reasons=[],
            plan=BundlePlan(
                input_stages=stages,
                bundle=bundle,
                remaining=remaining,
                used_budget=used_budget,
                max_budget=policy.max_stage_budget,
                policy_source="inline_or_runtime_policy",
            ),
        )
    )
