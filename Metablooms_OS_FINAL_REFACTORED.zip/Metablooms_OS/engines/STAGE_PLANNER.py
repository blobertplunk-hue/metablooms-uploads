from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, List, Literal

PlannerStatus = Literal["PASS", "FAIL_CLOSED"]


@dataclass
class StagePlan:
    task: str
    planning_mode: str
    stages: List[str]
    rationale: List[str]


@dataclass
class PlannerResult:
    status: PlannerStatus
    reasons: List[str]
    plan: StagePlan | None


def _lint_plan() -> StagePlan:
    return StagePlan(
        task="lint",
        planning_mode="deterministic_rule_plan",
        stages=[
            "run_flake8",
            "fix_flake8",
            "run_pylint",
            "fix_pylint",
            "run_mypy",
            "fix_mypy",
            "verify_all",
        ],
        rationale=[
            "formatting/style issues should be surfaced and reduced first",
            "structural issues should be handled after formatting stabilizes",
            "typing issues should be handled after structure is stabilized",
            "full verification should occur only after repair stages complete",
        ],
    )


def _single_stage(task: str) -> StagePlan:
    return StagePlan(
        task=task,
        planning_mode="single_stage_fallback",
        stages=["single_stage"],
        rationale=["no specialized planner rule matched the task"],
    )


def plan_stages(task: str) -> dict[str, Any]:
    request = (task or "").strip()
    if not request:
        return asdict(
            PlannerResult(
                status="FAIL_CLOSED",
                reasons=["empty_task"],
                plan=None,
            )
        )

    lowered = request.lower()
    if any(token in lowered for token in ["lint", "flake8", "pylint", "mypy"]):
        plan = _lint_plan()
    else:
        plan = _single_stage(request)

    return asdict(
        PlannerResult(
            status="PASS",
            reasons=[],
            plan=plan,
        )
    )
