from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import List, Dict, Any, Literal

Status = Literal["PASS","FAIL_CLOSED"]

@dataclass
class TaskContract:
    task: str
    task_class: str
    constraints: List[str]
    required_output: List[str]
    validation: List[str]
    external_verification_required: bool
    memory_required: bool
    artifact_gate_required: bool

@dataclass
class NormalizeResult:
    status: Status
    reasons: List[str]
    contract: TaskContract | None

def _classify(task: str) -> str:
    t = task.lower()
    if any(k in t for k in ["build","implement","patch","script","repair"]):
        return "coding"
    if any(k in t for k in ["research","verify","validate"]):
        return "research"
    if any(k in t for k in ["debug","error","fix","failure"]):
        return "debugging"
    if any(k in t for k in ["metablooms","boot","runtime","artifact"]):
        return "os_governance"
    return "reasoning"

def _infer_constraints(task: str) -> List[str]:
    t = task.lower()
    out: List[str] = []
    if "sandbox" in t:
        out.append("sandbox_only")
    if "artifact" in t or "/mnt/data" in t:
        out.append("artifact_first")
    if "fail closed" in t:
        out.append("fail_closed")
    if "cite" in t or "web.run" in t:
        out.append("citations_required")
    if "memory" in t or "chat history" in t:
        out.append("memory_required")
    return out

def _infer_output(task: str, cls: str) -> List[str]:
    t = task.lower()
    if "json" in t:
        return ["json_artifact"]
    if "python" in t or cls == "coding":
        return ["python_artifact","receipt"]
    return ["markdown_artifact"]

def _infer_validation(cls: str, constraints: List[str], outputs: List[str]) -> List[str]:
    base: Dict[str, List[str]] = {
        "coding": ["artifact exists","imports without error"],
        "research": ["dual citations when applicable"],
        "debugging": ["root cause named","verification passes"],
        "os_governance": ["boot first","artifact gate enforced"],
        "reasoning": ["grounded in memory when applicable"],
    }
    checks = list(base.get(cls, []))
    if "citations_required" in constraints:
        checks += ["memory citations present","web citations present"]
    if "sandbox_only" in constraints:
        checks += ["no local-machine dependency"]
    if "receipt" in outputs:
        checks += ["receipt written"]
    return checks

def normalize_task(request: str) -> Dict[str, Any]:
    req = (request or "").strip()
    if not req:
        return asdict(NormalizeResult(
            status="FAIL_CLOSED",
            reasons=["empty_request"],
            contract=None
        ))

    cls = _classify(req)
    constraints = _infer_constraints(req)
    outputs = _infer_output(req, cls)
    validation = _infer_validation(cls, constraints, outputs)

    contract = TaskContract(
        task=req,
        task_class=cls,
        constraints=constraints,
        required_output=outputs,
        validation=validation,
        external_verification_required=("citations_required" in constraints or cls=="research"),
        memory_required=("memory_required" in constraints),
        artifact_gate_required=(cls in {"coding","debugging","os_governance"} or "artifact_first" in constraints),
    )

    reasons: List[str] = []
    if contract.artifact_gate_required and "artifact_first" not in constraints:
        reasons.append("artifact_gate_inferred")
    if contract.external_verification_required and "citations_required" not in constraints:
        reasons.append("external_verification_inferred")

    return asdict(NormalizeResult(
        status="PASS",
        reasons=reasons,
        contract=contract
    ))
