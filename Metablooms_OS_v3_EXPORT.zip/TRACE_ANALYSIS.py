"""
TRACE_ANALYSIS.py — Span aggregation and anomaly detection (OpenTelemetry model)
=================================================================================

CDR V1 (Rationale):
    The pipeline produces trace spans at every stage but never analyzes them.
    This creates observability without insight — we know what ran but not whether
    it ran efficiently, whether any stage was anomalously slow or thin, or whether
    the trace chain has integrity gaps. Modeled on OpenTelemetry's analysis layer:
    Execution → Instrumentation → Trace → Metrics → Analysis → Action.

CDR V2 (Trust):
    Analysis is read-only — reads trace from PipelineState, produces findings,
    does not modify any prior stage outputs. Anomalies are findings, not mutations.

CDR V3 (Boundary):
    Inputs:  state.trace (list of trace spans from all stages)
    Outputs: trace_analysis artifact with anomalies, metrics, integrity score
    Side effects: none
    Assumptions: all prior stages have completed and written trace_spans

CDR V4 (Failure):
    Empty trace → blocks. A pipeline with no trace cannot be analyzed.
    Broken chain → flagged as anomaly, does not block.

CDR V5 (S-tier):
    Trace output now includes trace_hash (SHA-256 of all stage names in order).
    Per-stage artifact schema validation added via STAGE_ARTIFACT_SCHEMAS registry.
    Broken chain (orphaned spans) → flagged as anomaly, does not block.

Integration contract:
    Inputs:  state.trace (list of dicts with 'stage', 'artifacts' keys)
    Outputs: {'integrity_score', 'anomalies', 'stage_metrics', 'chain_complete'}
    Side effects: none
    Assumptions: runs AFTER VERIFICATION, BEFORE DEBUGGING conditional check
"""

from __future__ import annotations

import hashlib
from typing import Any

from STAGE_BASE import StageBase

INTEGRITY_THRESHOLD: float = 0.80  # hard gate — below this blocks pipeline

# S-TIER: Per-stage artifact schema registry
# Each entry lists required keys for that stage's artifact
STAGE_ARTIFACT_SCHEMAS: dict[str, set[str]] = {
    "SEE": {"evidence_count", "dimensions_covered"},
    "NORMALIZE_EVIDENCE": {"atom_count", "normalization_complete"},
    "MMD": {"gaps", "gap_count"},
    "DRS": {"decisions", "decision_count"},
    "CDR": {"cdr_compliant", "pillars_checked"},
    "OFM": {"objective_id", "success_criteria"},
    "ADS": {"engine_list", "architecture_locked"},
    "UXR": {"constraints", "constraint_count"},
    "NUF": {"requirements", "requirement_count"},
    "SSO": {"in_scope", "scope_locked"},
    "RRP": {"failure_modes", "recovery_plan_locked"},
    "IMPLEMENTATION": {"artifact_path", "artifact_hash"},
    "VERIFICATION": {"verified", "checks_passed"},
    "DEBUGGING": {"skipped"},
}

# Stages expected in a complete trace
EXPECTED_STAGES: list[str] = [
    "SEE",
    "NORMALIZE_EVIDENCE",
    "MMD",
    "DRS",
    "CDR",
    "OFM",
    "ADS",
    "UXR",
    "NUF",
    "SSO",
    "RRP",
    "IMPLEMENTATION",
    "VERIFICATION",
]

# Artifact quality thresholds
MIN_ARTIFACT_KEYS: int = 1
THIN_ARTIFACT_THRESHOLD: int = 1  # artifact with only 1 key is suspicious


class TRACE_ANALYSIS(StageBase):
    name = "TRACE_ANALYSIS"

    def _check_chain_integrity(self, trace: list[dict[str, Any]]) -> tuple[bool, list[str]]:
        """Verify all expected stages appear in trace in correct order."""
        stage_names = [span.get("stage") for span in trace]
        missing = [s for s in EXPECTED_STAGES if s not in stage_names]
        if missing:
            return False, missing
        return True, []

    def _detect_anomalies(self, trace: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Detect suspicious patterns in trace spans."""
        anomalies: list[dict[str, Any]] = []

        for span in trace:
            stage = span.get("stage", "UNKNOWN")
            artifacts = span.get("artifacts", {})

            # Anomaly: artifact is empty dict
            if isinstance(artifacts, dict) and len(artifacts) == 0:
                anomalies.append(
                    {
                        "stage": stage,
                        "type": "EMPTY_ARTIFACT",
                        "severity": "high",
                        "detail": f"{stage} produced empty artifact dict",
                    }
                )

            # S-TIER: validate artifact keys against expected schema
            expected_keys = STAGE_ARTIFACT_SCHEMAS.get(stage, set())
            if expected_keys and isinstance(artifacts, dict):
                missing_keys = expected_keys - set(artifacts.keys())
                if missing_keys:
                    anomalies.append(
                        {
                            "stage": stage,
                            "type": "SCHEMA_VIOLATION",
                            "severity": "high",
                            "detail": f"{stage} artifact missing required keys: {missing_keys}",
                        }
                    )

            # Anomaly: artifact has only one key (likely stub/placeholder)
            if isinstance(artifacts, dict) and len(artifacts) == THIN_ARTIFACT_THRESHOLD:
                key = list(artifacts.keys())[0]
                # Skip known single-key valid artifacts
                if key not in (
                    "skipped",
                    "normalization_complete",
                    "scope_locked",
                    "recovery_plan_locked",
                    "architecture_locked",
                ):
                    anomalies.append(
                        {
                            "stage": stage,
                            "type": "THIN_ARTIFACT",
                            "severity": "warn",
                            "detail": f"{stage} artifact has only 1 key: {key}",
                        }
                    )

            # Anomaly: skipped=True on a non-DEBUGGING stage
            if isinstance(artifacts, dict) and artifacts.get("skipped") and stage != "DEBUGGING":
                anomalies.append(
                    {
                        "stage": stage,
                        "type": "UNEXPECTED_SKIP",
                        "severity": "high",
                        "detail": f"{stage} marked skipped but is not DEBUGGING",
                    }
                )

        return anomalies

    def _compute_metrics(self, trace: list[dict[str, Any]]) -> dict[str, Any]:
        """Compute per-stage and aggregate trace metrics."""
        total = len(trace)
        with_artifacts = sum(1 for s in trace if isinstance(s.get("artifacts"), dict) and s["artifacts"])
        return {
            "total_spans": total,
            "spans_with_artifacts": with_artifacts,
            "artifact_coverage": round(with_artifacts / total, 3) if total else 0.0,
        }

    def execute(self, state: Any) -> dict[str, Any]:
        trace: list[dict[str, Any]] = getattr(state, "trace", [])

        if not trace:
            raise RuntimeError(
                "TRACE_ANALYSIS_NO_TRACE: state.trace is empty — " "all stages must produce trace_spans before analysis"
            )

        chain_complete, missing_stages = self._check_chain_integrity(trace)
        anomalies = self._detect_anomalies(trace)
        metrics = self._compute_metrics(trace)

        # Integrity score: penalize missing stages and high-severity anomalies
        high_anomalies = sum(1 for a in anomalies if a["severity"] == "high")
        missing_penalty = len(missing_stages) * 0.05
        anomaly_penalty = high_anomalies * 0.03
        integrity_score = max(0.0, round(1.0 - missing_penalty - anomaly_penalty, 3))

        # Block only on critical integrity failures (missing mandatory stages)
        mandatory = {"SEE", "IMPLEMENTATION", "VERIFICATION"}
        missing_mandatory = [s for s in missing_stages if s in mandatory]
        if missing_mandatory:
            raise RuntimeError(f"TRACE_ANALYSIS_MANDATORY_MISSING: " f"mandatory stages absent from trace: {missing_mandatory}")

        # HARD GATE: integrity score must meet threshold
        if integrity_score < INTEGRITY_THRESHOLD:
            raise RuntimeError(
                f"TRACE_INTEGRITY_FAIL: integrity_score={integrity_score:.3f} "
                f"< threshold={INTEGRITY_THRESHOLD}. "
                f"Pipeline blocked. Fix anomalies or missing stages before advancing."
            )

        trace_content = str(sorted(s.get("stage", "") for s in trace))
        trace_hash = hashlib.sha256(trace_content.encode()).hexdigest()
        return {
            "integrity_score": integrity_score,
            "trace_hash": trace_hash,
            "chain_complete": chain_complete,
            "missing_stages": missing_stages,
            "anomalies": anomalies,
            "anomaly_count": len(anomalies),
            "high_severity_count": high_anomalies,
            "stage_metrics": metrics,
            "analysis_complete": True,
        }
