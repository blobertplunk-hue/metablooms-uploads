"""
HostVerifier — MetaBlooms Host Trust Layer
-------------------------------------------
Authority: Runtime extension layer.
Schema:    MB-HOST-VERIFIER-1.0

Problem:
    MetaBlooms runs inside GPT-5, which uses tools (file_search, web.run,
    python execution, memory) that can report incorrect results:
        - file_search claims a file doesn't exist, but it's on disk
        - a tool reports success but no artifact was written
        - session state is reported as intact but the store is empty
        - a tool returns stale cached results from a prior session

    If the kernel acts on tool claims without verification, it can make
    decisions based on false premises — importing files that aren't there,
    skipping operations that are actually needed, or trusting a store that
    was silently reset.

Solution:
    Treat tool claims as advisory. Filesystem and artifact_store are
    authoritative. Before acting on any tool claim about file existence,
    artifact presence, or operation success, verify against reality.

    Rule: if tool says X but filesystem/store says not-X, filesystem wins.

HostVerifier does not replace tools. It wraps the decision point:

    tool_claim = file_search("my_file.json")
    verified   = host_verifier.verify_file_exists("my_file.json", tool_claim)
    # verified.authoritative_result is what the kernel acts on

Verification methods:
    verify_file_exists(path, tool_claim)     → VerificationResult
    verify_artifact_exists(aid, tool_claim)  → VerificationResult
    verify_store_integrity(store)            → StoreIntegrityResult
    verify_operation_succeeded(op, result)   → VerificationResult
    assert_filesystem_over_tool(path, claim) → raises if claim is false and file exists

Tool Reliability Ledger:
    Every verification is logged to an append-only ledger (NDJSON).
    Records: tool_name, operation, tool_claimed, verified_result, match, timestamp.
    The ledger accumulates evidence of which tools are reliable.
    read_reliability_report() returns per-tool accuracy over recorded history.

    This is the only in-session learning the host layer does — it does not
    change kernel behavior automatically, but surfaces data for human review
    or governance trigger input.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

SCHEMA   = "MB-HOST-VERIFIER-1.0"
_SELF_ID = "host_verifier"


# ── Data structures ───────────────────────────────────────────────────────────

@dataclass
class VerificationResult:
    operation:            str
    tool_name:            str
    tool_claimed:         Any       # what the tool reported
    authoritative_result: Any       # what filesystem/store actually shows
    match:                bool      # tool claim matched reality
    discrepancy:          Optional[str]  # description if mismatch
    timestamp_utc:        str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    @property
    def tool_lied(self) -> bool:
        return not self.match

    def to_ledger_entry(self) -> str:
        """NDJSON line for the reliability ledger."""
        return json.dumps({
            "schema":               SCHEMA,
            "operation":            self.operation,
            "tool_name":            self.tool_name,
            "tool_claimed":         str(self.tool_claimed),
            "authoritative_result": str(self.authoritative_result),
            "match":                self.match,
            "discrepancy":          self.discrepancy,
            "timestamp_utc":        self.timestamp_utc,
        })


@dataclass
class StoreIntegrityResult:
    artifacts_in_index:  int
    artifacts_on_disk:   int
    missing_files:       list[str]    # indexed but missing from disk
    unindexed_files:     list[str]    # on disk but not in index
    integrity_ok:        bool
    timestamp_utc:       str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


@dataclass
class ToolReliabilityReport:
    tool_name:       str
    total_calls:     int
    accurate_calls:  int
    false_claims:    int
    accuracy_rate:   float
    false_examples:  list[str]    # discrepancy strings from false claims


# ── Host Verifier ─────────────────────────────────────────────────────────────

class HostVerifier:
    """
    Verifies GPT tool claims against filesystem/store reality.

    Usage:
        verifier = HostVerifier(ledger_path="/mnt/data/governance/host_reliability.ndjson")

        # Before trusting a tool's file-existence claim:
        result = verifier.verify_file_exists(
            path="/mnt/data/my_artifact.json",
            tool_claimed_exists=True,     # what file_search said
            tool_name="file_search",
        )
        if result.tool_lied:
            # filesystem says differently — act on authoritative_result
            actual_exists = result.authoritative_result

        # Check store integrity after a session restart:
        integrity = verifier.verify_store_integrity(ctx.artifact_store)
        if not integrity.integrity_ok:
            # Store has missing files — need to rehydrate from snapshot
            pass
    """

    def __init__(self, ledger_path: Optional[str | Path] = None):
        self._ledger_path = Path(ledger_path) if ledger_path else None
        if self._ledger_path:
            self._ledger_path.parent.mkdir(parents=True, exist_ok=True)

    # ── Verification methods ──────────────────────────────────────────────────

    def verify_file_exists(
        self,
        path:                 str | Path,
        tool_claimed_exists:  bool,
        tool_name:            str = "unknown_tool",
    ) -> VerificationResult:
        """
        Check whether a file actually exists on disk.
        Filesystem is authoritative — tool claim is advisory.
        """
        actual_exists = Path(path).exists()
        match         = (tool_claimed_exists == actual_exists)
        discrepancy   = None
        if not match:
            if tool_claimed_exists and not actual_exists:
                discrepancy = f"Tool claimed '{path}' exists but file not found on disk."
            else:
                discrepancy = f"Tool claimed '{path}' missing but file exists on disk."

        result = VerificationResult(
            operation            = "file_exists",
            tool_name            = tool_name,
            tool_claimed         = tool_claimed_exists,
            authoritative_result = actual_exists,
            match                = match,
            discrepancy          = discrepancy,
        )
        self._log(result)
        return result

    def verify_artifact_exists(
        self,
        artifact_id:          str,
        tool_claimed_exists:  bool,
        artifact_store:       Any,
        tool_name:            str = "unknown_tool",
    ) -> VerificationResult:
        """
        Check whether an artifact actually exists in the store.
        Store.exists() is authoritative.
        """
        try:
            actual_exists = artifact_store.exists(artifact_id)
        except Exception as e:
            actual_exists = False

        match       = (tool_claimed_exists == actual_exists)
        discrepancy = None
        if not match:
            if tool_claimed_exists:
                discrepancy = f"Tool claimed artifact '{artifact_id}' exists but store says no."
            else:
                discrepancy = f"Tool claimed artifact '{artifact_id}' missing but store has it."

        result = VerificationResult(
            operation            = "artifact_exists",
            tool_name            = tool_name,
            tool_claimed         = tool_claimed_exists,
            authoritative_result = actual_exists,
            match                = match,
            discrepancy          = discrepancy,
        )
        self._log(result)
        return result

    def verify_store_integrity(self, artifact_store: Any) -> StoreIntegrityResult:
        """
        Cross-check artifact_store index against actual disk files.
        Surfaces missing files (indexed but not on disk) and unindexed files.
        Useful after session restart to detect silent store corruption.
        """
        try:
            all_records   = artifact_store.list_artifacts()
            store_root    = Path(artifact_store.store_root)
            indexed_paths = set()
            missing_files = []

            for record in all_records:
                rel_path = getattr(record, "artifact_path", None) or ""
                full_path = store_root / rel_path
                indexed_paths.add(full_path)
                if not full_path.exists():
                    missing_files.append(str(full_path))

            # Files on disk not in index
            disk_files    = set(store_root.glob("*.json")) if store_root.exists() else set()
            unindexed     = [str(p) for p in disk_files if p not in indexed_paths]

            integrity_ok  = len(missing_files) == 0
            result = StoreIntegrityResult(
                artifacts_in_index = len(all_records),
                artifacts_on_disk  = len(disk_files),
                missing_files      = missing_files,
                unindexed_files    = unindexed,
                integrity_ok       = integrity_ok,
            )
        except Exception as e:
            result = StoreIntegrityResult(
                artifacts_in_index = 0,
                artifacts_on_disk  = 0,
                missing_files      = [f"store_error:{e}"],
                unindexed_files    = [],
                integrity_ok       = False,
            )

        # Log as a verification event
        vr = VerificationResult(
            operation            = "store_integrity",
            tool_name            = "artifact_store",
            tool_claimed         = "intact",
            authoritative_result = result.integrity_ok,
            match                = result.integrity_ok,
            discrepancy          = (
                f"{len(result.missing_files)} missing files"
                if result.missing_files else None
            ),
        )
        self._log(vr)
        return result

    def verify_operation_succeeded(
        self,
        operation:          str,
        tool_reported_ok:   bool,
        verification_fn:    Any,   # callable() → bool — ground truth check
        tool_name:          str = "unknown_tool",
    ) -> VerificationResult:
        """
        Verify an operation actually succeeded by calling verification_fn().
        verification_fn should return True if the operation's effect is
        observable on disk/in store (e.g., file exists, artifact present).
        """
        try:
            actual_ok = bool(verification_fn())
        except Exception as e:
            actual_ok = False

        match       = (tool_reported_ok == actual_ok)
        discrepancy = None
        if not match:
            if tool_reported_ok:
                discrepancy = f"Tool reported {operation} succeeded but verification failed."
            else:
                discrepancy = f"Tool reported {operation} failed but verification passed."

        result = VerificationResult(
            operation            = operation,
            tool_name            = tool_name,
            tool_claimed         = tool_reported_ok,
            authoritative_result = actual_ok,
            match                = match,
            discrepancy          = discrepancy,
        )
        self._log(result)
        return result

    # ── Reliability report ────────────────────────────────────────────────────

    def read_reliability_report(self) -> list[ToolReliabilityReport]:
        """
        Read the reliability ledger and return per-tool accuracy statistics.
        Returns empty list if ledger doesn't exist or can't be read.
        """
        if not self._ledger_path or not self._ledger_path.exists():
            return []

        by_tool: dict[str, list[VerificationResult]] = {}
        try:
            for line in self._ledger_path.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    entry     = json.loads(line)
                    tool_name = entry.get("tool_name", "unknown")
                    if tool_name not in by_tool:
                        by_tool[tool_name] = []
                    by_tool[tool_name].append(entry)
                except json.JSONDecodeError:
                    continue
        except Exception:
            return []

        reports = []
        for tool_name, entries in by_tool.items():
            total     = len(entries)
            accurate  = sum(1 for e in entries if e.get("match", True))
            false_cls = [e["discrepancy"] for e in entries
                         if not e.get("match", True) and e.get("discrepancy")]
            reports.append(ToolReliabilityReport(
                tool_name      = tool_name,
                total_calls    = total,
                accurate_calls = accurate,
                false_claims   = total - accurate,
                accuracy_rate  = round(accurate / total, 3) if total > 0 else 1.0,
                false_examples = false_cls[:5],  # first 5 examples
            ))
        return sorted(reports, key=lambda r: r.accuracy_rate)

    # ── Ledger ────────────────────────────────────────────────────────────────

    def _log(self, result: VerificationResult) -> None:
        """Append result to NDJSON reliability ledger. Never raises."""
        if not self._ledger_path:
            return
        try:
            with self._ledger_path.open("a") as f:
                f.write(result.to_ledger_entry() + "\n")
        except Exception:
            pass  # ledger write failure must never crash the kernel
