"""
SessionBootstrap — MetaBlooms Session Reconstitution
-----------------------------------------------------
Authority: Runtime extension layer.
Schema:    MB-SESSION-BOOTSTRAP-1.0

Problem:
    GPT-5 sessions are ephemeral. When a session restarts:
        - /mnt/data may be empty or partially populated
        - The kernel's artifact_store, commit_system, and governance state
          are gone unless explicitly rehydrated
        - MetaBlooms cannot continue work without knowing what state it was in

Solution:
    SessionBootstrap reads the snapshot zip (always available as a user upload),
    extracts Python source files to a working directory, verifies the extraction
    against the freeze manifest, and returns a ready-to-use KernelContext.

    It also produces a BootstrapReceipt — an artifact recording exactly what
    was loaded, what was verified, and what (if anything) was missing. This
    receipt is the first artifact in any new session's commit chain.

Bootstrap sequence:
    1. LOCATE    — find snapshot zip (uploaded file or known path)
    2. EXTRACT   — extract Python source to working directory
    3. VERIFY    — check extracted files against freeze manifest
    4. BOOT      — build KernelContext from extracted kernel
    5. RECEIPT   — write BootstrapReceipt artifact and commit it

Fallback ladder (the only place in MetaBlooms where fallbacks are legitimate,
because the host environment is genuinely unreliable):
    A: load from snapshot zip at known path
    B: load from user-provided upload path
    C: report BOOTSTRAP_INCOMPLETE — cannot proceed without snapshot

Usage:
    from session_bootstrap import SessionBootstrap

    bootstrap = SessionBootstrap(
        snapshot_path="/mnt/user-data/uploads/Metablooms_KERNEL_FULL_SNAPSHOT_20260307.zip",
        work_dir="/home/user/mb_session",
    )
    result = bootstrap.run()

    if result.ok:
        ctx = result.kernel_context
        # proceed with full kernel
    else:
        print(result.failure_reason)
        # incomplete bootstrap — cannot run kernel
"""

from __future__ import annotations

import json
import sys
import zipfile
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

SCHEMA   = "MB-SESSION-BOOTSTRAP-1.0"
_SELF_ID = "session_bootstrap"

# Canonical kernel component directories — must be present after extraction
_REQUIRED_KERNEL_COMPONENTS = [
    "artifact_store",
    "commit_system",
    "fingerprint_engine",
    "phase_registry",
    "governance_compiler",
    "mpp_executor",
    "engine_registry",
    "capability_resolver",
    "ir_registry",
    "pipeline_planner",
    "state_loader",
    "reasoning_engine",
    "reflector_engine",
    "evolution_engine",
]

# Expected runtime files alongside the kernel
_REQUIRED_RUNTIME_FILES = [
    "egg_juicer_registration.py",
    "engine_contract.py",
    "governance_trigger.py",
    "host_verifier.py",
    "metablooms_integration_test.py",
]


@dataclass
class BootstrapReceipt:
    schema:              str = SCHEMA
    bootstrap_run_id:    str = ""
    timestamp_utc:       str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    ok:                  bool = False
    snapshot_path:       str  = ""
    work_dir:            str  = ""
    components_found:    list = field(default_factory=list)
    components_missing:  list = field(default_factory=list)
    runtime_files_found: list = field(default_factory=list)
    verification_method: str  = ""   # "freeze_manifest" | "component_scan"
    freeze_hash:         Optional[str] = None
    failure_reason:      Optional[str] = None
    artifact_id:         Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "schema":              self.schema,
            "bootstrap_run_id":    self.bootstrap_run_id,
            "timestamp_utc":       self.timestamp_utc,
            "ok":                  self.ok,
            "snapshot_path":       self.snapshot_path,
            "work_dir":            self.work_dir,
            "components_found":    self.components_found,
            "components_missing":  self.components_missing,
            "runtime_files_found": self.runtime_files_found,
            "verification_method": self.verification_method,
            "freeze_hash":         self.freeze_hash,
            "failure_reason":      self.failure_reason,
        }


@dataclass
class BootstrapResult:
    ok:              bool
    receipt:         BootstrapReceipt
    kernel_context:  Optional[Any]   # KernelContext if ok=True
    kernel_root:     Optional[str]
    runtime_root:    Optional[str]
    failure_reason:  Optional[str]


class SessionBootstrap:
    """
    Reconstitutes MetaBlooms kernel from snapshot zip.
    Produces a BootstrapReceipt as the first committed artifact of the session.
    """

    def __init__(
        self,
        snapshot_path:  str | Path,
        work_dir:       str | Path,
        data_root:      Optional[str | Path] = None,
    ):
        self.snapshot_path = Path(snapshot_path)
        self.work_dir      = Path(work_dir)
        self.data_root     = Path(data_root) if data_root else self.work_dir / "kernel_data"

    def run(self) -> BootstrapResult:
        """
        Execute the full bootstrap sequence.
        Returns BootstrapResult — never raises.
        """
        receipt = BootstrapReceipt(
            bootstrap_run_id = _run_id(),
            snapshot_path    = str(self.snapshot_path),
            work_dir         = str(self.work_dir),
        )

        # ── Step 1: LOCATE ────────────────────────────────────────────────────
        if not self.snapshot_path.exists():
            receipt.failure_reason = (
                f"Snapshot not found at {self.snapshot_path}. "
                f"Upload Metablooms_KERNEL_FULL_SNAPSHOT_*.zip and provide path."
            )
            return BootstrapResult(
                ok=False, receipt=receipt, kernel_context=None,
                kernel_root=None, runtime_root=None,
                failure_reason=receipt.failure_reason,
            )

        # ── Step 2: EXTRACT ───────────────────────────────────────────────────
        self.work_dir.mkdir(parents=True, exist_ok=True)
        try:
            with zipfile.ZipFile(self.snapshot_path) as zf:
                zf.extractall(self.work_dir)
        except Exception as e:
            receipt.failure_reason = f"Extraction failed: {e}"
            return BootstrapResult(
                ok=False, receipt=receipt, kernel_context=None,
                kernel_root=None, runtime_root=None,
                failure_reason=receipt.failure_reason,
            )

        # ── Step 3: VERIFY ────────────────────────────────────────────────────
        kernel_root, runtime_root = self._find_roots()
        if not kernel_root:
            receipt.failure_reason = (
                "Could not locate kernel root after extraction. "
                "Expected mb_kernel/Metablooms_OS/kernel in snapshot."
            )
            return BootstrapResult(
                ok=False, receipt=receipt, kernel_context=None,
                kernel_root=None, runtime_root=None,
                failure_reason=receipt.failure_reason,
            )

        found, missing = self._verify_components(kernel_root, runtime_root)
        receipt.components_found   = found
        receipt.components_missing = missing

        # Load freeze hash for provenance if available
        receipt.freeze_hash, receipt.verification_method = self._load_freeze_hash()

        # Runtime files (non-fatal if missing — kernel can still boot)
        receipt.runtime_files_found = self._check_runtime_files(runtime_root)

        if missing:
            receipt.failure_reason = f"Required components missing: {missing}"
            return BootstrapResult(
                ok=False, receipt=receipt, kernel_context=None,
                kernel_root=str(kernel_root), runtime_root=str(runtime_root),
                failure_reason=receipt.failure_reason,
            )

        # ── Step 4: BOOT ──────────────────────────────────────────────────────
        kernel_context = self._boot_kernel(kernel_root, runtime_root)

        # ── Step 5: RECEIPT ───────────────────────────────────────────────────
        receipt.ok = True
        if kernel_context:
            try:
                r = kernel_context.artifact_store.store(
                    receipt.to_dict(), _SELF_ID, "commit", "session_bootstrap"
                )
                kernel_context.commit_system.commit(
                    artifact_ids=[r.artifact_id],
                    engine_id=_SELF_ID,
                    phase="commit",
                    intent="session_bootstrap",
                )
                receipt.artifact_id = r.artifact_id
            except Exception:
                pass  # receipt persistence failure is non-fatal

        return BootstrapResult(
            ok=True, receipt=receipt,
            kernel_context=kernel_context,
            kernel_root=str(kernel_root),
            runtime_root=str(runtime_root),
            failure_reason=None,
        )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _find_roots(self) -> tuple[Optional[Path], Optional[Path]]:
        """Locate kernel root and runtime root after extraction."""
        # Search for canonical kernel marker
        for candidate in self.work_dir.rglob("kernel_context.py"):
            kernel_root = candidate.parent
            # Runtime root is the metablooms_runtime_extensions directory
            runtime_root = None
            for rt_candidate in self.work_dir.rglob("egg_juicer_registration.py"):
                runtime_root = rt_candidate.parent
                break
            return kernel_root, runtime_root
        return None, None

    def _verify_components(
        self, kernel_root: Path, runtime_root: Optional[Path]
    ) -> tuple[list, list]:
        found   = []
        missing = []
        for comp in _REQUIRED_KERNEL_COMPONENTS:
            comp_path = kernel_root / comp
            if comp_path.exists() or (kernel_root / f"{comp}.py").exists():
                found.append(comp)
            else:
                missing.append(comp)
        return found, missing

    def _check_runtime_files(self, runtime_root: Optional[Path]) -> list:
        if not runtime_root:
            return []
        return [f for f in _REQUIRED_RUNTIME_FILES
                if (runtime_root / f).exists()]

    def _load_freeze_hash(self) -> tuple[Optional[str], str]:
        """Try to load freeze hash from freeze artifact for provenance."""
        for freeze_file in self.work_dir.rglob("KERNEL_ADOPTION_FREEZE*.json"):
            try:
                data = json.loads(freeze_file.read_text())
                return data.get("top_level_freeze_hash"), "freeze_manifest"
            except Exception:
                pass
        return None, "component_scan"

    def _boot_kernel(
        self, kernel_root: Path, runtime_root: Optional[Path]
    ) -> Optional[Any]:
        """Bootstrap sys.path and build KernelContext. Returns None on failure."""
        try:
            for comp in _REQUIRED_KERNEL_COMPONENTS:
                p = str(kernel_root / comp)
                if p not in sys.path:
                    sys.path.insert(0, p)
            if str(kernel_root) not in sys.path:
                sys.path.insert(0, str(kernel_root))

            if runtime_root:
                egg_pkg = str(runtime_root / "engines" / "egg_juicer_package")
                if egg_pkg not in sys.path:
                    sys.path.insert(0, egg_pkg)
                if str(runtime_root) not in sys.path:
                    sys.path.append(str(runtime_root))

            from kernel_context import build_kernel_context
            self.data_root.mkdir(parents=True, exist_ok=True)
            return build_kernel_context(self.data_root)
        except Exception:
            return None


def _run_id() -> str:
    from datetime import datetime, timezone
    import hashlib
    ts = datetime.now(timezone.utc).isoformat()
    return "bootstrap-" + hashlib.sha256(ts.encode()).hexdigest()[:16]
