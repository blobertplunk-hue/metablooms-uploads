"""
MetaBlooms Full Integration Test
----------------------------------
Canonical end-to-end proof that the governed execution pipeline works:

    intent
    → reasoning_engine   (R1-R6 + DAG)
    → governance_compiler
    → kernel_mpp_executor (egg_juicer registered)
    → artifact_store
    → commit_system
    → reflector_engine
    → evolution_engine

Pass criteria:
    1. status == 'ok'          — no failed engines, no enforcer violations
    2. artifact_ids not empty  — execution produced committed artifacts
    3. reasoning_artifacts == 7 — R1-R6 + DAG all committed
    4. reflection.proposals == [] on clean run — reflector is evidence-based
    5. commit chain: 4 commits, 0 violations
    6. egg_juicer artifact: file_count > 0, structure_hash present

Run:
    python3 metablooms_integration_test.py

Exit 0 = all assertions pass.
Exit 1 = one or more assertions failed.
"""

from __future__ import annotations

import sys
import tempfile
import json
import hashlib
from datetime import datetime, timezone
from pathlib import Path

KERNEL  = str(Path(__file__).resolve().parents[3] / "mb_kernel" / "Metablooms_OS" / "kernel")
RUNTIME = str(Path(__file__).resolve().parent)
EGG_PKG = str(Path(RUNTIME) / "engines" / "egg_juicer_package")

# Bootstrap sys.path
for comp in ["artifact_store", "commit_system", "fingerprint_engine", "phase_registry",
             "governance_compiler", "mpp_executor", "engine_registry", "capability_resolver",
             "ir_registry", "pipeline_planner", "state_loader"]:
    p = str(Path(KERNEL) / comp)
    if p not in sys.path:
        sys.path.insert(0, p)
if KERNEL not in sys.path:
    sys.path.insert(0, KERNEL)
if RUNTIME not in sys.path:
    sys.path.append(RUNTIME)
if EGG_PKG not in sys.path:
    sys.path.insert(0, EGG_PKG)

_evo_path = str(Path(KERNEL) / "evolution_engine")
if _evo_path not in sys.path:
    sys.path.insert(0, _evo_path)

import importlib.util as ilu

def _load_as(name, path):
    spec = ilu.spec_from_file_location(name, path)
    mod  = ilu.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

_load_as("reasoning_dag_builder",     str(Path(KERNEL) / "reasoning_engine" / "reasoning_dag_builder.py"))
_load_as("reasoning_engine",          str(Path(KERNEL) / "reasoning_engine" / "reasoning_engine.py"))
_load_as("reflector_engine",          str(Path(KERNEL) / "reflector_engine"  / "reflector_engine.py"))
_load_as("patch_builder",             str(Path(KERNEL) / "evolution_engine"  / "patch_builder.py"))
_load_as("patch_validator",           str(Path(KERNEL) / "evolution_engine"  / "patch_validator.py"))
_load_as("evolution_engine",          str(Path(KERNEL) / "evolution_engine"  / "evolution_engine.py"))
_load_as("kernel_wired_orchestrator", str(Path(KERNEL) / "kernel_wired_orchestrator.py"))

from kernel_context import build_kernel_context
from egg_juicer_registration import build_egg_juicer_engine_map
from governance_trigger import (
    GovernanceTrigger, TriggerType, GovernanceArea,
)
from engine_contract import (
    register_engine, EngineRegistrationConflict, EngineContractRegistry,
    AB_PRODUCES, AB_NONE,
)
from host_verifier import HostVerifier
from session_bootstrap import SessionBootstrap

SNAPSHOT_PATH = str(Path(RUNTIME) / ".." / ".." / ".." / "mnt" / "user-data" /
                    "outputs" / "Metablooms_KERNEL_FULL_SNAPSHOT_20260307.zip")
# Canonical snapshot location
_SNAPSHOT = "/mnt/user-data/outputs/Metablooms_KERNEL_FULL_SNAPSHOT_20260307.zip"

kwo  = sys.modules["kernel_wired_orchestrator"]
Refl = sys.modules["reflector_engine"].ReflectorEngine
Evol = sys.modules["evolution_engine"].EvolutionEngine


# ── Assertions ────────────────────────────────────────────────────────────────

_failures = []

def assert_eq(label, actual, expected):
    if actual != expected:
        _failures.append(f"FAIL [{label}]: expected {expected!r}, got {actual!r}")
    else:
        print(f"  PASS [{label}]")

def assert_true(label, value):
    if not value:
        _failures.append(f"FAIL [{label}]: expected truthy, got {value!r}")
    else:
        print(f"  PASS [{label}]")

def assert_gte(label, actual, minimum):
    if actual < minimum:
        _failures.append(f"FAIL [{label}]: expected >= {minimum}, got {actual!r}")
    else:
        print(f"  PASS [{label}]")

def assert_raises(label, exc_type, fn):
    try:
        fn()
        _failures.append(f"FAIL [{label}]: expected {exc_type.__name__}, got no exception")
    except exc_type:
        print(f"  PASS [{label}]")
    except Exception as e:
        _failures.append(f"FAIL [{label}]: expected {exc_type.__name__}, got {type(e).__name__}: {e}")


def _run_contract_tests():
    """
    Tests for Bug 1 (context-capture drift) and Bug 2 (contract erosion).
    Always resets the process registry before and after.
    """

    # ── Bug 1: Context-capture drift detection ────────────────────────────────
    print("\n── Bug 1: Context-capture drift ──")
    EngineContractRegistry.clear()

    # First registration succeeds
    m1, w1 = register_engine(
        "test_engine_drift", lambda: {"ok": True},
        context={"repo_root": "/path/A"},
        registration_site="test",
        use_process_registry=True,
    )
    assert_true("first registration ok", m1.context_fingerprint != "")

    # Same engine name, same context — idempotent (allow_reregister=True)
    m2, _ = register_engine(
        "test_engine_drift", lambda: {"ok": True},
        context={"repo_root": "/path/A"},
        registration_site="test",
        allow_reregister=True,
        use_process_registry=True,
    )
    assert_eq("same context fingerprint", m1.context_fingerprint, m2.context_fingerprint)

    # Same engine name, DIFFERENT context → must raise EngineRegistrationConflict
    assert_raises(
        "drift detected: different repo_root raises conflict",
        EngineRegistrationConflict,
        lambda: register_engine(
            "test_engine_drift", lambda: {"ok": True},
            context={"repo_root": "/path/B"},   # different — drift!
            registration_site="other_caller.py",
            use_process_registry=True,
        )
    )

    # ── Bug 2a: Contract erosion — None return ────────────────────────────────
    print("\n── Bug 2a: Contract erosion — None return ──")
    EngineContractRegistry.clear()

    _, wrapper_none = register_engine(
        "test_engine_none", lambda: None,
        context={"repo_root": "/x"},
        registration_site="test",
        use_process_registry=False,
    )
    assert_raises(
        "None return raises ValueError (NO_SILENT_FAIL)",
        ValueError,
        wrapper_none,
    )

    # ── Bug 2b: Contract erosion — EngineResult normalized to dict ────────────
    print("\n── Bug 2b: Contract erosion — EngineResult normalized ──")
    EngineContractRegistry.clear()

    sys.path.insert(0, str(Path(RUNTIME) / "engines" / "egg_juicer_package"))
    from engine_interface import EngineResult

    engine_result_callable = lambda: EngineResult(
        artifact={"key": "value", "count": 42},
        metadata={"deterministic": True},
    )
    _, wrapper_er = register_engine(
        "test_engine_er", engine_result_callable,
        context={"repo_root": "/x"},
        registration_site="test",
        use_process_registry=False,
    )
    result = wrapper_er()
    assert_true("EngineResult normalized to dict",   isinstance(result, dict))
    assert_eq("artifact key preserved",              result.get("key"), "value")
    assert_true("metadata surfaced in result",       "_engine_metadata" in result)

    # ── Bug 2c: Contract erosion — exception surfaces, not swallowed ──────────
    print("\n── Bug 2c: Contract erosion — exception surfaces ──")
    EngineContractRegistry.clear()

    def _exploding_engine():
        raise RuntimeError("disk full")

    _, wrapper_ex = register_engine(
        "test_engine_explode", _exploding_engine,
        context={"repo_root": "/x"},
        registration_site="test",
        use_process_registry=False,
    )
    assert_raises(
        "engine exception re-raised (not swallowed)",
        RuntimeError,
        wrapper_ex,
    )

    # ── Bug 2d: Raw dict return works ────────────────────────────────────────
    print("\n── Bug 2d: Raw dict return ──")
    EngineContractRegistry.clear()

    _, wrapper_dict = register_engine(
        "test_engine_dict", lambda: {"result": "clean", "count": 1},
        context={"repo_root": "/x"},
        registration_site="test",
        use_process_registry=False,
    )
    result = wrapper_dict()
    assert_eq("raw dict passes through", result.get("result"), "clean")

    # ── Cleanup ───────────────────────────────────────────────────────────────
    EngineContractRegistry.clear()
    print("\n  Registry cleared after contract tests.")


def _run_governance_trigger_tests():
    """Tests that governance additions require observed evidence — artifact-backed."""
    import tempfile, sys
    from pathlib import Path as _Path

    _kernel = '/home/claude/mb_kernel/Metablooms_OS/kernel'
    for comp in ['artifact_store', 'commit_system', 'fingerprint_engine',
                 'state_loader', 'phase_registry', 'governance_compiler',
                 'mpp_executor', 'engine_registry', 'capability_resolver',
                 'ir_registry', 'pipeline_planner']:
        p = str(_Path(_kernel) / comp)
        if p not in sys.path:
            sys.path.insert(0, p)
    if _kernel not in sys.path:
        sys.path.insert(0, _kernel)
    from kernel_context import build_kernel_context

    print("\n── Trigger: no evidence → not warranted (persisted) ──")
    with tempfile.TemporaryDirectory() as d:
        ctx = build_kernel_context(d)
        gt  = GovernanceTrigger(ctx.artifact_store, ctx.commit_system)
        dec = gt.evaluate(GovernanceArea.REFLECTION_NOISE, persist_decision=True)
        assert_eq("no evidence = not warranted", dec.warranted, False)
        assert_true("decision artifact written",
                    dec.decision_artifact_id is not None)

    print("\n── Trigger: below threshold → not warranted ──")
    with tempfile.TemporaryDirectory() as d:
        ctx = build_kernel_context(d)
        gt  = GovernanceTrigger(ctx.artifact_store, ctx.commit_system)
        aid = gt.record(TriggerType.REPEATED_FINDING, GovernanceArea.REFLECTION_NOISE,
                        detail="5 proposals on last run", count=5)
        assert_true("record returned artifact_id", aid.startswith("sha256:"))
        dec = gt.evaluate(GovernanceArea.REFLECTION_NOISE, persist_decision=False)
        assert_eq("5 < threshold 20 = not warranted", dec.warranted, False)
        assert_true("reason shows count", "5" in dec.reason)

    print("\n── Trigger: threshold met across two records → warranted ──")
    with tempfile.TemporaryDirectory() as d:
        ctx = build_kernel_context(d)
        gt  = GovernanceTrigger(ctx.artifact_store, ctx.commit_system)
        gt.record(TriggerType.REPEATED_FINDING, GovernanceArea.REFLECTION_NOISE,
                  detail="batch 1", count=12)
        gt.record(TriggerType.REPEATED_FINDING, GovernanceArea.REFLECTION_NOISE,
                  detail="batch 2", count=10)
        dec = gt.evaluate(GovernanceArea.REFLECTION_NOISE, persist_decision=True)
        assert_eq("12+10=22 >= 20 = warranted", dec.warranted, True)
        assert_true("spec provided",             dec.spec is not None)
        assert_true("decision artifact written", dec.decision_artifact_id is not None)

    print("\n── Trigger: restart-safe — new instance reads same evidence ──")
    with tempfile.TemporaryDirectory() as d:
        ctx1 = build_kernel_context(d)
        gt1  = GovernanceTrigger(ctx1.artifact_store, ctx1.commit_system)
        gt1.record(TriggerType.COLLISION_DETECTED, GovernanceArea.ARTIFACT_NAMESPACE,
                   detail="two engines same artifact_id", count=1)
        # Simulate restart: new context pointing to same data_root
        ctx2 = build_kernel_context(d)
        gt2  = GovernanceTrigger(ctx2.artifact_store, ctx2.commit_system)
        dec  = gt2.evaluate(GovernanceArea.ARTIFACT_NAMESPACE, persist_decision=False)
        assert_eq("restart-safe: evidence survives new instance",
                  dec.warranted, True)

    print("\n── Trigger: collision = immediate warrant ──")
    with tempfile.TemporaryDirectory() as d:
        ctx = build_kernel_context(d)
        gt  = GovernanceTrigger(ctx.artifact_store, ctx.commit_system)
        gt.record(TriggerType.COLLISION_DETECTED, GovernanceArea.ARTIFACT_NAMESPACE,
                  detail="collision observed", count=1)
        dec = gt.evaluate(GovernanceArea.ARTIFACT_NAMESPACE, persist_decision=False)
        assert_eq("1 collision = immediate warrant", dec.warranted, True)

    print("\n── Trigger: manual override = immediate warrant ──")
    with tempfile.TemporaryDirectory() as d:
        ctx = build_kernel_context(d)
        gt  = GovernanceTrigger(ctx.artifact_store, ctx.commit_system)
        gt.record(TriggerType.MANUAL, GovernanceArea.INTENT_RESOLUTION,
                  detail="human decision", count=1)
        dec = gt.evaluate(GovernanceArea.INTENT_RESOLUTION, persist_decision=False)
        assert_eq("manual = immediate warrant", dec.warranted, True)

    print("\n── Artifact namespace: same payload, different engines → different IDs ──")
    with tempfile.TemporaryDirectory() as d:
        ctx     = build_kernel_context(d)
        payload = {"result": "identical_content", "count": 42}
        r1 = ctx.artifact_store.store(payload, "engine_A", "verification", "run_egg_juicer")
        r2 = ctx.artifact_store.store(payload, "engine_B", "verification", "run_egg_juicer")
        assert_true(
            "same payload, engine_A vs engine_B = different artifact_ids",
            r1.artifact_id != r2.artifact_id
        )
        retrieved = ctx.artifact_store.retrieve(r1.artifact_id)
        assert_eq("retrieve unwraps envelope transparently", retrieved.get("count"), 42)


# ── Run ───────────────────────────────────────────────────────────────────────

def run_integration_test(repo_root: str = KERNEL) -> dict:
    results = {}

    with tempfile.TemporaryDirectory() as data_root:
        ctx  = build_kernel_context(
            data_root,
            engine_map=build_egg_juicer_engine_map(repo_root, allow_reregister=True),
        )
        orch = kwo.KernelWiredOrchestrator(kernel_context=ctx)
        refl = Refl(ctx.artifact_store, ctx.commit_system)
        evol = Evol(ctx.artifact_store, ctx.commit_system, kernel_root=KERNEL)

        # ── Execute ───────────────────────────────────────────────────────────
        exec_result = orch.run("run_egg_juicer on the kernel source tree")

        print("\n── Execution assertions ──")
        assert_eq("status=ok",              exec_result["status"],                    "ok")
        assert_eq("no failed_engines",      exec_result.get("failed_engines"),        [])
        assert_eq("no enforcer_violations", exec_result.get("enforcer_violations"),   [])
        assert_gte("exec artifact_ids >= 1",len(exec_result.get("artifact_ids", [])), 1)
        assert_eq("reasoning_artifacts=7",  len(exec_result.get("reasoning_artifact_ids", [])), 7)
        assert_true("commit_id present",    exec_result.get("commit_id"))
        assert_true("reasoning_commit present", exec_result.get("reasoning_commit_id"))

        # ── Egg juicer artifact ───────────────────────────────────────────────
        print("\n── Egg juicer artifact assertions ──")
        egg_artifact = None
        for aid in exec_result.get("artifact_ids", []):
            a = ctx.artifact_store.retrieve(aid)
            if a and a.get("engine") == "egg_juicer":
                egg_artifact = a
                break
        assert_true("egg_artifact found",          egg_artifact is not None)
        assert_gte("file_count > 0",               egg_artifact.get("file_count", 0) if egg_artifact else 0, 1)
        assert_true("structure_hash present",      bool(egg_artifact.get("structure_hash") if egg_artifact else None))

        # ── Reasoning DAG ─────────────────────────────────────────────────────
        print("\n── Reasoning DAG assertions ──")
        dag_artifact = None
        for aid in exec_result.get("reasoning_artifact_ids", []):
            a = ctx.artifact_store.retrieve(aid)
            if a and a.get("schema") == "MB-REASONING-DAG-1.0":
                dag_artifact = a
                break
        assert_true("dag_artifact found",          dag_artifact is not None)
        assert_eq("dag integrity_ok",              dag_artifact.get("integrity_ok") if dag_artifact else None, True)
        assert_eq("dag missing_phases=[]",         dag_artifact.get("missing_phases") if dag_artifact else None, [])
        assert_gte("dag node_count >= 5",          dag_artifact.get("node_count", 0) if dag_artifact else 0, 5)

        # ── Reflection ───────────────────────────────────────────────────────
        print("\n── Reflection assertions ──")
        reflection = refl.reflect(
            execution_result=exec_result,
            reasoning_artifact_ids=exec_result.get("reasoning_artifact_ids", []),
        )
        assert_eq("reflection.valid",          reflection.valid,              True)
        assert_eq("zero_proposals_on_ok_run",  len(reflection.proposals),     0)

        # ── Evolution ────────────────────────────────────────────────────────
        print("\n── Evolution assertions ──")
        evolution = evol.evolve_from_reflection(reflection)
        assert_eq("evolution.valid",           evolution.valid,               True)
        assert_eq("zero_candidates_on_ok_run", len(evolution.candidates),     0)

        # ── Commit chain ─────────────────────────────────────────────────────
        print("\n── Commit chain assertions ──")
        violations = ctx.commit_system.verify_chain()
        commits    = ctx.commit_system.log()
        assert_eq("chain_violations=0",        len(violations), 0)
        assert_gte("commit_count >= 4",        len(commits),    4)

        # ── Build result dict ─────────────────────────────────────────────────
        results = {
            "schema":            "MB-INTEGRATION-TEST-1.0",
            "timestamp_utc":     datetime.now(timezone.utc).isoformat(),
            "repo_root_scanned": repo_root,
            "status":            exec_result["status"],
            "file_count":        egg_artifact.get("file_count") if egg_artifact else None,
            "structure_hash":    egg_artifact.get("structure_hash") if egg_artifact else None,
            "reasoning_artifacts": len(exec_result.get("reasoning_artifact_ids", [])),
            "dag_node_count":    dag_artifact.get("node_count") if dag_artifact else None,
            "dag_edge_count":    dag_artifact.get("edge_count") if dag_artifact else None,
            "dag_integrity_ok":  dag_artifact.get("integrity_ok") if dag_artifact else None,
            "dag_metrics":       dag_artifact.get("metrics") if dag_artifact else None,
            "reflection_proposals": len(reflection.proposals),
            "evolution_candidates": len(evolution.candidates),
            "commit_count":      len(commits),
            "chain_violations":  len(violations),
            "test_result":       "PASS" if not _failures else "FAIL",
            "failures":          _failures,
        }

    return results


def _run_host_tests():
    import tempfile
    from pathlib import Path as _Path

    print("\n── HostVerifier: tool lie detection ──")
    with tempfile.TemporaryDirectory() as d:
        ledger  = _Path(d) / "reliability.ndjson"
        v       = HostVerifier(ledger_path=ledger)
        real    = _Path(d) / "real.json"
        real.write_text("{}")

        r1 = v.verify_file_exists(real, tool_claimed_exists=True, tool_name="file_search")
        assert_eq("correct claim: match=True",          r1.match, True)

        r2 = v.verify_file_exists(_Path(d)/"ghost.json", tool_claimed_exists=True, tool_name="file_search")
        assert_eq("lie detected: tool_lied=True",       r2.tool_lied, True)
        assert_eq("authoritative=False",                r2.authoritative_result, False)
        assert_true("discrepancy populated",            r2.discrepancy is not None)

        r3 = v.verify_file_exists(real, tool_claimed_exists=False, tool_name="file_search")
        assert_eq("lie: said missing but exists",       r3.tool_lied, True)

        report = v.read_reliability_report()
        fs = next((r for r in report if r.tool_name == "file_search"), None)
        assert_true("file_search in report",            fs is not None)
        assert_eq("2 false claims recorded",            fs.false_claims if fs else -1, 2)
        assert_true("accuracy < 1.0",                   (fs.accuracy_rate < 1.0) if fs else False)

    print("\n── SessionBootstrap: from snapshot ──")
    with tempfile.TemporaryDirectory() as d:
        result = SessionBootstrap(
            snapshot_path=_SNAPSHOT,
            work_dir=_Path(d)/"mb_session",
            data_root=_Path(d)/"kdata",
        ).run()
        assert_eq("bootstrap ok",                       result.ok, True)
        assert_true("kernel_context built",             result.kernel_context is not None)
        assert_true("receipt artifact_id",              result.receipt.artifact_id is not None)
        assert_eq("no missing components",              len(result.receipt.components_missing), 0)
        assert_true("freeze hash loaded",               result.receipt.freeze_hash is not None)
        if result.kernel_context:
            ctx = result.kernel_context
            r   = ctx.artifact_store.store({"ok": True}, "test", "verification", "bootstrap")
            ctx.commit_system.commit([r.artifact_id], "test", "verification", "bootstrap")
            assert_eq("bootstrapped ctx: 0 violations",
                      len(ctx.commit_system.verify_chain()), 0)

    print("\n── SessionBootstrap: missing snapshot = clean failure ──")
    with tempfile.TemporaryDirectory() as d:
        r2 = SessionBootstrap("/nonexistent/snap.zip", d).run()
        assert_eq("missing snap = ok=False",            r2.ok, False)
        assert_true("failure_reason set",               r2.failure_reason is not None)


if __name__ == "__main__":
    print("MetaBlooms Full Integration Test")
    print("=" * 60)

    results = run_integration_test()

    print(f"\n{'='*60}")
    print(f"RESULT: {results['test_result']}")
    if _failures:
        print("\nFailed assertions:")
        for f in _failures:
            print(f"  {f}")
    else:
        print("\nAll assertions passed.")

    print(f"\nKey metrics:")
    print(f"  Execution status:      {results['status']}")
    print(f"  Files scanned:         {results['file_count']}")
    print(f"  Structure hash:        {str(results.get('structure_hash',''))[:24]}...")
    print(f"  Reasoning artifacts:   {results['reasoning_artifacts']}")
    print(f"  DAG nodes/edges:       {results['dag_node_count']}/{results['dag_edge_count']}")
    print(f"  DAG integrity:         {results['dag_integrity_ok']}")
    print(f"  Reflection proposals:  {results['reflection_proposals']}  ← 0 = clean run")
    print(f"  Evolution candidates:  {results['evolution_candidates']}  ← 0 = clean run")
    print(f"  Commit chain:          {results['commit_count']} commits, "
          f"{results['chain_violations']} violations")

    # ── Contract enforcement tests ────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("Engine Contract Tests")
    print("=" * 60)
    _run_contract_tests()

    # ── Governance trigger tests ──────────────────────────────────────────────
    print(f"\n{'='*60}")
    print("Governance Trigger Tests")
    print("=" * 60)
    _run_governance_trigger_tests()

    # ── Host verifier + session bootstrap tests ───────────────────────────────
    print(f"\n{'='*60}")
    print("Host Verifier + Session Bootstrap Tests")
    print("=" * 60)
    _run_host_tests()

    final = "PASS" if not _failures else "FAIL"
    print(f"\nFINAL RESULT: {final}")
    sys.exit(0 if final == "PASS" else 1)
