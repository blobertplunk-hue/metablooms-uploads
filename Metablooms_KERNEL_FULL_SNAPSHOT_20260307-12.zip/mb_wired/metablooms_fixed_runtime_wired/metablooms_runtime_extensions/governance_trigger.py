"""
GovernanceTrigger — MetaBlooms Governance-When-Needed System
--------------------------------------------------------------
Authority: Runtime extension layer.
Schema:    MB-GOVERNANCE-TRIGGER-1.0

Architectural rule:
    No governance state lives only in memory.

    record()   → writes trigger event artifact to artifact_store + commits
    evaluate() → reads trigger artifacts from store, aggregates evidence,
                 returns warranted/not warranted, writes decision artifact

    A process restart produces identical evaluate() results because evidence
    lives in the artifact store, not in memory.

Trigger types:
    THRESHOLD_BREACH   REPEATED_FINDING   FAILURE_OBSERVED
    COLLISION_DETECTED DRIFT_DETECTED     MANUAL

Governance areas:
    ARTIFACT_NAMESPACE    INTENT_RESOLUTION     CROSS_ENGINE_STATE
    PARTIAL_EXECUTION     REFLECTION_NOISE      REASONING_STRATEGY
    EXECUTION_GRAPH_SYNC  REPLAY_DETERMINISM    EVOLUTION_FEEDBACK
    REGISTRY_MANAGEMENT

Usage:
    trigger = GovernanceTrigger(ctx.artifact_store, ctx.commit_system)
    trigger.record(TriggerType.COLLISION_DETECTED, GovernanceArea.ARTIFACT_NAMESPACE,
                   detail="engine_A and engine_B produced same artifact_id",
                   source_run_id="run-abc123")
    decision = trigger.evaluate(GovernanceArea.ARTIFACT_NAMESPACE)
    if decision.warranted:
        print(decision.spec)   # concrete description of what to build
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

SCHEMA           = "MB-GOVERNANCE-TRIGGER-1.0"
_SELF_ID         = "governance_trigger"
_EVENT_INTENT    = "governance_trigger_event"
_DECISION_INTENT = "governance_decision"


class TriggerType(str, Enum):
    THRESHOLD_BREACH   = "threshold_breach"
    REPEATED_FINDING   = "repeated_finding"
    FAILURE_OBSERVED   = "failure_observed"
    COLLISION_DETECTED = "collision_detected"
    DRIFT_DETECTED     = "drift_detected"
    MANUAL             = "manual"


class GovernanceArea(str, Enum):
    ARTIFACT_NAMESPACE   = "artifact_namespace"
    INTENT_RESOLUTION    = "intent_resolution"
    CROSS_ENGINE_STATE   = "cross_engine_state"
    PARTIAL_EXECUTION    = "partial_execution"
    REFLECTION_NOISE     = "reflection_noise"
    REASONING_STRATEGY   = "reasoning_strategy"
    EXECUTION_GRAPH_SYNC = "execution_graph_sync"
    REPLAY_DETERMINISM   = "replay_determinism"
    EVOLUTION_FEEDBACK   = "evolution_feedback"
    REGISTRY_MANAGEMENT  = "registry_management"


# Evidence thresholds — governance requires this many accumulated count units.
# Collisions/drift/failures = immediate (1). Patterns require repetition.
_THRESHOLDS: dict[tuple[GovernanceArea, TriggerType], int] = {
    (GovernanceArea.ARTIFACT_NAMESPACE,   TriggerType.COLLISION_DETECTED): 1,
    (GovernanceArea.INTENT_RESOLUTION,    TriggerType.COLLISION_DETECTED): 1,
    (GovernanceArea.REGISTRY_MANAGEMENT,  TriggerType.DRIFT_DETECTED):     1,
    (GovernanceArea.PARTIAL_EXECUTION,    TriggerType.FAILURE_OBSERVED):   1,
    (GovernanceArea.CROSS_ENGINE_STATE,   TriggerType.FAILURE_OBSERVED):   1,
    (GovernanceArea.REPLAY_DETERMINISM,   TriggerType.FAILURE_OBSERVED):   1,
    (GovernanceArea.EVOLUTION_FEEDBACK,   TriggerType.FAILURE_OBSERVED):   1,
    (GovernanceArea.REFLECTION_NOISE,     TriggerType.REPEATED_FINDING):  20,
    (GovernanceArea.REASONING_STRATEGY,   TriggerType.REPEATED_FINDING):  10,
    (GovernanceArea.EXECUTION_GRAPH_SYNC, TriggerType.THRESHOLD_BREACH):   1,
    **{(area, TriggerType.MANUAL): 1 for area in GovernanceArea},
}

_GOVERNANCE_SPEC: dict[GovernanceArea, str] = {
    GovernanceArea.ARTIFACT_NAMESPACE:
        "Verify artifact_store envelope includes engine_id+intent. "
        "Add uniqueness assertion to integration test.",
    GovernanceArea.INTENT_RESOLUTION:
        "Add capability declarations to EngineRegistrationManifest. "
        "Replace direct intent→engine lookup with capability→engine resolution.",
    GovernanceArea.CROSS_ENGINE_STATE:
        "Audit all engine callables for global state access. "
        "Add engine isolation check to ContractEnforcingWrapper.",
    GovernanceArea.PARTIAL_EXECUTION:
        "Verify orchestrator status semantics: ok/partial/failed are distinct. "
        "Ensure reflector treats partial differently from failed.",
    GovernanceArea.REFLECTION_NOISE:
        "Add proposal deduplication to reflector. "
        "Add severity threshold filter (surface HIGH only by default). "
        "Add per-area proposal count cap.",
    GovernanceArea.REASONING_STRATEGY:
        "Add strategy_hint field to ReasonedPlan. "
        "Add strategy selection logic to reasoning_engine based on intent complexity.",
    GovernanceArea.EXECUTION_GRAPH_SYNC:
        "Generate execution graph dynamically from orchestrator config "
        "instead of maintaining static artifact.",
    GovernanceArea.REPLAY_DETERMINISM:
        "Add replay normalization: fixed sort order, timestamp stripping, "
        "determinism hash comparison between original and replay run.",
    GovernanceArea.EVOLUTION_FEEDBACK:
        "Add confirmation_count requirement to evolution engine: "
        "patch candidate requires N reflections before promotion to freeze candidate.",
    GovernanceArea.REGISTRY_MANAGEMENT:
        "Enforce single registration entry point via build_governed_engine_map. "
        "Add registry scope validation to integration test.",
}


@dataclass
class GovernanceDecision:
    area:                GovernanceArea
    warranted:           bool
    reason:              str
    evidence_count:      int
    threshold:           int
    spec:                Optional[str]
    decision_artifact_id: Optional[str]

    def to_dict(self) -> dict:
        return {
            "schema":                SCHEMA,
            "area":                  self.area.value,
            "warranted":             self.warranted,
            "reason":                self.reason,
            "evidence_count":        self.evidence_count,
            "threshold":             self.threshold,
            "spec":                  self.spec,
            "decision_artifact_id":  self.decision_artifact_id,
        }


class GovernanceTrigger:
    """
    Artifact-backed, restart-safe governance trigger system.

    record() persists each trigger event to artifact_store.
    evaluate() reads from the store — never from memory.
    No governance threshold depends on process memory.
    """

    def __init__(self, artifact_store: Any, commit_system: Any):
        self.store   = artifact_store
        self.commits = commit_system

    # ── record ────────────────────────────────────────────────────────────────

    def record(
        self,
        trigger_type:       TriggerType,
        area:               GovernanceArea,
        detail:             str,
        count:              int = 1,
        source_run_id:      Optional[str] = None,
        source_artifact_id: Optional[str] = None,
    ) -> str:
        """
        Persist a trigger event to artifact_store and commit it.
        Returns artifact_id of the persisted event.
        On failure returns 'error:<reason>' — never raises.
        """
        event = {
            "schema":             SCHEMA,
            "record_type":        "trigger_event",
            "trigger_type":       trigger_type.value,
            "governance_area":    area.value,
            "detail":             detail,
            "count":              count,
            "timestamp_utc":      datetime.now(timezone.utc).isoformat(),
            "source_run_id":      source_run_id,
            "source_artifact_id": source_artifact_id,
        }
        try:
            receipt = self.store.store(event, _SELF_ID, "commit", _EVENT_INTENT)
            self.commits.commit(
                artifact_ids=[receipt.artifact_id],
                engine_id=_SELF_ID,
                phase="commit",
                intent=f"{_EVENT_INTENT}:{area.value}",
            )
            return receipt.artifact_id
        except Exception as e:
            return f"error:{e}"

    # ── evaluate ──────────────────────────────────────────────────────────────

    def evaluate(
        self,
        area:             GovernanceArea,
        persist_decision: bool = True,
    ) -> GovernanceDecision:
        """
        Read all persisted trigger events for this area from artifact_store,
        aggregate evidence, determine whether governance is warranted.

        persist_decision=True: writes the decision as an artifact (default).
        persist_decision=False: read-only evaluation, no artifact written.

        Never raises. warranted=False is the safe default on store failure.
        """
        events = self._load_events(area)

        if not events:
            decision = GovernanceDecision(
                area=area, warranted=False,
                reason=(
                    f"No persisted trigger events for {area.value}. "
                    f"Governance not warranted until evidence is recorded."
                ),
                evidence_count=0, threshold=0, spec=None,
                decision_artifact_id=None,
            )
            if persist_decision:
                decision.decision_artifact_id = self._persist_decision(decision)
            return decision

        # Aggregate count per trigger_type across persisted events
        counts_by_type: dict[str, int] = {}
        for ev in events:
            tt    = ev.get("trigger_type", "")
            cnt   = ev.get("count", 1)
            counts_by_type[tt] = counts_by_type.get(tt, 0) + cnt

        # Check each type against its threshold
        warranted      = False
        best_tt        = ""
        best_total     = 0
        best_threshold = 999

        for tt_str, total in counts_by_type.items():
            try:
                tt = TriggerType(tt_str)
            except ValueError:
                continue
            threshold = _THRESHOLDS.get((area, tt), 999)
            if total >= threshold:
                warranted      = True
                best_tt        = tt_str
                best_total     = total
                best_threshold = threshold
                break
            if total > best_total:
                best_tt        = tt_str
                best_total     = total
                best_threshold = threshold

        if warranted:
            reason = (
                f"Warranted: {best_tt} accumulated count={best_total} "
                f">= threshold={best_threshold} "
                f"across {len(events)} persisted events."
            )
        else:
            reason = (
                f"Not yet warranted: {best_tt} count={best_total} "
                f"< threshold={best_threshold}. "
                f"({len(events)} events on record. Continue monitoring.)"
            )

        decision = GovernanceDecision(
            area=area, warranted=warranted, reason=reason,
            evidence_count=best_total, threshold=best_threshold,
            spec=_GOVERNANCE_SPEC.get(area) if warranted else None,
            decision_artifact_id=None,
        )
        if persist_decision:
            decision.decision_artifact_id = self._persist_decision(decision)
        return decision

    def evaluate_all(self, persist_decisions: bool = False) -> list[GovernanceDecision]:
        """Evaluate all areas. Returns only warranted decisions."""
        return [
            d for area in GovernanceArea
            for d in [self.evaluate(area, persist_decision=persist_decisions)]
            if d.warranted
        ]

    def status_report(self) -> dict:
        """Full status across all areas. Read-only — no decision artifacts written."""
        report: dict = {"schema": SCHEMA, "warranted": [], "monitoring": [], "inactive": []}
        for area in GovernanceArea:
            events = self._load_events(area)
            if not events:
                report["inactive"].append(area.value)
                continue
            d = self.evaluate(area, persist_decision=False)
            entry = {
                "area":           area.value,
                "event_count":    len(events),
                "evidence_total": sum(e.get("count", 1) for e in events),
                "warranted":      d.warranted,
                "reason":         d.reason,
            }
            if d.warranted:
                entry["spec"] = d.spec
                report["warranted"].append(entry)
            else:
                report["monitoring"].append(entry)
        return report

    # ── persistence helpers ───────────────────────────────────────────────────

    def _load_events(self, area: GovernanceArea) -> list[dict]:
        """Read all trigger_event artifacts for this area from the store."""
        events = []
        try:
            for record in self.store.list_artifacts(engine_id=_SELF_ID):
                try:
                    artifact = self.store.retrieve(record.artifact_id)
                    if (isinstance(artifact, dict)
                            and artifact.get("record_type") == "trigger_event"
                            and artifact.get("governance_area") == area.value):
                        events.append(artifact)
                except Exception:
                    continue
        except Exception:
            pass
        return events

    def _persist_decision(self, decision: GovernanceDecision) -> Optional[str]:
        """Write a governance_decision artifact. Returns artifact_id or None on failure."""
        artifact = {
            "schema":         SCHEMA,
            "record_type":    "governance_decision",
            "area":           decision.area.value,
            "warranted":      decision.warranted,
            "reason":         decision.reason,
            "evidence_count": decision.evidence_count,
            "threshold":      decision.threshold,
            "spec":           decision.spec,
            "timestamp_utc":  datetime.now(timezone.utc).isoformat(),
        }
        try:
            receipt = self.store.store(artifact, _SELF_ID, "commit", _DECISION_INTENT)
            self.commits.commit(
                artifact_ids=[receipt.artifact_id],
                engine_id=_SELF_ID,
                phase="commit",
                intent=f"{_DECISION_INTENT}:{decision.area.value}",
            )
            return receipt.artifact_id
        except Exception:
            return None
