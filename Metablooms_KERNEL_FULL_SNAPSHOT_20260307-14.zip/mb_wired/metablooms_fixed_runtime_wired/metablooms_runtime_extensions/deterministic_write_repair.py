"""
Deterministic Write Repair Protocol — Sandbox Edition
------------------------------------------------------
Designed for volatile sandboxes (ChatGPT Code Interpreter, Claude).

Changes from original:
- Canonical root is NOT hardcoded; resolved at runtime via METABLOOMS_ROOT env
  or falls back to /mnt/data if present, else cwd/metablooms_data.
- Does NOT raise on missing canonical root — creates it instead.
- Returns a typed WriteState rather than a bare string.
- Cleans up write-probe files even on partial failure.
"""

from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path


def _resolve_root() -> Path:
    """Resolve canonical root: env override → /mnt/data → cwd fallback."""
    env = os.environ.get("METABLOOMS_ROOT")
    if env:
        return Path(env)
    mnt = Path("/mnt/data")
    if mnt.exists():
        return mnt / "Metablooms_OS"
    return Path.cwd() / "metablooms_data"


def _is_writable(path: Path) -> bool:
    probe = path / ".write_probe"
    try:
        probe.write_text("probe", encoding="utf-8")
        probe.unlink()
        return True
    except Exception:
        try:
            probe.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def _repair_permissions(path: Path) -> None:
    rw_dir = stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP
    rw_file = stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP
    for root, dirs, files in os.walk(path):
        try:
            os.chmod(root, rw_dir)
        except Exception:
            pass
        for d in dirs:
            try:
                os.chmod(Path(root) / d, rw_dir)
            except Exception:
                pass
        for f in files:
            try:
                os.chmod(Path(root) / f, rw_file)
            except Exception:
                pass


def ensure_writable(canonical_root: Path | None = None) -> dict:
    """
    Returns a dict:
      {
        "status": "WRITABLE" | "CREATED" | "REPAIRED_PERMISSIONS" | "REHYDRATED" | "FAILED",
        "root": str,
        "detail": str
      }
    Never raises — callers can check status and decide.
    """
    root = canonical_root or _resolve_root()

    # Create if missing — sandbox loses state between sessions
    if not root.exists():
        try:
            root.mkdir(parents=True, exist_ok=True)
            return {"status": "CREATED", "root": str(root), "detail": "Root created"}
        except Exception as e:
            return {"status": "FAILED", "root": str(root), "detail": f"Could not create root: {e}"}

    if _is_writable(root):
        return {"status": "WRITABLE", "root": str(root), "detail": "Write probe passed"}

    _repair_permissions(root)
    if _is_writable(root):
        return {"status": "REPAIRED_PERMISSIONS", "root": str(root), "detail": "chmod repair succeeded"}

    mirror = root.parent / (root.name + "_writable")
    try:
        if mirror.exists():
            shutil.rmtree(mirror)
        shutil.copytree(root, mirror)
        if _is_writable(mirror):
            return {"status": "REHYDRATED", "root": str(mirror), "detail": f"Mirror at {mirror}"}
    except Exception as e:
        return {"status": "FAILED", "root": str(root), "detail": f"Rehydrate failed: {e}"}

    return {"status": "FAILED", "root": str(root), "detail": "All repair tiers exhausted"}


if __name__ == "__main__":
    import json
    print(json.dumps(ensure_writable(), indent=2))
