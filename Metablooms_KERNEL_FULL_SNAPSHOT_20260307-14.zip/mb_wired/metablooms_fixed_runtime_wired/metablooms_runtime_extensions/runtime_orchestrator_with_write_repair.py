
from __future__ import annotations

import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

from deterministic_write_repair import ensure_writable
from authoritative_state_gate import AuthoritativeStateGate


def _normalize_result(value):
    if isinstance(value, dict):
        return {k: _normalize_result(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_normalize_result(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if hasattr(value, "__dict__"):
        return {k: _normalize_result(v) for k, v in value.__dict__.items()}
    return value


class RuntimeOrchestrator:
    def __init__(self, command_bus, planner, governance, executor, receipt_root=None):
        self.command_bus = command_bus
        self.planner = planner
        self.governance = governance
        self.executor = executor
        self.receipt_root = Path(receipt_root or (_HERE / "runtime_receipts"))
        self.gate = AuthoritativeStateGate()

    def _write_runtime_receipt(self, payload: dict) -> dict:
        self.receipt_root.mkdir(parents=True, exist_ok=True)
        receipt_file = self.receipt_root / "runtime_orchestrator_receipt.json"
        receipt = self.gate.write_verified_json(
            receipt_file,
            payload,
            schema={"type": "object", "required": ["status", "intent", "write_state"]},
        )
        return {
            "receipt_path": str(receipt_file),
            "receipt_sha256": receipt.sha256,
            "authoritative": receipt.authoritative,
        }

    def run(self, user_input: str) -> dict:
        write_state = ensure_writable()
        dispatch = self.command_bus.dispatch(user_input)

        if dispatch.intent_type == "unknown":
            result = {
                "status": "unknown_intent",
                "write_state": write_state,
                "intent": dispatch.intent_type,
                "detail": f"No route for input: {repr(user_input)}",
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        planner_kwargs = {
            "requested_phases": dispatch.requested_phases,
            "engine_attachments": dispatch.engine_attachments,
        }
        if hasattr(dispatch, "repo_root"):
            planner_kwargs["repo_root"] = dispatch.repo_root

        plan = self.planner.create_plan(**planner_kwargs)

        if getattr(plan, "phase_order_violations", []):
            result = {
                "status": "plan_error",
                "write_state": write_state,
                "intent": dispatch.intent_type,
                "violations": plan.phase_order_violations,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        gov_result = self.governance.validate(plan)
        if not gov_result.allowed:
            result = {
                "status": "rejected",
                "write_state": write_state,
                "intent": dispatch.intent_type,
                "violations": gov_result.violations,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        exec_result = self.executor.execute(plan)

        status = "ok"
        if not getattr(exec_result, "ok", True):
            failed = getattr(exec_result, "failed_engines", [])
            status = "partial" if failed else "failed"

        result = {
            "status": status,
            "write_state": write_state,
            "intent": dispatch.intent_type,
            "phases_executed": getattr(exec_result, "phases_executed", []),
            "results": _normalize_result(getattr(exec_result, "results", {})),
            "failed_engines": getattr(exec_result, "failed_engines", []),
            "execution_receipt": _normalize_result(getattr(exec_result, "receipt", {})),
        }
        result["verification"] = self._write_runtime_receipt(result)
        return result
