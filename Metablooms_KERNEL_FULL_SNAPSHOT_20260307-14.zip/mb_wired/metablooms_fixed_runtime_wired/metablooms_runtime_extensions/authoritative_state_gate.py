
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Optional
import hashlib
import json


class AuthoritativeStateGateError(Exception):
    pass


class VerificationFailedError(AuthoritativeStateGateError):
    pass


class SchemaValidationError(AuthoritativeStateGateError):
    pass


@dataclass(frozen=True)
class VerificationReceipt:
    path: str
    sha256: str
    read_back_match: bool
    schema_valid: bool
    authoritative: bool
    bytes_written: int
    timestamp_utc: str


class AuthoritativeStateGate:
    """
    Verified-state gate:
    no written state becomes authoritative until it is written,
    read back, hashed, optionally schema-validated, and receipted.
    """

    def __init__(self):
        pass

    @staticmethod
    def canonical_json(obj: Any) -> str:
        return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

    @staticmethod
    def sha256_bytes(data: bytes) -> str:
        return hashlib.sha256(data).hexdigest()

    def _validate_schema(self, obj: Any, schema: Optional[dict]) -> bool:
        if schema is None:
            return True

        if schema.get("type") == "object":
            if not isinstance(obj, dict):
                raise SchemaValidationError("Expected object/dict")
            required = schema.get("required", [])
            for field in required:
                if field not in obj:
                    raise SchemaValidationError(f"Missing required field: {field}")
        return True

    def write_verified_json(self, path: str | Path, obj: Any, schema: Optional[dict] = None) -> VerificationReceipt:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        canonical = self.canonical_json(obj)
        encoded = canonical.encode("utf-8")
        path.write_bytes(encoded)

        read_back = path.read_bytes()
        read_back_match = (encoded == read_back)
        if not read_back_match:
            raise VerificationFailedError("Read-back content does not match written content")

        loaded = json.loads(read_back.decode("utf-8"))
        schema_valid = self._validate_schema(loaded, schema)

        receipt = VerificationReceipt(
            path=str(path),
            sha256=self.sha256_bytes(read_back),
            read_back_match=read_back_match,
            schema_valid=schema_valid,
            authoritative=(read_back_match and schema_valid),
            bytes_written=len(read_back),
            timestamp_utc=__import__("datetime").datetime.now(__import__("datetime").UTC).isoformat(),
        )
        return receipt

    def write_verified_text(self, path: str | Path, text: str) -> VerificationReceipt:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        encoded = text.encode("utf-8")
        path.write_bytes(encoded)
        read_back = path.read_bytes()
        read_back_match = (encoded == read_back)
        if not read_back_match:
            raise VerificationFailedError("Read-back content does not match written content")

        receipt = VerificationReceipt(
            path=str(path),
            sha256=self.sha256_bytes(read_back),
            read_back_match=read_back_match,
            schema_valid=True,
            authoritative=read_back_match,
            bytes_written=len(read_back),
            timestamp_utc=__import__("datetime").datetime.now(__import__("datetime").UTC).isoformat(),
        )
        return receipt

    @staticmethod
    def receipt_dict(receipt: VerificationReceipt) -> dict:
        return asdict(receipt)
