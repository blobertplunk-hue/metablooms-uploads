
def plan_stages(task):
    t = (task or "").lower()
    if "lint" in t:
        return [
            "run_flake8",
            "fix_flake8",
            "run_pylint",
            "fix_pylint",
            "run_mypy",
            "fix_mypy",
            "verify_all"]
    return ["single_stage"]