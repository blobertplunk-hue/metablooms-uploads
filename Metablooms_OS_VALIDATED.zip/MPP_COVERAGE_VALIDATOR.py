from __future__ import annotations
from typing import Any
from STAGE_BASE import StageBase

REQUIRED = {
    "SEE","MMD","DRS","CDR","OFM","ADS","UXR","NUF","SSO","RRP",
    "IMPLEMENTATION","VERIFICATION","DEBUGGING","ECL"
}

class MPP_COVERAGE_VALIDATOR(StageBase):
    name = "MPP_COVERAGE_VALIDATOR"

    def execute(self, state: Any) -> dict[str, Any]:
        present = set(state.data.keys())
        missing = sorted(list(REQUIRED - present))
        if missing:
            raise RuntimeError(f"MPP_COVERAGE_FAIL: missing stages {missing}")
        return {"coverage_valid": True, "missing": []}
