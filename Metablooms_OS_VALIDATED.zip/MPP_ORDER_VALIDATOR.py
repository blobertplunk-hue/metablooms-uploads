from __future__ import annotations
from typing import Any
from STAGE_BASE import StageBase

EXPECTED_ORDER: list[str] = [
    "SEE",
    "MMD",
    "DRS",
    "CDR",
    "OFM",
    "ADS",
    "UXR",
    "NUF",
    "SSO",
    "RRP",
    "IMPLEMENTATION",
    "VERIFICATION",
    "DEBUGGING",
    "ECL",
    "MPP_COVERAGE_VALIDATOR",
    "MPP_ORDER_VALIDATOR",
    "MPP_DEPENDENCY_VALIDATOR",
]

class MPP_ORDER_VALIDATOR(StageBase):
    name = "MPP_ORDER_VALIDATOR"

    def execute(self, state: Any) -> dict[str, Any]:
        executed = list(state.data.keys())
        positions: dict[str, int] = {stage: idx for idx, stage in enumerate(EXPECTED_ORDER)}

        last_index = -1
        for stage in executed:
            if stage not in positions:
                raise RuntimeError(f"MPP_ORDER_UNKNOWN_STAGE: {stage}")
            idx = positions[stage]
            if idx < last_index:
                raise RuntimeError(
                    f"MPP_ORDER_FAIL: {stage} executed out of order relative to prior stages"
                )
            last_index = idx

        return {
            "order_valid": True,
            "executed_stages": executed,
            "expected_order": EXPECTED_ORDER,
        }
