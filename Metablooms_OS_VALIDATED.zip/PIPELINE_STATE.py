class PipelineState:
    def __init__(self, task=None):
        self.task = task or {}
        self.data = {}
    def update(self, record):
        stage = record.get("stage")
        if not stage:
            raise ValueError("record missing stage")
        self.data[stage] = record
