class StageBase:
    name = "BASE"
    def execute(self, state):
        raise NotImplementedError
