import unittest
from PIPELINE_STATE import PipelineState
from MPP_COVERAGE_VALIDATOR import MPP_COVERAGE_VALIDATOR
from MPP_ORDER_VALIDATOR import MPP_ORDER_VALIDATOR
from MPP_DEPENDENCY_VALIDATOR import MPP_DEPENDENCY_VALIDATOR

BASE_STAGES = [
    "SEE","MMD","DRS","CDR","OFM","ADS","UXR","NUF","SSO","RRP",
    "IMPLEMENTATION","VERIFICATION","DEBUGGING","ECL"
]

def make_state(stage_names):
    state = PipelineState(task={})
    for name in stage_names:
        state.update({
            "stage": name,
            "status": "COMPLETE",
            "artifact": {"ok": True},
            "trace_span": {"stage": name, "artifacts": {"ok": True}},
        })
    return state

class TestMPPFullValidation(unittest.TestCase):
    def test_coverage_pass(self):
        state = make_state(BASE_STAGES)
        self.assertTrue(MPP_COVERAGE_VALIDATOR().execute(state)["coverage_valid"])

    def test_coverage_fail_missing_stage(self):
        state = make_state([s for s in BASE_STAGES if s != "CDR"])
        with self.assertRaises(RuntimeError):
            MPP_COVERAGE_VALIDATOR().execute(state)

    def test_order_fail(self):
        state = make_state(["SEE","DRS","MMD"])
        with self.assertRaises(RuntimeError):
            MPP_ORDER_VALIDATOR().execute(state)

    def test_dependency_fail(self):
        state = make_state(["SEE","MMD","CDR"])
        with self.assertRaises(RuntimeError):
            MPP_DEPENDENCY_VALIDATOR().execute(state)

    def test_valid_all(self):
        state = make_state(BASE_STAGES + ["MPP_COVERAGE_VALIDATOR","MPP_ORDER_VALIDATOR"])
        # coverage ok
        MPP_COVERAGE_VALIDATOR().execute(state)
        # order ok
        MPP_ORDER_VALIDATOR().execute(state)
        # dependency ok
        MPP_DEPENDENCY_VALIDATOR().execute(state)

if __name__ == "__main__":
    unittest.main()
