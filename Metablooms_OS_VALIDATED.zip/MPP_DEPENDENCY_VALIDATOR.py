from __future__ import annotations
from typing import Any
from STAGE_BASE import StageBase

DEPENDENCIES: dict[str, list[str]] = {
    "MMD": ["SEE"],
    "DRS": ["MMD"],
    "CDR": ["DRS"],
    "OFM": ["CDR"],
    "ADS": ["OFM"],
    "UXR": ["ADS"],
    "NUF": ["UXR"],
    "SSO": ["NUF"],
    "RRP": ["SSO"],
    "IMPLEMENTATION": ["RRP"],
    "VERIFICATION": ["IMPLEMENTATION"],
    "DEBUGGING": ["VERIFICATION"],
    "ECL": ["DEBUGGING"],
    "MPP_COVERAGE_VALIDATOR": ["ECL"],
    "MPP_ORDER_VALIDATOR": ["MPP_COVERAGE_VALIDATOR"],
    "MPP_DEPENDENCY_VALIDATOR": ["MPP_ORDER_VALIDATOR"],
}

class MPP_DEPENDENCY_VALIDATOR(StageBase):
    name = "MPP_DEPENDENCY_VALIDATOR"

    def execute(self, state: Any) -> dict[str, Any]:
        completed = set(state.data.keys())
        checked: dict[str, list[str]] = {}

        for stage, deps in DEPENDENCIES.items():
            if stage in completed:
                missing = [dep for dep in deps if dep not in completed]
                checked[stage] = deps
                if missing:
                    raise RuntimeError(
                        f"MPP_DEPENDENCY_FAIL: {stage} missing dependencies {missing}"
                    )

        return {
            "dependency_valid": True,
            "checked_dependencies": checked,
        }
