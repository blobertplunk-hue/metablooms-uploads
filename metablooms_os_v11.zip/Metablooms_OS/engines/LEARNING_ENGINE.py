"""
LEARNING_ENGINE.py — MetaBlooms Learning Engine v1

CDR V1 (Intent): Ensure no mistake is ever repeated silently and no successful
pattern is ever abandoned. Two registries — mistakes and successes — are
consulted before every significant action and updated after every outcome.
Per-module trackers give each engine its own learning history.

CDR V2 (Trust): Learning entries are written to append-only LEARNING_LEDGER.ndjson
with timestamps and source engine. Pre-action checks read from real JSON files
on disk. No in-memory-only learning — all learning persists across sessions.

CDR V3 (Boundary): LearningEngine reads registries and writes ledger entries.
It does not execute actions, modify other engines, or apply patches. It
surfaces known risks and successful patterns as advisory data to the BTS
decision mechanism.

CDR V4 (State): LEARNING_LEDGER.ndjson is append-only. MISTAKE_REGISTRY.json
and SUCCESS_REGISTRY.json are updated by writing new entries. times_caught
and score fields are updated in place (the only mutable fields).

CDR V5 (Failure): If registries cannot be read, pre_action_check returns empty
results with a warning — it does not block. Missing registries mean no learning,
not a hard stop. But missing registries are logged as a gap.

constraint_mapping:
  - LEARNING_LEDGER.ndjson is append-only — never truncated or overwritten
  - times_caught increments only — never decremented
  - S4_CRITICAL mistakes surface as known_risks in BTS decision artifacts
  - Creative exploration labeled EXPLORE bypasses S1/S2 mistake warnings
  - Per-module trackers stored at learning/modules/<module_name>.json

integration_reciprocity:
  Inputs:  action_class (str), module (str), context (dict), outcome (dict)
  Outputs: PreActionResult (known_risks, success_patterns, should_block)
           LedgerEntry written to LEARNING_LEDGER.ndjson
  Side effects: increments times_caught in MISTAKE_REGISTRY.json on match
  Promises: pre_action_check never blocks on missing data — degrades gracefully
  Callers: BTS.decide() (enriches decision with known_risks)
           FIR.evaluate_session() (records session outcome as learning)
           Any engine wanting to check/record learning

legacy_impact_statement:
  Before this engine, mistakes were fixed but not named. The wrong bundle root
  error (ME-EXPORT-001) was fixed but nothing prevented the same class of error
  from occurring in a different context. This engine closes that loop.

ChatGPT behavioral contract:
  Before any significant action:
    1. Call LearningEngine.pre_action_check(action_class, module, context)
    2. If result.should_block: stop and fix
    3. If result.known_risks: surface in BTS decision as known_risks field
    4. If result.success_patterns: prefer those approaches in governed_choice

  After any completed action:
    1. Call LearningEngine.record_outcome(action_class, module, outcome, success)
    2. This feeds into FIR measurement and future pre-action checks
"""

from __future__ import annotations


# Declared direct dependencies — COEV-029 (explicit over inferred)
REQUIRES = ["BTS", "FIR"]
REQUIRES_HASH = "1c53847f103933a16c0d5a0c8fbf4e4417a51d1cde5fa881726c6e051c304c28"  # SHA256(source_canonical + sorted(REQUIRES)) — stable Merkle identity

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


SCHEMA   = "mb.learning.v1"
LEDGER   = Path("learning/LEARNING_LEDGER.ndjson")
MISTAKES = Path("learning/MISTAKE_REGISTRY.json")
SUCCESS  = Path("learning/SUCCESS_REGISTRY.json")
MODULES  = Path("learning/modules")


# ── Data structures ────────────────────────────────────────────────────────────

@dataclass
class KnownRisk:
    mistake_id: str
    name: str
    severity: str
    description: str
    prevention_strategy: str
    times_caught: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mistake_id": self.mistake_id,
            "name": self.name,
            "severity": self.severity,
            "description": self.description[:100],
            "prevention_strategy": self.prevention_strategy[:100],
            "times_caught": self.times_caught,
        }


@dataclass
class SuccessPattern:
    pattern_id: str
    name: str
    description: str
    repeat_when: str
    score: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pattern_id": self.pattern_id,
            "name": self.name,
            "description": self.description[:100],
            "repeat_when": self.repeat_when[:100],
            "score": self.score,
        }


@dataclass
class PreActionResult:
    """Result of checking learning registries before an action."""
    action_class: str
    module: str
    known_risks: List[KnownRisk] = field(default_factory=list)
    success_patterns: List[SuccessPattern] = field(default_factory=list)
    should_block: bool = False   # True only for S4_CRITICAL with no override
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_class": self.action_class,
            "module": self.module,
            "known_risks": [r.to_dict() for r in self.known_risks],
            "success_patterns": [p.to_dict() for p in self.success_patterns],
            "should_block": self.should_block,
            "warnings": self.warnings,
        }

    def summary(self) -> str:
        """
        Constitutional AI insight: lead with positive direction, then constraints.
        Success patterns first — frame what TO DO before what NOT to do.
        """
        parts = []
        if self.success_patterns:
            parts.append(f"APPLY PATTERNS: {[p.pattern_id for p in self.success_patterns]}")
        if self.should_block:
            parts.append("⛔ BLOCK: S4_CRITICAL risk detected")
        elif self.known_risks:
            parts.append(f"WATCH: {[r.mistake_id for r in self.known_risks]}")
        return " | ".join(parts) if parts else "CLEAR — no known risks or patterns"


# ── LearningEngine ─────────────────────────────────────────────────────────────

class LearningEngine:
    """
    Consults mistake and success registries before actions.
    Records outcomes after actions. Per-module tracking.

    Usage:
        le = LearningEngine(runtime_root)

        # Before action:
        check = le.pre_action_check("packaging", "EXPORT_GATE", {})
        if check.should_block:
            raise RuntimeError("Known S4 risk — fix before proceeding")
        # Include check.known_risks in BTS decision artifact

        # After action:
        le.record_outcome("packaging", "EXPORT_GATE", {"zip_path": "..."}, success=True)
    """

    def __init__(self, runtime_root: str | Path = ".") -> None:
        self.root    = Path(runtime_root)
        self._ledger = self.root / LEDGER
        self._mistakes_path = self.root / MISTAKES
        self._success_path  = self.root / SUCCESS
        self._modules_dir   = self.root / MODULES
        self._modules_dir.mkdir(parents=True, exist_ok=True)
        self._ledger.parent.mkdir(parents=True, exist_ok=True)

        self._mistakes: Optional[Dict] = None
        self._successes: Optional[Dict] = None

    def _now(self) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _load_mistakes(self) -> Dict[str, Any]:
        if self._mistakes is None:
            try:
                self._mistakes = json.loads(self._mistakes_path.read_text())
            except Exception:
                self._mistakes = {"classes": {}}
        return self._mistakes

    def _load_successes(self) -> Dict[str, Any]:
        if self._successes is None:
            try:
                self._successes = json.loads(self._success_path.read_text())
            except Exception:
                self._successes = {"patterns": {}}
        return self._successes

    def _append_ledger(self, entry: Dict[str, Any]) -> None:
        """Append-only ledger write. CDR V4."""
        entry["ts_utc"] = self._now()
        entry["entry_id"] = f"LE-{uuid.uuid4().hex[:8].upper()}"
        try:
            with self._ledger.open("a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception as e:
            pass  # Ledger write failure should not block execution

    # ── Pre-action check ───────────────────────────────────────────────────────

    def pre_action_check(
        self,
        action_class: str,
        module: str,
        context: Dict[str, Any],
        explore: bool = False,  # EXPLORE label bypasses S1/S2 warnings
    ) -> PreActionResult:
        """
        Check registries for known risks and success patterns relevant to this action.
        Returns PreActionResult with known_risks and success_patterns.
        should_block=True only for S4_CRITICAL risks (unless explore=True).
        """
        result = PreActionResult(action_class=action_class, module=module)

        # Check mistake registry
        mistakes = self._load_mistakes()
        for mistake_id, mc in mistakes.get("classes", {}).items():
            # Match on module or domain
            mc_module = mc.get("module", "")
            mc_domain = mc.get("domain", "")
            if (module in mc_module or mc_module == "ALL_ENGINES" or
                    action_class in mc_domain or module.lower() in mc_domain):
                risk = KnownRisk(
                    mistake_id=mistake_id,
                    name=mc.get("name", ""),
                    severity=mc.get("severity", "S1_LOW"),
                    description=mc.get("description", ""),
                    prevention_strategy=mc.get("prevention_strategy", ""),
                    times_caught=mc.get("times_caught", 0),
                )
                result.known_risks.append(risk)

                # S4_CRITICAL blocks unless labeled EXPLORE
                if risk.severity == "S4_CRITICAL" and not explore:
                    result.should_block = True
                    result.warnings.append(
                        f"S4_CRITICAL risk {mistake_id} ({risk.name}): "
                        f"{risk.prevention_strategy[:80]}"
                    )
                elif risk.severity in ("S3_HIGH", "S2_MED") and not explore:
                    result.warnings.append(
                        f"{risk.severity} risk {mistake_id} ({risk.name})"
                    )

        # Check success registry
        successes = self._load_successes()
        for pattern_id, sp in successes.get("patterns", {}).items():
            sp_module = sp.get("module", "")
            sp_domain = sp.get("domain", "")
            repeat_when = sp.get("repeat_when", "")
            if (module in sp_module or sp_module == "ALL" or
                    action_class in sp_domain or
                    action_class.lower() in repeat_when.lower()):
                result.success_patterns.append(SuccessPattern(
                    pattern_id=pattern_id,
                    name=sp.get("name", ""),
                    description=sp.get("description", ""),
                    repeat_when=sp.get("repeat_when", ""),
                    score=sp.get("score", 0.0),
                ))

        # Sort by score desc
        result.success_patterns.sort(key=lambda p: p.score, reverse=True)
        result.known_risks.sort(
            key=lambda r: {"S4_CRITICAL": 4, "S3_HIGH": 3, "S2_MED": 2, "S1_LOW": 1}.get(r.severity, 0),
            reverse=True,
        )

        # Log the check
        self._append_ledger({
            "event": "PRE_ACTION_CHECK",
            "action_class": action_class,
            "module": module,
            "known_risks_count": len(result.known_risks),
            "success_patterns_count": len(result.success_patterns),
            "should_block": result.should_block,
        })

        return result

    # ── Record outcome ─────────────────────────────────────────────────────────

    def record_outcome(
        self,
        action_class: str,
        module: str,
        outcome: Dict[str, Any],
        success: bool,
        mistake_class: Optional[str] = None,  # if failure, name the class
        notes: str = "",
    ) -> None:
        """
        Record what happened after an action.
        If failure and mistake_class provided: increment times_caught in registry.
        Appends to LEARNING_LEDGER.ndjson and per-module tracker.
        """
        entry = {
            "event": "OUTCOME_RECORDED",
            "action_class": action_class,
            "module": module,
            "success": success,
            "mistake_class": mistake_class,
            "notes": notes[:200],
            "outcome_summary": str(outcome)[:200],
        }
        self._append_ledger(entry)

        # Increment times_caught if failure with named class
        if not success and mistake_class:
            mistakes = self._load_mistakes()
            if mistake_class in mistakes.get("classes", {}):
                mistakes["classes"][mistake_class]["times_caught"] = (
                    mistakes["classes"][mistake_class].get("times_caught", 0) + 1
                )
                try:
                    self._mistakes_path.write_text(
                        json.dumps(mistakes, indent=2), encoding="utf-8"
                    )
                    self._mistakes = mistakes  # refresh cache
                except Exception:
                    pass

        # Per-module tracker
        self._update_module_tracker(module, action_class, success, mistake_class, notes)

    def _update_module_tracker(
        self, module: str, action_class: str,
        success: bool, mistake_class: Optional[str], notes: str
    ) -> None:
        """Update per-module learning tracker."""
        tracker_path = self._modules_dir / f"{module}.json"
        try:
            tracker = json.loads(tracker_path.read_text()) if tracker_path.exists() else {
                "schema": SCHEMA,
                "module": module,
                "total_actions": 0,
                "successes": 0,
                "failures": 0,
                "mistake_classes_hit": {},
                "last_updated": "",
                "history": [],
            }
        except Exception:
            tracker = {
                "schema": SCHEMA, "module": module,
                "total_actions": 0, "successes": 0, "failures": 0,
                "mistake_classes_hit": {}, "last_updated": "", "history": [],
            }

        tracker["total_actions"] += 1
        if success:
            tracker["successes"] += 1
        else:
            tracker["failures"] += 1
            if mistake_class:
                tracker["mistake_classes_hit"][mistake_class] = (
                    tracker["mistake_classes_hit"].get(mistake_class, 0) + 1
                )

        tracker["last_updated"] = self._now()
        tracker["history"].append({
            "ts": self._now(),
            "action_class": action_class,
            "success": success,
            "mistake_class": mistake_class,
            "notes": notes[:100],
        })
        # Keep last 50 history entries
        tracker["history"] = tracker["history"][-50:]

        try:
            tracker_path.write_text(json.dumps(tracker, indent=2), encoding="utf-8")
        except Exception:
            pass

    # ── Registry management ────────────────────────────────────────────────────

    def add_mistake(self, mistake_id: str, entry: Dict[str, Any]) -> bool:
        """Add a new mistake class to the registry."""
        mistakes = self._load_mistakes()
        if mistake_id in mistakes.get("classes", {}):
            return False  # already exists
        mistakes.setdefault("classes", {})[mistake_id] = {
            **entry,
            "first_seen": self._now(),
            "times_caught": 0,
        }
        try:
            self._mistakes_path.write_text(json.dumps(mistakes, indent=2))
            self._mistakes = mistakes
            self._append_ledger({"event": "MISTAKE_CLASS_ADDED", "mistake_id": mistake_id})
            return True
        except Exception:
            return False

    def add_success(self, pattern_id: str, entry: Dict[str, Any]) -> bool:
        """Add a new success pattern to the registry."""
        successes = self._load_successes()
        if pattern_id in successes.get("patterns", {}):
            return False
        successes.setdefault("patterns", {})[pattern_id] = {
            **entry,
            "first_proven": self._now(),
        }
        try:
            self._success_path.write_text(json.dumps(successes, indent=2))
            self._successes = successes
            self._append_ledger({"event": "SUCCESS_PATTERN_ADDED", "pattern_id": pattern_id})
            return True
        except Exception:
            return False

    # ── Summary ────────────────────────────────────────────────────────────────

    def session_summary(self) -> Dict[str, Any]:
        """Summary of learning activity from current session ledger entries."""
        if not self._ledger.exists():
            return {"ledger_entries": 0, "mistake_classes": 0, "success_patterns": 0}
        try:
            entries = [json.loads(l) for l in self._ledger.read_text().splitlines() if l.strip()]
        except Exception:
            return {"error": "ledger_unreadable"}

        mistakes = self._load_mistakes()
        successes = self._load_successes()

        pre_checks = sum(1 for e in entries if e.get("event") == "PRE_ACTION_CHECK")
        outcomes   = sum(1 for e in entries if e.get("event") == "OUTCOME_RECORDED")
        blocks     = sum(1 for e in entries if e.get("event") == "PRE_ACTION_CHECK" and e.get("should_block"))

        return {
            "ledger_entries": len(entries),
            "pre_action_checks": pre_checks,
            "outcomes_recorded": outcomes,
            "blocks_triggered": blocks,
            "mistake_classes_registered": len(mistakes.get("classes", {})),
            "success_patterns_registered": len(successes.get("patterns", {})),
            "module_trackers": len(list(self._modules_dir.glob("*.json"))),
        }


# ── Self-test ──────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, tempfile, shutil
    from pathlib import Path

    print("LEARNING_ENGINE self-test...")

    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        # Copy learning registries
        src_learning = Path("learning")
        dst_learning = root / "learning"
        if src_learning.exists():
            shutil.copytree(str(src_learning), str(dst_learning))
        else:
            dst_learning.mkdir(parents=True)

        le = LearningEngine(root)

        # Test 1: pre_action_check finds packaging risks
        result = le.pre_action_check("packaging", "EXPORT_GATE", {})
        assert len(result.known_risks) > 0, "Should find ME-EXPORT-* risks"
        assert result.should_block, "S4_CRITICAL risks should block"
        print(f"  Packaging risks found: {len(result.known_risks)}, should_block={result.should_block} ✓")

        # Test 2: EXPLORE label bypasses S4 block
        result2 = le.pre_action_check("packaging", "EXPORT_GATE", {}, explore=True)
        assert not result2.should_block, "EXPLORE should bypass block"
        print(f"  EXPLORE bypasses S4 block ✓")

        # Test 3: FIR risks detected
        result3 = le.pre_action_check("measurement", "FIR", {})
        assert any("FIR" in r.mistake_id for r in result3.known_risks)
        print(f"  FIR risks found: {len(result3.known_risks)} ✓")

        # Test 4: Success patterns returned
        result4 = le.pre_action_check("packaging", "EXPORT_GATE", {}, explore=True)
        print(f"  Success patterns: {len(result4.success_patterns)} ✓")

        # Test 5: record_outcome writes ledger
        le.record_outcome("packaging", "EXPORT_GATE", {"status": "PASS"}, success=True)
        assert le._ledger.exists()
        print(f"  Outcome recorded to ledger ✓")

        # Test 6: Failure increments times_caught
        # First reset so we can measure increment
        mistakes = le._load_mistakes()
        original_count = mistakes["classes"].get("ME-FIR-001", {}).get("times_caught", 0)
        le.record_outcome("measurement", "FIR", {}, success=False, mistake_class="ME-FIR-001")
        mistakes2 = json.loads((root / "learning" / "MISTAKE_REGISTRY.json").read_text())
        new_count = mistakes2["classes"].get("ME-FIR-001", {}).get("times_caught", 0)
        assert new_count == original_count + 1
        print(f"  times_caught incremented: {original_count} → {new_count} ✓")

        # Test 7: Per-module tracker created
        tracker_path = root / "learning" / "modules" / "FIR.json"
        assert tracker_path.exists()
        tracker = json.loads(tracker_path.read_text())
        assert tracker["failures"] >= 1
        print(f"  Module tracker: FIR total={tracker['total_actions']} failures={tracker['failures']} ✓")

        # Test 8: add_mistake works
        added = le.add_mistake("ME-TEST-001", {
            "name": "TEST_MISTAKE",
            "severity": "S2_MED",
            "domain": "test",
            "module": "TEST",
            "description": "Test mistake class",
            "prevention_strategy": "Don't do it",
        })
        assert added
        result5 = le.pre_action_check("test", "TEST", {})
        assert any("ME-TEST-001" in r.mistake_id for r in result5.known_risks)
        print(f"  add_mistake + pre_action_check detects new class ✓")

        # Test 9: Summary
        summary = le.session_summary()
        assert summary["ledger_entries"] > 0
        assert summary["mistake_classes_registered"] >= 10
        print(f"  Summary: {summary['ledger_entries']} ledger entries, "
              f"{summary['mistake_classes_registered']} mistake classes ✓")

    print()
    print("LEARNING_ENGINE SELF-TEST PASSED")
    sys.exit(0)
