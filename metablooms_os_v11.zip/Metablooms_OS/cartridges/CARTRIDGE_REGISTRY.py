"""
CARTRIDGE_REGISTRY.py — Cartridge Storage, Lookup, Load, and Lifecycle

CDR V1 (Intent): Implement all 6 registry operations defined in
    CARTRIDGE_REGISTRY_SPEC-1.0: WRITE, LOOKUP, LOAD, UNLOAD,
    STATUS, DEPRECATE. This is the authoritative store for all
    cartridges in MetaBlooms OS v11. PYTHON_CODE_QUALITY always
    loads first (load_order=1) and cannot be unloaded while others
    are active. Integrity rule RI-010.

CDR V2 (Trust): SHA-256 verified on every LOAD (RI-001).
    REGISTRY_INDEX.json is always consistent with filesystem (RI-004).
    COEVOLUTION_LOG entry written on every lifecycle transition (RI-009).
    DEPRECATED cartridges never loaded (RI-002).

CDR V3 (Boundary):
    Inputs:  operation dicts per USB-1.0 envelope
    Outputs: result dicts per USB-1.0 envelope
    Side effects: filesystem writes to CARTRIDGE_REGISTRY/
    Assumptions: registry_root exists and is writable,
                 SPEC_GATE.py present in registry_root

CDR V4 (Failure):
    RR-W-001 through RR-W-004: write failures
    RR-L-001 through RR-L-003: lookup failures
    RR-LD-001 through RR-LD-007: load failures
    RR-D-001 through RR-D-003: deprecate failures
    All failures raise RuntimeError with named code or return
    status=FAILED in output envelope. No silent failures.

CDR V5 (Integration):
    Inputs:  registry_root: Path, coev_log: Path (optional)
    Outputs: per-operation result dicts
    Side effects: writes to registry_root filesystem,
                  appends to COEVOLUTION_LOG.ndjson
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REQUIRES: list[str] = ["SPEC_GATE"]

ANCHOR_CARTRIDGE = "PYTHON_CODE_QUALITY"
INDEX_FILENAME = "REGISTRY_INDEX.json"
LOCK_FILENAME = "REGISTRY_LOCK.json"
COEV_FILENAME = "COEVOLUTION_LOG.ndjson"


# ── Registry class ─────────────────────────────────────────────────────────────

class CartridgeRegistry:
    """
    Main registry object. Instantiate once per session.

    Usage:
        registry = CartridgeRegistry(Path("CARTRIDGE_REGISTRY"))
        registry.boot()
        result = registry.load("PYTHON_CODE_QUALITY", session_id="s001")
    """

    def __init__(self, registry_root: Path, coev_log: Path | None = None):
        self.root = Path(registry_root)
        self.coev_path = coev_log or (self.root.parent / "state" / COEV_FILENAME)
        self._index: dict[str, Any] = {}
        self._lock: dict[str, Any] = {}
        self._session_id: str = ""

        # Import SPEC_GATE from registry root
        sys.path.insert(0, str(self.root))
        try:
            import SPEC_GATE as _sg
            self._spec_gate = _sg
        except ImportError:
            raise RuntimeError(
                "REGISTRY_INIT_NO_SPEC_GATE: SPEC_GATE.py not found in registry root. "
                f"Expected at: {self.root / 'SPEC_GATE.py'}"
            )

    # ── Boot ──────────────────────────────────────────────────────────────────

    def boot(self, session_id: str = "") -> dict[str, Any]:
        """
        Boot sequence: load INDEX, verify, init LOCK.
        Calls rebuild() if INDEX missing or corrupt.
        """
        self._session_id = session_id or datetime.now(UTC).strftime("session-%Y%m%dT%H%M%S")
        index_path = self.root / INDEX_FILENAME

        if index_path.exists():
            try:
                with open(index_path) as f:
                    self._index = json.load(f)
            except (json.JSONDecodeError, OSError):
                self._index = {}
                self._rebuild_index()
        else:
            self._rebuild_index()

        self._lock = {
            "session_id": self._session_id,
            "locked_at": datetime.now(UTC).isoformat(),
            "primary_cartridge": None,
            "loaded_cartridges": [],
            "composite_rubric": None,
            "active_mistake_classes": 0,
            "active_success_patterns": 0,
        }
        self._write_lock()

        return {
            "status": "READY",
            "session_id": self._session_id,
            "registry_total": len(self._index.get("cartridges", {})),
            "registry_active": sum(
                1 for v in self._index.get("cartridges", {}).values()
                if v.get("status") == "ACTIVE"
            ),
        }

    # ── REGISTRY_WRITE ────────────────────────────────────────────────────────

    def write(
        self,
        cartridge_data: dict[str, Any],
        forge_score: str = "UNSCORED",
        overwrite: bool = False,
    ) -> dict[str, Any]:
        """
        Write a cartridge to the registry.
        Calls SPEC_GATE before writing. SHA-256 verified.
        """
        cid = cartridge_data.get("cartridge_id", "")
        if not cid:
            raise RuntimeError("RR-W-000: cartridge_data missing cartridge_id")

        exists = cid in self._index.get("cartridges", {})

        # V-001 check: overwrite flag consistency
        if not overwrite and exists:
            return {"operation": "REGISTRY_WRITE", "status": "FAILED",
                    "cartridge_id": cid, "error": f"RR-W-001: '{cid}' already exists. Use overwrite=True to update."}
        if overwrite and not exists:
            return {"operation": "REGISTRY_WRITE", "status": "FAILED",
                    "cartridge_id": cid, "error": f"RR-W-002: '{cid}' does not exist. Use overwrite=False to create."}

        # SHA-256 verify
        stored_sha = cartridge_data.get("sha256", "")
        c_copy = dict(cartridge_data); c_copy["sha256"] = ""
        expected_sha = hashlib.sha256(
            json.dumps(c_copy, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest()
        if stored_sha != expected_sha:
            return {"operation": "REGISTRY_WRITE", "status": "FAILED",
                    "cartridge_id": cid, "error": f"RR-W-003: SHA-256 mismatch — stored={stored_sha[:16]}... expected={expected_sha[:16]}..."}

        # SPEC_GATE
        gate_result = self._spec_gate.validate(cartridge_data, self.root)
        if not gate_result.passed:
            return {"operation": "REGISTRY_WRITE", "status": "FAILED",
                    "cartridge_id": cid,
                    "error": f"RR-W-SPEC_GATE: {len(gate_result.violations)} violations",
                    "violations": gate_result.violations}

        # Archive existing if overwrite
        cart_dir = self.root / cid
        cart_dir.mkdir(exist_ok=True)
        live_path = cart_dir / f"{cid}.cartridge.json"

        if overwrite and live_path.exists():
            old_version = self._index["cartridges"][cid].get("version", "0.0.0")
            archive_path = cart_dir / f"{cid}.v{old_version}.cartridge.json"
            shutil.copy2(live_path, archive_path)

        # Write
        try:
            with open(live_path, "w") as f:
                json.dump(cartridge_data, f, indent=2)
        except OSError as e:
            return {"operation": "REGISTRY_WRITE", "status": "FAILED",
                    "cartridge_id": cid, "error": f"RR-W-004: filesystem write error — {e}"}

        # Update INDEX
        cartridges = self._index.setdefault("cartridges", {})
        cartridges[cid] = {
            "cartridge_id": cid,
            "version": cartridge_data.get("version", "1.0.0"),
            "domain": cartridge_data.get("domain", ""),
            "subdomain": cartridge_data.get("subdomain"),
            "status": cartridge_data.get("status", "DRAFT"),
            "path": str(live_path.relative_to(self.root)),
            "sha256": stored_sha,
            "created_at": cartridge_data.get("created_at", datetime.now(UTC).isoformat()),
            "updated_at": datetime.now(UTC).isoformat(),
            "forge_score": forge_score,
            "tags": cartridge_data.get("tags", []),
        }
        self._index["last_updated"] = datetime.now(UTC).isoformat()
        self._index["total_cartridges"] = len(cartridges)
        self._write_index()
        self._log_coev("CARTRIDGE_WRITTEN", {"cartridge_id": cid, "version": cartridge_data.get("version"), "forge_score": forge_score})

        return {"operation": "REGISTRY_WRITE", "status": "SUCCESS",
                "cartridge_id": cid, "path": str(live_path), "error": None}

    # ── REGISTRY_LOOKUP ───────────────────────────────────────────────────────

    def lookup(self, query: str, status_filter: str = "ACTIVE") -> dict[str, Any]:
        """
        Resolve a query to a registered cartridge.
        Tries: exact ID match → domain match → tag match → fuzzy.
        """
        cartridges = self._index.get("cartridges", {})

        def status_ok(entry: dict) -> bool:
            if status_filter == "ANY":
                return True
            return entry.get("status") == status_filter

        # Exact ID match
        if query in cartridges and status_ok(cartridges[query]):
            e = cartridges[query]
            return {"operation": "REGISTRY_LOOKUP", "found": True,
                    "cartridge_id": query, "match_type": "EXACT",
                    "confidence": 1.0, "status": e["status"]}

        # Deprecated exact match
        if query in cartridges and cartridges[query].get("status") == "DEPRECATED":
            return {"operation": "REGISTRY_LOOKUP", "found": False,
                    "cartridge_id": None, "match_type": "NONE",
                    "confidence": 0.0, "status": None,
                    "note": f"'{query}' exists but is DEPRECATED"}

        query_lower = query.lower()

        # Domain match
        for cid, entry in cartridges.items():
            if not status_ok(entry):
                continue
            if query_lower in (entry.get("domain", "").lower(),
                               (entry.get("subdomain") or "").lower()):
                return {"operation": "REGISTRY_LOOKUP", "found": True,
                        "cartridge_id": cid, "match_type": "DOMAIN",
                        "confidence": 0.9, "status": entry["status"]}

        # Tag match
        for cid, entry in cartridges.items():
            if not status_ok(entry):
                continue
            tags = [t.lower() for t in entry.get("tags", [])]
            if query_lower in tags:
                return {"operation": "REGISTRY_LOOKUP", "found": True,
                        "cartridge_id": cid, "match_type": "TAG",
                        "confidence": 0.75, "status": entry["status"]}

        # Fuzzy: token overlap
        query_tokens = set(re.findall(r"[a-z0-9]+", query_lower))
        best_cid, best_score = None, 0.0
        for cid, entry in cartridges.items():
            if not status_ok(entry):
                continue
            target = f"{entry.get('domain','')} {entry.get('subdomain','')} {' '.join(entry.get('tags',[]))}"
            target_tokens = set(re.findall(r"[a-z0-9]+", target.lower()))
            if not target_tokens:
                continue
            overlap = len(query_tokens & target_tokens) / max(len(query_tokens), len(target_tokens))
            if overlap > best_score:
                best_score, best_cid = overlap, cid

        if best_score >= 0.3 and best_cid:
            return {"operation": "REGISTRY_LOOKUP", "found": True,
                    "cartridge_id": best_cid, "match_type": "FUZZY",
                    "confidence": round(best_score, 2),
                    "status": cartridges[best_cid]["status"]}

        return {"operation": "REGISTRY_LOOKUP", "found": False,
                "cartridge_id": None, "match_type": "NONE",
                "confidence": 0.0, "status": None}

    # ── REGISTRY_LOAD ─────────────────────────────────────────────────────────

    def load(
        self,
        cartridge_id: str,
        session_id: str = "",
        load_reason: str = "",
        force_draft: bool = False,
    ) -> dict[str, Any]:
        """
        Load a cartridge into session context.
        Verifies SHA-256, checks conflicts, merges into LOCK.
        """
        cartridges = self._index.get("cartridges", {})

        if cartridge_id not in cartridges:
            return {"operation": "REGISTRY_LOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-LD-001: '{cartridge_id}' not in registry"}

        entry = cartridges[cartridge_id]

        if entry["status"] == "DEPRECATED":
            return {"operation": "REGISTRY_LOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-LD-002: '{cartridge_id}' is DEPRECATED"}

        if entry["status"] == "DRAFT" and not force_draft:
            return {"operation": "REGISTRY_LOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-LD-003: '{cartridge_id}' is DRAFT — pass force_draft=True to load in dev mode"}

        # Read and verify SHA-256
        cart_path = self.root / entry["path"]
        try:
            with open(cart_path) as f:
                cartridge_data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            return {"operation": "REGISTRY_LOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-LD-004a: cannot read cartridge file — {e}"}

        stored_sha = cartridge_data.get("sha256", "")
        if stored_sha != entry["sha256"]:
            return {"operation": "REGISTRY_LOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-LD-004: SHA-256 mismatch — possible corruption"}

        # Conflict check
        loaded_ids = [lc["cartridge_id"] for lc in self._lock.get("loaded_cartridges", [])]

        # Already loaded?
        if cartridge_id in loaded_ids:
            return {"operation": "REGISTRY_LOAD", "status": "SUCCESS",
                    "cartridge_id": cartridge_id, "load_order": loaded_ids.index(cartridge_id) + 1,
                    "conflict_summary": None, "total_loaded": len(loaded_ids),
                    "note": "already loaded"}

        # Check explicit incompatibilities
        comp = cartridge_data.get("composition", {})
        incompatible = comp.get("incompatible_with", [])
        for inc in incompatible:
            if inc in loaded_ids:
                return {"operation": "REGISTRY_LOAD", "status": "CONFLICT",
                        "cartridge_id": cartridge_id,
                        "conflict_summary": f"RR-LD-005: '{cartridge_id}' is incompatible with loaded '{inc}'",
                        "error": None}

        # Check requires
        requires = comp.get("requires", [])
        missing_deps = [r for r in requires if r not in loaded_ids]
        if missing_deps:
            return {"operation": "REGISTRY_LOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-LD-006: missing required cartridges: {missing_deps}"}

        # Circular dependency check
        if cartridge_id in requires:
            return {"operation": "REGISTRY_LOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-LD-007: circular dependency — '{cartridge_id}' requires itself"}

        # Add to lock
        load_order = len(loaded_ids) + 1
        self._lock.setdefault("loaded_cartridges", []).append({
            "cartridge_id": cartridge_id,
            "load_order": load_order,
            "load_reason": load_reason or f"explicit load request",
            "sha256_verified": True,
        })

        # Set primary if first
        if load_order == 1:
            self._lock["primary_cartridge"] = cartridge_id

        # Recompute composite counts
        self._recompute_composite()
        self._write_lock()
        self._log_coev("CARTRIDGE_LOADED", {"cartridge_id": cartridge_id, "load_order": load_order})

        return {"operation": "REGISTRY_LOAD", "status": "SUCCESS",
                "cartridge_id": cartridge_id, "load_order": load_order,
                "conflict_summary": None,
                "total_loaded": len(self._lock["loaded_cartridges"]),
                "error": None}

    # ── REGISTRY_UNLOAD ───────────────────────────────────────────────────────

    def unload(self, cartridge_id: str) -> dict[str, Any]:
        """Remove a cartridge from session context."""
        loaded = self._lock.get("loaded_cartridges", [])
        loaded_ids = [lc["cartridge_id"] for lc in loaded]

        if cartridge_id not in loaded_ids:
            return {"operation": "REGISTRY_UNLOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"'{cartridge_id}' is not currently loaded"}

        # Protect anchor
        if cartridge_id == ANCHOR_CARTRIDGE and len(loaded_ids) > 1:
            return {"operation": "REGISTRY_UNLOAD", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-D-anchor: '{ANCHOR_CARTRIDGE}' cannot be unloaded while other cartridges are active (RI-010)"}

        # Check dependents
        dependents = []
        for other_id in loaded_ids:
            if other_id == cartridge_id:
                continue
            other_path = self.root / self._index["cartridges"][other_id]["path"]
            try:
                with open(other_path) as f:
                    other_data = json.load(f)
                if cartridge_id in other_data.get("composition", {}).get("requires", []):
                    dependents.append(other_id)
            except Exception:
                pass

        if dependents:
            return {"operation": "REGISTRY_UNLOAD", "status": "CONFLICT",
                    "cartridge_id": cartridge_id,
                    "dependents_blocked": dependents,
                    "error": f"Cannot unload — required by: {dependents}"}

        self._lock["loaded_cartridges"] = [lc for lc in loaded if lc["cartridge_id"] != cartridge_id]
        self._recompute_composite()
        self._write_lock()
        self._log_coev("CARTRIDGE_UNLOADED", {"cartridge_id": cartridge_id})

        return {"operation": "REGISTRY_UNLOAD", "status": "SUCCESS",
                "cartridge_id": cartridge_id, "dependents_blocked": [], "error": None}

    # ── REGISTRY_STATUS ───────────────────────────────────────────────────────

    def status(self) -> dict[str, Any]:
        """Return current session registry state."""
        loaded = self._lock.get("loaded_cartridges", [])
        cartridges = self._index.get("cartridges", {})
        return {
            "operation": "REGISTRY_STATUS",
            "session_id": self._lock.get("session_id", ""),
            "loaded_cartridges": [lc["cartridge_id"] for lc in loaded],
            "primary_cartridge": self._lock.get("primary_cartridge"),
            "composite_rubric": self._lock.get("composite_rubric"),
            "active_mistake_classes": self._lock.get("active_mistake_classes", 0),
            "active_success_patterns": self._lock.get("active_success_patterns", 0),
            "registry_total": len(cartridges),
            "registry_active": sum(1 for v in cartridges.values() if v.get("status") == "ACTIVE"),
        }

    # ── REGISTRY_DEPRECATE ────────────────────────────────────────────────────

    def deprecate(self, cartridge_id: str, reason: str, successor_id: str | None = None) -> dict[str, Any]:
        """Transition a cartridge from ACTIVE to DEPRECATED."""
        cartridges = self._index.get("cartridges", {})

        if cartridge_id not in cartridges:
            return {"operation": "REGISTRY_DEPRECATE", "status": "FAILED",
                    "cartridge_id": cartridge_id, "error": f"RR-D-000: '{cartridge_id}' not in registry"}

        entry = cartridges[cartridge_id]

        if entry["status"] == "DEPRECATED":
            return {"operation": "REGISTRY_DEPRECATE", "status": "FAILED",
                    "cartridge_id": cartridge_id, "error": f"RR-D-002: '{cartridge_id}' is already DEPRECATED"}

        # Protect anchor from deprecation without successor
        if cartridge_id == ANCHOR_CARTRIDGE and not successor_id:
            return {"operation": "REGISTRY_DEPRECATE", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-D-anchor: '{ANCHOR_CARTRIDGE}' cannot be deprecated without a certified successor (RI-010)"}

        # Check not currently loaded
        loaded_ids = [lc["cartridge_id"] for lc in self._lock.get("loaded_cartridges", [])]
        if cartridge_id in loaded_ids:
            return {"operation": "REGISTRY_DEPRECATE", "status": "FAILED",
                    "cartridge_id": cartridge_id,
                    "error": f"RR-D-001: '{cartridge_id}' is currently loaded — unload first"}

        # Archive
        cart_path = self.root / entry["path"]
        version = entry.get("version", "0.0.0")
        archive_path = self.root / cartridge_id / f"{cartridge_id}.v{version}.cartridge.json"
        if cart_path.exists():
            shutil.copy2(cart_path, archive_path)

        # Update status
        cartridges[cartridge_id]["status"] = "DEPRECATED"
        cartridges[cartridge_id]["updated_at"] = datetime.now(UTC).isoformat()
        self._write_index()

        # Update cartridge file status field too
        try:
            with open(cart_path) as f:
                cd = json.load(f)
            cd["status"] = "DEPRECATED"
            with open(cart_path, "w") as f:
                json.dump(cd, f, indent=2)
        except Exception:
            pass

        # Warn if successor not active
        warn = None
        if successor_id and successor_id not in cartridges:
            warn = f"RR-D-003: successor '{successor_id}' not in registry"
        elif successor_id and cartridges.get(successor_id, {}).get("status") != "ACTIVE":
            warn = f"RR-D-003: successor '{successor_id}' is not ACTIVE"

        self._log_coev("CARTRIDGE_DEPRECATED", {
            "cartridge_id": cartridge_id, "reason": reason,
            "successor_id": successor_id, "archived_as": str(archive_path)
        })

        return {"operation": "REGISTRY_DEPRECATE", "status": "SUCCESS",
                "cartridge_id": cartridge_id, "warning": warn, "error": None}

    # ── COMPOSITE ASSEMBLY ─────────────────────────────────────────────────────

    def get_composite_context(self) -> dict[str, Any]:
        """
        Build merged mistake classes, success patterns, and expert lenses
        from all currently loaded cartridges. Used by pre-action check and BTS.
        """
        loaded = self._lock.get("loaded_cartridges", [])
        composite_mistakes: dict[str, Any] = {}
        composite_successes: dict[str, Any] = {}
        composite_lenses: dict[str, list] = {}
        all_criteria: list[dict] = []
        total_cartridges = len(loaded)

        for lc in loaded:
            cid = lc["cartridge_id"]
            entry = self._index.get("cartridges", {}).get(cid, {})
            if not entry:
                continue
            cart_path = self.root / entry["path"]
            try:
                with open(cart_path) as f:
                    cd = json.load(f)
            except Exception:
                continue

            # Merge mistake classes
            for mc in cd.get("mistake_classes", []):
                mid = mc.get("id", "")
                if mid not in composite_mistakes:
                    composite_mistakes[mid] = mc
                else:
                    # ID collision: suffix with cartridge abbrev
                    composite_mistakes[f"{mid}-{cid[:4]}"] = mc

            # Merge success patterns
            for sp in cd.get("success_patterns", []):
                sid = sp.get("id", "")
                if sid not in composite_successes:
                    composite_successes[sid] = sp

            # Merge expert lenses (additive)
            for lens_name, lens_val in cd.get("expert_lenses", {}).items():
                composite_lenses.setdefault(lens_name, []).append({
                    "source": cid, "value": lens_val
                })

            # Rubric criteria for composite (renormalize weights)
            rubric = cd.get("quality_rubric", {})
            for cr in rubric.get("criteria", []):
                cr_copy = dict(cr)
                if total_cartridges > 0:
                    cr_copy["weight"] = round(cr.get("weight", 0) / total_cartridges, 4)
                cr_copy["source_cartridge"] = cid
                all_criteria.append(cr_copy)

        return {
            "composite_mistake_classes": composite_mistakes,
            "composite_success_patterns": composite_successes,
            "composite_expert_lenses": composite_lenses,
            "composite_rubric_criteria": all_criteria,
            "loaded_cartridge_count": total_cartridges,
            "total_mistake_classes": len(composite_mistakes),
            "total_success_patterns": len(composite_successes),
        }

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _recompute_composite(self) -> None:
        loaded = self._lock.get("loaded_cartridges", [])
        mc_total = sp_total = 0
        for lc in loaded:
            cid = lc["cartridge_id"]
            entry = self._index.get("cartridges", {}).get(cid, {})
            if not entry:
                continue
            try:
                with open(self.root / entry["path"]) as f:
                    cd = json.load(f)
                mc_total += len(cd.get("mistake_classes", []))
                sp_total += len(cd.get("success_patterns", []))
            except Exception:
                pass

        self._lock["active_mistake_classes"] = mc_total
        self._lock["active_success_patterns"] = sp_total
        self._lock["composite_rubric"] = "COMPOSITE" if len(loaded) > 1 else (
            loaded[0]["cartridge_id"] if loaded else None
        )

    def _rebuild_index(self) -> None:
        """Rebuild REGISTRY_INDEX.json from filesystem scan."""
        cartridges = {}
        for cart_dir in self.root.iterdir():
            if not cart_dir.is_dir():
                continue
            cart_file = cart_dir / f"{cart_dir.name}.cartridge.json"
            if not cart_file.exists():
                continue
            try:
                with open(cart_file) as f:
                    cd = json.load(f)
                stored_sha = cd.get("sha256", "")
                c_copy = dict(cd); c_copy["sha256"] = ""
                computed = hashlib.sha256(
                    json.dumps(c_copy, sort_keys=True, separators=(",", ":")).encode()
                ).hexdigest()
                if stored_sha != computed:
                    continue  # Skip corrupt files
                cartridges[cd["cartridge_id"]] = {
                    "cartridge_id": cd["cartridge_id"],
                    "version": cd.get("version", ""),
                    "domain": cd.get("domain", ""),
                    "subdomain": cd.get("subdomain"),
                    "status": cd.get("status", "DRAFT"),
                    "path": str(cart_file.relative_to(self.root)),
                    "sha256": stored_sha,
                    "created_at": cd.get("created_at", ""),
                    "updated_at": cd.get("updated_at", ""),
                    "forge_score": "UNSCORED",
                    "tags": cd.get("tags", []),
                }
            except Exception:
                continue

        self._index = {
            "registry_version": "1.0",
            "last_updated": datetime.now(UTC).isoformat(),
            "total_cartridges": len(cartridges),
            "cartridges": cartridges,
        }
        self._write_index()
        self._log_coev("REGISTRY_REBUILT", {"cartridge_count": len(cartridges)})

    def _write_index(self) -> None:
        index_path = self.root / INDEX_FILENAME
        tmp = index_path.with_suffix(".tmp")
        with open(tmp, "w") as f:
            json.dump(self._index, f, indent=2)
        os.replace(tmp, index_path)

    def _write_lock(self) -> None:
        lock_path = self.root / LOCK_FILENAME
        with open(lock_path, "w") as f:
            json.dump(self._lock, f, indent=2)

    def _log_coev(self, event_type: str, data: dict[str, Any]) -> None:
        entry = {
            "entry_id": f"COEV-{datetime.now(UTC).strftime('%Y%m%dT%H%M%S%f')}",
            "type": event_type,
            "session_id": self._session_id,
            "timestamp": datetime.now(UTC).isoformat(),
            **data,
        }
        try:
            self.coev_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.coev_path, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass  # Log failure must not crash the registry


# ── Module-level convenience functions ────────────────────────────────────────

def boot_registry(registry_root: Path, session_id: str = "") -> "CartridgeRegistry":
    """Boot and return a ready CartridgeRegistry instance."""
    reg = CartridgeRegistry(registry_root)
    reg.boot(session_id=session_id)
    return reg


# ── Missing import ─────────────────────────────────────────────────────────────
import re
