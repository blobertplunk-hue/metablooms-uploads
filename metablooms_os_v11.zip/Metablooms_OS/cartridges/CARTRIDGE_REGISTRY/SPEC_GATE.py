"""
SPEC_GATE.py — Cartridge Schema Validator

CDR V1 (Intent): Validate any .cartridge.json file against all 20 rules
    defined in CARTRIDGE_SPEC-1.0. Called by CARTRIDGE_REGISTRY before
    any write and by CARTRIDGE_GENERATOR in Stage 7B. No cartridge may
    be registered ACTIVE without passing all 20 rules.

CDR V2 (Trust): Every rule check reads actual cartridge data. No rule
    is skipped. Partial passes are not accepted — all 20 must pass or
    the cartridge is rejected. Violations are collected and returned in
    full, never truncated.

CDR V3 (Boundary):
    Inputs:  cartridge (dict), registry_root (Path, optional — for V-013)
    Outputs: SpecGateResult with passed bool and violations list
    Side effects: none — read-only validation
    Assumptions: cartridge is already parsed JSON (dict)

CDR V4 (Failure):
    SPEC_GATE_EMPTY_CARTRIDGE: cartridge is None or not a dict
    SPEC_GATE_REGISTRY_ROOT_MISSING: V-013 check requested but no root given
    All other failures: collected as violations, returned in result.

CDR V5 (Integration):
    Inputs:  cartridge: dict, registry_root: Path | None
    Outputs: SpecGateResult(passed, violations, cartridge_id, checked_at)
    Side effects: none
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REQUIRES: list[str] = []

SPEC_VERSION = "CARTRIDGE_SPEC-1.0"
REQUIRED_FIELDS = [
    "cartridge_id", "version", "spec_version", "domain", "subdomain",
    "envelope", "status", "created_at", "updated_at", "sha256",
    "provenance", "domain_knowledge", "expert_lenses", "quality_rubric",
    "mistake_classes", "success_patterns", "artifact_types", "domain_stages",
    "composition", "forge_config", "research_queries", "fmea",
    "dok_calibration", "mpp_override",
]
VALID_STATUSES = {"DRAFT", "ACTIVE", "DEPRECATED"}
VALID_CONFLICT_RESOLUTIONS = {"MERGE_RUBRICS", "PRIMARY_WINS", "FAIL_ON_CONFLICT"}
ID_ABBREV_RE = re.compile(r"^[A-Z]{2,6}$")
ME_ID_RE = re.compile(r"^ME-[A-Z]{2,6}-\d{3}$")
MS_ID_RE = re.compile(r"^MS-[A-Z]{2,6}-\d{3}$")
CRITERION_ID_RE = re.compile(r"^[A-Z]{2,6}-R\d{2}$")
SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
SCREAMING_RE = re.compile(r"^[A-Z][A-Z0-9_]*$")


@dataclass
class SpecGateResult:
    passed: bool
    cartridge_id: str
    violations: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    checked_at: str = field(default_factory=lambda: datetime.now(UTC).isoformat())
    rules_checked: int = 20

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "cartridge_id": self.cartridge_id,
            "violations": self.violations,
            "warnings": self.warnings,
            "checked_at": self.checked_at,
            "rules_checked": self.rules_checked,
            "violation_count": len(self.violations),
        }


def validate(
    cartridge: dict[str, Any],
    registry_root: Path | None = None,
) -> SpecGateResult:
    """
    Run all 20 CARTRIDGE_SPEC-1.0 validation rules against a cartridge dict.

    Args:
        cartridge: parsed cartridge JSON as dict
        registry_root: optional path to CARTRIDGE_REGISTRY root (for V-013)

    Returns:
        SpecGateResult with passed=True only if all 20 rules pass
    """
    if not cartridge or not isinstance(cartridge, dict):
        raise RuntimeError("SPEC_GATE_EMPTY_CARTRIDGE: cartridge must be a non-empty dict")

    violations: list[str] = []
    warnings: list[str] = []
    cid = cartridge.get("cartridge_id", "UNKNOWN")

    # ── V-001: All required fields present ────────────────────────────────────
    for f in REQUIRED_FIELDS:
        if f not in cartridge:
            violations.append(f"V-001: missing required field '{f}'")

    # Short-circuit: if critical identity fields missing, remaining rules can't run cleanly
    has_identity = all(f in cartridge for f in ["cartridge_id", "version", "spec_version",
                                                  "envelope", "status", "sha256"])

    # ── V-002: cartridge_id is SCREAMING_SNAKE_CASE ───────────────────────────
    if "cartridge_id" in cartridge:
        if not SCREAMING_RE.match(str(cartridge["cartridge_id"])):
            violations.append(f"V-002: cartridge_id '{cartridge['cartridge_id']}' is not SCREAMING_SNAKE_CASE")

    # ── V-003: version is valid semver ────────────────────────────────────────
    if "version" in cartridge:
        if not SEMVER_RE.match(str(cartridge.get("version", ""))):
            violations.append(f"V-003: version '{cartridge.get('version')}' is not valid semver (MAJOR.MINOR.PATCH)")

    # ── V-004: spec_version == CARTRIDGE_SPEC-1.0 ─────────────────────────────
    if "spec_version" in cartridge:
        if cartridge["spec_version"] != SPEC_VERSION:
            violations.append(f"V-004: spec_version '{cartridge['spec_version']}' != '{SPEC_VERSION}'")

    # ── V-005: envelope == USB-1.0 ────────────────────────────────────────────
    if "envelope" in cartridge:
        if cartridge["envelope"] != "USB-1.0":
            violations.append(f"V-005: envelope '{cartridge['envelope']}' != 'USB-1.0'")

    # ── V-006: sha256 matches computed hash ───────────────────────────────────
    if "sha256" in cartridge and has_identity:
        stored = cartridge["sha256"]
        c_copy = dict(cartridge)
        c_copy["sha256"] = ""
        canonical = json.dumps(c_copy, sort_keys=True, separators=(",", ":"))
        expected = hashlib.sha256(canonical.encode()).hexdigest()
        if stored != expected:
            violations.append(
                f"V-006: sha256 mismatch — stored={stored[:16]}... expected={expected[:16]}..."
            )

    # ── V-007: rubric criterion weights sum to 1.0 ───────────────────────────
    rubric = cartridge.get("quality_rubric", {})
    criteria = rubric.get("criteria", []) if isinstance(rubric, dict) else []
    if criteria:
        weight_sum = sum(c.get("weight", 0) for c in criteria if isinstance(c, dict))
        if abs(weight_sum - 1.0) > 0.001:
            violations.append(f"V-007: rubric weights sum to {weight_sum:.4f}, not 1.0 (±0.001)")

    # ── V-008: mistake class IDs follow ME-{ABBREV}-{nnn} ────────────────────
    for mc in cartridge.get("mistake_classes", []):
        if isinstance(mc, dict):
            mid = mc.get("id", "")
            if not ME_ID_RE.match(str(mid)):
                violations.append(f"V-008: mistake class id '{mid}' does not match ME-{{ABBREV2-6}}-{{nnn}}")

    # ── V-009: success pattern IDs follow MS-{ABBREV}-{nnn} ──────────────────
    for sp in cartridge.get("success_patterns", []):
        if isinstance(sp, dict):
            sid = sp.get("id", "")
            if not MS_ID_RE.match(str(sid)):
                violations.append(f"V-009: success pattern id '{sid}' does not match MS-{{ABBREV2-6}}-{{nnn}}")

    # ── V-010: rubric criterion IDs follow {PREFIX}-R{nn} ────────────────────
    for cr in criteria:
        if isinstance(cr, dict):
            crid = cr.get("id", "")
            if not CRITERION_ID_RE.match(str(crid)):
                violations.append(f"V-010: criterion id '{crid}' does not match {{PREFIX2-6}}-R{{nn}}")

    # ── V-011: FMEA RPN == severity × likelihood × detectability ─────────────
    for fm in cartridge.get("fmea", []):
        if isinstance(fm, dict):
            s = fm.get("severity", 0)
            l = fm.get("likelihood", 0)
            d = fm.get("detectability", 0)
            rpn = fm.get("rpn", -1)
            expected_rpn = s * l * d
            if rpn != expected_rpn:
                violations.append(
                    f"V-011: FMEA '{str(fm.get('failure_mode',''))[:40]}' RPN={rpn} != {s}×{l}×{d}={expected_rpn}"
                )

    # ── V-012: FMEA RPN > 100 must have mitigation referencing a named class ──
    for fm in cartridge.get("fmea", []):
        if isinstance(fm, dict):
            if fm.get("rpn", 0) > 100:
                mitigation = fm.get("mitigation", "")
                if not mitigation or len(str(mitigation)) < 10:
                    violations.append(
                        f"V-012: FMEA RPN={fm['rpn']} entry '{str(fm.get('failure_mode',''))[:40]}' "
                        f"missing mitigation referencing a named class"
                    )

    # ── V-013: forge_config.engine exists or is null ──────────────────────────
    fc = cartridge.get("forge_config", {})
    engine = fc.get("engine") if isinstance(fc, dict) else None
    if engine is not None:
        if registry_root is not None:
            engine_path = registry_root / "forge" / "rubrics" / engine
            if not engine_path.exists():
                warnings.append(
                    f"V-013: forge engine '{engine}' not found at {engine_path} — verify before activation"
                )
        else:
            warnings.append(f"V-013: forge engine '{engine}' declared but registry_root not provided — cannot verify path")

    # ── V-014: Minimum counts ─────────────────────────────────────────────────
    mc_count = len([x for x in cartridge.get("mistake_classes", []) if isinstance(x, dict)])
    sp_count = len([x for x in cartridge.get("success_patterns", []) if isinstance(x, dict)])
    cr_count = len([x for x in criteria if isinstance(x, dict)])
    rq_count = len([x for x in cartridge.get("research_queries", []) if isinstance(x, str)])
    fm_count = len([x for x in cartridge.get("fmea", []) if isinstance(x, dict)])
    el = cartridge.get("expert_lenses", {})
    el_terms = len(el.get("language_of_discipline", [])) if isinstance(el, dict) else 0

    minimums = [
        (mc_count, 3, "mistake_classes"),
        (sp_count, 2, "success_patterns"),
        (cr_count, 5, "rubric criteria"),
        (rq_count, 3, "research_queries"),
        (fm_count, 3, "fmea entries"),
        (el_terms, 5, "expert lens language_of_discipline terms"),
    ]
    for count, minimum, label in minimums:
        if count < minimum:
            violations.append(f"V-014: {label} count={count} < minimum {minimum}")

    # ── V-015: composition.conflict_resolution is valid enum ─────────────────
    comp = cartridge.get("composition", {})
    if isinstance(comp, dict):
        cr_val = comp.get("conflict_resolution", "")
        if cr_val not in VALID_CONFLICT_RESOLUTIONS:
            violations.append(
                f"V-015: conflict_resolution '{cr_val}' not in {VALID_CONFLICT_RESOLUTIONS}"
            )

    # ── V-016: status is valid enum ───────────────────────────────────────────
    if "status" in cartridge:
        if cartridge["status"] not in VALID_STATUSES:
            violations.append(f"V-016: status '{cartridge['status']}' not in {VALID_STATUSES}")

    # ── V-017: dok_calibration.target_dok is 1-4 ─────────────────────────────
    dok = cartridge.get("dok_calibration", {})
    if isinstance(dok, dict):
        target = dok.get("target_dok")
        if target not in [1, 2, 3, 4]:
            violations.append(f"V-017: dok_calibration.target_dok={target!r} not in [1,2,3,4]")

    # ── V-018: No circular composition.requires dependencies ─────────────────
    if isinstance(comp, dict):
        requires = comp.get("requires", [])
        if isinstance(requires, list) and cid in requires:
            violations.append(f"V-018: circular dependency — '{cid}' requires itself")

    # ── V-019: mpp_override non-null flagged for human review ─────────────────
    if cartridge.get("mpp_override") is not None:
        warnings.append(
            "V-019: mpp_override is non-null — requires human review before activation"
        )

    # ── V-020: linked_success and linked_mistake cross-references resolve ─────
    mc_ids = {mc["id"] for mc in cartridge.get("mistake_classes", []) if isinstance(mc, dict) and "id" in mc}
    sp_ids = {sp["id"] for sp in cartridge.get("success_patterns", []) if isinstance(sp, dict) and "id" in sp}

    for mc in cartridge.get("mistake_classes", []):
        if isinstance(mc, dict):
            ls = mc.get("linked_success")
            if ls and ls not in sp_ids:
                violations.append(f"V-020: {mc.get('id')} linked_success='{ls}' not found in success_patterns")

    for sp in cartridge.get("success_patterns", []):
        if isinstance(sp, dict):
            lm = sp.get("linked_mistake")
            if lm and lm not in mc_ids:
                violations.append(f"V-020: {sp.get('id')} linked_mistake='{lm}' not found in mistake_classes")

    passed = len(violations) == 0
    return SpecGateResult(
        passed=passed,
        cartridge_id=cid,
        violations=violations,
        warnings=warnings,
    )
