# CARTRIDGE_GENERATOR_SPEC.md
# MetaBlooms OS v11 — Cartridge Generator Engine Specification
# Version: 1.0
# Status: LOCKED
# Depends on: CARTRIDGE_SPEC-1.0, USB-1.0
# SPEC_GATE: No CARTRIDGE_GENERATOR code may be written without conforming to this spec.
# Last updated: COEV-session (post-COEV-062)

---

## 1. PURPOSE

CARTRIDGE_GENERATOR is the engine that builds domain cartridges.

It is the meta-cartridge: the cartridge that makes all other cartridges.

It takes a domain request as input and produces a fully validated
CARTRIDGE_SPEC-1.0 conformant cartridge as output, registered in
CARTRIDGE_REGISTRY and ready for immediate loading.

It runs UNDER the governance of PYTHON_CODE_QUALITY cartridge.
Every cartridge it produces is scored by FORGE before it ships.
A cartridge that does not pass RUBRIC_PYTHON stays DRAFT.

---

## 2. USB-1.0 ENVELOPE

### INPUT

```json
{
  "engine": "CARTRIDGE_GENERATOR",
  "version": "1.0.0",
  "input": {
    "domain_request": "<string: natural language or slug describing the domain>",
    "cartridge_id":   "<string: proposed SCREAMING_SNAKE_CASE ID, or null for auto-generate>",
    "subdomain":      "<string: optional refinement, or null>",
    "seed_queries":   ["<string>", ...],
    "target_dok":     "<integer: 1-4, or null for auto-detect>",
    "requester":      "<string: who is requesting this cartridge>",
    "session_id":     "<string: COEV log entry ID to attach provenance to>"
  }
}
```

Required: `domain_request`, `session_id`
Optional: all others (generator derives them if not supplied)

### OUTPUT

```json
{
  "engine": "CARTRIDGE_GENERATOR",
  "version": "1.0.0",
  "status": "<enum: SUCCESS | DRAFT | FAILED>",
  "cartridge_id": "<string>",
  "cartridge_path": "<string: path to written .cartridge.json file>",
  "forge_score": "<enum: S | A | B | C | F>",
  "spec_gate_result": {
    "passed": "<boolean>",
    "violations": ["<V-{nnn}: description>", ...]
  },
  "research_summary": "<string: what WEB_SEE_ENGINE found>",
  "atoms_generated": "<integer>",
  "error": "<string | null>"
}
```

Status meanings:
- `SUCCESS`: cartridge passed SPEC_GATE + FORGE A-tier or better → status ACTIVE
- `DRAFT`: cartridge passed SPEC_GATE but FORGE scored B or below → status DRAFT
- `FAILED`: SPEC_GATE violations found → cartridge not written, error returned

---

## 3. SEVEN-STAGE PIPELINE

CARTRIDGE_GENERATOR executes exactly 7 stages in order.
No stage may be skipped. No stage may run out of order.
Each stage has defined inputs, outputs, and failure modes.

```
Stage 1: DOMAIN_RESEARCH      (WEB_SEE_ENGINE)
Stage 2: LENS_EXTRACTION      (Kaplan D&C framework)
Stage 3: DOK_CALIBRATION      (Webb's DOK framework)
Stage 4: FMEA_ANALYSIS        (failure mode identification)
Stage 5: PATTERN_EXTRACTION   (success patterns + mistake classes)
Stage 6: RUBRIC_GENERATION    (quality rubric construction)
Stage 7: CARTRIDGE_ASSEMBLY   (schema build + SPEC_GATE + FORGE)
```

---

## 4. STAGE DEFINITIONS

### STAGE 1: DOMAIN_RESEARCH

**Purpose:** Build the knowledge foundation the rest of the pipeline depends on.

**Engine:** WEB_SEE_ENGINE (web search + atom extraction)

**Inputs:**
- `domain_request` from envelope input
- `seed_queries` (if provided) or auto-generated from domain_request

**Process:**
1. Generate minimum 5 research queries from domain_request
   - Query 1: domain fundamentals (what is this domain?)
   - Query 2: quality signals (what does world-class look like here?)
   - Query 3: failure patterns (what do bad practitioners do?)
   - Query 4: expert vocabulary (what terms do experts use?)
   - Query 5: cross-domain connections (what other fields touch this?)
   - Seed queries appended if provided
2. Execute WEB_SEE_ENGINE on all queries
3. Extract atoms (discrete facts) and links (relationships between facts)
4. Identify top 5-10 authoritative sources
5. Build `domain_knowledge` block for cartridge schema

**Outputs:**
- `knowledge_atoms`: list of extracted facts
- `knowledge_links`: list of relationships
- `sources`: list of URLs/titles
- `domain_vocabulary`: list of domain-specific terms (feeds Stage 2)
- `quality_signals`: list of what "world class" means here (feeds Stage 6)
- `failure_signals`: list of common failures (feeds Stages 4 + 5)

**Failure modes:**
- FG-S1-001: WEB_SEE_ENGINE returns zero results → abort, return FAILED
- FG-S1-002: Domain too vague to generate meaningful queries → request clarification
- FG-S1-003: All sources low-quality (forums, SEO spam) → flag in provenance, continue with warning

**Stage gate:** Minimum 10 atoms extracted before Stage 2 may begin.

---

### STAGE 2: LENS_EXTRACTION

**Purpose:** Apply Kaplan's Depth and Complexity framework to map expert thinking in this domain.

**Engine:** Internal reasoning (no web search needed — applies framework to Stage 1 output)

**Inputs:**
- `knowledge_atoms` from Stage 1
- `domain_vocabulary` from Stage 1
- `sources` from Stage 1

**Process:**
Apply all 11 Kaplan lenses to Stage 1 findings:

1. **Language of Discipline** → extract minimum 5 domain-specific terms from vocabulary
2. **Big Idea** → synthesize the single central organizing principle
3. **Unanswered Questions** → identify minimum 2 questions that must be answered before acting
4. **Ethics** → identify domain-specific ethical obligations (never null in teaching/healthcare/legal domains)
5. **Patterns** → identify recurring patterns experts recognize and novices miss
6. **Change Over Time** → how has this domain evolved, what's currently shifting
7. **Across Disciplines** → minimum 2 adjacent domains, with connection described
8. **Multiple Perspectives** → who disagrees in this domain and on what grounds
9. **Details vs Big Picture** → when to zoom in, when to zoom out
10. **Rules vs Exceptions** → what the rules are and where they legitimately break
11. **Proof** → what counts as evidence of quality in this domain

**Outputs:**
- `expert_lenses` block (complete, conformant with CARTRIDGE_SPEC Section 4.4)

**Failure modes:**
- FG-S2-001: Cannot identify Big Idea → domain too broad, recommend narrowing subdomain
- FG-S2-002: Ethics field empty in a domain with clear ethical stakes → flag S3_HIGH, force human review

**Stage gate:** All 11 lenses populated (null only where genuinely inapplicable and documented).

---

### STAGE 3: DOK_CALIBRATION

**Purpose:** Establish the cognitive level this cartridge operates at and what level mismatch looks like.

**Engine:** Internal reasoning using Webb's DOK framework

**Inputs:**
- `domain_request`
- `knowledge_atoms` from Stage 1
- `expert_lenses` from Stage 2
- `target_dok` from envelope input (or auto-detect)

**Process:**
1. If `target_dok` provided: validate it makes sense for this domain
2. If `target_dok` null: infer from domain_request and knowledge atoms
   - DOK 1: recall, recognition, single-step — e.g. vocabulary drill
   - DOK 2: skill/concept application — e.g. applying a formula
   - DOK 3: strategic thinking — e.g. debugging, designing a lesson
   - DOK 4: extended thinking — e.g. curriculum design, system architecture
3. Write DOK descriptors for all 4 levels IN THIS DOMAIN (not generic)
4. Identify what DOK mismatch looks like (too high → confusion, too low → boredom)
5. Map DOK mismatch to a mistake class ID (pre-assigned: ME-{ABBREV}-001 reserved for DOK_MISMATCH)

**Outputs:**
- `dok_calibration` block (conformant with CARTRIDGE_SPEC Section 4.14)

**Failure modes:**
- FG-S3-001: Domain has no meaningful DOK gradient → set all levels to descriptive text, flag in notes
- FG-S3-002: Requested DOK level inconsistent with domain artifacts → warn, use inferred level

**Stage gate:** `dok_calibration` block complete with all 4 level descriptors populated.

---

### STAGE 4: FMEA_ANALYSIS

**Purpose:** Identify and prioritize what can go wrong when operating in this domain.

**Engine:** Internal reasoning using FMEA methodology + Stage 1 failure signals

**Inputs:**
- `failure_signals` from Stage 1
- `expert_lenses` from Stage 2 (especially Ethics, Rules vs Exceptions)
- `dok_calibration` from Stage 3

**Process:**
1. List all failure modes from Stage 1 failure signals
2. Add domain-specific failures from expert lens analysis
3. Add DOK mismatch as a failure mode (always present)
4. For each failure mode:
   a. Describe the effect on output quality or user harm
   b. Score severity (1-10): how bad if this happens
   c. Score likelihood (1-10): how often this happens without mitigation
   d. Score detectability (1-10): how hard it is to catch (10 = nearly impossible to detect)
   e. Compute RPN = severity × likelihood × detectability
   f. For RPN > 100: write concrete mitigation mapped to a named ERAC code or mistake class
5. Sort by RPN descending

**Outputs:**
- `fmea` list (conformant with CARTRIDGE_SPEC Section 4.13)
- `high_rpn_failures`: list of failures with RPN > 100 (feeds Stage 5)

**Failure modes:**
- FG-S4-001: Fewer than 3 FMEA entries generated → domain too narrow, expand scope
- FG-S4-002: RPN > 100 entry has no mitigation → SPEC_GATE V-012 will catch this, must resolve before Stage 7

**Stage gate:** Minimum 3 FMEA entries. All RPN > 100 entries have mitigations.

---

### STAGE 5: PATTERN_EXTRACTION

**Purpose:** Build the domain-specific mistake class and success pattern registries.

**Engine:** Internal reasoning using Stage 1-4 outputs

**Inputs:**
- `failure_signals` from Stage 1
- `high_rpn_failures` from Stage 4
- `quality_signals` from Stage 1
- `dok_calibration` from Stage 3
- `expert_lenses` from Stage 2

**Process:**

#### 5A: Mistake Class Generation
1. Reserve ME-{ABBREV}-001 for DOK_MISMATCH (always first)
2. For each high-RPN failure mode: generate a corresponding mistake class
3. For each failure signal from Stage 1: generate a mistake class if not already covered
4. Assign severities:
   - S4_CRITICAL: output causes direct harm or completely wrong output ships
   - S3_HIGH: output is significantly degraded, FORGE must block
   - S2_MED: output is below standard, FORGE should flag
   - S1_LOW: quality issue, FORGE notes but does not block
5. Write detection signal (how FORGE or pre-action check catches this)
6. Write recovery protocol (what to do when caught)
7. Pre-assign `linked_success` field (pair each mistake with its success twin where possible)

#### 5B: Success Pattern Generation
1. For each mistake class: generate at least one paired success pattern
2. For each quality signal from Stage 1: generate a success pattern
3. For each expert lens insight: generate a success pattern where applicable
4. Write protocol (minimum 2 steps each)
5. Cite research basis where available (from Stage 1 sources)
6. Pre-assign `linked_mistake` field

**Naming convention:**
- Domain abbreviation: 2-6 uppercase chars derived from domain slug
  - `instructional_design` → `TEACH`
  - `python_engineering` → `PY`
  - `educational_assessment` → `ASMT`
  - `product_design` → `PROD`
  - Ambiguous: use first 4 chars of cartridge_id
- Numbering: sequential from 001, no gaps

**Outputs:**
- `mistake_classes` list (conformant with CARTRIDGE_SPEC Section 4.6)
- `success_patterns` list (conformant with CARTRIDGE_SPEC Section 4.7)

**Failure modes:**
- FG-S5-001: Fewer than 3 mistake classes generated → insufficient domain analysis, return to Stage 4
- FG-S5-002: Fewer than 2 success patterns generated → insufficient quality signals, return to Stage 1
- FG-S5-003: No linked_success/linked_mistake pairs at all → negative framing violation, must pair at least 50%

**Stage gate:** Minimum 3 mistake classes, 2 success patterns, ≥50% paired.

---

### STAGE 6: RUBRIC_GENERATION

**Purpose:** Build the FORGE quality rubric for this domain.

**Engine:** Internal reasoning using all prior stage outputs

**Inputs:**
- `quality_signals` from Stage 1
- `expert_lenses` from Stage 2 (especially Proof, Big Idea)
- `dok_calibration` from Stage 3
- `mistake_classes` from Stage 5 (S4_CRITICAL entries → F-tier signals)
- `success_patterns` from Stage 5 (S-tier signals)

**Process:**
1. Identify 5-10 quality dimensions from quality_signals and expert lenses
2. For each dimension:
   a. Write a criterion ID (`{ABBREV}-R{nn}`, two-digit)
   b. Name it (SCREAMING_SNAKE_CASE)
   c. Describe what it evaluates
   d. Assign weight (all weights must sum to 1.0)
   e. Write S-tier signal (what world-class looks like for this criterion)
   f. Write F-tier signal (what hard failure looks like — must connect to a mistake class or FMEA entry)
3. Write scoring tier descriptions (S/A/B/C/F) for this domain
4. Set `forge_block_threshold`:
   - Domains where bad output causes harm (teaching, medical, legal): `C`
   - Domains where bad output is recoverable: `F`
5. Set `rubric_id` = `RUBRIC_{CARTRIDGE_ID}`

**Weight allocation guidance:**
- No single criterion should exceed 0.30
- No criterion should be below 0.05 (too low = not really a criterion)
- Weights reflect domain priorities (a teaching rubric weights DOK alignment heavily)

**Outputs:**
- `quality_rubric` block (conformant with CARTRIDGE_SPEC Section 4.5)

**Failure modes:**
- FG-S6-001: Weights do not sum to 1.0 → SPEC_GATE V-007 will catch, must fix before Stage 7
- FG-S6-002: Fewer than 5 criteria → insufficient rubric, return to Stage 1 for more quality signals
- FG-S6-003: F-tier signal not connected to any mistake class or FMEA entry → arbitrary rubric, must link

**Stage gate:** ≥5 criteria, weights sum to 1.0 ±0.001, all F-tier signals linked.

---

### STAGE 7: CARTRIDGE_ASSEMBLY

**Purpose:** Assemble all stage outputs into a valid cartridge, run SPEC_GATE, run FORGE, register.

**Engine:** SPEC_GATE validator + FORGE (under PYTHON_CODE_QUALITY cartridge)

**Inputs:** All outputs from Stages 1-6

**Process:**

#### 7A: Schema Assembly
1. Build complete cartridge JSON from all stage outputs
2. Populate identity fields: cartridge_id, version, spec_version, domain, subdomain, envelope, status=DRAFT
3. Set timestamps: created_at, updated_at = now
4. Compute SHA-256: serialize JSON with sha256="" → hash → set sha256 field
5. Write to `CARTRIDGE_REGISTRY/{CARTRIDGE_ID}/{CARTRIDGE_ID}.cartridge.json`

#### 7B: SPEC_GATE Validation
Run all 20 validation rules from CARTRIDGE_SPEC Section 5.
If any rule fails:
- Collect all violations
- Return output with status=FAILED, spec_gate_result.passed=false, violations listed
- Do NOT proceed to FORGE
- Do NOT write cartridge as ACTIVE

If all rules pass: proceed to 7C.

#### 7C: FORGE Scoring
Load PYTHON_CODE_QUALITY cartridge (meta-cartridge).
Score the assembled cartridge JSON against RUBRIC_PYTHON_CODE_QUALITY:
- Is schema complete and valid? (CDR V1: purpose stated)
- Are all contracts declared? (CDR V5: inputs/outputs declared)
- Are failure modes present? (CDR V4: FMEA present)
- Are IDs consistent and non-duplicated? (CDR V3: no duplication)
- Are weights mathematically correct? (CDR V2: evidence of correctness)

FORGE result determines cartridge status:
- S or A tier → status = ACTIVE
- B tier → status = DRAFT (shippable but needs polish, human review recommended)
- C or F tier → status = DRAFT (do not activate without human review + fixes)

#### 7D: Registry Write
Write cartridge to CARTRIDGE_REGISTRY with final status.
Write COEVOLUTION_LOG entry:
```json
{
  "entry_id": "COEV-{next}",
  "type": "CARTRIDGE_GENERATED",
  "cartridge_id": "<id>",
  "forge_score": "<tier>",
  "spec_gate_passed": true,
  "session_id": "<from input>",
  "atoms_generated": "<count>",
  "timestamp": "<ISO 8601>"
}
```

**Outputs:** Final USB-1.0 output envelope (see Section 2)

**Failure modes:**
- FG-S7-001: SPEC_GATE violations → return FAILED, list all violations
- FG-S7-002: FORGE returns F-tier → return DRAFT, flag for immediate human review
- FG-S7-003: Registry write fails → return FAILED, do not log partial state
- FG-S7-004: SHA-256 mismatch on re-verification → abort, corrupted assembly

**Stage gate:** SPEC_GATE passed + FORGE scored + registry written + COEV logged.

---

## 5. EXECUTION STATE MACHINE

```
IDLE
  → (input received, validated) → STAGE_1_RESEARCH
  → (stage 1 gate passed) → STAGE_2_LENSES
  → (stage 2 gate passed) → STAGE_3_DOK
  → (stage 3 gate passed) → STAGE_4_FMEA
  → (stage 4 gate passed) → STAGE_5_PATTERNS
  → (stage 5 gate passed) → STAGE_6_RUBRIC
  → (stage 6 gate passed) → STAGE_7_ASSEMBLY
  → (SPEC_GATE passed + FORGE scored) → COMPLETE
  → (any stage gate failure) → FAILED
  → (SPEC_GATE violations) → FAILED
```

No forward progress without passing the stage gate.
No backward looping allowed (prevents infinite retry — use ERAC-003 if stuck).
On FAILED: return full error report, do not silently degrade.

---

## 6. GENERATOR FAILURE MODES (FG codes)

| ID | Stage | Description | Severity |
|----|-------|-------------|----------|
| FG-S1-001 | 1 | WEB_SEE_ENGINE returns zero results | S4_CRITICAL |
| FG-S1-002 | 1 | Domain too vague for queries | S3_HIGH |
| FG-S1-003 | 1 | Only low-quality sources found | S2_MED |
| FG-S2-001 | 2 | Cannot identify Big Idea | S3_HIGH |
| FG-S2-002 | 2 | Ethics null in high-stakes domain | S3_HIGH |
| FG-S3-001 | 3 | No DOK gradient in domain | S1_LOW |
| FG-S3-002 | 3 | Requested DOK inconsistent | S2_MED |
| FG-S4-001 | 4 | Fewer than 3 FMEA entries | S3_HIGH |
| FG-S4-002 | 4 | RPN > 100 without mitigation | S4_CRITICAL |
| FG-S5-001 | 5 | Fewer than 3 mistake classes | S3_HIGH |
| FG-S5-002 | 5 | Fewer than 2 success patterns | S3_HIGH |
| FG-S5-003 | 5 | No paired mistake/success | S2_MED |
| FG-S6-001 | 6 | Weights don't sum to 1.0 | S4_CRITICAL |
| FG-S6-002 | 6 | Fewer than 5 rubric criteria | S3_HIGH |
| FG-S6-003 | 6 | F-tier signal unlinked | S2_MED |
| FG-S7-001 | 7 | SPEC_GATE violations | S4_CRITICAL |
| FG-S7-002 | 7 | FORGE F-tier result | S3_HIGH |
| FG-S7-003 | 7 | Registry write failure | S4_CRITICAL |
| FG-S7-004 | 7 | SHA-256 mismatch | S4_CRITICAL |

---

## 7. THE META-CARTRIDGE CONSTRAINT

CARTRIDGE_GENERATOR always runs under PYTHON_CODE_QUALITY cartridge governance.

This means:
- Every cartridge JSON produced is a code artifact
- FORGE scores it against RUBRIC_PYTHON before it ships
- CDR principles apply to the cartridge schema itself:
  - CDR V1: purpose stated (cartridge has domain + description)
  - CDR V2: evidence present (sources in provenance, FMEA RPN math checks out)
  - CDR V3: no duplication (no duplicate IDs)
  - CDR V4: failure modes named (FMEA section populated)
  - CDR V5: contracts declared (USB envelope present)

This cannot be disabled.
A cartridge that generates cartridges without self-governing its own output
is the definition of ME-CODE-001 (code without contracts).

---

## 8. INCREMENTAL UPDATE MODE

For existing ACTIVE cartridges, CARTRIDGE_GENERATOR supports update mode.

**Trigger:** cartridge_id provided in input + cartridge already in registry

**Update process:**
1. Load existing cartridge
2. Run only the stages needed for the update type:
   - New research → Stage 1 only, then merge atoms
   - New mistake class → Stage 5 only (with context from existing)
   - Rubric adjustment → Stage 6 only
   - Full rebuild → all 7 stages
3. Increment version (MINOR for additions, PATCH for corrections)
4. Re-run SPEC_GATE + FORGE on full updated cartridge
5. If passes: new version ACTIVE, old version DEPRECATED
6. Log COEVOLUTION_LOG entry with diff summary

---

## 9. WHAT DERIVES FROM THIS SPEC

| Component | Derives From |
|-----------|-------------|
| CARTRIDGE_GENERATOR.py | Sections 3-7 (implementation target) |
| CARTRIDGE_REGISTRY_SPEC | Section 7D (registry write contract) |
| WEB_SEE_ENGINE integration | Section 4, Stage 1 |
| FORGE rubric loader | Section 7C (meta-cartridge constraint) |
| COEVOLUTION_LOG schema | Section 7D (log entry format) |
| SPEC_GATE validator | CARTRIDGE_SPEC Section 5 (called in Stage 7B) |

---

## 10. ACCEPTANCE CRITERIA

CARTRIDGE_GENERATOR is complete when:

- [ ] All 7 stages execute in order with no skips
- [ ] All stage gates enforced (pipeline halts on failure, does not degrade silently)
- [ ] USB-1.0 envelope honored (input validated, output structured)
- [ ] SPEC_GATE called in Stage 7B with all 20 rules
- [ ] FORGE called in Stage 7C under PYTHON_CODE_QUALITY cartridge
- [ ] All 19 FG failure codes handled and returned (not swallowed)
- [ ] COEVOLUTION_LOG entry written on every completion (SUCCESS or FAILED)
- [ ] Incremental update mode functional (version bump + deprecation)
- [ ] SHA-256 computed and verified

---

## 11. CHANGE LOG

| Version | Date | Change |
|---------|------|--------|
| 1.0 | 2026-03-22 | Initial locked spec |

---

## SPEC_GATE DECLARATION

This document is LOCKED at v1.0.
No CARTRIDGE_GENERATOR code may be written without conforming to this spec.
Changes require MINOR version bump minimum.
Breaking changes to the 7-stage pipeline require MAJOR bump and human review.
