# CARTRIDGE_SPEC.md
# MetaBlooms OS v11 — Canonical Cartridge Schema
# Version: 1.0
# Status: LOCKED
# SPEC_GATE: No cartridge may be generated, loaded, or validated without conforming to this spec.
# Last updated: COEV-session (post-COEV-062)

---

## 1. PURPOSE

A cartridge is a self-contained domain package that tells MetaBlooms OS:
- What this domain KNOWS (domain knowledge graph atoms + links)
- What this domain VALUES (quality rubric, success criteria)
- What this domain PRODUCES (artifact types and output schemas)
- What experts in this domain LOOK LIKE (Kaplan expert lenses applied)
- What failures look like (domain-prefixed mistake classes)
- What mastery looks like (domain-prefixed success patterns)

A cartridge does NOT replace the OS.
The OS governs HOW the LLM thinks.
The cartridge defines WHAT domain it operates in.
All Four Laws, STOP, BTS, ERAC, MPP, FORGE still apply.
The cartridge only changes what FORGE scores against and which domain registries load.

---

## 2. CARTRIDGE FILE FORMAT

File:     `{CARTRIDGE_ID}.cartridge.json`
Location: `CARTRIDGE_REGISTRY/{CARTRIDGE_ID}/`
Encoding: UTF-8
Schema:   This document (CARTRIDGE_SPEC v1.0)

---

## 3. TOP-LEVEL SCHEMA

```json
{
  "cartridge_id":   "<string: SCREAMING_SNAKE_CASE, unique, permanent>",
  "version":        "<string: semver, e.g. '1.0.0'>",
  "spec_version":   "CARTRIDGE_SPEC-1.0",
  "domain":         "<string: primary domain slug, e.g. 'instructional_design'>",
  "subdomain":      "<string: optional refinement, e.g. 'html_css_interactive'>",
  "envelope":       "USB-1.0",
  "status":         "<enum: DRAFT | ACTIVE | DEPRECATED>",
  "created_at":     "<ISO 8601 datetime>",
  "updated_at":     "<ISO 8601 datetime>",
  "sha256":         "<string: SHA-256 of canonical JSON with sha256 field set to empty string>",

  "provenance":     { ... },
  "domain_knowledge": { ... },
  "expert_lenses":  { ... },
  "quality_rubric": { ... },
  "mistake_classes": [ ... ],
  "success_patterns": [ ... ],
  "artifact_types": [ ... ],
  "domain_stages":  [ ... ],
  "composition":    { ... },
  "forge_config":   { ... },
  "research_queries": [ ... ],
  "fmea":           [ ... ],
  "dok_calibration": { ... },
  "mpp_override":   null
}
```

ALL top-level fields are REQUIRED unless marked OPTIONAL.
A cartridge missing any required field FAILS SPEC_GATE and is rejected.

---

## 4. FIELD DEFINITIONS

### 4.1 IDENTITY FIELDS

#### `cartridge_id`
- Type: string
- Format: SCREAMING_SNAKE_CASE
- Constraints: unique across registry, permanent (never reused after deprecation)
- Examples: `PYTHON_CODE_QUALITY`, `WORLD_CLASS_TEACHING_HTML`, `STAAR_ASSESSMENT_DESIGN`

#### `version`
- Type: string
- Format: semver (MAJOR.MINOR.PATCH)
- MAJOR: breaking schema change
- MINOR: new mistake classes, success patterns, rubric criteria added
- PATCH: corrections, wording fixes, research additions

#### `spec_version`
- Type: string
- Value: must be exactly `"CARTRIDGE_SPEC-1.0"` for cartridges conforming to this spec
- Purpose: CARTRIDGE_GENERATOR uses this to validate against the correct spec version

#### `domain`
- Type: string
- Format: lowercase_snake_case
- Examples: `instructional_design`, `python_engineering`, `educational_assessment`, `product_design`

#### `subdomain`
- Type: string | null
- OPTIONAL
- Format: lowercase_snake_case
- Examples: `html_css_interactive`, `3rd_grade_bilingual`, `staar_math`

#### `envelope`
- Type: string
- Value: must be exactly `"USB-1.0"`
- Purpose: declares this cartridge conforms to the USB-1.0 I/O contract

#### `status`
- Type: enum
- Values:
  - `DRAFT`: generated, not yet validated by FORGE
  - `ACTIVE`: validated, registered, available for loading
  - `DEPRECATED`: superseded, not loadable (preserved for audit)

#### `created_at`, `updated_at`
- Type: ISO 8601 datetime string
- Example: `"2026-03-22T14:00:00Z"`

#### `sha256`
- Type: string
- Computed: SHA-256 of the canonical JSON with `sha256` field set to `""`
- Purpose: integrity verification at load time

---

### 4.2 PROVENANCE

```json
"provenance": {
  "generated_by": "<enum: CARTRIDGE_GENERATOR | HUMAN | HYBRID>",
  "generator_version": "<string: version of CARTRIDGE_GENERATOR used, or null>",
  "research_session_id": "<string: COEV log entry ID, or null>",
  "research_sources": ["<url or title>", ...],
  "human_author": "<string: name, or null if fully generated>",
  "review_status": "<enum: UNREVIEWED | REVIEWED | CERTIFIED>",
  "notes": "<string: free text, OPTIONAL>"
}
```

- `generated_by`: REQUIRED
- `research_sources`: REQUIRED (may be empty list `[]` if HUMAN-authored)
- `review_status`: REQUIRED
- All other fields: OPTIONAL (null if not applicable)

---

### 4.3 DOMAIN KNOWLEDGE

```json
"domain_knowledge": {
  "source": "<string: description of how knowledge was acquired>",
  "knowledge_db": "<string: filename of SQLite knowledge DB, or null>",
  "atoms": "<integer: count of knowledge atoms, 0 if not yet built>",
  "links": "<integer: count of knowledge links, 0 if not yet built>",
  "rebuild_at_boot": "<boolean: true means DB is regenerated each session>",
  "last_rebuilt": "<ISO 8601 datetime | null>",
  "summary": "<string: 1-3 sentence plain-language description of what the DB contains>"
}
```

- All fields REQUIRED.
- `atoms` and `links` may be 0 for DRAFT cartridges (populated after first boot).
- `rebuild_at_boot: true` is the default for all generated cartridges (no DB shipped).

---

### 4.4 EXPERT LENSES (Kaplan D&C Framework)

All 11 Kaplan lenses REQUIRED. Null is acceptable only for lenses that genuinely do not apply.

```json
"expert_lenses": {
  "language_of_discipline": ["<term>", ...],
  "big_idea": "<string: the central organizing principle of this domain>",
  "unanswered_questions": ["<string>", ...],
  "ethics": "<string: ethical obligations specific to this domain>",
  "patterns": "<string: recurring patterns experts recognize in this domain>",
  "change_over_time": "<string: how this domain evolves>",
  "across_disciplines": ["<string: related domain>", ...],
  "multiple_perspectives": "<string: who disagrees and why in this domain>",
  "details_vs_big_picture": "<string: when to zoom in vs zoom out>",
  "rules_vs_exceptions": "<string: what the rules are and where they break>",
  "proof": "<string: what counts as evidence of quality in this domain>"
}
```

`language_of_discipline`: minimum 5 terms.
`unanswered_questions`: minimum 2 questions that the system must answer before acting.
`across_disciplines`: minimum 2 related domains.

---

### 4.5 QUALITY RUBRIC

```json
"quality_rubric": {
  "rubric_id": "<string: RUBRIC_{CARTRIDGE_ID}>",
  "scoring_tiers": {
    "S": "<string: description of S-tier (world class)>",
    "A": "<string: description of A-tier (solid, shippable)>",
    "B": "<string: description of B-tier (acceptable, needs polish)>",
    "C": "<string: description of C-tier (below standard, do not ship)>",
    "F": "<string: description of F-tier (fail, FORGE blocks output)>"
  },
  "forge_block_threshold": "<enum: C | F>",
  "criteria": [
    {
      "id": "<string: {DOMAIN_PREFIX}-R{nn}>",
      "name": "<string: SCREAMING_SNAKE_CASE>",
      "description": "<string: what this criterion evaluates>",
      "weight": "<float: 0.0 to 1.0, all weights must sum to 1.0>",
      "s_tier_signal": "<string: what S-tier looks like for this criterion>",
      "f_tier_signal": "<string: what F-tier (hard fail) looks like>"
    }
  ]
}
```

- `rubric_id`: REQUIRED, must follow pattern `RUBRIC_{CARTRIDGE_ID}`
- `criteria`: REQUIRED, minimum 5 criteria
- `weight`: all criterion weights must sum to exactly 1.0 (validated by SPEC_GATE)
- `forge_block_threshold`: C means C and below are blocked. F means only F is blocked.
- `s_tier_signal` and `f_tier_signal`: REQUIRED on every criterion (used by FORGE scoring logic)

---

### 4.6 MISTAKE CLASSES

```json
"mistake_classes": [
  {
    "id": "<string: ME-{DOMAIN_ABBREV}-{nnn}>",
    "name": "<string: SCREAMING_SNAKE_CASE>",
    "description": "<string: what this mistake is>",
    "severity": "<enum: S1_LOW | S2_MED | S3_HIGH | S4_CRITICAL>",
    "detection": "<string: how to detect this mistake>",
    "recovery": "<string: what to do when this mistake is caught>",
    "linked_success": "<string: MS-{DOMAIN_ABBREV}-{nnn} ID of paired success pattern, or null>"
  }
]
```

- Minimum 3 mistake classes per cartridge.
- S4_CRITICAL mistakes are hard blocks — FORGE refuses output.
- S3_HIGH mistakes trigger mandatory FORGE pass before output.
- `linked_success`: strongly preferred (promotes paired positive/negative framing).
- ID format enforced: `ME-` prefix, domain abbreviation (2-6 chars), 3-digit number.

---

### 4.7 SUCCESS PATTERNS

```json
"success_patterns": [
  {
    "id": "<string: MS-{DOMAIN_ABBREV}-{nnn}>",
    "name": "<string: SCREAMING_SNAKE_CASE>",
    "description": "<string: what this pattern achieves>",
    "protocol": ["<step 1>", "<step 2>", ...],
    "research_basis": "<string: paper/framework/source this is grounded in, or null>",
    "linked_mistake": "<string: ME-{DOMAIN_ABBREV}-{nnn} ID, or null>"
  }
]
```

- Minimum 2 success patterns per cartridge.
- Target ratio: at least 1 success pattern per 2 mistake classes.
- `protocol`: minimum 2 steps.
- `research_basis`: strongly preferred, null only if domain is entirely novel.

---

### 4.8 ARTIFACT TYPES

```json
"artifact_types": [
  {
    "type_id": "<string: SCREAMING_SNAKE_CASE>",
    "description": "<string: what this artifact is>",
    "file_extensions": ["<string>", ...],
    "schema_ref": "<string: path to schema file, or null>",
    "forge_rubric": "<string: rubric_id to score this artifact type against>"
  }
]
```

- Minimum 1 artifact type per cartridge.
- `forge_rubric`: must reference a valid rubric — either this cartridge's rubric or a named external rubric.
- `file_extensions`: e.g. `[".html", ".css"]`, `[".py"]`, `[".json"]`

---

### 4.9 DOMAIN STAGES

OPTIONAL. Null or empty list means the cartridge uses the standard 19-stage MPP.

```json
"domain_stages": [
  {
    "stage_id": "<integer: 1-based>",
    "name": "<string: SCREAMING_SNAKE_CASE>",
    "description": "<string>",
    "required": "<boolean>",
    "maps_to_mpp": "<integer | null: standard MPP stage this overrides>"
  }
]
```

- If provided, domain_stages extend or override MPP stages, they do not replace governance.
- `maps_to_mpp`: null means this is a domain-specific insertion between MPP stages.

---

### 4.10 COMPOSITION

```json
"composition": {
  "compatible_with": ["<CARTRIDGE_ID>", ...],
  "incompatible_with": ["<CARTRIDGE_ID>", ...],
  "requires": ["<CARTRIDGE_ID>", ...],
  "conflict_resolution": "<enum: MERGE_RUBRICS | PRIMARY_WINS | FAIL_ON_CONFLICT>"
}
```

- `compatible_with`: cartridges that can be loaded simultaneously. OPTIONAL (empty list = unknown).
- `incompatible_with`: cartridges that CANNOT be loaded simultaneously. OPTIONAL.
- `requires`: cartridges that MUST be loaded for this cartridge to function. OPTIONAL.
- `conflict_resolution`: what happens when two loaded cartridges have conflicting mistake classes on the same ID.
  - `MERGE_RUBRICS`: combine all rubric criteria, score against all
  - `PRIMARY_WINS`: first-loaded cartridge's definition wins
  - `FAIL_ON_CONFLICT`: SPEC_GATE rejects the combination

---

### 4.11 FORGE CONFIGURATION

```json
"forge_config": {
  "engine": "<string: FORGE engine filename, e.g. 'FORGE_TEACHING_HTML.py'>",
  "min_passes": "<integer: minimum FORGE passes required before output>",
  "s_tier_required": "<boolean: true means only S-tier output is accepted>",
  "distill_on_success": "<boolean: true means SUCCESS_DISTILL fires on S-tier>",
  "distill_on_failure": "<boolean: true means MISTAKE_DISTILL fires on C/F-tier>"
}
```

- All fields REQUIRED.
- `engine`: if null, uses base FORGE.py with this cartridge's rubric loaded.
- `min_passes`: minimum 1.
- `distill_on_success` and `distill_on_failure`: both should default to true.

---

### 4.12 RESEARCH QUERIES

```json
"research_queries": ["<string>", ...]
```

- Type: list of strings
- Minimum: 3 queries
- Purpose: WEB_SEE_ENGINE uses these to rebuild the knowledge DB at boot
- Should cover: domain fundamentals, quality signals, failure patterns, expert sources
- Format: natural language search queries (not URLs)

---

### 4.13 FMEA (Failure Mode and Effects Analysis)

```json
"fmea": [
  {
    "failure_mode": "<string: what could go wrong>",
    "effect": "<string: consequence of this failure>",
    "severity": "<integer: 1-10>",
    "likelihood": "<integer: 1-10>",
    "detectability": "<integer: 1-10>",
    "rpn": "<integer: severity × likelihood × detectability, computed>",
    "mitigation": "<string: how MetaBlooms prevents or catches this>"
  }
]
```

- Minimum 3 failure modes per cartridge.
- `rpn` (Risk Priority Number): computed field, validated by SPEC_GATE (must equal S×L×D).
- Failure modes with RPN > 100 MUST have a mitigation mapped to a named mistake class or ERAC code.
- This is the research layer that makes mistake classes non-arbitrary.

---

### 4.14 DOK CALIBRATION

```json
"dok_calibration": {
  "target_dok": "<integer: 1-4>",
  "dok_descriptors": {
    "1": "<string: what DOK1 looks like in this domain>",
    "2": "<string: what DOK2 looks like in this domain>",
    "3": "<string: what DOK3 looks like in this domain>",
    "4": "<string: what DOK4 looks like in this domain>"
  },
  "default_learner_dok": "<integer: 1-4 | null>",
  "dok_mismatch_class": "<string: mistake class ID for DOK mismatch, e.g. ME-TEACH-001>"
}
```

- `target_dok`: the DOK level the cartridge is designed to produce output AT.
- `default_learner_dok`: the assumed incoming DOK level of the end user (null if not applicable).
- `dok_mismatch_class`: the mistake class ID that fires when DOK level is wrong.

---

### 4.15 MPP OVERRIDE

```json
"mpp_override": null
```

- Type: null | object
- Default: null (use standard 19-stage MPP)
- If non-null: must specify which MPP stages are overridden and why (advanced use only)
- SPEC_GATE flags any non-null mpp_override for human review before activation

---

## 5. VALIDATION RULES (enforced by SPEC_GATE)

| Rule | Description |
|------|-------------|
| V-001 | All required fields present |
| V-002 | `cartridge_id` is SCREAMING_SNAKE_CASE |
| V-003 | `version` is valid semver |
| V-004 | `spec_version` == "CARTRIDGE_SPEC-1.0" |
| V-005 | `envelope` == "USB-1.0" |
| V-006 | `sha256` matches computed hash |
| V-007 | All rubric criterion weights sum to 1.0 (±0.001 tolerance) |
| V-008 | All mistake class IDs follow `ME-{ABBREV}-{nnn}` format |
| V-009 | All success pattern IDs follow `MS-{ABBREV}-{nnn}` format |
| V-010 | All rubric criterion IDs follow `{PREFIX}-R{nn}` format |
| V-011 | FMEA RPN == severity × likelihood × detectability for every entry |
| V-012 | FMEA entries with RPN > 100 have mitigation referencing a named class |
| V-013 | `forge_config.engine` exists in filesystem OR is null |
| V-014 | Minimum counts met: 3+ mistake classes, 2+ success patterns, 5+ rubric criteria, 3+ research queries, 3+ FMEA entries, 5+ expert lens terms |
| V-015 | `composition.conflict_resolution` is a valid enum value |
| V-016 | `status` is a valid enum value |
| V-017 | `dok_calibration.target_dok` is 1, 2, 3, or 4 |
| V-018 | No circular `composition.requires` dependencies |
| V-019 | `mpp_override` non-null entries flagged for human review |
| V-020 | `linked_success` and `linked_mistake` cross-references resolve to existing IDs |

---

## 6. CARTRIDGE LIFECYCLE

```
DRAFT
  → (SPEC_GATE validation) → ACTIVE
  → (superseded by new version) → DEPRECATED
```

- DRAFT cartridges may be loaded in dev sessions only.
- ACTIVE cartridges are available to all sessions.
- DEPRECATED cartridges are preserved in registry but not loadable.
- Version bump: ACTIVE → new version DRAFT → new ACTIVE. Old version → DEPRECATED.

---

## 7. META-CARTRIDGE RULE

The `PYTHON_CODE_QUALITY` cartridge is the meta-cartridge.
It runs INSIDE every cartridge generation session.
When CARTRIDGE_GENERATOR builds a new cartridge:
  - The cartridge JSON is scored against RUBRIC_PYTHON_CODE_QUALITY before it is written
  - A cartridge that does not pass RUBRIC_PYTHON is DRAFT, not ACTIVE
  - FORGE must return A-tier or better on the cartridge JSON itself before status → ACTIVE

This means: every cartridge is a quality-gated artifact.
The code quality cartridge enforces quality on every other cartridge.

---

## 8. EXAMPLE: MINIMAL VALID CARTRIDGE

See: `CARTRIDGE_REGISTRY/PYTHON_CODE_QUALITY/PYTHON_CODE_QUALITY.cartridge.json`
This is the reference implementation. All new cartridges are validated against the pattern it sets.

---

## 9. WHAT DERIVES FROM THIS SPEC

| Component | Derives From |
|-----------|-------------|
| CARTRIDGE_GENERATOR | Sections 3-7 (builds to this schema) |
| CARTRIDGE_REGISTRY | Section 3 (stores by cartridge_id), Section 6 (lifecycle) |
| SPEC_GATE validator | Section 5 (all 20 validation rules) |
| FORGE rubric loader | Section 4.5 (quality_rubric) |
| Pre-action check | Sections 4.6, 4.7 (mistake + success loading) |
| BTS deliberation | Section 4.4 (expert lenses loaded as context) |
| DISTILLATION_ENGINE | Section 4.11 (distill_on_success, distill_on_failure) |
| COEVOLUTION_LOG | Section 4.2 (research_session_id links log to cartridge) |

---

## 10. CHANGE LOG

| Version | Date | Change |
|---------|------|--------|
| 1.0 | 2026-03-22 | Initial locked spec |

---

## SPEC_GATE DECLARATION

This document is LOCKED at v1.0.
No cartridge may be generated or loaded without conforming to this spec.
No CARTRIDGE_GENERATOR may ship without validating against Section 5.
Changes to this spec require a MAJOR version bump and human review.

SHA-256: [computed at lock time]
