# CARTRIDGE_REGISTRY_SPEC.md
# MetaBlooms OS v11 — Cartridge Registry Specification
# Version: 1.0
# Status: LOCKED
# Depends on: CARTRIDGE_SPEC-1.0, CARTRIDGE_GENERATOR_SPEC-1.0, USB-1.0
# SPEC_GATE: No registry read, write, or load operation may occur outside this contract.
# Last updated: COEV-session (post-COEV-062)

---

## 1. PURPOSE

CARTRIDGE_REGISTRY is the authoritative store for all cartridges in MetaBlooms OS.

It is responsible for:
- **Storage**: persisting cartridge files by cartridge_id
- **Lookup**: resolving a domain request or cartridge_id to a cartridge file
- **Load**: reading a cartridge into session context for active use
- **Composition**: managing multiple simultaneously loaded cartridges
- **Conflict resolution**: handling collisions between loaded cartridges
- **Lifecycle**: enforcing DRAFT → ACTIVE → DEPRECATED transitions
- **Integrity**: verifying SHA-256 on every load

It is NOT responsible for:
- Generating cartridges (CARTRIDGE_GENERATOR does that)
- Scoring cartridges (FORGE does that)
- Validating cartridge schema (SPEC_GATE does that)
- Executing domain logic (the OS + active cartridge does that)

---

## 2. FILESYSTEM LAYOUT

```
CARTRIDGE_REGISTRY/
  REGISTRY_INDEX.json                    ← master index of all cartridges
  REGISTRY_LOCK.json                     ← currently loaded cartridges this session
  PYTHON_CODE_QUALITY/
    PYTHON_CODE_QUALITY.cartridge.json   ← reference implementation (always present)
  WORLD_CLASS_TEACHING_HTML/
    WORLD_CLASS_TEACHING_HTML.cartridge.json
  STAAR_ASSESSMENT_DESIGN/
    STAAR_ASSESSMENT_DESIGN.cartridge.json
  {CARTRIDGE_ID}/
    {CARTRIDGE_ID}.cartridge.json
    {CARTRIDGE_ID}.v1.0.0.cartridge.json  ← version archive (DEPRECATED copies)
```

Rules:
- Each cartridge lives in its own directory named exactly `{CARTRIDGE_ID}`
- The live file is always `{CARTRIDGE_ID}.cartridge.json` (no version in filename)
- Deprecated versions are archived as `{CARTRIDGE_ID}.v{semver}.cartridge.json`
- No cartridge file may exist outside its named directory
- REGISTRY_INDEX.json is the single source of truth for what is registered

---

## 3. REGISTRY_INDEX.json SCHEMA

```json
{
  "registry_version": "1.0",
  "last_updated": "<ISO 8601 datetime>",
  "total_cartridges": "<integer>",
  "cartridges": {
    "<CARTRIDGE_ID>": {
      "cartridge_id": "<string>",
      "version": "<string: semver>",
      "domain": "<string>",
      "subdomain": "<string | null>",
      "status": "<enum: DRAFT | ACTIVE | DEPRECATED>",
      "path": "<string: relative path to .cartridge.json>",
      "sha256": "<string>",
      "created_at": "<ISO 8601>",
      "updated_at": "<ISO 8601>",
      "forge_score": "<enum: S | A | B | C | F | UNSCORED>",
      "tags": ["<string>", ...]
    }
  }
}
```

- `tags`: optional domain taxonomy for lookup (e.g. `["teaching", "html", "bilingual"]`)
- `forge_score`: last recorded FORGE score from CARTRIDGE_GENERATOR or manual scoring
- `path`: always relative to CARTRIDGE_REGISTRY root

REGISTRY_INDEX.json is rebuilt by `registry_rebuild()` if corrupted.
It is the lookup table — the cartridge files are the source of truth.

---

## 4. REGISTRY_LOCK.json SCHEMA

Tracks what is loaded in the current session.

```json
{
  "session_id": "<string>",
  "locked_at": "<ISO 8601>",
  "primary_cartridge": "<CARTRIDGE_ID | null>",
  "loaded_cartridges": [
    {
      "cartridge_id": "<string>",
      "load_order": "<integer: 1-based, determines PRIMARY_WINS priority>",
      "load_reason": "<string: why this cartridge was loaded>",
      "sha256_verified": "<boolean>"
    }
  ],
  "composite_rubric": "<string: COMPOSITE | {CARTRIDGE_ID} | null>",
  "active_mistake_classes": "<integer: total count across all loaded cartridges>",
  "active_success_patterns": "<integer: total count across all loaded cartridges>"
}
```

- `primary_cartridge`: the cartridge whose conflict_resolution strategy takes precedence
- `load_order`: determines priority in PRIMARY_WINS conflict resolution (1 = highest priority)
- `composite_rubric`: COMPOSITE if multiple cartridges loaded with MERGE_RUBRICS

REGISTRY_LOCK.json is written on first cartridge load, updated on each subsequent load,
and cleared (reset to empty) at session end.

---

## 5. USB-1.0 ENVELOPE — REGISTRY OPERATIONS

All registry operations conform to USB-1.0. Each operation is a discrete call
with defined input, output, and failure mode.

### 5.1 REGISTRY_WRITE

Write a new or updated cartridge to the registry.
Called by CARTRIDGE_GENERATOR Stage 7D only.

**Input:**
```json
{
  "operation": "REGISTRY_WRITE",
  "cartridge_id": "<string>",
  "cartridge_data": { ... },
  "forge_score": "<enum: S | A | B | C | F>",
  "overwrite": "<boolean: true for updates, false for new>"
}
```

**Process:**
1. Verify `overwrite` matches registry state (false = must not exist, true = must exist)
2. Validate SHA-256 of cartridge_data
3. If `overwrite=true`: archive existing file as versioned copy
4. Write `{CARTRIDGE_ID}.cartridge.json` to `CARTRIDGE_REGISTRY/{CARTRIDGE_ID}/`
5. Update REGISTRY_INDEX.json entry
6. Return output

**Output:**
```json
{
  "operation": "REGISTRY_WRITE",
  "status": "<enum: SUCCESS | FAILED>",
  "cartridge_id": "<string>",
  "path": "<string>",
  "error": "<string | null>"
}
```

**Failure modes:**
- RR-W-001: `overwrite=false` but cartridge already exists → FAILED
- RR-W-002: `overwrite=true` but cartridge does not exist → FAILED
- RR-W-003: SHA-256 mismatch → FAILED, do not write
- RR-W-004: Filesystem write error → FAILED, do not update INDEX

---

### 5.2 REGISTRY_LOOKUP

Resolve a domain request or cartridge_id to a registered cartridge entry.

**Input:**
```json
{
  "operation": "REGISTRY_LOOKUP",
  "query": "<string: cartridge_id OR domain slug OR natural language domain description>",
  "status_filter": "<enum: ACTIVE | DRAFT | ANY>"
}
```

**Process:**
1. Exact match: check if query == cartridge_id in INDEX → return immediately
2. Domain match: check if query == domain or subdomain in any INDEX entry
3. Tag match: check if query appears in tags of any INDEX entry
4. Fuzzy match: tokenize query, score against domain+subdomain+tags of all entries
5. Return best match or empty result

**Output:**
```json
{
  "operation": "REGISTRY_LOOKUP",
  "found": "<boolean>",
  "cartridge_id": "<string | null>",
  "match_type": "<enum: EXACT | DOMAIN | TAG | FUZZY | NONE>",
  "confidence": "<float: 0.0 to 1.0>",
  "status": "<enum: ACTIVE | DRAFT | DEPRECATED | null>"
}
```

**Failure modes:**
- RR-L-001: INDEX file missing or corrupted → attempt rebuild, return FAILED if rebuild fails
- RR-L-002: No match found → return found=false (not an error, triggers CARTRIDGE_GENERATOR)
- RR-L-003: Match found but status=DEPRECATED → return found=false with note

---

### 5.3 REGISTRY_LOAD

Load a cartridge into session context. Writes to REGISTRY_LOCK.json.

**Input:**
```json
{
  "operation": "REGISTRY_LOAD",
  "cartridge_id": "<string>",
  "session_id": "<string>",
  "load_reason": "<string>",
  "force_draft": "<boolean: true to load DRAFT cartridges in dev mode>"
}
```

**Process:**
1. Lookup cartridge in INDEX → must be ACTIVE (or DRAFT if force_draft=true)
2. Read `{CARTRIDGE_ID}.cartridge.json` from filesystem
3. Verify SHA-256 matches INDEX entry
4. Check REGISTRY_LOCK for already-loaded cartridges → run conflict check (Section 6)
5. If conflict check passes: append to REGISTRY_LOCK.loaded_cartridges
6. Merge mistake classes and success patterns into session context (Section 7)
7. Return output

**Output:**
```json
{
  "operation": "REGISTRY_LOAD",
  "status": "<enum: SUCCESS | CONFLICT | FAILED>",
  "cartridge_id": "<string>",
  "load_order": "<integer>",
  "conflict_summary": "<string | null>",
  "total_loaded": "<integer: total cartridges now in session>",
  "error": "<string | null>"
}
```

**Failure modes:**
- RR-LD-001: Cartridge not in INDEX → FAILED (use REGISTRY_LOOKUP first)
- RR-LD-002: Cartridge status=DEPRECATED → FAILED
- RR-LD-003: Cartridge status=DRAFT and force_draft=false → FAILED
- RR-LD-004: SHA-256 mismatch at load time → FAILED, possible corruption
- RR-LD-005: `composition.incompatible_with` conflict → CONFLICT, return conflict summary
- RR-LD-006: `composition.requires` dependency not loaded → FAILED, list missing dependencies
- RR-LD-007: Circular dependency detected → FAILED

---

### 5.4 REGISTRY_UNLOAD

Remove a cartridge from session context.

**Input:**
```json
{
  "operation": "REGISTRY_UNLOAD",
  "cartridge_id": "<string>",
  "session_id": "<string>"
}
```

**Process:**
1. Verify cartridge is in REGISTRY_LOCK
2. Check if any other loaded cartridge has `requires` pointing to this cartridge
3. If dependents exist: return CONFLICT with list of dependents
4. Remove from REGISTRY_LOCK.loaded_cartridges
5. Recompute composite rubric and active class counts
6. Return output

**Output:**
```json
{
  "operation": "REGISTRY_UNLOAD",
  "status": "<enum: SUCCESS | CONFLICT | FAILED>",
  "cartridge_id": "<string>",
  "dependents_blocked": ["<CARTRIDGE_ID>", ...],
  "error": "<string | null>"
}
```

---

### 5.5 REGISTRY_STATUS

Inspect current session registry state.

**Input:**
```json
{
  "operation": "REGISTRY_STATUS",
  "session_id": "<string>"
}
```

**Output:**
```json
{
  "operation": "REGISTRY_STATUS",
  "session_id": "<string>",
  "loaded_cartridges": ["<CARTRIDGE_ID>", ...],
  "primary_cartridge": "<CARTRIDGE_ID | null>",
  "composite_rubric": "<string>",
  "active_mistake_classes": "<integer>",
  "active_success_patterns": "<integer>",
  "registry_total": "<integer: total registered cartridges>",
  "registry_active": "<integer: ACTIVE cartridges only>"
}
```

---

### 5.6 REGISTRY_DEPRECATE

Transition a cartridge from ACTIVE to DEPRECATED.

**Input:**
```json
{
  "operation": "REGISTRY_DEPRECATE",
  "cartridge_id": "<string>",
  "reason": "<string>",
  "successor_id": "<string | null>"
}
```

**Process:**
1. Verify cartridge is ACTIVE
2. Archive current file as `{CARTRIDGE_ID}.v{version}.cartridge.json`
3. Update cartridge status field to DEPRECATED
4. Update INDEX entry
5. If `successor_id` provided: verify successor is ACTIVE
6. Log COEVOLUTION_LOG entry

**Failure modes:**
- RR-D-001: Cartridge currently loaded in an active session → FAILED (unload first)
- RR-D-002: Cartridge already DEPRECATED → FAILED
- RR-D-003: Successor cartridge not ACTIVE → warn but proceed

---

## 6. CONFLICT RESOLUTION

When two or more cartridges are loaded simultaneously, conflicts may arise on:
- Same mistake class ID in two cartridges (ID collision)
- Same rubric criterion name in two cartridges
- Incompatible `composition.incompatible_with` declarations

### 6.1 Conflict Types

| Type | Description | Detection Point |
|------|-------------|-----------------|
| ID_COLLISION | Two cartridges define the same ME-*/MS-* ID | REGISTRY_LOAD |
| RUBRIC_OVERLAP | Two cartridges define criteria with the same name | REGISTRY_LOAD |
| EXPLICIT_INCOMPATIBLE | Cartridge B is in cartridge A's `incompatible_with` list | REGISTRY_LOAD |
| MISSING_DEPENDENCY | Cartridge requires another that is not loaded | REGISTRY_LOAD |
| CIRCULAR_DEPENDENCY | A requires B requires A | REGISTRY_LOAD |

### 6.2 Resolution Strategies

Determined by the PRIMARY cartridge's `composition.conflict_resolution` field.

#### MERGE_RUBRICS
- All rubric criteria from all loaded cartridges are combined into a single composite rubric
- Weights are renormalized: each cartridge's criteria weights are divided by total cartridges loaded
- ID collisions on mistake classes: both kept, suffixed with cartridge abbreviation
  - `ME-TEACH-001` and `ME-PY-001` both survive (different prefixes = no collision)
  - Two `ME-TEACH-001` from different cartridges → `ME-TEACH-001-C1` and `ME-TEACH-001-C2`
- FORGE scores against all criteria in composite rubric
- S-tier requires passing all rubrics

#### PRIMARY_WINS
- Primary cartridge (load_order=1) definitions take precedence
- On ID collision: primary cartridge's definition is used, secondary's is discarded
- On rubric overlap: primary cartridge's criterion is used
- Secondary cartridge's non-conflicting classes and patterns are still loaded
- Discarded definitions logged to session context for transparency

#### FAIL_ON_CONFLICT
- Any ID collision or rubric overlap → REGISTRY_LOAD returns CONFLICT
- Session must resolve before proceeding
- Explicit incompatibility → REGISTRY_LOAD returns CONFLICT immediately
- Safest option for high-stakes domains

### 6.3 Conflict Resolution Decision Matrix

| Scenario | Recommended Strategy |
|----------|---------------------|
| Teaching + Code Quality (different domains) | MERGE_RUBRICS |
| Two versions of same domain cartridge | PRIMARY_WINS (never load both — deprecate old) |
| Legal + Medical (both high-stakes) | FAIL_ON_CONFLICT |
| Teaching + STAAR + Bilingual (all complementary) | MERGE_RUBRICS |
| Unknown combination | FAIL_ON_CONFLICT (safe default) |

---

## 7. COMPOSITE CONTEXT ASSEMBLY

When multiple cartridges are loaded, the registry assembles a unified session context.

### 7.1 Mistake Class Merge

```
composite_mistake_classes = {}

for cartridge in loaded_cartridges (by load_order):
    for mistake in cartridge.mistake_classes:
        if mistake.id not in composite:
            composite[mistake.id] = mistake
        else:
            apply conflict_resolution strategy
```

Result: `composite_mistake_classes` is the full set available to pre-action check and FORGE.

### 7.2 Success Pattern Merge

Same algorithm as mistake class merge. No ID collisions expected (different domain prefixes).
If collision occurs: MERGE_RUBRICS keeps both (renamed), PRIMARY_WINS keeps primary.

### 7.3 Composite Rubric Assembly (MERGE_RUBRICS mode)

```
composite_rubric = {
    rubric_id: "COMPOSITE_{session_id}",
    criteria: [],
    scoring_tiers: <from primary cartridge>
}

total_cartridges = len(loaded_cartridges)

for cartridge in loaded_cartridges:
    for criterion in cartridge.quality_rubric.criteria:
        criterion.weight = criterion.weight / total_cartridges
        composite_rubric.criteria.append(criterion)

assert sum(c.weight for c in composite_rubric.criteria) ≈ 1.0
```

### 7.4 Expert Lens Merge

Expert lenses are merged additively — all lenses from all cartridges are available to BTS.
No conflict resolution needed: more lenses = richer deliberation context.

```
composite_lenses = {}
for cartridge in loaded_cartridges:
    for lens_name, lens_value in cartridge.expert_lenses.items():
        if lens_name not in composite_lenses:
            composite_lenses[lens_name] = []
        composite_lenses[lens_name].append({
            "source": cartridge.cartridge_id,
            "value": lens_value
        })
```

---

## 8. INTEGRITY RULES

| Rule | Description | Enforced At |
|------|-------------|-------------|
| RI-001 | SHA-256 verified on every load | REGISTRY_LOAD |
| RI-002 | DEPRECATED cartridges never loaded | REGISTRY_LOAD |
| RI-003 | DRAFT cartridges only in dev sessions | REGISTRY_LOAD |
| RI-004 | REGISTRY_INDEX always consistent with filesystem | REGISTRY_WRITE, rebuild |
| RI-005 | No duplicate cartridge_ids ever registered | REGISTRY_WRITE |
| RI-006 | Deprecated IDs never reused | REGISTRY_WRITE |
| RI-007 | REGISTRY_LOCK cleared at session end | Session manager |
| RI-008 | Composite rubric weights verified to sum to 1.0 | Composite assembly |
| RI-009 | COEVOLUTION_LOG entry on every lifecycle transition | All write ops |
| RI-010 | PYTHON_CODE_QUALITY always available (never deprecated without successor) | REGISTRY_DEPRECATE |

---

## 9. BOOT SEQUENCE INTEGRATION

On MetaBlooms OS boot:

```
1. REGISTRY_INDEX.json loaded → verified (hash check)
2. If INDEX missing or corrupt → registry_rebuild() called
3. PYTHON_CODE_QUALITY loaded automatically (always first, load_order=1)
4. SESSION_HANDOFF checked for requested cartridges → loaded in order
5. REGISTRY_LOCK.json written for this session
6. CONTEXT_BUDGET_TRACKER notified of loaded mistake/success class counts
```

PYTHON_CODE_QUALITY is the only cartridge loaded without an explicit request.
It is always load_order=1. It cannot be unloaded while any other cartridge is active.

---

## 10. REGISTRY_REBUILD

Recovery operation when REGISTRY_INDEX.json is missing or corrupted.

```
registry_rebuild():
    scan CARTRIDGE_REGISTRY/ for all directories
    for each directory:
        read {CARTRIDGE_ID}.cartridge.json
        verify SHA-256 (skip if mismatch, log warning)
        extract identity fields
        add to rebuilt INDEX
    write new REGISTRY_INDEX.json
    log COEVOLUTION_LOG entry: REGISTRY_REBUILT
```

Rebuild is non-destructive. Cartridge files are the source of truth. INDEX is derived.

---

## 11. WHAT DERIVES FROM THIS SPEC

| Component | Derives From |
|-----------|-------------|
| CARTRIDGE_REGISTRY.py | All sections |
| REGISTRY_INDEX.json | Section 3 |
| REGISTRY_LOCK.json | Section 4 |
| REGISTRY_LOAD call | Section 5.3 |
| REGISTRY_WRITE call | Section 5.1 (called by CARTRIDGE_GENERATOR Stage 7D) |
| Conflict resolution logic | Section 6 |
| Composite rubric builder | Section 7.3 |
| OS boot sequence | Section 9 |
| CONTEXT_BUDGET_TRACKER | Section 9 (notified of loaded class counts) |

---

## 12. ACCEPTANCE CRITERIA

CARTRIDGE_REGISTRY is complete when:

- [ ] All 6 operations implemented (WRITE, LOOKUP, LOAD, UNLOAD, STATUS, DEPRECATE)
- [ ] All USB-1.0 envelopes honored on every operation
- [ ] All failure modes returned (never swallowed)
- [ ] SHA-256 verified on every LOAD (RI-001)
- [ ] Conflict resolution all 3 strategies implemented (MERGE, PRIMARY_WINS, FAIL)
- [ ] Composite rubric weights verified to sum to 1.0 after merge
- [ ] REGISTRY_LOCK.json written and cleared correctly
- [ ] REGISTRY_REBUILD functional (recovery path)
- [ ] PYTHON_CODE_QUALITY protected from unload while others active (RI-010)
- [ ] COEVOLUTION_LOG entry written on every lifecycle transition (RI-009)

---

## 13. CHANGE LOG

| Version | Date | Change |
|---------|------|--------|
| 1.0 | 2026-03-22 | Initial locked spec |

---

## SPEC_GATE DECLARATION

This document is LOCKED at v1.0.
No registry read, write, or load operation may occur outside this contract.
The registry is the single source of truth for cartridge state.
REGISTRY_INDEX.json is derived. Cartridge files are authoritative.
Changes require MINOR version bump minimum.
