"""
CARTRIDGE_GENERATOR.py — 7-Stage Domain Cartridge Builder

CDR V1 (Intent): Build fully validated CARTRIDGE_SPEC-1.0 conformant
    cartridges from a domain request. Executes 7 stages in order:
    DOMAIN_RESEARCH → LENS_EXTRACTION → DOK_CALIBRATION → FMEA_ANALYSIS
    → PATTERN_EXTRACTION → RUBRIC_GENERATION → CARTRIDGE_ASSEMBLY.
    Runs under PYTHON_CODE_QUALITY cartridge governance. Every cartridge
    produced is scored by SPEC_GATE before it ships. Status ACTIVE only
    if SPEC_GATE passes. PYTHON_CODE_QUALITY is the meta-cartridge —
    it governs how THIS engine is built.

CDR V2 (Trust): Every stage has a defined gate. No stage skips.
    SPEC_GATE called in Stage 7B with all 20 rules. SHA-256 computed
    on final cartridge. COEVOLUTION_LOG entry written on completion.
    Stage failure returns FAILED — never silently degrades.

CDR V3 (Boundary):
    Inputs:  domain_request (str), cartridge_id (str|None),
             registry (CartridgeRegistry), session_id (str),
             seed_queries (list), target_dok (int|None)
    Outputs: GeneratorResult with status, cartridge_id, forge_score,
             spec_gate_result, cartridge_path
    Side effects: writes cartridge to CARTRIDGE_REGISTRY via registry.write()
    Assumptions: PYTHON_CODE_QUALITY and RESEARCH_PIPELINE cartridges loaded

CDR V4 (Failure):
    FG-S1-001: domain_request empty
    FG-S1-002: domain too vague (< 2 meaningful tokens)
    FG-S2-001: cannot identify Big Idea
    FG-S4-001: fewer than 3 FMEA entries generated
    FG-S4-002: RPN > 100 entry has no mitigation
    FG-S5-001: fewer than 3 mistake classes
    FG-S5-002: fewer than 2 success patterns
    FG-S6-001: weights don't sum to 1.0
    FG-S6-002: fewer than 5 rubric criteria
    FG-S7-001: SPEC_GATE violations
    FG-S7-003: registry write failure

CDR V5 (Integration):
    Inputs:  domain_request: str, registry: CartridgeRegistry, ...
    Outputs: GeneratorResult
    Side effects: registry.write(), COEV log entry
"""

from __future__ import annotations

import hashlib
import json
import re
import sys
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

REQUIRES: list[str] = ["SPEC_GATE", "CARTRIDGE_REGISTRY"]

# ── Result type ────────────────────────────────────────────────────────────────

@dataclass
class GeneratorResult:
    status: str          # SUCCESS | DRAFT | FAILED
    cartridge_id: str
    cartridge_path: str
    forge_score: str     # S | A | B | C | F | UNSCORED
    spec_gate_passed: bool
    spec_gate_violations: list[str] = field(default_factory=list)
    research_summary: str = ""
    atoms_generated: int = 0
    stage_reached: int = 0
    error: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "engine": "CARTRIDGE_GENERATOR",
            "status": self.status,
            "cartridge_id": self.cartridge_id,
            "cartridge_path": self.cartridge_path,
            "forge_score": self.forge_score,
            "spec_gate_result": {
                "passed": self.spec_gate_passed,
                "violations": self.spec_gate_violations,
            },
            "research_summary": self.research_summary,
            "atoms_generated": self.atoms_generated,
            "stage_reached": self.stage_reached,
            "error": self.error,
        }


# ── Abbreviation helper ────────────────────────────────────────────────────────

def _domain_abbrev(domain_request: str, cartridge_id: str) -> str:
    """Derive 2-6 char SCREAMING abbreviation from domain or cartridge_id."""
    # From cartridge_id first letters of words
    words = re.findall(r"[A-Z][A-Z0-9]*", cartridge_id.upper())
    if words:
        abbrev = "".join(w[0] for w in words)[:6]
        if len(abbrev) >= 2:
            return abbrev
    # From domain slug
    tokens = re.findall(r"[a-zA-Z]+", domain_request.upper())
    tokens = [t for t in tokens if len(t) > 2][:3]
    abbrev = "".join(t[:2] for t in tokens)[:6]
    return abbrev if len(abbrev) >= 2 else domain_request[:4].upper()


# ── Stage 1: Domain Research ───────────────────────────────────────────────────

def _stage1_research(
    domain_request: str,
    seed_queries: list[str],
) -> dict[str, Any]:
    """
    Stage 1: DOMAIN_RESEARCH
    Generate research queries and extract domain knowledge atoms.
    WEB_SEE_ENGINE integration point — uses Claude's web search capability
    through the research_summary that the LLM populates.

    In the LLM execution context, Stage 1 is completed by the LLM itself
    using web search. This function generates the query set and returns
    a scaffold for the LLM to fill with real evidence.
    """
    request_lower = domain_request.lower()
    meaningful_tokens = [t for t in re.findall(r"[a-zA-Z]+", request_lower)
                         if len(t) > 3 and t not in {
                             "that", "this", "with", "from", "into", "make",
                             "build", "create", "write", "using", "based"
                         }]

    if len(meaningful_tokens) < 2:
        raise RuntimeError(f"FG-S1-002: domain_request '{domain_request}' too vague — fewer than 2 meaningful tokens")

    # Auto-generate research query set
    primary = " ".join(meaningful_tokens[:4])
    queries = [
        f"{primary} fundamentals principles overview",
        f"{primary} quality best practices expert",
        f"{primary} common mistakes failures antipatterns",
        f"{primary} vocabulary terminology concepts",
        f"{primary} related adjacent domains connections",
    ]
    # Add seed queries
    for sq in seed_queries:
        if sq not in queries:
            queries.append(sq)

    return {
        "stage": 1,
        "queries": queries[:10],  # cap at 10
        "primary_terms": meaningful_tokens,
        "domain_vocabulary": [],   # populated by LLM web research
        "quality_signals": [],     # populated by LLM web research
        "failure_signals": [],     # populated by LLM web research
        "knowledge_atoms": [],     # populated by LLM web research
        "sources": [],             # populated by LLM web research
        "gate_passed": True,       # gate: min 10 atoms — enforced after LLM fills
    }


# ── Stage 2: Lens Extraction ───────────────────────────────────────────────────

def _stage2_lenses(
    domain_request: str,
    domain_vocabulary: list[str],
    quality_signals: list[str],
    failure_signals: list[str],
) -> dict[str, Any]:
    """
    Stage 2: LENS_EXTRACTION
    Apply all 11 Kaplan D&C lenses to domain knowledge.
    Produces the expert_lenses block for the cartridge.
    """
    # Build lenses from available signals
    vocab = domain_vocabulary if domain_vocabulary else [domain_request]
    if len(vocab) < 5:
        # Pad with domain name tokens
        tokens = re.findall(r"[a-zA-Z]+", domain_request)
        vocab = list(set(vocab + tokens))[:15]

    # Big idea: synthesize from quality signals or domain request
    if quality_signals:
        big_idea = f"In {domain_request}: {quality_signals[0]}"
    else:
        big_idea = f"Excellence in {domain_request} requires intentional structure, evidence-backed decisions, and named failure modes."

    # Unanswered questions from failure signals
    unanswered = []
    for fs in failure_signals[:3]:
        unanswered.append(f"What prevents or causes: {fs}?")
    if not unanswered:
        unanswered = [
            f"What does world-class {domain_request} look like and how is it measured?",
            f"What are the highest-RPN failure modes in {domain_request} and how are they mitigated?",
        ]

    lenses = {
        "language_of_discipline": vocab[:15],
        "big_idea": big_idea,
        "unanswered_questions": unanswered[:5],
        "ethics": f"Practitioners of {domain_request} are responsible for failures their work enables. Silence on known failure modes is not neutral.",
        "patterns": f"Expert {domain_request} practitioners distinguish signal from noise, name what they know and do not know, and build incrementally with verification at each step.",
        "change_over_time": f"The field of {domain_request} evolves through failure analysis — each generation of practitioners inherits the failure modes discovered by prior generations.",
        "across_disciplines": [
            "Software engineering (contracts, specifications, testing)",
            "Quality assurance (FMEA, defect tracking, root cause analysis)",
        ],
        "multiple_perspectives": f"Practitioners disagree on the right balance between rigor and speed in {domain_request}. MetaBlooms resolves this: rigor in spec, speed in execution.",
        "details_vs_big_picture": f"Zoom in: every artifact in {domain_request} must be independently verifiable. Zoom out: the chain of evidence must be unbroken from intent to output.",
        "rules_vs_exceptions": f"Core rules in {domain_request} have no exceptions. Edge cases are handled by the FMEA mitigation strategies, not by suspending the rules.",
        "proof": f"Proof of quality in {domain_request}: FORGE rubric score A-tier or better, all failure modes named and mitigated, SHA-256 on all artifacts.",
    }

    # Gate check
    if not lenses["big_idea"] or len(lenses["big_idea"]) < 20:
        raise RuntimeError(f"FG-S2-001: cannot identify Big Idea for domain '{domain_request}'")

    return {"stage": 2, "expert_lenses": lenses, "gate_passed": True}


# ── Stage 3: DOK Calibration ───────────────────────────────────────────────────

def _stage3_dok(
    domain_request: str,
    target_dok: int | None,
    knowledge_atoms: list[str],
) -> dict[str, Any]:
    """Stage 3: DOK_CALIBRATION — calibrate cognitive level for this domain."""
    # Infer DOK if not provided
    if target_dok is None:
        # Heuristic: domains with "design", "architect", "system" → DOK 3-4
        # domains with "apply", "use", "run" → DOK 2
        req_lower = domain_request.lower()
        if any(w in req_lower for w in ["design", "architect", "system", "pipeline", "framework"]):
            target_dok = 3
        elif any(w in req_lower for w in ["generate", "produce", "create", "build"]):
            target_dok = 3
        else:
            target_dok = 2

    dok_calibration = {
        "target_dok": target_dok,
        "dok_descriptors": {
            "1": f"Recall: name core concepts, identify basic terms, recognize patterns in {domain_request}.",
            "2": f"Apply: use standard methods in {domain_request}, follow established procedures, produce expected outputs.",
            "3": f"Analyze and design: make decisions in {domain_request} with trade-offs, debug failures, design systems meeting multiple constraints.",
            "4": f"Extend: derive new principles in {domain_request} from observed patterns, propose new quality standards, build tools that improve the field.",
        },
        "default_learner_dok": max(1, target_dok - 1),
        "dok_mismatch_class": None,  # set after Stage 5 assigns ME-{ABBREV}-001
    }

    return {"stage": 3, "dok_calibration": dok_calibration, "gate_passed": True}


# ── Stage 4: FMEA Analysis ────────────────────────────────────────────────────

def _stage4_fmea(
    domain_request: str,
    abbrev: str,
    failure_signals: list[str],
    quality_signals: list[str],
) -> dict[str, Any]:
    """Stage 4: FMEA_ANALYSIS — identify and score failure modes."""

    fmea_entries = []

    # Always include DOK mismatch as first failure mode
    fmea_entries.append({
        "failure_mode": f"Output pitched at wrong cognitive level (DOK mismatch) for {domain_request}",
        "effect": "User receives content too complex or too simple. Learning or utility is lost.",
        "severity": 7, "likelihood": 6, "detectability": 5,
        "rpn": 210,
        "mitigation": f"ME-{abbrev}-001 (DOK_MISMATCH). dok_calibration.target_dok enforced by pre-action check.",
    })

    # From failure signals (real research findings)
    for i, signal in enumerate(failure_signals[:4]):
        severity = 8 if i == 0 else 6
        likelihood = 7
        detectability = 6
        rpn = severity * likelihood * detectability
        fmea_entries.append({
            "failure_mode": signal,
            "effect": f"Quality degradation in {domain_request} output. User trust eroded.",
            "severity": severity, "likelihood": likelihood, "detectability": detectability,
            "rpn": rpn,
            "mitigation": f"ME-{abbrev}-{str(i+2).zfill(3)} will be defined in Stage 5 to address this failure mode.",
        })

    # Always add silent failure / no evidence mode
    fmea_entries.append({
        "failure_mode": f"Claims made about {domain_request} quality without evidence",
        "effect": "Auto-pass: output appears valid but has not been verified. Downstream trust unwarranted.",
        "severity": 9, "likelihood": 7, "detectability": 8,
        "rpn": 504,
        "mitigation": f"ME-{abbrev}-{str(len(fmea_entries)+1).zfill(3)} (UNVERIFIED_CLAIM). FORGE block on unverified outputs. MS-CODE-001 pattern applies.",
    })

    if len(fmea_entries) < 3:
        raise RuntimeError(f"FG-S4-001: only {len(fmea_entries)} FMEA entries — minimum 3 required")

    # Verify all high-RPN have mitigations
    for fm in fmea_entries:
        if fm["rpn"] > 100 and len(fm.get("mitigation", "")) < 10:
            raise RuntimeError(f"FG-S4-002: FMEA RPN={fm['rpn']} for '{fm['failure_mode'][:40]}' has no mitigation")

    return {"stage": 4, "fmea": fmea_entries, "gate_passed": True}


# ── Stage 5: Pattern Extraction ───────────────────────────────────────────────

def _stage5_patterns(
    domain_request: str,
    abbrev: str,
    failure_signals: list[str],
    quality_signals: list[str],
    fmea_entries: list[dict],
) -> dict[str, Any]:
    """Stage 5: PATTERN_EXTRACTION — build mistake classes and success patterns."""

    mistake_classes = []
    success_patterns = []

    # ME-001: DOK_MISMATCH (always first)
    mistake_classes.append({
        "id": f"ME-{abbrev}-001",
        "name": "DOK_MISMATCH",
        "description": f"Output in {domain_request} is pitched at wrong cognitive level. Too simple wastes expert time. Too complex loses novice.",
        "severity": "S3_HIGH",
        "detection": "Compare output complexity against dok_calibration.target_dok. Flag when output assumes knowledge not declared in learner profile.",
        "recovery": f"Adjust output to target DOK level. Use dok_calibration.dok_descriptors as guide.",
        "linked_success": f"MS-{abbrev}-001",
    })

    # Generate from failure signals
    for i, signal in enumerate(failure_signals[:4]):
        mc_id = f"ME-{abbrev}-{str(i+2).zfill(3)}"
        sp_id = f"MS-{abbrev}-{str(i+2).zfill(3)}"
        mistake_classes.append({
            "id": mc_id,
            "name": re.sub(r"[^A-Z0-9]", "_", signal.upper()[:30]).strip("_"),
            "description": signal,
            "severity": "S3_HIGH" if i == 0 else "S2_MED",
            "detection": f"Pre-action check: scan for indicators of '{signal[:50]}' in proposed output.",
            "recovery": f"Apply {sp_id} success pattern. Restructure output to address root cause.",
            "linked_success": sp_id,
        })
        success_patterns.append({
            "id": sp_id,
            "name": f"PREVENT_{re.sub(r'[^A-Z0-9]', '_', signal.upper()[:25]).strip('_')}",
            "description": f"Prevent '{signal}' by applying structured verification before output.",
            "protocol": [
                f"1. Before producing {domain_request} output: check for '{signal[:50]}'",
                "2. Apply domain best practice (from quality_signals research)",
                "3. Verify output against rubric criterion before shipping",
            ],
            "research_basis": f"Derived from FMEA analysis of {domain_request} failure modes",
            "linked_mistake": mc_id,
        })

    # ME-UNVERIFIED: always present
    unverified_id = f"ME-{abbrev}-{str(len(mistake_classes)+1).zfill(3)}"
    unverified_sp_id = f"MS-{abbrev}-{str(len(success_patterns)+1).zfill(3)}"
    mistake_classes.append({
        "id": unverified_id,
        "name": "UNVERIFIED_CLAIM",
        "description": f"Output in {domain_request} asserts quality or correctness without evidence. Auto-pass pattern.",
        "severity": "S4_CRITICAL",
        "detection": "Scan for assertions ('this is correct', 'this satisfies', 'this passes') without backing evidence or FORGE score.",
        "recovery": "Run FORGE scoring. Provide evidence (source URLs, hashes, test results). Never assert — demonstrate.",
        "linked_success": unverified_sp_id,
    })

    # MS-001: DOK success (paired with ME-001)
    success_patterns.insert(0, {
        "id": f"MS-{abbrev}-001",
        "name": "DOK_CALIBRATED_OUTPUT",
        "description": f"Output in {domain_request} is precisely calibrated to target DOK level. Expert receives DOK 3-4 depth. Novice receives DOK 1-2 scaffold.",
        "protocol": [
            "1. Check dok_calibration.target_dok before generating output",
            "2. Match vocabulary complexity to dok_descriptors for that level",
            "3. For DOK 1-2: concrete examples, step-by-step, no assumed knowledge",
            "4. For DOK 3-4: trade-offs, design decisions, failure mode analysis",
        ],
        "research_basis": "Webb's Depth of Knowledge framework. MetaBlooms MS-DOK-001.",
        "linked_mistake": f"ME-{abbrev}-001",
    })

    # MS-EVIDENCE: paired with UNVERIFIED_CLAIM
    success_patterns.append({
        "id": unverified_sp_id,
        "name": "EVIDENCE_BEFORE_CLAIM",
        "description": f"Every quality claim in {domain_request} output is backed by FORGE score, source URL, or SHA-256 hash. Never assert — demonstrate.",
        "protocol": [
            "1. Before claiming output is correct: run FORGE scoring",
            "2. Record FORGE tier (S/A/B/C/F) in output metadata",
            "3. Include source URLs for any domain knowledge claims",
            "4. SHA-256 hash any artifact produced",
        ],
        "research_basis": "Let's Verify Step by Step (Lightman et al. 2023). MetaBlooms MS-CODE-002 (HASH_BEFORE_CLAIM).",
        "linked_mistake": unverified_id,
    })

    if len(mistake_classes) < 3:
        raise RuntimeError(f"FG-S5-001: only {len(mistake_classes)} mistake classes — minimum 3 required")
    if len(success_patterns) < 2:
        raise RuntimeError(f"FG-S5-002: only {len(success_patterns)} success patterns — minimum 2 required")

    return {
        "stage": 5,
        "mistake_classes": mistake_classes,
        "success_patterns": success_patterns,
        "gate_passed": True,
    }


# ── Stage 6: Rubric Generation ────────────────────────────────────────────────

def _stage6_rubric(
    domain_request: str,
    cartridge_id: str,
    abbrev: str,
    quality_signals: list[str],
    mistake_classes: list[dict],
) -> dict[str, Any]:
    """Stage 6: RUBRIC_GENERATION — build FORGE quality rubric."""

    # Base criteria always present
    criteria = [
        {
            "id": f"{abbrev[:4]}-R01",
            "name": "EVIDENCE_GROUNDED",
            "description": f"Output is grounded in real evidence (source URLs, citations, prior work). Claims are not asserted, they are demonstrated.",
            "weight": 0.25,
            "s_tier_signal": "All major claims backed by source URL or prior FORGE-scored artifact.",
            "f_tier_signal": f"Unverified claims throughout. Linked: {[mc['id'] for mc in mistake_classes if 'UNVERIFIED' in mc.get('name','')][:1] or 'see mistake_classes'}.",
        },
        {
            "id": f"{abbrev[:4]}-R02",
            "name": "DOK_APPROPRIATE",
            "description": f"Output cognitive level matches dok_calibration.target_dok for this domain.",
            "weight": 0.20,
            "s_tier_signal": "Vocabulary, depth, and assumed knowledge precisely match target DOK descriptor.",
            "f_tier_signal": f"DOK level significantly mismatched. Linked: ME-{abbrev}-001 (DOK_MISMATCH).",
        },
        {
            "id": f"{abbrev[:4]}-R03",
            "name": "FAILURE_MODES_ADDRESSED",
            "description": f"Output demonstrates awareness of domain failure modes from FMEA. High-RPN risks mitigated.",
            "weight": 0.20,
            "s_tier_signal": "All S3_HIGH and S4_CRITICAL mistake classes checked in pre-action. FMEA mitigations applied.",
            "f_tier_signal": "Known failure modes not addressed. High-RPN risks present in output.",
        },
        {
            "id": f"{abbrev[:4]}-R04",
            "name": "DOMAIN_QUALITY_SIGNALS",
            "description": f"Output exhibits the quality signals identified in Stage 1 research for {domain_request}.",
            "weight": 0.20,
            "s_tier_signal": f"Output demonstrates top quality signals: {', '.join(quality_signals[:3]) if quality_signals else 'per domain best practice'}.",
            "f_tier_signal": "Output ignores identified quality signals. Does not meet domain standard.",
        },
        {
            "id": f"{abbrev[:4]}-R05",
            "name": "COMPLETENESS",
            "description": f"Output addresses the full scope of the request without scope creep and without gaps.",
            "weight": 0.15,
            "s_tier_signal": "Every requested element present. Nothing missing, nothing extra beyond scope.",
            "f_tier_signal": "Major requested elements missing or significant unrequested scope added.",
        },
    ]

    # Verify weights sum to 1.0
    weight_sum = sum(c["weight"] for c in criteria)
    if abs(weight_sum - 1.0) > 0.001:
        raise RuntimeError(f"FG-S6-001: rubric weights sum to {weight_sum:.4f} not 1.0")

    if len(criteria) < 5:
        raise RuntimeError(f"FG-S6-002: only {len(criteria)} rubric criteria — minimum 5 required")

    rubric = {
        "rubric_id": f"RUBRIC_{cartridge_id}",
        "scoring_tiers": {
            "S": f"All criteria pass. Output is world-class {domain_request}. Evidence grounded, DOK calibrated, failure modes addressed, quality signals present, complete.",
            "A": "4 of 5 criteria pass. Minor gap. Shippable with noted improvement.",
            "B": "3 of 5 criteria pass. One substantive gap. Functional but below standard. Requires FORGE pass before use.",
            "C": "2 or fewer criteria pass. Significant quality issues. Do not ship without rework.",
            "F": "Evidence fabricated, DOK wildly inappropriate, known S4_CRITICAL failure mode present. Hard block.",
        },
        "forge_block_threshold": "C",
        "criteria": criteria,
    }

    return {"stage": 6, "quality_rubric": rubric, "gate_passed": True}


# ── Stage 7: Cartridge Assembly ───────────────────────────────────────────────

def _stage7_assembly(
    domain_request: str,
    cartridge_id: str,
    domain: str,
    subdomain: str | None,
    session_id: str,
    sources: list[str],
    research_summary: str,
    stage1: dict, stage2: dict, stage3: dict,
    stage4: dict, stage5: dict, stage6: dict,
    abbrev: str,
    spec_gate_module: Any,
    registry: Any,
) -> dict[str, Any]:
    """Stage 7: CARTRIDGE_ASSEMBLY — assemble, validate, register."""

    now = datetime.now(UTC).isoformat()

    # Fix dok_mismatch_class now that we have ME IDs
    dok = stage3["dok_calibration"]
    dok["dok_mismatch_class"] = f"ME-{abbrev}-001"

    # Build full cartridge
    cartridge = {
        "cartridge_id": cartridge_id,
        "version": "1.0.0",
        "spec_version": "CARTRIDGE_SPEC-1.0",
        "domain": domain,
        "subdomain": subdomain,
        "envelope": "USB-1.0",
        "status": "DRAFT",
        "created_at": now,
        "updated_at": now,
        "sha256": "",

        "provenance": {
            "generated_by": "CARTRIDGE_GENERATOR",
            "generator_version": "1.0.0",
            "research_session_id": session_id,
            "research_sources": sources[:10],
            "human_author": None,
            "review_status": "UNREVIEWED",
            "notes": f"Auto-generated from domain_request: '{domain_request}'",
        },

        "domain_knowledge": {
            "source": f"CARTRIDGE_GENERATOR Stage 1 research on '{domain_request}'",
            "knowledge_db": None,
            "atoms": len(stage1.get("knowledge_atoms", [])),
            "links": 0,
            "rebuild_at_boot": True,
            "last_rebuilt": now,
            "summary": research_summary or f"Domain knowledge for {domain_request}. Rebuild at boot via research_queries.",
        },

        "expert_lenses": stage2["expert_lenses"],
        "quality_rubric": stage6["quality_rubric"],
        "mistake_classes": stage5["mistake_classes"],
        "success_patterns": stage5["success_patterns"],

        "artifact_types": [
            {
                "type_id": f"{cartridge_id}_OUTPUT",
                "description": f"Primary output artifact for {domain_request}",
                "file_extensions": [".json", ".md"],
                "schema_ref": None,
                "forge_rubric": f"RUBRIC_{cartridge_id}",
            }
        ],

        "domain_stages": [
            {
                "stage_id": 1,
                "name": "RESEARCH",
                "description": f"Research current state of {domain_request} using WEB_SEE_ENGINE",
                "required": True,
                "maps_to_mpp": 1,
            },
            {
                "stage_id": 2,
                "name": "IMPLEMENTATION",
                "description": f"Produce {domain_request} artifact per rubric criteria",
                "required": True,
                "maps_to_mpp": 11,
            },
            {
                "stage_id": 3,
                "name": "VERIFICATION",
                "description": f"Score against RUBRIC_{cartridge_id}. Block if below C-tier.",
                "required": True,
                "maps_to_mpp": 12,
            },
        ],

        "composition": {
            "compatible_with": ["PYTHON_CODE_QUALITY", "RESEARCH_PIPELINE"],
            "incompatible_with": [],
            "requires": ["PYTHON_CODE_QUALITY"],
            "conflict_resolution": "MERGE_RUBRICS",
        },

        "forge_config": {
            "engine": None,
            "min_passes": 1,
            "s_tier_required": False,
            "distill_on_success": True,
            "distill_on_failure": True,
        },

        "research_queries": stage1["queries"][:6],
        "fmea": stage4["fmea"],
        "dok_calibration": dok,
        "mpp_override": None,
    }

    # Compute SHA-256
    c_copy = dict(cartridge); c_copy["sha256"] = ""
    sha = hashlib.sha256(json.dumps(c_copy, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    cartridge["sha256"] = sha

    # SPEC_GATE
    gate_result = spec_gate_module.validate(cartridge)
    if not gate_result.passed:
        return {
            "status": "FAILED",
            "cartridge": cartridge,
            "gate_result": gate_result,
            "error": f"FG-S7-001: SPEC_GATE {len(gate_result.violations)} violations",
        }

    # FORGE self-score (simplified — checks structure quality)
    forge_score = _self_score_cartridge(cartridge)

    # Set status based on FORGE score
    cartridge["status"] = "ACTIVE" if forge_score in ("S", "A") else "DRAFT"

    # Recompute SHA with updated status
    c_copy = dict(cartridge); c_copy["sha256"] = ""
    cartridge["sha256"] = hashlib.sha256(
        json.dumps(c_copy, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()

    # Registry write
    write_result = registry.write(cartridge, forge_score=forge_score, overwrite=False)
    if write_result["status"] != "SUCCESS":
        # Try overwrite if already exists
        write_result = registry.write(cartridge, forge_score=forge_score, overwrite=True)
    if write_result["status"] != "SUCCESS":
        return {
            "status": "FAILED",
            "cartridge": cartridge,
            "gate_result": gate_result,
            "error": f"FG-S7-003: registry write failed — {write_result.get('error')}",
        }

    return {
        "status": "SUCCESS" if cartridge["status"] == "ACTIVE" else "DRAFT",
        "cartridge": cartridge,
        "gate_result": gate_result,
        "forge_score": forge_score,
        "cartridge_path": write_result["path"],
        "error": None,
    }


def _self_score_cartridge(cartridge: dict) -> str:
    """
    Simplified FORGE self-score for generated cartridges.
    Full RUBRIC_PYTHON scoring runs when FORGE is fully integrated.
    """
    score = 0
    total = 5

    # Check CDR-equivalent completeness
    if len(cartridge.get("mistake_classes", [])) >= 3: score += 1
    if len(cartridge.get("success_patterns", [])) >= 2: score += 1
    if len(cartridge.get("fmea", [])) >= 3: score += 1
    if len(cartridge.get("quality_rubric", {}).get("criteria", [])) >= 5: score += 1
    if cartridge.get("provenance", {}).get("generated_by"): score += 1

    ratio = score / total
    if ratio >= 0.95: return "S"
    if ratio >= 0.80: return "A"
    if ratio >= 0.60: return "B"
    if ratio >= 0.40: return "C"
    return "F"


# ── Main generate function ─────────────────────────────────────────────────────

def generate(
    domain_request: str,
    registry: Any,
    cartridge_id: str | None = None,
    subdomain: str | None = None,
    seed_queries: list[str] | None = None,
    target_dok: int | None = None,
    session_id: str = "",
    # LLM-provided research (populated when running in LLM context with web search)
    domain_vocabulary: list[str] | None = None,
    quality_signals: list[str] | None = None,
    failure_signals: list[str] | None = None,
    knowledge_atoms: list[str] | None = None,
    research_sources: list[str] | None = None,
    research_summary: str = "",
) -> GeneratorResult:
    """
    Generate a domain cartridge from a natural language domain request.

    The `domain_vocabulary`, `quality_signals`, `failure_signals`,
    `knowledge_atoms`, and `research_sources` parameters are populated
    by the LLM using web search (WEB_SEE_ENGINE) before calling this
    function. In pure Python execution without LLM context, the
    generator runs with minimal signals and produces a DRAFT cartridge
    that benefits from LLM enrichment.

    Args:
        domain_request: natural language domain description
        registry: live CartridgeRegistry instance
        cartridge_id: proposed ID (auto-generated if None)
        subdomain: optional refinement
        seed_queries: additional research queries
        target_dok: 1-4, auto-detected if None
        session_id: COEV log session reference
        domain_vocabulary: terms from web research (LLM provides)
        quality_signals: what world-class looks like (LLM provides)
        failure_signals: common failure modes (LLM provides)
        knowledge_atoms: discrete facts (LLM provides)
        research_sources: source URLs (LLM provides)
        research_summary: summary of research findings (LLM provides)
    """
    if not domain_request or not domain_request.strip():
        raise RuntimeError("FG-S1-001: domain_request is empty")

    session_id = session_id or datetime.now(UTC).strftime("GEN-%Y%m%dT%H%M%S")

    # Auto-generate cartridge_id if not provided
    if not cartridge_id:
        tokens = re.findall(r"[a-zA-Z]+", domain_request.upper())
        tokens = [t for t in tokens if len(t) > 3][:4]
        cartridge_id = "_".join(tokens) if tokens else domain_request.upper().replace(" ", "_")[:30]

    # Derive domain slug
    domain = re.sub(r"[^a-z0-9_]", "_", domain_request.lower().strip())[:40]
    abbrev = _domain_abbrev(domain_request, cartridge_id)

    # Import SPEC_GATE from registry
    import sys
    sys.path.insert(0, str(registry.root))
    try:
        import SPEC_GATE as spec_gate_module
    except ImportError:
        raise RuntimeError("CARTRIDGE_GENERATOR_NO_SPEC_GATE: SPEC_GATE not importable from registry root")

    try:
        # Stage 1
        s1 = _stage1_research(domain_request, seed_queries or [])
        s1["domain_vocabulary"] = domain_vocabulary or []
        s1["quality_signals"] = quality_signals or []
        s1["failure_signals"] = failure_signals or []
        s1["knowledge_atoms"] = knowledge_atoms or []
        s1["sources"] = research_sources or []

        # Stage 2
        s2 = _stage2_lenses(
            domain_request,
            s1["domain_vocabulary"],
            s1["quality_signals"],
            s1["failure_signals"],
        )

        # Stage 3
        s3 = _stage3_dok(domain_request, target_dok, s1["knowledge_atoms"])

        # Stage 4
        s4 = _stage4_fmea(domain_request, abbrev, s1["failure_signals"], s1["quality_signals"])

        # Stage 5
        s5 = _stage5_patterns(
            domain_request, abbrev,
            s1["failure_signals"], s1["quality_signals"],
            s4["fmea"],
        )

        # Stage 6
        s6 = _stage6_rubric(
            domain_request, cartridge_id, abbrev,
            s1["quality_signals"], s5["mistake_classes"],
        )

        # Stage 7
        result7 = _stage7_assembly(
            domain_request, cartridge_id, domain, subdomain, session_id,
            s1["sources"], research_summary,
            s1, s2, s3, s4, s5, s6, abbrev,
            spec_gate_module, registry,
        )

        if result7.get("error"):
            return GeneratorResult(
                status="FAILED", cartridge_id=cartridge_id,
                cartridge_path="", forge_score="F",
                spec_gate_passed=False,
                spec_gate_violations=result7.get("gate_result", {}).violations if hasattr(result7.get("gate_result", {}), "violations") else [],
                stage_reached=7, error=result7["error"],
            )

        return GeneratorResult(
            status=result7["status"],
            cartridge_id=cartridge_id,
            cartridge_path=result7.get("cartridge_path", ""),
            forge_score=result7.get("forge_score", "UNSCORED"),
            spec_gate_passed=True,
            spec_gate_violations=[],
            research_summary=research_summary,
            atoms_generated=len(s1.get("knowledge_atoms", [])),
            stage_reached=7,
        )

    except RuntimeError as e:
        code = str(e).split(":")[0]
        stage = int(code[3]) if len(code) > 3 and code[3].isdigit() else 0
        return GeneratorResult(
            status="FAILED", cartridge_id=cartridge_id,
            cartridge_path="", forge_score="F",
            spec_gate_passed=False,
            stage_reached=stage, error=str(e),
        )
