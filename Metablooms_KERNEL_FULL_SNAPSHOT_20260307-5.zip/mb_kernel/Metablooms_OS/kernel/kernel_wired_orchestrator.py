"""
Runtime Orchestrator — Kernel Wired
-------------------------------------
Extends RuntimeOrchestrator to route execution through the MetaBlooms kernel.

Feature flag: USE_KERNEL_EXECUTOR = True
  True  → capability resolution, planning, governance, and execution all
           go through kernel components. Results are stored in ArtifactStore
           and committed via CommitSystem.
  False → falls back to original runtime behavior (legacy path, unchanged).

Legacy impact: replaces direct inline planning/governance/execution in
  runtime_orchestrator_with_write_repair.py. Prior orchestrator had no
  commit trail and no boot gate. Kernel path adds both.

Constraint: kernel path requires state_loader.boot() to succeed before
  any execution. If boot fails, run() returns status='kernel_boot_failed'.

Integration reciprocity:
  - Caller provides a KernelContext (from build_kernel_context()).
  - ASG (AuthoritativeStateGate) is still used for the runtime receipt write
    (the outer envelope). Kernel handles inner artifact commits.
  - graph/dashboard engines remain on ASG writes (derived views, not
    executable artifacts — storing them in ArtifactStore creates a loop).

Schema: MB-ORCHESTRATOR-WIRED-1.0
"""

from __future__ import annotations

import sys
from pathlib import Path

_HERE = Path(__file__).resolve().parent
if str(_HERE) not in sys.path:
    sys.path.insert(0, str(_HERE))

# Kernel path bootstrap
_KERNEL_ROOT = Path(__file__).resolve().parents[2] / "kernel"
_KERNEL_COMP_DIRS = [
    "artifact_store", "commit_system", "state_loader",
    "fingerprint_engine", "phase_registry", "governance_compiler",
    "mpp_executor", "engine_registry", "capability_resolver",
    "ir_registry", "pipeline_planner",
]
for _comp in _KERNEL_COMP_DIRS:
    _p = str(_KERNEL_ROOT / _comp)
    if _p not in sys.path:
        sys.path.insert(0, _p)

_KERNEL_CTX_PATH = str(_KERNEL_ROOT)
if _KERNEL_CTX_PATH not in sys.path:
    sys.path.insert(0, _KERNEL_CTX_PATH)

from deterministic_write_repair import ensure_writable
from authoritative_state_gate import AuthoritativeStateGate
from runtime_orchestrator_with_write_repair import RuntimeOrchestrator, _normalize_result

# Feature flag — flip to False to revert to legacy runtime path
USE_KERNEL_EXECUTOR = True


class KernelWiredOrchestrator:
    """
    Drop-in replacement for RuntimeOrchestrator when USE_KERNEL_EXECUTOR=True.
    Falls back to RuntimeOrchestrator when flag is False.
    """

    def __init__(
        self,
        kernel_context,           # KernelContext from build_kernel_context()
        legacy_orchestrator=None, # RuntimeOrchestrator — used when flag=False
        receipt_root=None,
    ):
        self.kernel = kernel_context
        self.legacy = legacy_orchestrator
        self.receipt_root = Path(receipt_root or (_HERE / "runtime_receipts"))
        self.gate = AuthoritativeStateGate()

    def _write_runtime_receipt(self, payload: dict) -> dict:
        self.receipt_root.mkdir(parents=True, exist_ok=True)
        receipt_file = self.receipt_root / "runtime_orchestrator_receipt.json"
        receipt = self.gate.write_verified_json(
            receipt_file,
            payload,
            schema={"type": "object", "required": ["status", "intent", "write_state"]},
        )
        return {
            "receipt_path": str(receipt_file),
            "receipt_sha256": receipt.sha256,
            "authoritative": receipt.authoritative,
        }

    def run(self, user_input: str) -> dict:
        if not USE_KERNEL_EXECUTOR:
            if self.legacy is None:
                raise RuntimeError(
                    "USE_KERNEL_EXECUTOR=False but no legacy_orchestrator provided."
                )
            return self.legacy.run(user_input)

        return self._kernel_run(user_input)

    def _kernel_run(self, user_input: str) -> dict:
        write_state = ensure_writable()
        kernel = self.kernel

        # --- BOOT GATE ---
        try:
            boot_receipt = kernel.state_loader.boot()
        except Exception as e:
            result = {
                "status": "kernel_boot_error",
                "write_state": write_state,
                "intent": "unknown",
                "detail": str(e),
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        if boot_receipt.boot_status != "BOOT_OK":
            result = {
                "status": "kernel_boot_failed",
                "write_state": write_state,
                "intent": "unknown",
                "boot_violations": boot_receipt.violations,
                "boot_warnings": boot_receipt.warnings,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- CAPABILITY RESOLUTION (kernel command bus via CapabilityResolver) ---
        # For now: direct intent dispatch via IR registry pattern.
        # CapabilityResolver.resolve() requires engine_registry to have engines.
        # We use a simple intent extraction from user_input and build a plan directly.
        intent_type = self._extract_intent(user_input)

        if intent_type == "unknown":
            result = {
                "status": "unknown_intent",
                "write_state": write_state,
                "intent": intent_type,
                "detail": f"No route for input: {repr(user_input)}",
                "session_id": kernel.session_id,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- PIPELINE PLANNING (kernel) ---
        plan = kernel.pipeline_planner.create_plan(
            intent=intent_type,
            requested_phases=["verification"],
            engine_attachments={"verification": [intent_type]},
        )

        if getattr(plan, "phase_order_violations", []):
            result = {
                "status": "plan_error",
                "write_state": write_state,
                "intent": intent_type,
                "violations": plan.phase_order_violations,
                "session_id": kernel.session_id,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- GOVERNANCE (kernel) ---
        gov_result = kernel.governance_compiler.validate(plan)
        if not gov_result.allowed:
            result = {
                "status": "rejected",
                "write_state": write_state,
                "intent": intent_type,
                "violations": gov_result.violations,
                "session_id": kernel.session_id,
            }
            result["verification"] = self._write_runtime_receipt(result)
            return result

        # --- EXECUTION (kernel MPP executor — boot-gated, artifact-storing) ---
        exec_result = kernel.executor.execute(plan, intent_type=intent_type)

        status = "ok"
        if not exec_result.ok:
            status = "partial" if exec_result.failed_engines else "failed"

        result = {
            "status": status,
            "write_state": write_state,
            "intent": intent_type,
            "session_id": kernel.session_id,
            "boot_status": boot_receipt.boot_status,
            "phases_executed": exec_result.phases_executed,
            "results": _normalize_result(exec_result.results),
            "artifact_ids": exec_result.artifact_ids,
            "commit_id": exec_result.commit_id,
            "failed_engines": exec_result.failed_engines,
            "enforcer_violations": exec_result.enforcer_violations,
            "execution_receipt": _normalize_result(exec_result.receipt),
        }
        result["verification"] = self._write_runtime_receipt(result)
        return result

    def _extract_intent(self, user_input: str) -> str:
        """
        Simple keyword-based intent extraction.
        Routes to IRRegistry intents. Returns 'unknown' if no match.
        Constraint: deterministic — same input always produces same intent.
        """
        lowered = user_input.lower()
        # Ordered — first match wins
        _ROUTES = [
            (["egg_juicer", "egg juicer", "run_egg_juicer"], "run_egg_juicer"),
            (["replay", "replay_pack"], "replay_pack"),
            (["dashboard", "status"], "dashboard"),
            (["index", "graph_index"], "graph_index"),
        ]
        for keywords, intent in _ROUTES:
            if any(kw in lowered for kw in keywords):
                return intent
        return "unknown"
