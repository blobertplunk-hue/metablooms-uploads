
from pathlib import Path
import json, importlib.util

ROOT = Path(r"/mnt/data/Metablooms_OS")
GOV = ROOT / "governance"

def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

ENGINE = _load("engine", GOV / "BTS_ENGINE.py")

class PipelineError(RuntimeError):
    pass

def run_pipeline(input_data: dict) -> dict:

    # 0. Objective
    objective = input_data.get("objective")
    if not objective:
        raise PipelineError("Missing objective")

    # 1. Gap analysis
    gap = {
        "requirement": objective.get("target_outcome"),
        "observed": input_data.get("observed", ""),
        "gap_type": "unknown",
        "root_cause": "unspecified"
    }

    # 2. Hypothesis (conditional)
    hypotheses = []
    if input_data.get("ambiguous", False):
        hypotheses = [
            {"id": "H1", "type": "implied", "description": "Likely cause A"},
            {"id": "H2", "type": "implied", "description": "Likely cause B"}
        ]

    # 3. Evaluation
    evaluation = {
        "evidence_strength": input_data.get("evidence_strength", "weak")
    }

    # 4. Decision scaffold
    decision = {
        "objective": objective,
        "see_context": input_data.get("see_context", {"see_required": False, "see_completed": False}),
        "evaluation": evaluation,
        "decision": {
            "epistemic_status": "plausible",
            "implementation_status": "allowed"
        },
        "hypotheses": hypotheses
    }

    # 5. Run governed decision
    return ENGINE.governed_decision(decision)
