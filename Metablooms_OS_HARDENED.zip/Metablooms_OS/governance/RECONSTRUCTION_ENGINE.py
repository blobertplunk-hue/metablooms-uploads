from pathlib import Path
import json, hashlib

ROOT = Path(r"/mnt/data/Metablooms_OS")
SPEC = ROOT / "governance" / "RECONSTRUCTION_SPEC.json"

class ReconstructionError(RuntimeError):
    pass

def _read_json(rel: str):
    p = ROOT / rel
    if not p.exists():
        raise ReconstructionError(f"Missing canonical artifact: {rel}")
    return json.loads(p.read_text(encoding="utf-8"))

def reconstruct_runtime_state():
    spec = json.loads(SPEC.read_text(encoding="utf-8"))
    # fail closed if any canonical artifact missing
    for rel in spec["canonical_artifacts"]:
        if not (ROOT / rel).exists():
            raise ReconstructionError(f"Missing canonical artifact: {rel}")

    boot_header = _read_json("boot/METABLOOMS_BOOT_HEADER.json")
    spine = _read_json("state/RUNTIME_SPINE.json")
    graph = _read_json("state/RUNTIME_GRAPH.json")
    authority = _read_json("state/STAGE_AUTHORITY.json")
    r1 = _read_json("_bts/receipts/R1_BOOT_RECEIPT.json")
    r2 = _read_json("_bts/receipts/R2_SPINE_RECEIPT.json")
    r3 = _read_json("_bts/receipts/R3_GRAPH_RECEIPT.json")
    r4 = _read_json("_bts/receipts/R4_STAGE_AUTHORITY_RECEIPT.json")

    authoritative_stage_ids = [s["stage_id"] for s in authority["stages"]]
    derived = {
        "canonical_root": boot_header["canonical_root"],
        "boot_valid": r1.get("boot_validation", {}).get("boot_valid", False),
        "spine_id": spine["spine_id"],
        "graph_id": graph["graph_id"],
        "authoritative_stage_ids": authoritative_stage_ids,
        "invariants": {
            "boot_fail_closed": bool(boot_header.get("fail_closed", False)),
            "spine_fail_closed": bool(spine["invariants"].get("fail_closed", False)),
            "graph_no_execution_without_boot": bool(graph["invariants"].get("no_execution_without_boot", False)),
            "authority_fail_closed": bool(authority["invariants"].get("fail_closed_on_missing_authority", False)),
        }
    }

    canonical = json.dumps(derived, sort_keys=True, separators=(",", ":"))
    fingerprint = hashlib.sha256(canonical.encode()).hexdigest()
    return {
        "reconstruction_valid": True,
        "derived": derived,
        "fingerprint": fingerprint
    }
