
from pathlib import Path
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")

class RehydrationError(RuntimeError):
    pass

def _read_json(rel):
    p = ROOT / rel
    if not p.exists():
        raise RehydrationError(f"Missing required artifact: {rel}")
    return json.loads(p.read_text(encoding="utf-8"))

def rehydrate_runtime():
    # Load canonical artifacts
    spine = _read_json("state/RUNTIME_SPINE.json")
    graph = _read_json("state/RUNTIME_GRAPH.json")
    authority = _read_json("state/STAGE_AUTHORITY.json")
    reconstruction = _read_json("state/RUNTIME_RECONSTRUCTION_SNAPSHOT.json")

    runtime_context = {
        "spine": spine,
        "graph": graph,
        "authority": authority,
        "reconstruction": reconstruction
    }

    # Basic integrity check
    if not runtime_context["reconstruction"].get("reconstruction_valid", False):
        raise RehydrationError("Reconstruction invalid")

    return {
        "runtime_context": runtime_context,
        "rehydration_complete": True
    }
