from __future__ import annotations

class SEEGateError(RuntimeError):
    pass

def requires_see(decision: dict) -> bool:
    see_context = decision.get("see_context", {})
    return bool(see_context.get("see_required", False))

def enforce_see_gate(decision: dict) -> dict:
    see_context = decision.get("see_context", {})
    required = bool(see_context.get("see_required", False))
    completed = bool(see_context.get("see_completed", False))
    if required and not completed:
        raise SEEGateError("FAIL_CLOSED: SEE required but not completed")
    return {
        "see_required": required,
        "see_completed": completed,
        "gate_result": "pass" if (not required or completed) else "fail"
    }
