
from pathlib import Path
import importlib.util

ROOT = Path(r"/mnt/data/Metablooms_OS")

class BootGateError(RuntimeError):
    pass

def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

def enforce_boot():
    # Load validators
    boot_validator = _load("boot_validator", ROOT / "governance" / "BOOT_VALIDATOR.py")
    canonical_validator = _load("canonical_validator", ROOT / "governance" / "CANONICAL_VALIDATOR.py")
    spine_validator = _load("spine_validator", ROOT / "governance" / "SPINE_VALIDATOR.py")
    graph_validator = _load("graph_validator", ROOT / "governance" / "GRAPH_VALIDATOR.py")
    authority_validator = _load("authority_validator", ROOT / "governance" / "STAGE_AUTHORITY_VALIDATOR.py")

    # Execute validations (fail closed on any error)
    boot = boot_validator.boot_validate()
    canonical = canonical_validator.validate_canonical_index()
    spine = spine_validator.validate_spine()
    graph = graph_validator.validate_runtime_graph()
    authority = authority_validator.validate_stage_authority()

    return {
        "boot": boot,
        "canonical": canonical,
        "spine": spine,
        "graph": graph,
        "authority": authority,
        "boot_gate_passed": True
    }
