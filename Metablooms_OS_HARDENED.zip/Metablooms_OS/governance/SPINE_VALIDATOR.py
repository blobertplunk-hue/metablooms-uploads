from pathlib import Path
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")
SPINE = ROOT / "state" / "RUNTIME_SPINE.json"

class SpineError(RuntimeError):
    pass

def validate_spine():
    if not SPINE.exists():
        raise SpineError("Missing RUNTIME_SPINE.json")

    data = json.loads(SPINE.read_text(encoding="utf-8"))

    required = [
        "spine_id",
        "canonical_root",
        "authoritative_modules",
        "authoritative_schemas",
        "authoritative_state",
        "boot_contract",
        "invariants",
        "timestamp_utc",
    ]
    for f in required:
        if f not in data:
            raise SpineError(f"Missing spine field: {f}")

    if data["canonical_root"] != str(ROOT):
        raise SpineError("canonical_root mismatch")

    if not Path(data["canonical_root"]).exists():
        raise SpineError("canonical_root missing")

    for rel in data["authoritative_modules"]:
        if not (ROOT / rel).exists():
            raise SpineError(f"Missing authoritative module: {rel}")

    for rel in data["authoritative_schemas"]:
        if not (ROOT / rel).exists():
            raise SpineError(f"Missing authoritative schema: {rel}")

    for rel in data["authoritative_state"]:
        if not (ROOT / rel).exists():
            raise SpineError(f"Missing authoritative state path: {rel}")

    if not (ROOT / data["boot_contract"]).exists():
        raise SpineError("boot contract missing")

    inv = data["invariants"]
    if inv.get("fail_closed") is not True:
        raise SpineError("fail_closed invariant must be true")
    if inv.get("artifact_authority") is not True:
        raise SpineError("artifact_authority invariant must be true")
    if inv.get("no_execution_without_spine") is not True:
        raise SpineError("no_execution_without_spine invariant must be true")
    if inv.get("boot_contract_required") is not True:
        raise SpineError("boot_contract_required invariant must be true")

    return {
        "spine_valid": True,
        "modules_verified": len(data["authoritative_modules"]),
        "schemas_verified": len(data["authoritative_schemas"]),
        "state_paths_verified": len(data["authoritative_state"]),
        "spine_id": data["spine_id"],
    }
