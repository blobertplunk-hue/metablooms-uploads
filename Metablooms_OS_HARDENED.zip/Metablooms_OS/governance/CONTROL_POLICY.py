
from pathlib import Path
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")
MEMORY_FILE = ROOT / "learning" / "MISTAKE_LOG.ndjson"
SCHEMA = json.loads((ROOT / "governance" / "MEMORY_SCHEMA.json").read_text())

def _valid(entry):
    if not isinstance(entry, dict): return False
    for f in SCHEMA["required"]:
        if f not in entry: return False
    return True

def _load_memory():
    if not MEMORY_FILE.exists():
        return []
    lines = MEMORY_FILE.read_text().splitlines()
    valid = []
    for l in lines:
        try:
            obj = json.loads(l)
            if _valid(obj):
                valid.append(obj)
        except:
            continue
    return valid

def apply_control_policy(decision: dict) -> dict:
    context = decision.get("objective", {}).get("target_outcome", "")
    memory = _load_memory()

    constraints = []
    for m in memory:
        if context.lower() in m["context"].lower():
            constraints.append(m["constraint"])

    # bound + dedupe
    constraints = list(dict.fromkeys(constraints))[:5]

    decision["control_policy_applied"] = {
        "constraints_injected": constraints,
        "retrieved_cases": len(constraints),
        "guardrails_triggered": []
    }
    return decision
