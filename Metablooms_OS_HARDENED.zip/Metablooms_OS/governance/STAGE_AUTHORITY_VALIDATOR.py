from pathlib import Path
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")
AUTH = ROOT / "state" / "STAGE_AUTHORITY.json"

class StageAuthorityError(RuntimeError):
    pass

def validate_stage_authority():
    if not AUTH.exists():
        raise StageAuthorityError("Missing STAGE_AUTHORITY.json")

    data = json.loads(AUTH.read_text(encoding="utf-8"))
    if "stages" not in data or "invariants" not in data:
        raise StageAuthorityError("Missing top-level fields")

    verified = []
    for stage in data["stages"]:
        required = [
            "stage_id",
            "required_decision_artifact",
            "required_receipt_artifact",
            "required_validator",
            "required_validation_key",
            "authority_rule",
        ]
        for f in required:
            if f not in stage:
                raise StageAuthorityError(f"Stage missing field: {f}")

        dpath = ROOT / stage["required_decision_artifact"]
        rpath = ROOT / stage["required_receipt_artifact"]
        vpath = ROOT / stage["required_validator"]
        if not dpath.exists():
            raise StageAuthorityError(f"Missing decision artifact: {dpath}")
        if not rpath.exists():
            raise StageAuthorityError(f"Missing receipt artifact: {rpath}")
        if not vpath.exists():
            raise StageAuthorityError(f"Missing validator: {vpath}")

        receipt = json.loads(rpath.read_text(encoding="utf-8"))
        key = stage["required_validation_key"]

        if stage["stage_id"] == "R1_BOOT_CONTRACT":
            ok = receipt.get("boot_validation", {}).get(key) is True
        elif stage["stage_id"] == "R2_RUNTIME_SPINE":
            ok = receipt.get("spine_validation", {}).get(key) is True
        elif stage["stage_id"] == "R3_RUNTIME_GRAPH":
            ok = receipt.get("graph_validation", {}).get(key) is True
        else:
            raise StageAuthorityError("Unknown stage_id in authority validator")

        if not ok:
            raise StageAuthorityError(f"Authority failed for stage {stage['stage_id']}")

        verified.append(stage["stage_id"])

    inv = data["invariants"]
    if inv.get("no_stage_claim_without_receipt") is not True:
        raise StageAuthorityError("receipt invariant must be true")
    if inv.get("no_stage_claim_without_decision") is not True:
        raise StageAuthorityError("decision invariant must be true")
    if inv.get("no_stage_claim_without_validator") is not True:
        raise StageAuthorityError("validator invariant must be true")
    if inv.get("fail_closed_on_missing_authority") is not True:
        raise StageAuthorityError("fail_closed invariant must be true")

    return {
        "stage_authority_valid": True,
        "stages_verified": verified
    }
