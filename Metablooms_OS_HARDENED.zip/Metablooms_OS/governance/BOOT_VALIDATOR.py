
from pathlib import Path
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")
BOOT = ROOT / "boot" / "METABLOOMS_BOOT_HEADER.json"
SPEC = ROOT / "boot" / "BOOT_HEADER_SPEC.json"

class BootError(RuntimeError):
    pass

def boot_validate():
    if not BOOT.exists():
        raise BootError("Missing BOOT_HEADER")

    header = json.loads(BOOT.read_text())
    spec = json.loads(SPEC.read_text())

    # required fields
    for f in spec["required_fields"]:
        if f not in header:
            raise BootError(f"Missing field: {f}")

    # canonical root
    if not Path(header["canonical_root"]).exists():
        raise BootError("Canonical root missing")

    # required paths
    for p in header["boot_required_paths"]:
        if not (ROOT / p).exists():
            raise BootError(f"Missing required path: {p}")

    return {
        "boot_valid": True,
        "paths_verified": len(header["boot_required_paths"])
    }
