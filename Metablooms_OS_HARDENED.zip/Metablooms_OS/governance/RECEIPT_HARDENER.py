
from pathlib import Path
import json, hashlib
from datetime import datetime, timezone

ROOT = Path(r"/mnt/data/Metablooms_OS")

class ReceiptError(RuntimeError):
    pass

def _hash_file(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def generate_hardened_receipt(stage_name, input_payload):
    receipts_dir = ROOT / "_bts" / "receipts"

    # previous receipt (chain)
    existing = sorted(receipts_dir.glob("*.json"))
    prev_hash = None
    if existing:
        last = existing[-1]
        prev_hash = _hash_file(last)

    # canonical artifacts
    artifacts = [
        "state/RUNTIME_SPINE.json",
        "state/RUNTIME_GRAPH.json",
        "state/STAGE_AUTHORITY.json",
        "state/RUNTIME_RECONSTRUCTION_SNAPSHOT.json"
    ]

    artifact_hashes = {}
    for rel in artifacts:
        p = ROOT / rel
        if not p.exists():
            raise ReceiptError(f"Missing artifact: {rel}")
        artifact_hashes[rel] = _hash_file(p)

    # canonical payload
    payload = {
        "stage": stage_name,
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "input_hash": hashlib.sha256(json.dumps(input_payload, sort_keys=True).encode()).hexdigest(),
        "artifact_hashes": artifact_hashes,
        "previous_receipt_hash": prev_hash
    }

    payload_str = json.dumps(payload, sort_keys=True)
    payload_hash = hashlib.sha256(payload_str.encode()).hexdigest()

    payload["receipt_hash"] = payload_hash

    # write receipt
    fname = f"HARDENED_{stage_name}_RECEIPT.json"
    out = receipts_dir / fname
    out.write_text(json.dumps(payload, indent=2))

    return {
        "receipt_created": True,
        "receipt_hash": payload_hash,
        "chained": prev_hash is not None
    }
