from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")
SCHEMA_PATH = ROOT / "governance" / "SEE_SCHEMA.json"

class SEEValidationError(ValueError):
    pass

def _load_schema():
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))

def _validate_sources(sources, schema):
    if not isinstance(sources, list) or not sources:
        raise SEEValidationError("sources must be a non-empty list")
    required = set(schema["source_required_fields"])
    allowed_conf = set(schema["allowed_source_confidence"])
    for idx, src in enumerate(sources):
        if not isinstance(src, dict):
            raise SEEValidationError(f"source[{idx}] must be an object")
        missing = sorted(required - set(src.keys()))
        if missing:
            raise SEEValidationError(f"source[{idx}] missing fields: {missing}")
        if src["confidence"] not in allowed_conf:
            raise SEEValidationError(f"source[{idx}].confidence invalid")
        if not str(src["url"]).strip():
            raise SEEValidationError(f"source[{idx}].url empty")

def _validate_claims(claims, schema):
    if not isinstance(claims, list) or not claims:
        raise SEEValidationError("claims must be a non-empty list")
    required = set(schema["claim_required_fields"])
    allowed_status = set(schema["allowed_claim_statuses"])
    for idx, claim in enumerate(claims):
        if not isinstance(claim, dict):
            raise SEEValidationError(f"claim[{idx}] must be an object")
        missing = sorted(required - set(claim.keys()))
        if missing:
            raise SEEValidationError(f"claim[{idx}] missing fields: {missing}")
        if claim["status"] not in allowed_status:
            raise SEEValidationError(f"claim[{idx}].status invalid")
        if not isinstance(claim["sources"], list) or not claim["sources"]:
            raise SEEValidationError(f"claim[{idx}].sources must be non-empty list")

def validate_see_payload(topic, sources, claims):
    schema = _load_schema()
    if not isinstance(topic, str) or not topic.strip():
        raise SEEValidationError("topic must be a non-empty string")
    _validate_sources(sources, schema)
    _validate_claims(claims, schema)
    return True

def write_see_artifact(topic, sources, claims):
    validate_see_payload(topic, sources, claims)
    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    see_id = f"SEE-{hashlib.sha256((topic + ts).encode()).hexdigest()[:8]}_{ts}"
    path = ROOT / "_bts" / "see" / f"{see_id}.json"
    data = {
        "see_run_id": see_id,
        "topic": topic,
        "sources": sources,
        "claims": claims,
        "timestamp_utc": datetime.now(timezone.utc).isoformat()
    }
    canonical = json.dumps(data, indent=2, sort_keys=True)
    data["artifact_sha256"] = hashlib.sha256(canonical.encode()).hexdigest()
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return see_id, str(path), data["artifact_sha256"]
