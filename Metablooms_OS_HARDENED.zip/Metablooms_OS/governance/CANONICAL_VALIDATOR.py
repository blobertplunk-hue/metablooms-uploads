from pathlib import Path
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")
INDEX = ROOT / "state" / "CANONICAL_INDEX.json"

class CanonicalError(RuntimeError):
    pass

def validate_canonical_index():
    if not INDEX.exists():
        raise CanonicalError("Missing CANONICAL_INDEX.json")
    data = json.loads(INDEX.read_text(encoding="utf-8"))

    # required keys
    for k in ["canonical_root","canonical_paths","entrypoint","invariants","timestamp_utc"]:
        if k not in data:
            raise CanonicalError(f"Missing field: {k}")

    if data["canonical_root"] != str(ROOT):
        raise CanonicalError("canonical_root mismatch")

    # check canonical paths exist
    for _, rel in data["canonical_paths"].items():
        p = ROOT / rel
        if not p.exists():
            raise CanonicalError(f"Missing canonical path: {rel}")

    inv = data["invariants"]
    if inv.get("single_canonical_reading_path") is not True:
        raise CanonicalError("Invariant single_canonical_reading_path must be true")
    if inv.get("no_execution_without_canonical_index") is not True:
        raise CanonicalError("Invariant no_execution_without_canonical_index must be true")

    return {
        "canonical_valid": True,
        "paths_verified": len(data["canonical_paths"])
    }
