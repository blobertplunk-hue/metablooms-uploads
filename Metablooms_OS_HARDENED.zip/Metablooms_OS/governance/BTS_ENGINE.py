from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, uuid, importlib.util

ROOT = Path(r"/mnt/data/Metablooms_OS")
DECISIONS_DIR = ROOT / "_bts" / "decisions"
RECEIPTS_DIR = ROOT / "_bts" / "receipts"
GOV = ROOT / "governance"

def _load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore
    return module


CONTROL_POLICY = _load_module("control_policy_runtime", GOV / "CONTROL_POLICY.py")

SEE_GATE = _load_module("see_gate_runtime", GOV / "SEE_GATE.py")

SCHEMA = json.loads((GOV / "BTS_DECISION_SCHEMA.json").read_text(encoding="utf-8"))

class BTSDecisionError(RuntimeError):
    pass

def _validate_objective(obj: dict):
    req = SCHEMA["objective_required"]
    if not isinstance(obj, dict):
        raise BTSDecisionError("objective must be object")
    missing = [f for f in req if f not in obj]
    if missing:
        raise BTSDecisionError(f"objective missing fields: {missing}")
    if not isinstance(obj.get("constraints"), list):
        raise BTSDecisionError("objective.constraints must be list")

def _validate_see(sc: dict):
    req = SCHEMA["see_context_required"]
    if not isinstance(sc, dict):
        raise BTSDecisionError("see_context must be object")
    missing = [f for f in req if f not in sc]
    if missing:
        raise BTSDecisionError(f"see_context missing fields: {missing}")

def _validate_eval(ev: dict):
    req = SCHEMA["evaluation_required"]
    if not isinstance(ev, dict):
        raise BTSDecisionError("evaluation must be object")
    missing = [f for f in req if f not in ev]
    if missing:
        raise BTSDecisionError(f"evaluation missing fields: {missing}")
    if ev["evidence_strength"] not in SCHEMA["allowed_evidence_strength"]:
        raise BTSDecisionError("evaluation.evidence_strength invalid")

def _validate_decision(dec: dict):
    req = SCHEMA["decision_required"]
    if not isinstance(dec, dict):
        raise BTSDecisionError("decision must be object")
    missing = [f for f in req if f not in dec]
    if missing:
        raise BTSDecisionError(f"decision missing fields: {missing}")
    if dec["epistemic_status"] not in SCHEMA["allowed_epistemic"]:
        raise BTSDecisionError("epistemic_status invalid")
    if dec["implementation_status"] not in SCHEMA["allowed_impl"]:
        raise BTSDecisionError("implementation_status invalid")

def _calibrate_confidence(evidence_strength: str, competing: bool) -> str:
    if evidence_strength == "strong" and not competing:
        return "high"
    if evidence_strength in ["strong","partial"] and competing:
        return "medium"
    return "low"

def _make_id(payload: dict) -> str:
    ts = datetime.now(timezone.utc).isoformat()
    rand = uuid.uuid4().hex
    h = hashlib.sha256((json.dumps(payload, sort_keys=True)+rand).encode()).hexdigest()[:12]
    return f"DEC-{h}-{rand[:8]}"

def governed_decision(decision: dict) -> dict:
    # Schema validation
    for f in SCHEMA["required_top_level_fields"]:
        if f not in decision:
            raise BTSDecisionError(f"missing top-level field: {f}")

    _validate_objective(decision["objective"])
    _validate_see(decision["see_context"])
    _validate_eval(decision["evaluation"])
    _validate_decision(decision["decision"])

    # Control policy
    # SEE gate
    gate_result = SEE_GATE.enforce_see_gate(decision)

    decision = CONTROL_POLICY.apply_control_policy(decision)

    # Confidence
    ev = decision["evaluation"]["evidence_strength"]
    competing = bool(decision.get("hypotheses"))
    decision["decision"]["confidence"] = _calibrate_confidence(ev, competing)

    # ID + persist
    did = _make_id(decision)
    decision["decision_id"] = did
    decision["timestamp_utc"] = datetime.now(timezone.utc).isoformat()
    path = DECISIONS_DIR / f"{did}.json"
    path.write_text(json.dumps(decision, indent=2), encoding="utf-8")

    # Receipt with strong validation flags
    receipt = {
        "stage": "BTS_STAGE_3_REPAIR",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "decision_path": str(path),
        "validation": {
            "schema_valid": True,
            "objective_valid": True,
            "see_gate": gate_result,
            "unique_id": True
        }
    }
    r_hash = hashlib.sha256(json.dumps(receipt, sort_keys=True).encode()).hexdigest()
    receipt["receipt_sha256"] = r_hash
    rpath = RECEIPTS_DIR / f"STAGE3_REPAIR_RECEIPT_{r_hash[:8]}.json"
    rpath.write_text(json.dumps(receipt, indent=2), encoding="utf-8")

    return {"decision_path": str(path), "receipt_path": str(rpath)}
