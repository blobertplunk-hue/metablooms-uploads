from pathlib import Path
import json
import importlib.util

ROOT = Path(r"/mnt/data/Metablooms_OS")
ENGINE = ROOT / "governance" / "RECONSTRUCTION_ENGINE.py"

class ReconstructionValidationError(RuntimeError):
    pass

def _load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, str(path))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)  # type: ignore
    return mod

def validate_reconstruction():
    engine = _load_module("reconstruction_engine_runtime", ENGINE)
    first = engine.reconstruct_runtime_state()
    second = engine.reconstruct_runtime_state()

    if first["reconstruction_valid"] is not True or second["reconstruction_valid"] is not True:
        raise ReconstructionValidationError("reconstruction_valid false")
    if first["fingerprint"] != second["fingerprint"]:
        raise ReconstructionValidationError("Non-deterministic reconstruction fingerprint")

    return {
        "reconstruction_valid": True,
        "fingerprint": first["fingerprint"],
        "repeatable": True
    }
