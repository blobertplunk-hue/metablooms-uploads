from pathlib import Path
import json

ROOT = Path(r"/mnt/data/Metablooms_OS")
GRAPH = ROOT / "state" / "RUNTIME_GRAPH.json"

class GraphError(RuntimeError):
    pass

def validate_runtime_graph():
    if not GRAPH.exists():
        raise GraphError("Missing RUNTIME_GRAPH.json")

    data = json.loads(GRAPH.read_text(encoding="utf-8"))
    required = ["graph_id", "canonical_root", "nodes", "edges", "invariants", "timestamp_utc"]
    for f in required:
        if f not in data:
            raise GraphError(f"Missing graph field: {f}")

    if data["canonical_root"] != str(ROOT):
        raise GraphError("canonical_root mismatch")

    node_ids = set()
    for node in data["nodes"]:
        if "id" not in node or "path" not in node or "type" not in node:
            raise GraphError("Node missing required fields")
        node_ids.add(node["id"])
        if not (ROOT / node["path"]).exists():
            raise GraphError(f"Graph node path missing: {node['path']}")

    for edge in data["edges"]:
        if "from" not in edge or "to" not in edge or "kind" not in edge:
            raise GraphError("Edge missing required fields")
        if edge["from"] not in node_ids or edge["to"] not in node_ids:
            raise GraphError("Edge references unknown node")

    inv = data["invariants"]
    if inv.get("all_edges_must_reference_existing_nodes") is not True:
        raise GraphError("Edge-reference invariant must be true")
    if inv.get("no_execution_without_boot") is not True:
        raise GraphError("no_execution_without_boot invariant must be true")
    if inv.get("no_execution_without_spine") is not True:
        raise GraphError("no_execution_without_spine invariant must be true")

    return {
        "graph_valid": True,
        "nodes_verified": len(data["nodes"]),
        "edges_verified": len(data["edges"]),
        "graph_id": data["graph_id"]
    }
