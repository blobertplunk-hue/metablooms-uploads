"""
PatchBuilder — Evolution Engine sub-module
-------------------------------------------
Authority: Runtime extension layer. Sub-module of evolution_engine.
Schema:    MB-PATCH-BUILDER-1.0

Purpose:
    Converts ImprovementProposals from reflector_engine reflection reports
    into structured PatchCandidate objects. Each candidate describes a
    single governed change to the MetaBlooms runtime or kernel configuration.

    The builder does NOT apply patches. It produces data artifacts describing
    what should change, why, and what validation is required.

Patch types supported:
    engine_registration    — register a missing engine in engine_map
    governance_rule_update — adjust a governance rule threshold or condition
    freeze_regeneration    — flag that freeze artifact needs regeneration
    topology_correction    — flag a sequence deviation for human review
    config_update          — update a runtime configuration value
    no_action              — proposal acknowledged, no patch needed (INFO severity)

Constraint:
    Patches for kernel_frozen components always set requires_human_approval=True
    and freeze_required=True. No automated path exists to modify frozen components.

Legacy impact:
    Previously there was no structured path from reflection findings to proposed
    changes. Improvements were implicit (human reads logs, manually changes code).
    PatchBuilder makes that path explicit, typed, and governed.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


SCHEMA = "MB-PATCH-BUILDER-1.0"

# Frozen component names — patches targeting these always require human approval
FROZEN_COMPONENTS = {
    "artifact_store", "commit_system", "state_loader", "fingerprint_engine",
    "phase_registry", "ir_registry", "pipeline_planner", "pipeline_determinism_guard",
    "governance_compiler", "mpp_executor", "engine_registry", "capability_resolver",
    "kernel_context", "validation_runner",
}

# Patch types
PATCH_TYPE_ENGINE_REGISTRATION    = "engine_registration"
PATCH_TYPE_GOVERNANCE_RULE_UPDATE = "governance_rule_update"
PATCH_TYPE_FREEZE_REGENERATION    = "freeze_regeneration"
PATCH_TYPE_TOPOLOGY_CORRECTION    = "topology_correction"
PATCH_TYPE_CONFIG_UPDATE          = "config_update"
PATCH_TYPE_NO_ACTION              = "no_action"


@dataclass
class PatchCandidate:
    patch_id: str
    source_reflection_run_id: str
    source_proposal_id: str
    patch_type: str
    target_component: str
    severity: str
    observation: str
    proposed_change: dict          # typed payload specific to patch_type
    validation_required: bool
    freeze_required: bool
    requires_human_approval: bool
    evidence: list
    status: str = "CANDIDATE"      # CANDIDATE | VALIDATED | REJECTED | APPLIED (by human)
    validation_result: Optional[str] = None
    validation_detail: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "patch_id": self.patch_id,
            "source_reflection_run_id": self.source_reflection_run_id,
            "source_proposal_id": self.source_proposal_id,
            "patch_type": self.patch_type,
            "target_component": self.target_component,
            "severity": self.severity,
            "observation": self.observation,
            "proposed_change": self.proposed_change,
            "validation_required": self.validation_required,
            "freeze_required": self.freeze_required,
            "requires_human_approval": self.requires_human_approval,
            "evidence": self.evidence,
            "status": self.status,
            "validation_result": self.validation_result,
            "validation_detail": self.validation_detail,
        }


class PatchBuilder:
    """
    Converts a list of ImprovementProposal dicts into PatchCandidate objects.
    Each proposal maps to exactly one candidate (1:1 mapping).
    Proposals that don't map to a known patch type produce PATCH_TYPE_NO_ACTION.
    """

    def build(
        self,
        proposals: list[dict],
        reflection_run_id: str,
    ) -> list[PatchCandidate]:
        candidates = []
        for proposal in proposals:
            candidate = self._build_one(proposal, reflection_run_id)
            candidates.append(candidate)
        return candidates

    def _build_one(
        self, proposal: dict, reflection_run_id: str
    ) -> PatchCandidate:
        proposal_id = proposal.get("proposal_id", "UNKNOWN")
        target = proposal.get("target_component", "unknown")
        severity = proposal.get("severity", "INFO")
        observation = proposal.get("observation", "")
        evidence = proposal.get("evidence", [])
        category = proposal.get("category", "")

        # Route to patch type by pattern matching on proposal content
        patch_type, proposed_change, validation_required, freeze_required = \
            self._classify(proposal)

        # Frozen component → always requires human approval
        requires_human = (
            target in FROZEN_COMPONENTS
            or freeze_required
            or severity in ("CRITICAL", "HIGH")
        )

        return PatchCandidate(
            patch_id=f"PATCH-{proposal_id[:20]}-{reflection_run_id[:8]}",
            source_reflection_run_id=reflection_run_id,
            source_proposal_id=proposal_id,
            patch_type=patch_type,
            target_component=target,
            severity=severity,
            observation=observation,
            proposed_change=proposed_change,
            validation_required=validation_required,
            freeze_required=freeze_required,
            requires_human_approval=requires_human,
            evidence=evidence,
        )

    def _classify(
        self, proposal: dict
    ) -> tuple[str, dict, bool, bool]:
        """
        Returns (patch_type, proposed_change_dict, validation_required, freeze_required).
        """
        observation = proposal.get("observation", "").lower()
        proposed_action = proposal.get("proposed_action", "").lower()
        target = proposal.get("target_component", "")
        category = proposal.get("category", "")
        severity = proposal.get("severity", "INFO")

        # Engine registration
        if (("not registered" in observation or "engine_map" in observation
             or "register" in proposed_action or "engine_map" in proposed_action
             or "no execution artifacts" in observation)
                and category in ("execution",)):
            # Extract engine name from evidence (failed_engines field) or proposal_id
            engine_name = "unknown"
            intent_hint = ""
            for ev in proposal.get("evidence", []):
                ev_str = str(ev)
                if "failed_engines=" in ev_str:
                    # parse ['run_egg_juicer'] style
                    import re
                    match = re.search(r"\['([^']+)'\]", ev_str)
                    if match:
                        engine_name = match.group(1)
                if "intent=" in ev_str:
                    intent_hint = ev_str.replace("intent=", "")
            # If we still don't have an engine name from evidence, use target only
            # if it's not a kernel component
            if engine_name == "unknown" and target not in FROZEN_COMPONENTS:
                engine_name = target
            return (
                PATCH_TYPE_ENGINE_REGISTRATION,
                {
                    "engine": engine_name,
                    "intent": intent_hint or engine_name,
                    "registration_site": "build_kernel_context(engine_map={...})",
                    "note": "Caller must provide a callable that matches the engine's contract.",
                },
                True,   # validation_required
                False,  # freeze_required
            )

        # Governance rule update
        if (category == "governance" and "violation" in observation
                and "threshold" in proposed_action or "rule" in proposed_action):
            return (
                PATCH_TYPE_GOVERNANCE_RULE_UPDATE,
                {
                    "target_rule": "unspecified — inspect governance_compiler for rule set",
                    "direction": "unknown — review violation context",
                    "note": "Manual review of governance_compiler rules required.",
                },
                True,   # validation_required
                True,   # freeze_required — governance changes affect architecture
            )

        # Freeze regeneration
        if ("freeze" in observation or "frozen" in observation
                or target in ("kernel_adoption_freeze", "kernel_wired_orchestrator")
                and "freeze" in proposed_action):
            return (
                PATCH_TYPE_FREEZE_REGENERATION,
                {
                    "trigger": observation[:120],
                    "action": "Re-run kernel_adoption_freeze.py generate after confirming all components are correct.",
                    "note": "Freeze regeneration requires human review of all changed components.",
                },
                True,   # validation_required
                True,   # freeze_required
            )

        # Topology correction
        if category == "topology" or "sequence" in observation or "topology" in observation:
            return (
                PATCH_TYPE_TOPOLOGY_CORRECTION,
                {
                    "observed_issue": observation[:120],
                    "action": "Review canonical call sequence in kernel_wired_orchestrator.py.",
                    "note": "Topology changes may require freeze regeneration.",
                },
                True,   # validation_required
                True,   # freeze_required
            )

        # INFO severity — no action needed, just acknowledgement
        if severity == "INFO":
            return (
                PATCH_TYPE_NO_ACTION,
                {"note": "Informational finding. No patch required."},
                False,
                False,
            )

        # Default — config update or general observation
        return (
            PATCH_TYPE_CONFIG_UPDATE,
            {
                "target": target,
                "observation": observation[:120],
                "action": proposal.get("proposed_action", "")[:120],
                "note": "Manual review required.",
            },
            True,
            False,
        )
