# BTS Decision Model

For every meaningful decision, record:
- decision id
- objective
- options considered
- pros / cons
- selected option
- rationale
- artifact evidence used
- receipt path

Granularize to the smallest meaningful decision.
Do not collapse multiple unrelated decisions into one record.
