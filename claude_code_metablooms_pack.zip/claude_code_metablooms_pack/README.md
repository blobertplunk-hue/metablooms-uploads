# MetaBlooms Claude Code Prompt Pack

This pack is a governed execution scaffold for repairing and hardening MetaBlooms OS in Claude Code.

## Intended use

1. Put this folder at the repo root or copy the files into your repo.
2. Keep `CLAUDE.md` at the repo root.
3. Start with `prompts/00_MASTER_INSTRUCTION.md`.
4. Run one stage at a time.
5. Require receipts after every stage.
6. Fail closed on missing artifacts or contradictory evidence.

## Stage order

1. PRE_BOOT_DISCOVERY
2. BOOT
3. RUNTIME_GROUNDING
4. REGISTRY_VALIDATE
5. REGISTRY_REPAIR
6. VALIDATORS
7. VALIDATION_GATE
8. DEBUG_LOOP
9. EXPORT_VALIDATION
10. EXPORT

## Hard rules

- No assumption without file read
- No mutation without receipt
- No claim of success without artifact evidence
- No skipping stages
- No silent fallback
