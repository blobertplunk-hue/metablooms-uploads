# Stage 8 — DEBUG_LOOP

## Goal
Repair only the exact failing layer, then rerun validation.

## Rules
- Diagnose from receipts and console output only
- Repair the smallest valid layer
- Rerun validators after repair
- Stop with either:
  - all receipts present
  - or fail-closed with the next exact failure point

## Forbidden
- broad rebuilds
- silent rewrites
- changing unrelated layers
