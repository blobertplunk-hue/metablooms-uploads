# Stage 1 — PRE_BOOT_DISCOVERY

## Goal
Resolve the canonical root from the provided bundle or working tree.

## Required actions
1. Enumerate bundle contents or repo tree.
2. Find the directory containing `BOOT_INDEX.json`.
3. If multiple candidates exist, fail closed.
4. If nested root exists, descend into the actual canonical root.
5. Write `PRE_BOOT_RECEIPT.json`.

## Output
- canonical root path
- file count
- root resolution evidence
- fail-closed if no valid root found
