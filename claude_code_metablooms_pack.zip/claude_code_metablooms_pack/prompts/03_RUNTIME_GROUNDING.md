# Stage 3 — RUNTIME_GROUNDING

## Goal
Load runtime truth without mutation.

## Required reads
- METABLOOMS_ROUTING_DICTIONARY.json if present
- START_HERE_METABLOOMS.md if present
- OMNISCIENCE_KERNEL.md if present
- RUNTIME_SPINE.json
- RUNTIME_GRAPH.json
- ENGINE_REGISTRY.json

## Must report
- active protocol
- entrypoints
- engine count or schema shape
- graph edge count
- spine layers / keys
- receipt path

Do not repair anything in this stage.
