# Stage 6 — VALIDATORS

## Build or run this minimal enforcement set
1. ENGINE_EXISTENCE_VALIDATOR
2. ENGINE_LOAD_VALIDATOR
3. GRAPH_TOPOLOGY_VALIDATOR

## Ordering (mandatory)
ENGINE_EXISTENCE -> ENGINE_LOAD -> GRAPH_TOPOLOGY

## Receipt rule
Each validator writes its own receipt:
- ENGINE_EXISTENCE_RECEIPT.json
- ENGINE_LOAD_RECEIPT.json
- GRAPH_TOPOLOGY_RECEIPT.json

If any validator crashes before writing, return a fail-closed report with:
- exact failure point
- exception type
- message
- missing receipts
