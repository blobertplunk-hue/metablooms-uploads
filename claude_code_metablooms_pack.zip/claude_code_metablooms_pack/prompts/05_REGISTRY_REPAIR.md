# Stage 5 — REGISTRY_REPAIR

## Trigger
Only run if REGISTRY_VALIDATE failed.

## Rules
- Repair from artifact evidence only
- Derive pointers only from actual files in the bundle/repo
- Do not invent engines not supported by artifacts
- Mark the registry as reconstructed if reconstructed
- Preserve unresolved engines explicitly if any remain

## Required output
- repaired ENGINE_REGISTRY.json
- REGISTRY_REPAIR_RECEIPT.json
- unresolved engines list
