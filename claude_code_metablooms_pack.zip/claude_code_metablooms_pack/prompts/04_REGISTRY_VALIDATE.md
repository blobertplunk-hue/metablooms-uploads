# Stage 4 — REGISTRY_VALIDATE

## Goal
Determine whether ENGINE_REGISTRY.json is authoritative and usable.

## Checks
- file exists
- schema shape is valid
- engines field is present
- engines entries are objects with id/pointer/exists OR explicitly recognized alternate schema
- no self-referential pointer
- no null target
- no unresolved canonical_path loop

## Output
- status PASS/FAIL
- exact schema shape
- exact failure class if invalid
- receipt path
