# Stage 2 — BOOT

## Goal
Verify minimum required boot artifacts at the resolved canonical root.

## Required artifacts
- BOOT_INDEX.json
- ENGINE_REGISTRY.json
- RUNTIME_GRAPH.json
- RUNTIME_SPINE.json
- boot/METABLOOMS_BOOT_HEADER.txt
- boot/BOOT_HEADER_SPEC.json

## Rules
- Read files directly
- Do not infer missing artifacts
- Write `BOOT_RECEIPT.json`
- Stop after boot
