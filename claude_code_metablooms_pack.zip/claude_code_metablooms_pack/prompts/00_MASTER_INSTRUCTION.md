# Master Instruction

Execute MetaBlooms OS repair under strict artifact-governed control.

Follow exactly this stage order:

PRE_BOOT_DISCOVERY -> BOOT -> RUNTIME_GROUNDING -> REGISTRY_VALIDATE -> REGISTRY_REPAIR (if needed) -> VALIDATORS -> VALIDATION_GATE -> DEBUG_LOOP (if needed) -> EXPORT_VALIDATION -> EXPORT

Global constraints:
- No assumption without file read
- No mutation without receipt
- Fail closed on any missing critical artifact
- One stage at a time
- Return artifact paths, receipts, and exact failure points
- Do not summarize success without receipts
- Do not continue after a failed stage unless the next stage is explicitly a repair/debug stage

When a stage completes, return:
1. stage result
2. receipt path
3. exact next valid stage
