# Stage 9 — EXPORT_VALIDATION

## Goal
Validate the bundle before export.

## Required checks
- single-root structure
- no self-referential pointers
- critical root artifacts present
- canonical state artifacts present
- manifest can be generated deterministically
- receipt directory exists

## Fail closed on
- missing critical artifacts
- ambiguous root
- invalid pointers
- split authority paths
