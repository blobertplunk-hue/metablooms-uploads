# Stage 7 — VALIDATION_GATE

## Goal
Aggregate validator results and enforce fail-closed behavior.

## Rules
- Load all three validator receipts
- If any receipt missing, fail closed
- If any status FAIL, fail closed
- Write VALIDATION_GATE_RECEIPT.json
- No continuation on failure unless explicitly entering DEBUG_LOOP
