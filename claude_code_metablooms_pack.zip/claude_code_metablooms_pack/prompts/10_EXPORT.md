# Stage 10 — EXPORT

## Goal
Produce one deterministic, single-root bundle.

## Requirements
- root folder in zip must be exactly `Metablooms_OS/`
- include MANIFEST.json
- include all stage receipts
- include deterministic file ordering
- include export receipt with hashes

## Output
- final zip path
- EXPORT_RECEIPT.json
- exact file count
